import React, { Component } from 'react'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { BrowserRouter, Switch, Route } from 'react-router-dom'

import './styles/index.scss'

import MainRouter from './MainRouter'
import Login from './pages/Login'
import Signup from './pages/Signup'
import SignupComplete from './pages/Signup/SignupComplete'
import ForgotPassword from './pages/ForgotPassword'
import ResetPassword from './pages/ResetPassword'

class App extends Component {
  render() {
    return (
      <BrowserRouter basename={process.env.PUBLIC_URL} >
        <Switch>
          <Route
            path='/login'
            component={Login}
          />
          <Route
            path='/signup'
            component={Signup}
          />
          <Route
            path='/signup-complete'
            component={SignupComplete}
          />
          <Route
            path='/forgot-password'
            component={ForgotPassword}
          />
          <Route
            path='/change-password'
            component={ResetPassword}
          />
          <Route path="/" component={MainRouter} />
        </Switch>
      </BrowserRouter>
    )
  }
}

function mapStateToProps(state) {
  return state
}

function mapDispatchToProps(dispatch) {
  return bindActionCreators({}, dispatch)
}

export default connect(mapStateToProps, mapDispatchToProps)(App)