import { campaignTypeMap } from '../utils/defaultValues'

const removeSpecialChar = (value) => {
  if (!value) {
    return 0
  }
  const valueStr = value.toString()
  return valueStr.replace(/[$,%]/g, '')
}

// Assuming that we allow 2 numbers at most after a decimal point,
// we don't check if we place commas after a decimal point.
// By assuming so, we don't need to use `negative lookbehind` regex
// which is not supported on Safari.
export const formatValue = (value, type, decimals = 2, currencySign = '$') => {
  const valueFixed = parseFloat(removeSpecialChar(value) || 0).toFixed(decimals)
  switch (type) {
    case 'currency':
      return currencySign + valueFixed.replace(/\B(?=(\d{3})+(?!\d))/g, ',')
    case 'percent':
      return valueFixed + '%'
    case 'number':
      return valueFixed.replace(/\B(?=(\d{3})+(?!\d))/g, ',')
    case 'removeZeroDecimal':
      return parseFloat(valueFixed).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')
    default:
      return valueFixed
  }
}

export const formatCurrency = (value, currencySign, currencyRate, decimals = 2) => (
  formatValue(value * currencyRate, 'currency', decimals, currencySign)
)

export const parseMoneyAsFloat = (value, currency_sign) => {
  if (!value) {
    return 0
  }
  const valueStr = value.toString()
  return parseFloat(valueStr.replace(new RegExp(`[$,%${currency_sign}]`, 'g'), ''))
}

export const checkSpecialCharater = (str) => {
  const regexp = /[`ģń~!@#$%^*()_|=?;:",<>{}[]\\\/]/gi
  return str.match(regexp)
}

export const capitalizeFirstLetter = (string) => {
  if (!string || string === '') {
    return ''
  }
  const [firstLetter, ...restLetters] = string.toLowerCase()
  return firstLetter.toUpperCase() + restLetters.join('')
}

// get the trend line's start and end point of the chart
export const getTrendLinePoint = (x, slope, intercept) => {
  return {x: x, y: ((slope * x) + intercept)}
}

export const calculateTrendLines = (data) => {
  if (!data || data.length === 0) {
    return [0, 0]
  }
  let xSum = 0
  let ySum = 0
  let xySum = 0
  let xSquare = 0
  const dpsLength = data.length
  for(let i = 0; i < dpsLength; i++) {
    xySum += (i * data[i].value)
  }
  const a = xySum * dpsLength

  for(let i = 0; i < dpsLength; i++){
    xSum += i
    ySum += data[i].value
  }
  const b = xSum * ySum

  for(let i = 0; i < dpsLength; i++) {
    xSquare += Math.pow(i, 2)
  }
  const c = dpsLength * xSquare

  const d = Math.pow(xSum, 2)
  const slope = (a-b)/(c-d)
  const e = slope * xSum
  const yIntercept = (ySum - e) / dpsLength

  const startPoint = getTrendLinePoint(0, slope, yIntercept)
  const endPoint = getTrendLinePoint(dpsLength - 1, slope, yIntercept)
  return [startPoint, endPoint]
}

// Default smart pilot settings.
export const apSettings = {
  // Ad group selection.
  adgroup_id: { default: 0, type: 'int' },
  day_used_auto_pilot: { default: 30 },
  pt_day_used_auto_pilot: { default: 90 },
  // Keyword basic settings.
  basic_isactive: { default: false },
  target_acos: { default: 30 },
  minimum_bid: { default: 0.15 },
  max_bid_price: { default: 2 },
  minimum_click: { default: 10 },
  minimum_impression: { default: 1000 },
  // Keyword advanced settings.
  // Zero sale targets
  zero_adv_byclick_isactive: { default: false },
  zero_adv_byclick_threshold: { default: 8 },
  adv_byclick_frequency_type: { default: 'daily' },
  adv_byclick_freq_weekly: { default: [], type: 'json_array' },
  adv_byclick_freq_month_day: { default: '' },
  adv_byclick_lookback_period: { default: 7 },
  adv_byclick_automated_rule: { default: '' },
  adv_byclick_automated_rule_value: { default: '' },

  copy_zero_adv_byclick_isactive: { default: false },
  copy_zero_adv_byclick_threshold: { default: 8 },
  copy_adv_byclick_frequency_type: { default: 'daily' },
  copy_adv_byclick_freq_weekly: { default: [], type: 'json_array' },
  copy_adv_byclick_freq_month_day: { default: '' },
  copy_adv_byclick_lookback_period: { default: 7 },
  copy_adv_byclick_automated_rule: { default: '' },
  copy_adv_byclick_automated_rule_value: { default: '' },
  // Low CTR targets
  low_adv_byctr_isactive: { default: false },
  increase_adv_byimpression_min: { default: 1000 },
  increase_adv_ctr_byimpression_threshold: { default: 0.15 },
  adv_byimpression_frequency_type: { default: 'daily' },
  adv_byimpression_freq_weekly: { default: [], type: 'json_array' },
  adv_byimpression_freq_month_day: { default: '' },
  adv_byimpression_lookback_period: { default: 7 },
  adv_byimpression_automated_rule: { default: '' },
  adv_byimpression_automated_rule_value: { default: '' },

  copy_low_adv_byctr_isactive: { default: false },
  copy_increase_adv_byimpression_min: { default: 1000 },
  copy_increase_adv_ctr_byimpression_threshold: { default: 0.15 },
  copy_adv_byimpression_frequency_type: { default: 'daily' },
  copy_adv_byimpression_freq_weekly: { default: [], type: 'json_array' },
  copy_adv_byimpression_freq_month_day: { default: '' },
  copy_adv_byimpression_lookback_period: { default: 7 },
  copy_adv_byimpression_automated_rule: { default: '' },
  copy_adv_byimpression_automated_rule_value: { default: '' },
  // Low Converting targets
  low_adv_converting_isactive: { default: false },
  increase_adv_conversion_threshold: { default: 5 },
  adv_lowconverting_frequency_type: { default: 'daily' },
  adv_lowconverting_freq_weekly: { default: [], type: 'json_array' },
  adv_lowconverting_freq_month_day: { default: '' },
  adv_lowconverting_lookback_period: { default: 7 },
  adv_lowconverting_automated_rule: { default: '' },
  adv_lowconverting_automated_rule_value: { default: '' },

  copy_low_adv_converting_isactive: { default: false },
  copy_increase_adv_conversion_threshold: { default: 5 },
  copy_adv_lowconverting_frequency_type: { default: 'daily'} ,
  copy_adv_lowconverting_freq_weekly: { default: [], type: 'json_array' },
  copy_adv_lowconverting_freq_month_day: { default: '' },
  copy_adv_lowconverting_lookback_period: { default: 7 },
  copy_adv_lowconverting_automated_rule: { default: '' },
  copy_adv_lowconverting_automated_rule_value: { default: '' },
  // Very high ACoS targets
  unprofitable_adv_isactive: { default: false },
  increase_adv_byacos_threshold: { default: 100 },
  increase_adv_percentbid_click_threshold: { default: 8 },
  adv_unprofitable_frequency_type: { default: 'daily' },
  adv_unprofitable_freq_weekly: { default: [], type: 'json_array' },
  adv_unprofitable_freq_month_day: { default: '' },
  adv_unprofitable_lookback_period: { default: 7 },
  adv_unprofitable_automated_rule: { default: '' },
  adv_unprofitable_automated_rule_value: { default: '' },

  copy_unprofitable_adv_isactive: { default: false },
  copy_increase_adv_byacos_threshold: { default: 100 },
  copy_increase_adv_percentbid_click_threshold: { default: 8 },
  copy_adv_unprofitable_frequency_type: { default: 'daily' },
  copy_adv_unprofitable_freq_weekly: { default: [], type: 'json_array' },
  copy_adv_unprofitable_freq_month_day: { default: '' },
  copy_adv_unprofitable_lookback_period: { default: 7 },
  copy_adv_unprofitable_automated_rule: { default: '' },
  copy_adv_unprofitable_automated_rule_value: { default: '' },
  // Unprofitable targets
  unprofitable_adv_targets_isactive: { default: false },
  increase_adv_percentacos_threshold: { default: 50 },
  increase_adv_percentbid_byacos_threshold: { default: 80 },
  increase_adv_percentbid_byacos_click_threshold: { default: 8 },
  adv_unprofitable_targets_frequency_type: { default: 'daily' },
  adv_unprofitable_targets_freq_weekly: { default: [], type: 'json_array' },
  adv_unprofitable_targets_freq_month_day: { default: '' },
  adv_unprofitable_targets_lookback_period: { default: 7 },
  adv_unprofitable_targets_automated_rule: { default: '' },
  adv_unprofitable_targets_automated_rule_value: { default: '' },

  copy_unprofitable_adv_targets_isactive: { default: false },
  copy_increase_adv_percentacos_threshold: { default: 50 },
  copy_increase_adv_percentbid_byacos_threshold: { default: 80 },
  copy_increase_adv_percentbid_byacos_click_threshold: { default: 8 },
  copy_adv_unprofitable_targets_frequency_type: { default: 'daily' },
  copy_adv_unprofitable_targets_freq_weekly: { default: [], type: 'json_array' },
  copy_adv_unprofitable_targets_freq_month_day: { default: '' },
  copy_adv_unprofitable_targets_lookback_period: { default: 7 },
  copy_adv_unprofitable_targets_automated_rule: { default: '' },
  copy_adv_unprofitable_targets_automated_rule_value: { default: '' },
  // Ignore keywords
  ignore_keywords: { default: [], type: 'json_array' },
  // Negative Target Automation.
  nta_isactive: { default: false },
  add_asin_negatives_isactive: { default: true },
  negative_campaignlevel_isactive: { default: false },
  negative_adgrouplevel_isactive: { default: false },
  negative_byclick_isactive: { default: false },
  negative_byclick_threshold: { default: 10 },
  negative_byimpression_isactive: { default: false },
  negative_byimpression_threshold: { default: 1000 },
  negative_byctr_isactive: { default: false },
  negative_byctr_threshold: { default: 0.1 },
  nta_frequency_type: { default: 'daily' },
  nta_freq_weekly: { default: [], type: 'json_array' },
  nta_freq_month_day: { default: '' },
  nt_lookback: { default: 30 },

  copy_nta_isactive: { default: false },
  copy_add_asin_negatives_isactive: { default: true },
  copy_negative_campaignlevel_isactive: { default: false },
  copy_negative_adgrouplevel_isactive: { default: false },
  copy_negative_byclick_isactive: { default: false },
  copy_negative_byclick_threshold: { default: 10 },
  copy_negative_byimpression_isactive: { default: false },
  copy_negative_byimpression_threshold: { default: 1000 },
  copy_negative_byctr_isactive: { default: false },
  copy_negative_byctr_threshold: { default: 0.1 },
  copy_nta_frequency_type: { default: 'daily' },
  copy_nta_freq_weekly: { default: [], type: 'json_array' },
  copy_nta_freq_month_day: { default: '' },
  copy_nt_lookback: { default: 30 },
  // Negative Product Targeting.
  npt_byclick_isactive: { default: false },
  npt_byclick_threshold: { default: 3 },
  npt_frequency_type: { default: 'daily' },
  npt_freq_weekly: { default: [], type: 'json_array' },
  npt_freq_month_day: { default: '' },
  npt_lookback: { default: 30 },

  copy_npt_byclick_isactive: { default: false },
  copy_npt_byclick_threshold: { default: 3 },
  copy_npt_frequency_type: { default: 'daily' },
  copy_npt_freq_weekly: { default: [], type: 'json_array' },
  copy_npt_freq_month_day: { default: '' },
  copy_npt_lookback: { default: 30 },
  // Dayparting/Seasonality.
  daily_off_isactive: { default: false },
  weekly_off_dates: { default: [], type: 'json_array' },
  daily_off_start_hour: { default: 0 },
  daily_off_end_hour: { default: 23 },
  season_off_isactive: { default: false },
  season_off_start_date: { default: new Date(), type: 'date' },
  season_off_end_date: { default: new Date(), type: 'date' },
  season_budget_isactive: { default: false },
  season_budget_start_date: { default: new Date(), type: 'date' },
  season_budget_end_date: { default: new Date(), type: 'date' },
  increase_constantbudget_season_isactive: { default: false },
  increase_constantbudget_season_amount: { default: 0.02 },
  increase_constantbudget_season_maxmoney: { default: 10 },
  increase_percentbudget_season_isactive: { default: false },
  increase_percentbudget_season_amount: { default: 10 },
  increase_percentbudget_season_maxmoney: { default: 10 },
  // Split testing.
  // FIXME: Some database records are corrupted to have
  // `split_test_isactive` as true and `split_test_day`,
  // `split_test_start_day` as NULL.
  split_test_isactive: { default: false },
  split_test_day: { default: 14 },
  split_test_send_email: { default: false },
  split_test_start_day: { default: null, type: 'date' },
  // Keyword/Targeting Expansion.
  zero_impression_sing: { default: '%' },
  increase_percentbid_byimpression_isactive: { default: false },
  increase_percentbid_byimpression_threshold: { default: 100 },
  increase_percentbid_byimpression_amount: { default: 10 },
  increase_percentbid_byimpression_maxmoney: { default: 3 },
  ex_frequency_type: { default: 'daily' },
  ex_freq_weekly: { default: [], type: 'json_array' },
  ex_freq_month_day: { default: '' },
  // Search Term Expansion.
  st_isactive: { default: false },
  st_keywords_acos: { default: 30 },
  st_keywords_campaign_selected: { default: [], type: 'concat' },
  st_minimum_orders: { default: 3 },
  st_new_keyword_only: { default: true },
  st_ctr_isactive: { default: false },
  st_ctr_above: { default: 0 },
  st_conversion_isactive: { default: false },
  st_conversion_above: { default: 0 },
  st_adgroups_apply: { default: [], type: 'json_array' },
  st_negate_parent: { default: false },
  // Product Targeting.
  pt_isactive: { default: false },
  pt_acos: { default: 30 },
  pt_campaign_selected: { default: [], type: 'concat' },
  pt_minimum_orders: { default: 3 },
  pt_new_asins_only: { default: true },
  pt_adgroups_apply: { default: [], type: 'json_array' },
  pt_negate_parent: { default: false },
}

export const getDefaultAPSettings = (adgroupId) => {
  const settings = {}
  Object.keys(apSettings).forEach((key) => {
    settings[key] = apSettings[key].default
  })
  // If there is no AP record saved for a given ad group,
  // set `adgroup_id` setting so that a correct ad group
  // is selected in the selector.
  if (adgroupId) {
    settings.adgroup_id = adgroupId
  }
  return settings
}

// Parse JSON string of array.
const parseJsonArray = (value) => {
  try {
    return JSON.parse(value || '[]')
  } catch (e) {
    return []
  }
}

// Parse a string value of concatenated array elements into array.
const parseConcatenatedArray = (value) => {
  if (Array.isArray(value)) {
    return value
  }
  return !value ? [] : value.split(',')
}

// Parse smart pilot settings retrieved from backend.
export const parseAPSettings = (ap) => {
  Object.keys(ap).forEach((key) => {
    if (!apSettings[key]) {
      return
    }
    if (apSettings[key].type === 'json_array') {
      // Parse array-type settings.
      // `filter` method here removes NULL values.
      ap[key] = parseJsonArray(ap[key]).filter(s => s === 0 || s)
    } else if (apSettings[key].type === 'concat') {
      ap[key] = parseConcatenatedArray(ap[key])
    } else if (apSettings[key].type === 'date') {
      // Parse date strings to date objects.
      ap[key] = ap[key] ? new Date(ap[key]) : ap[key]
    } else if (apSettings[key].type === 'int') {
      ap[key] = parseInt(ap[key] || apSettings[key].default, 10)
    } else {
      // Set default values.
      if (typeof ap[key] === 'undefined'
        || ap[key] === null
        || ap[key] === '') {
        ap[key] = apSettings[key].default
      }
    }
  })

  return ap
}

// Parse campaigns and set their ad types appropriately.
export const parseCampaignsToApply = (campaignsToApply) => {
  const campaigns = []
  campaignsToApply.forEach((campaign) => {
    let type = ''
    if (campaign.type === 'sponsoredProducts') {
      type = 'sp'
    } else if (campaign.type === 'sponsoredDisplays') {
      type = 'sd'
    } else if (campaign.type === 'headlineSearch') {
      type = 'sbv'
    } else {
      type = 'sb'
    }

    campaigns.push({
      ...campaign,
      type,
    })
  })
  return campaigns
}

// Categorize adgroups into keyword targetings and product targetings.
export const categorizeAdgroups = (adgroups, targetings) => {
  const targetingIds = targetings.map(targeting => targeting.adgroup_id)
  const keywordAdgroups = []
  const productAdgroups = []
  adgroups.forEach((adgroup) => {
    if (targetingIds.indexOf(adgroup.id) === -1) {
      keywordAdgroups.push(Object.assign({}, adgroup))
    } else {
      productAdgroups.push(Object.assign({}, adgroup))
    }
  })
  return { keywordAdgroups, productAdgroups }
}

// Copy text to clipboard.
export const copyToClipboard = (text) => {
  const textField = document.createElement('textarea')
  textField.innerHTML = text
  document.body.appendChild(textField)
  textField.select()
  document.execCommand('copy')
  textField.remove()
}

// Return a sorter function to sort rows in tables.
// Accept a list of field names whose data type is string.
// sortOrder - asc/desc
export const tableSorter = stringFields => (items, [sortBy, sortOrder]) => {
  const sortedItems = [...items]

  sortedItems.sort((a, b) => {
    let comparison
    if (stringFields.indexOf(sortBy) !== -1) {
      comparison = (a[sortBy] || '').toLowerCase().localeCompare((b[sortBy] || '').toLowerCase())
    } else {
      comparison = parseFloat(a[sortBy] || 0) - parseFloat(b[sortBy] || 0)
    }
    return sortOrder === 'asc' ? comparison : -comparison
  })

  return sortedItems
}

export const getNormalizedCampaignType = (type) => {
  switch (type) {
    case 'sponsoredProducts':
    case 'Sponsored Product':
      return 'Sponsored Products'
    case 'sponsoredDisplays':
    case 'Sponsored Display':
      return 'Sponsored Displays'
    case 'headlineSearch':
    case 'Sponsored Brand Video':
      return 'Sponsored Brands Video'
    default:
      return 'Sponsored Brands'
  }
}

// Return a user-friendly description for log types.
export const getLogDescription = (logType, description) => {
  switch (logType) {
    case 'ap_dayparting': return 'Dayparting/Seasonality'
    case 'ap_kw_adv': return 'Target Bid Optimization Advanced Settings'
    case 'ap_kw_basic': return 'Target Bid Optimization Basic Settings'
    case 'ap_kw_ex': return 'Target Bid Expansion'
    case 'ap_npt': return 'Negative Product Targeting'
    case 'ap_nta_asin': return 'Negative Target Automation/Add ASINs as Negatives'
    case 'ap_pt_ex': return 'Product Targeting Expansion'
    case 'ap_setup': return 'Smart Pilot Setup'
    case 'ap_setup_multiple': return 'Smart Pilot - Multiple Campaigns'
    case 'ap_test': return 'Smart Pilot – AB Test'
    case 'ap_update': return 'Smart Pilot Update'
    case 'out_of_budget': return 'Out of budget'
      // Fallback to description.
    case 'ad_create':
    case 'ad_state_change':
    case 'adgroup_create':
    case 'adgroup_name_change':
    case 'adgroup_state_change':
    case 'ap_nta':
    case 'ap_st_ex':
    case 'ap_st_negate':
    case 'bid_placement_change':
    case 'bulk_keyword_bid_change':
    case 'bulk_keyword_state_change':
    case 'bulk_negative_word':
    case 'bulk_sku':
    case 'bulk_st':
    case 'campaign_acos_update':
    case 'campaign_create':
    case 'campaign_name_change':
    case 'campaign_state_change':
    case 'daily_budget_change':
    case 'default_bid_change':
    case 'keyword_add':
    case 'keyword_bid_change':
    case 'keyword_state_change':
    case 'negative_add_adgroup':
    case 'negative_add_campaign':
    case 'negative_remove_adgroup':
    case 'negative_remove_campaign':
    case 'nk_add':
    case 'nk_add_campaign':
    case 'npt_add_adgroup':
    case 'npt_add_campaign':
    case 'sku_state_change':
    default:
      return description
  }
}

const parseIndividualTargetExp = (exp) => {
  const { type, value } = exp
  if (type === 'asinSameAs') {
    return `asin="${value}"`
  }
  if (type === 'asinCategorySameAs') {
    return `category="${value}"`
  }
  if (type === 'asinBrandSameAs') {
    return `brand="${value}"`
  }
  if (type === 'asinGenreSameAs') {
    return `genre="${value}"`
  }
  if (type === 'queryHighRelMatches') {
    return 'close-match'
  }
  if (type === 'queryBroadRelMatches') {
    return 'loose-match'
  }
  if (type === 'asinSubstituteRelated') {
    return 'substitutes'
  }
  if (type === 'asinAccessoryRelated') {
    return 'complements'
  }
  if (type === 'similarProduct') {
    return 'similar-product'
  }
  if (type === 'exactProduct') {
    return 'exact-product'
  }
  if (type === 'relatedProduct') {
    return 'related-product'
  }
  if (type === 'audienceSameAs') {
    return value
  }
  if (type === 'lookback') {
    return `lookback=${value}`
  }
  if (type === 'asinReviewRatingGreaterThan') {
    return `review rating>${value}`
  }
  if (type === 'asinReviewRatingLessThan') {
    return `review rating<${value}`
  }
  if (type === 'asinReviewRatingBetween') {
    return `review rating:${value}`
  }
  if (type === 'asinPriceGreaterThan') {
    return `price>${value}`
  }
  if (type === 'asinPriceLessThan') {
    return `price<${value}`
  }
  if (type === 'asinPriceBetween') {
    return `price:${value}`
  }
  if (type === 'asinAgeRangeSameAs') {
    return `age range:${value}`
  }
  if (type === 'asinIsPrimeShippingEligible') {
    return `prime shipping eligible:${value}`
  }
  if (type === 'negative') {
    return 'negative'
  }
  if (type === 'audience') {
    const children = value.map(v => parseIndividualTargetExp(v)).join(' ')
    return `audience(${children})`
  }
  if (type === 'views') {
    const children = value.map(v => parseIndividualTargetExp(v)).join(' ')
    return `views(${children})`
  }
  if (type === 'purchases') {
    const children = value.map(v => parseIndividualTargetExp(v)).join(' ')
    return `purchases(${children})`
  }
  return JSON.stringify(exp)
}

// Parse targeting expression and return human-friendly expression.
export const parseTargetExp = (exp) => {
  try {
    const parsed = JSON.parse(exp)
    if (!Array.isArray(parsed) || !parsed.length) {
      return exp
    }
    return parsed.map(v => parseIndividualTargetExp(v)).join(' ')
  } catch (e) {
    return exp
  }
}

// Parse ASIN targeting expression and return ASIN.
export const parseAsinTarget = (exp) => {
  const resolvedExp = parseTargetExp(exp)

  const textPos = resolvedExp.indexOf('asin=')
  if (textPos !== -1) {
    return resolvedExp.substr(textPos + 6, 10)
  }
  return resolvedExp
}

// Check if a record matches a list of filters.
export const matchFilter = (record, filterList, filterValues) => {
  const unmatching = filterList.filter((filter) => {
    // This type of filters are processed using a custom logic
    // by individual tables/components.
    if (filter.customProcessing) {
      return false
    }

    if (filter.type === 'select') {
      if (filterValues[filter.key] && filterValues[filter.key].value) {
        let selectedValue = filterValues[filter.key].value
        if (!Array.isArray(selectedValue)) {
          selectedValue = [selectedValue]
        }
        if (selectedValue.indexOf((record[filter.key] || '').toLowerCase()) === -1) {
          return true
        }
      }
    } else if (filter.type === 'target_acos') {
      if (filterValues[filter.key] === true
        && record.acos
        && record.acos < parseFloat(record[filter.key])) {
        return true
      }
    } else {
      const min = filterValues[`${filter.key}Min`] || ''
      if (min !== '' && !isNaN(min)) {
        if (parseFloat(record[filter.key] || 0) < parseFloat(min)) {
          return true
        }
      }

      const max = filterValues[`${filter.key}Max`] || ''
      if (max !== '' && !isNaN(max)) {
        if (parseFloat(record[filter.key] || 0) > parseFloat(max)) {
          return true
        }
      }
    }

    return false
  })
  return unmatching.length === 0
}

// Calculate derived metrics, such as ACoS, CTR, etc.
export const calcDerivedMetrics = (record) => {
  let ctr = 0
  let cpc = 0
  let conversion = 0
  let clickOrder = 0
  let acos = 0
  let roas = 0
  let ntb_orders_percent = 0
  let ntb_sales_percent = 0
  if (parseInt(record.impressions, 10)) {
    ctr = parseInt(record.clicks, 10) / parseInt(record.impressions, 10) * 100
  }
  if (parseInt(record.clicks, 10)) {
    cpc = parseFloat(record.cost) / parseInt(record.clicks, 10)
    conversion = parseInt(record.orders, 10) / parseInt(record.clicks, 10) * 100
  }
  if (parseInt(record.orders, 10)) {
    clickOrder = parseInt(record.clicks, 10) / parseInt(record.orders, 10)
    ntb_orders_percent = parseInt(record.ntb_orders || 0, 10) / parseInt(record.orders, 10) * 100
  }
  if (parseFloat(record.revenue)) {
    acos = parseFloat(record.cost) / parseFloat(record.revenue) * 100
    ntb_sales_percent = parseFloat(record.ntb_sales || 0) / parseFloat(record.revenue) * 100
  }
  if (parseFloat(record.cost)) {
    roas = parseFloat(record.revenue) / parseFloat(record.cost)
  }

  return {
    ...record,
    ctr,
    cpc,
    conversion,
    clickOrder,
    acos,
    roas,
    ntb_orders_percent,
    ntb_sales_percent,
  }
}

export const calcMaxCpc = (record) => {
  let maxCpc
  if (parseInt(record.clicks, 10) >= 3) {
    if (parseInt(record.units, 10) && record.clickOrder) {
      maxCpc = (parseFloat(record.revenue) / parseInt(record.units, 10))
        * (record.target_acos / 100)
        / record.clickOrder
    } else if (typeof record.units === 'undefined' && parseInt(record.clicks, 10)) {
      // For SB/SBV campaigns, the number of units is not available.
      maxCpc = parseFloat(record.revenue) * (record.target_acos / 100) / parseInt(record.clicks, 10)
    }

    if (maxCpc < 0.15) {
      maxCpc = 0.15
    }
  }
  return maxCpc
}

// Group records.
export const groupRecords = (records, groupBy, parentFields) => {
  const results = {}
  records.forEach((record) => {
    if (!results[record[groupBy]]) {
      const data = {
        [groupBy]: record[groupBy],
        cost: 0,
        revenue: 0,
        impressions: 0,
        clicks: 0,
        orders: 0,
        yearlyCost: 0,
        st_impr_rank: 0,
        st_impr_share: 0,
        viewable_impressions: 0,
        children: [],
      }
      parentFields.forEach((field) => {
        data[field] = record[field]
      })
      results[record[groupBy]] = data
    }

    results[record[groupBy]].children.push(record)
    if (typeof record.cost !== 'undefined') {
      results[record[groupBy]].cost += parseFloat(record.cost)
      results[record[groupBy]].revenue += parseFloat(record.revenue)
      results[record[groupBy]].impressions += parseInt(record.impressions, 10)
      results[record[groupBy]].clicks += parseInt(record.clicks, 10)
      results[record[groupBy]].orders += parseInt(record.orders, 10)
    }
    results[record[groupBy]].yearlyCost += parseFloat(record.yearlyCost || 0)
    results[record[groupBy]].st_impr_rank += parseFloat(record.st_impr_rank || 0)
    results[record[groupBy]].st_impr_share += parseFloat(record.st_impr_share || 0)
    results[record[groupBy]].viewable_impressions += parseInt(record.viewable_impressions || 0, 10)
  })

  return Object.keys(results).map((key) => {
    const record = results[key]
    record.st_impr_rank /= record.children.length
    record.st_impr_share /= record.children.length
    return calcDerivedMetrics(record)
  })
}

const amazonLinkList = {
  us: 'www.amazon.com',
  ca: 'www.amazon.ca',
  mx: 'www.amazon.com.mx',
  br: 'www.amazon.com.br',
  gb: 'www.amazon.co.uk',
  de: 'www.amazon.de',
  fr: 'www.amazon.fr',
  it: 'www.amazon.it',
  es: 'www.amazon.es',
  in: 'www.amazon.in',
  nl: 'www.amazon.nl',
  se: 'www.amazon.se',
  pl: 'www.amazon.pl',
  tr: 'www.amazon.com.tr',
  ae: 'www.amazon.ae',
  eg: 'www.amazon.eg',
  sa: 'www.amazon.sa',
  jp: 'www.amazon.co.jp',
  au: 'www.amazon.com.au',
  sg: 'www.amazon.sg',
  cn: 'www.amazon.cn',
}

// Get Amazon links for a provided account/country.
export const getAmazonLink = (account) => {
  if (!account || !account.country_id) {
    return amazonLinkList['us']
  }
  return amazonLinkList[account.country_id] || amazonLinkList['us']
}

// Filter logs based on type.
export const filterLogs = (logs, type) => {
  if (!type) {
    return logs
  }

  let filteredLogs = [...logs]
  switch (type.value) {
    case 'ap_kw_basic':
    case 'ap_kw_adv':
    case 'ap_kw_ex':
    case 'ap_npt':
    case 'out_of_budget':
    case 'ap_dayparting':
      filteredLogs = filteredLogs.filter(log => (
        log.log_type === type.value
      ))
      break
    case 'ap_nta':
      filteredLogs = filteredLogs.filter(log => (
        log.log_type === 'ap_nta' || log.log_type === 'ap_nta_asin'
      ))
      break
    case 'ap_st_ex':
      filteredLogs = filteredLogs.filter(log => (
        log.log_type === 'ap_st_ex' || log.log_type === 'ap_st_negate'
      ))
      break
    case 'ap_pt_ex':
      filteredLogs = filteredLogs.filter(log => (
        log.log_type === 'ap_pt_ex' || log.log_type === 'ap_pt_negate'
      ))
      break
    default:
      break
  }

  return filteredLogs
}

export const parseHealthKpi = (data) => {
  const {
    totalRevenue,
    totalRevenueForPrevMonth,
    totalCampaigns,
    totalCampaignsForPrevMonth,
    totalKeywords,
    totalKeywordsForPrevMonth,
  } = data

  const kpiForThisMonth = (data && data.kpi) ? data.kpi : {}
  const kpiForPrevMonth = (data && data.kpiForPrevMonth) ? data.kpiForPrevMonth : {}

  kpiForThisMonth['acos'] = kpiForThisMonth.revenue ? kpiForThisMonth.cost / kpiForThisMonth.revenue * 100.0 : 0
  kpiForThisMonth['conv'] = kpiForThisMonth.clicks ? kpiForThisMonth.orders / kpiForThisMonth.clicks * 100.0 : 0
  kpiForThisMonth['ctr'] = kpiForThisMonth.clicks / kpiForThisMonth.impressions * 100.0
  kpiForThisMonth['sales'] = totalRevenue - kpiForThisMonth['revenue']
  kpiForThisMonth['totalCampaigns'] = totalCampaigns
  kpiForThisMonth['totalKeywords'] = totalKeywords

  kpiForPrevMonth['acos'] = kpiForPrevMonth.revenue ? kpiForPrevMonth.cost / kpiForPrevMonth.revenue * 100.0 : 0
  kpiForPrevMonth['conv'] = kpiForPrevMonth.clicks ? kpiForPrevMonth.orders / kpiForPrevMonth.clicks * 100.0 : 0
  kpiForPrevMonth['ctr'] = kpiForPrevMonth.clicks / kpiForPrevMonth.impressions * 100.0
  kpiForPrevMonth['sales'] = totalRevenueForPrevMonth - kpiForPrevMonth['revenue']
  kpiForPrevMonth['totalCampaigns'] = totalCampaignsForPrevMonth
  kpiForPrevMonth['totalKeywords'] = totalKeywordsForPrevMonth

  return {
    kpiForThisMonth,
    kpiForPrevMonth,
  }
}

export const parsePerformanceSummary = (placementSummary = {}) => {
  const bidTotal = {}
  const types = ['auto', 'legacy', 'manual']
  types.forEach((type) => {
    const values = placementSummary[type]
    const capitalType = type.charAt(0).toUpperCase() + type.slice(1)
    if (values) {
      bidTotal[`impressions${capitalType}`] = values['impressionsTop'] + values['impressionsDetail'] + values['impressionsOther']
      bidTotal[`revenue${capitalType}`] = values['revenueTop'] + values['revenueDetail'] + values['revenueOther']
      bidTotal[`clicks${capitalType}`] = values['clicksTop'] + values['clicksDetail'] + values['clicksOther']
      bidTotal[`orders${capitalType}`] = values['ordersTop'] + values['ordersDetail'] + values['ordersOther']
      bidTotal[`cost${capitalType}`] = values['costTop'] + values['costDetail'] + values['costOther']
    }

    bidTotal[`ctr${capitalType}`] = bidTotal[`impressions${capitalType}`]
      ? bidTotal[`clicks${capitalType}`] / bidTotal[`impressions${capitalType}`] * 100.0 : 0
    bidTotal[`acos${capitalType}`] = bidTotal[`revenue${capitalType}`]
      ? bidTotal[`cost${capitalType}`] / bidTotal[`revenue${capitalType}`] * 100.0 : 0
    bidTotal[`conv${capitalType}`] = bidTotal[`clicks${capitalType}`]
      ? bidTotal[`orders${capitalType}`] / bidTotal[`clicks${capitalType}`] * 100.0 : 0
    bidTotal[`cpc${capitalType}`] = bidTotal[`clicks${capitalType}`]
      ? bidTotal[`cost${capitalType}`] / bidTotal[`clicks${capitalType}`] : 0
  })

  const placementTotal = {}
  for (let key in placementSummary.auto) {
    placementTotal[key] = placementSummary.auto[key]
      + placementSummary.manual[key]
      + placementSummary.legacy[key]
  }

  placementTotal['ctrTop'] = placementTotal['impressionsTop']
    ? placementTotal['clicksTop'] / placementTotal['impressionsTop'] * 100.0 : 0
  placementTotal['acosTop'] = placementTotal['revenueTop']
    ? placementTotal['costTop'] / placementTotal['revenueTop'] * 100.0 : 0
  placementTotal['convTop'] = placementTotal['clicksTop']
    ? placementTotal['ordersTop'] / placementTotal['clicksTop'] * 100.0 : 0
  placementTotal['cpcTop'] = placementTotal['clicksTop']
    ? placementTotal['costTop'] / placementTotal['clicksTop'] : 0

  placementTotal['ctrDetail'] = placementTotal['impressionsDetail']
    ? placementTotal['clicksDetail'] / placementTotal['impressionsDetail'] * 100.0 : 0
  placementTotal['acosDetail'] = placementTotal['revenueDetail']
    ? placementTotal['costDetail'] / placementTotal['revenueDetail'] * 100.0 : 0
  placementTotal['convDetail'] = placementTotal['clicksDetail']
    ? placementTotal['ordersDetail'] / placementTotal['clicksDetail'] * 100.0 : 0
  placementTotal['cpcDetail'] = placementTotal['clicksDetail']
    ? placementTotal['costDetail'] / placementTotal['clicksDetail'] : 0

  placementTotal['ctrOther'] = placementTotal['impressionsOther']
    ? placementTotal['clicksOther'] / placementTotal['impressionsOther'] * 100.0 : 0
  placementTotal['acosOther'] = placementTotal['revenueOther']
    ? placementTotal['costOther'] / placementTotal['revenueOther'] * 100.0 : 0
  placementTotal['convOther'] = placementTotal['clicksOther']
    ? placementTotal['ordersOther'] / placementTotal['clicksOther'] * 100.0 : 0
  placementTotal['cpcOther'] = placementTotal['clicksOther']
    ? placementTotal['costOther'] / placementTotal['clicksOther'] : 0

  return {
    bidTotal,
    placementTotal,
  }
}

// Get exportable data for a given column.
// Used for aggregation as well.
export const getExportValueForColumn = (record, columnKey, currencySign, currencyRate) => {
  if (columnKey === 'campaignName') {
    let targetingType = ''
    if (record.campaignType === 'Sponsored Products') {
      targetingType = record.targetingType === 'auto' ? 'Auto, ' : 'Manual, '
    }
    return `${record.campaignName} (${targetingType}${campaignTypeMap[record.campaignType]})`
  }
  if (columnKey === 'adgroupName') {
    return record.adgroupName
  }
  if (columnKey === 'orders' || columnKey === 'impressions' || columnKey === 'clicks'
    || columnKey === 'ntb_orders' || columnKey === 'viewable_impressions') {
    return formatValue(record[columnKey], 'removeZeroDecimal')
  } else if (columnKey === 'acos' || columnKey === 'ctr' || columnKey === 'conversion'
    || columnKey === 'ntb_orders_percent' || columnKey === 'ntb_sales_percent') {
    return formatValue(record[columnKey], 'percent')
  } else if (columnKey === 'revenue' || columnKey === 'cost' || columnKey === 'cpc'
    || columnKey === 'ntb_sales') {
    return formatCurrency(record[columnKey], currencySign, currencyRate)
  } else if (columnKey === 'st_impr_rank') {
    if (parseFloat(record[columnKey])) {
      return formatValue(Math.ceil(parseFloat(record[columnKey])), 'removeZeroDecimal')
    }
  } else if (columnKey === 'st_impr_share') {
    if (parseFloat(record[columnKey])) {
      return formatValue(record[columnKey], 'percent')
    }
  }
  return ''
}

export const getAccountLabel = (account) => {
  if (!account) {
    return 'N/A'
  }

  const country = (account.country_id || 'N/A').toUpperCase()
  let brandName
  if (account.brand_name) {
    brandName = account.brand_name
  } else {
    brandName = account.sellerid || 'N/A'
  }
  return `${country} - ${brandName}`
}
