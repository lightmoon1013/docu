export const endpoint = 'https://ppcentourage.com:1337'

export const SP_APP_ID = ''
export const SP_BETA = false
// Should match what you specified when registering the app.
export const SP_REDIRECT_URI = 'https://ppcentourage.com/signup-complete'
export const SP_SETTINGS_REDIRECT_URI = 'https://ppcentourage.com/settings'

export const LOGIN_CLIENT_ID = ''

export const STRIPE_PUB_KEY = ''

export const SENTRY_DNS=''

export const MARGINS_URL = 'https://ppcentourage.com/margins'
