export const endpoint = 'http://localhost:1337'
// export const endpoint = 'http://localhost:1337'
export const SP_APP_ID = ''
export const SP_BETA = false
export const SP_REDIRECT_URI = 'https://localhost:1337/signup-complete'
export const SP_SETTINGS_REDIRECT_URI = 'https://localhost:1337/settings'
// export const LOGIN_CLIENT_ID = 'amzn1.application-oa2-client.3CGMpN8jsU8cPWSYtV6RXypf2YmfjcAvoJ'
export const LOGIN_CLIENT_ID = 'amzn1.application-oa2-client.f250e3787a2b4105bd5881a6d0f0e3a9'
export const STRIPE_PUB_KEY = 'pk_live_tOaeHcM7VwvZm2wo2cJdYJxT'
export const SENTRY_DNS='https://eea3b11b3c0b4df7a1cd03a81dc2f053@o1059517.ingest.sentry.io/6048222'


export const MARGINS_URL = 'https://ppcentourage.com/margins'
