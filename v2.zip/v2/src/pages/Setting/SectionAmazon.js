import React, { useEffect, useState } from 'react'
import { useDispatch, useStore } from 'react-redux'
import { useLocation } from 'react-router-dom'
import moment from 'moment'

import { toast } from '../../components/CommonComponents/ToastComponent/toast'
import LoaderComponent from '../../components/CommonComponents/LoaderComponent'
import SectionAdd from './SectionAdd'

import { STORAGE_KEY_REGION } from '../../utils/defaultValues'
import { getAccountLabel } from '../../services/helper'

import { addAccountOpen, saveBrandName } from '../../redux/actions/auth'

const SectionAmazon = () => {
  const dispatch = useDispatch()
  const store = useStore().getState()
  const location = useLocation()

  const { header: { selectedUserInfo } } = store

  const [expanded, setExpanded] = useState(false)
  const [brandName, setBrandName] = useState(selectedUserInfo.brand_name || '')
  const [isSavingBrandName, setIsSavingBrandName] = useState(false)

  useEffect(() => {
    const qs = new URLSearchParams(location.search)
    const callbackUrl = qs.get('amazon_callback_uri')
    const spCode = qs.get('spapi_oauth_code')
    const code = qs.get('code')

    if (callbackUrl || spCode || code) {
      setExpanded(true)
    }
  }, [location])

  const handleExpand = () => {
    if (!expanded) {
      window.sessionStorage.removeItem(STORAGE_KEY_REGION)
      dispatch(addAccountOpen())
      setExpanded(true)
    } else {
      setExpanded(false)
    }
  }

  const handleSaveBrandName = () => {
    setIsSavingBrandName(true)
    dispatch(saveBrandName(brandName)).then(() => {
      setIsSavingBrandName(false)
      toast.show({
        title: 'Success',
        description: 'Brand name successfully saved.',
      })
    }).catch((error) => {
      setIsSavingBrandName(false)
      toast.show({
        title: 'Danger',
        description: error?.response?.data?.message || 'Failed to save brand name.',
      })
    })
  }

  return (
    <div className="page-section">
      <div className="section-title">Amazon Account</div>
      <div className="section-contents section-amazon">
        <div className="account-info">
          <div>
            { getAccountLabel(selectedUserInfo) }
          </div>
          {
            selectedUserInfo.createdat && (
              <div>
                Added at: { moment(selectedUserInfo.createdat).format('YYYY-MM-DD') }
              </div>
            )
          }
        </div>
        <button
          type="button"
          className="btn btn-white"
          title="Add additional accounts"
          onClick={handleExpand}
        >
          { !expanded ? '+' : '-' }
        </button>
        <div className="brand-name-container">
          { isSavingBrandName && <LoaderComponent /> }
          <label>Brand Name</label>
          <input
            type="text"
            required
            value={brandName}
            onChange={e => { setBrandName(e.target.value) }}
          />
          <button
            type="button"
            className="btn btn-red"
            disabled={isSavingBrandName}
            onClick={handleSaveBrandName}
          >
            Save
          </button>
        </div>
      </div>
      <SectionAdd
        expanded={expanded}
      />
    </div>
  )
}

export default SectionAmazon
