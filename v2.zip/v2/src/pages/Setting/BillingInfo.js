/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useEffect, useState } from 'react'
import * as Icon from 'react-icons/fi'

import CollapsibleSection from './CollapsibleSection'
import BillingInfoModal from './BillingInfoModal'

import { countryList } from '../../utils/country'

const BillingInfo = ({ isLoading, billingInfo }) => {
  const [currentInfo, setCurrentInfo] = useState(billingInfo)
  const [showInfoModal, setShowInfoModal] = useState(false)

  useEffect(() => {
    setCurrentInfo(billingInfo)
  }, [billingInfo])

  const handleInfoModalClose = (payload) => {
    setShowInfoModal(false)

    if (payload) {
      setCurrentInfo(payload)
    }
  }

  const renderInfo = () => {
    if (!currentInfo) {
      return (
        <em>Unavailable</em>
      )
    }

    let country
    if (currentInfo.country) {
      const found = countryList.find(option => option.value === currentInfo.country)
      if (found) {
        country = found.label
      }
    }

    return (
      <>
        <p>{ currentInfo.first_name } { currentInfo.last_name }</p>
        { currentInfo.line1 && <p>{ currentInfo.line1 }</p> }
        { currentInfo.line2 && <p>{ currentInfo.line2 }</p> }
        {
          (currentInfo.city || currentInfo.zip) && (
            <p>
              { currentInfo.city && `${currentInfo.city} ` }
              { currentInfo.zip || '' }
            </p>
          )
        }
        { currentInfo.state && <p>{ currentInfo.state }</p> }
        { country && <p>{ country }</p> }
      </>
    )
  }

  return (
    <CollapsibleSection
      title="Billing Information"
      topRight={(
        <a
          href="#"
          onClick={(event) => { event.preventDefault(); setShowInfoModal(true) }}
        >
          <Icon.FiEdit3 /> Edit
        </a>
      )}
    >
      {
        isLoading ? 'Loading...' : renderInfo()
      }
      <BillingInfoModal
        show={showInfoModal}
        onHide={handleInfoModalClose}
      />
    </CollapsibleSection>
  )
}

export default BillingInfo
