/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useState, useEffect } from 'react'
import { useDispatch, useStore } from 'react-redux'

import LoaderComponent from '../../components/CommonComponents/LoaderComponent'
import BillingCard from './BillingCard'
import BillingInfo from './BillingInfo'
import BillingInvoice from './BillingInvoice'
import BillingSubscription from './BillingSubscription'

import { getBillingInfo } from '../../redux/actions/auth'

const SectionBilling = () => {
  const dispatch = useDispatch()
  const store = useStore().getState()

  const { header: { accountList } } = store

  const [isLoading, setIsLoading] = useState(false)
  const [cardList, setCardList] = useState([])
  const [billingInfo, setBillingInfo] = useState({})
  const [invoiceList, setInvoiceList] = useState([])
  const [subscriptionList, setSubscriptionList] = useState([])

  useEffect(() => {
    setIsLoading(true)
    dispatch(getBillingInfo()).then((response) => {
      setIsLoading(false)
      setCardList(response.cards)
      setBillingInfo(response.billingInfo)
      setInvoiceList(response.invoices)
      setSubscriptionList(response.subscriptions)
    }).catch(() => {
      setIsLoading(false)
    })
  }, []) // eslint-disable-line

  const handleCancel = (subscription) => {
    setSubscriptionList(subscriptionList.map(subscr => ({
      ...subscr, 
      status: subscription?.id === subscr.id ? subscription?.status: subscr.status,
      cancelled_at: subscription?.id === subscr.id ? subscription?.cancelled_at : subscr.cancelled_at
    })))
  }

  return (
    <div className={`page-section${isLoading ? ' loading' : ''}`}>
      { isLoading && <LoaderComponent /> }
      <div className="section-title">Billing</div>
      <div className="section-contents section-billing">
        <BillingCard
          isLoading={isLoading}
          cardList={cardList}
          onCardChange={setCardList}
        />
        <BillingInfo
          isLoading={isLoading}
          billingInfo={billingInfo}
        />
        <BillingInvoice
          isLoading={isLoading}
          invoices={invoiceList}
        />
        <BillingSubscription
          isLoading={isLoading}
          accountList={accountList}
          subscriptions={subscriptionList}
          onCancel={handleCancel}
        />
      </div>
    </div>
  )
}

export default SectionBilling
