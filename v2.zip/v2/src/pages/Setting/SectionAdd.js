import React, { useState, useEffect } from 'react'
import { useDispatch, useStore } from 'react-redux'
import { useLocation } from 'react-router-dom'
import Select from 'react-select'

import { SP_APP_ID, SP_BETA, SP_SETTINGS_REDIRECT_URI, LOGIN_CLIENT_ID } from '../../config/api'

import { toast } from '../../components/CommonComponents/ToastComponent/toast'
import LoaderComponent from '../../components/CommonComponents/LoaderComponent'
import AccountSelector from './AccountSelector'

import { signupSPCode, signupADCode, addAccount } from '../../redux/actions/auth'

import {
  regionList,
  sellerCentralUrls,
  STORAGE_KEY_REGION,
  STORAGE_KEY_STATE,
} from '../../utils/defaultValues'

const SectionAdd = ({ expanded }) => {
  const dispatch = useDispatch()
  const location = useLocation()
  const store = useStore().getState()

  const {
    auth: {
      isSPCodeGetting,
      spRefreshToken,
      isADCodeGetting,
      adRefreshToken,
      profileList,
    },
    header: { accountList },
  } = store

  const [region, setRegion] = useState(regionList[0])
  const [selectedProfileIds, setSelectedProfileIds] = useState([])
  const [isAdding, setIsAdding] = useState(false)

  // Inject Amazon LWA script.
  useEffect(() => {
    let amazonRoot = document.getElementById('amazon-root')
    if (!amazonRoot) {
      amazonRoot = document.createElement('div')
      amazonRoot.setAttribute('id', 'amazon-root')
      document.body.appendChild(amazonRoot)

      const script = document.createElement('script')
      script.setAttribute('type', 'text/javascript')
      script.innerHTML = `
        window.onAmazonLoginReady = function() {
          amazon.Login.setClientId('${LOGIN_CLIENT_ID}');
        };
        (function(d) {
          var a = d.createElement('script'); a.type = 'text/javascript';
          a.async = true; a.id = 'amazon-login-sdk';
          a.src = 'https://assets.loginwithamazon.com/sdk/na/login1.js';
          d.getElementById('amazon-root').appendChild(a);
        })(document);
      `
      document.body.appendChild(script)
    }
  }, [])

  // Respond to Amazon returns.
  useEffect(() => {
    const qs = new URLSearchParams(location.search)
    const callbackUrl = qs.get('amazon_callback_uri')
    const spCode = qs.get('spapi_oauth_code')
    const code = qs.get('code')

    if (callbackUrl) {
      // After authorizing our app, users are redirected to another page
      // to get the LWA (Login with Amazon) code.
      const amazonState = qs.get('amazon_state')
      const state = (new Date()).valueOf()
      // Save state to sessionStorage for later validation.
      window.sessionStorage.setItem(STORAGE_KEY_STATE, state)
      let url = `${callbackUrl}?redirect_uri=${encodeURI(SP_SETTINGS_REDIRECT_URI)}`
        + `&amazon_state=${amazonState}&state=${state}`
      if (SP_BETA) {
        url = `${url}&version=beta`
      }
      window.location.href = url
    } else if (spCode) {
      let state = qs.get('state')
      const savedState = window.sessionStorage.getItem(STORAGE_KEY_STATE)
      if ((state === 'settings' || state === savedState) && !isSPCodeGetting) {
        window.sessionStorage.removeItem(STORAGE_KEY_STATE)

        dispatch(signupSPCode(spCode)).then(() => {
          if (typeof window.amazon === 'undefined') {
            setTimeout(() => {
              if (typeof window.amazon === 'undefined') {
                toast.show({
                  title: 'Danger',
                  description: 'The Amazon script is not loaded.',
                  duration: 20000,
                })
                return
              }
              initiateLWA()
            }, 5000)
            return
          }
          initiateLWA()
        }).catch((error) => {
          toast.show({
            title: 'Danger',
            description: error,
          })
        })
      }
    } else if (code) {
      let state = qs.get('state')
      const savedState = window.sessionStorage.getItem(STORAGE_KEY_STATE)
      if (state === savedState && !isADCodeGetting) {
        window.sessionStorage.removeItem(STORAGE_KEY_STATE)

        const savedRegion = window.sessionStorage.getItem(STORAGE_KEY_REGION)
        dispatch(signupADCode(code, SP_SETTINGS_REDIRECT_URI, savedRegion || region.value)).catch((error) => {
          toast.show({
            title: 'Danger',
            description: error,
          })
        })
      }
    }
  }, []) // eslint-disable-line

  const initiateLWA = () => {
    const state = (new Date()).valueOf()
    // Save state to sessionStorage for later validation.
    window.sessionStorage.setItem(STORAGE_KEY_STATE, state)

    window.amazon.Login.authorize({
      scope: [
        'profile',
        'profile:user_id',
        'cpc_advertising:campaign_management',
      ],
      response_type: 'code',
      popup: false,
      state,
    }, SP_SETTINGS_REDIRECT_URI)
  }

  const handleAdd = () => {
    const profiles = []
    profileList.forEach((profile) => {
      if (selectedProfileIds.indexOf(profile.profileId) === -1) {
        return
      }
      profiles.push({
        profileId: profile.profileId,
        countryCode: profile.countryCode.toLowerCase(),
        sellerStringId: profile.accountInfo.sellerStringId,
        brandEntityId: profile.accountInfo.brandEntityId,
        brandName: profile.accountInfo.brandName,
        type: profile.accountInfo.type.toLowerCase(),
      })
    })

    if (!profiles.length) {
      toast.show({
        title: 'Danger',
        description: 'Please select accounts.',
      })
      return
    }

    window.sessionStorage.removeItem(STORAGE_KEY_REGION)

    setIsAdding(true)

    dispatch(addAccount({
      adRefreshToken,
      spRefreshToken,
      profiles,
    })).then(() => {
      setIsAdding(false)
      toast.show({
        title: 'Success',
        description: 'Additional accounts successfully added! Please allow up to 24 hours to collect data.',
      })
    }).catch((error) => {
      setIsAdding(false)
      toast.show({
        title: 'Danger',
        description: error,
      })
    })
  }

  const handleRegionChange = (option) => {
    setRegion(option)
    window.sessionStorage.setItem(STORAGE_KEY_REGION, option.value)
  }

  const renderRegionSelector = () => {
    let url = `${sellerCentralUrls[region.value]}/apps/authorize/consent?application_id=${SP_APP_ID}&state=settings`
    if (SP_BETA) {
      url = `${url}&version=beta`
    }

    return (
      <div className="region-selector">
        <label>
          Choose Region
        </label>
        <Select
          className="region-list"
          isSearchable={false}
          value={region}
          options={regionList}
          onChange={handleRegionChange}
        />
        <a href={url} className="btn btn-blue">
          Grant Access
        </a>
      </div>
    )
  }

  if (!expanded) {
    return null
  }

  return (
    <div className="section-add">
      { (isADCodeGetting || isSPCodeGetting || isAdding) && <LoaderComponent /> }
      { renderRegionSelector() }
      {
        spRefreshToken && adRefreshToken && (
          <>
            <AccountSelector
              profileList={profileList}
              accountList={accountList}
              selectedProfileIds={selectedProfileIds}
              onSelect={setSelectedProfileIds}
            />
            <button
              type="button"
              className="btn btn-red"
              disabled={(selectedProfileIds.length === 0) || isAdding}
              onClick={handleAdd}
            >
              Add Additional Accounts
            </button>
          </>
        )
      }
    </div>
  )
}

export default SectionAdd
