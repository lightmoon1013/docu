/* eslint-disable jsx-a11y/anchor-is-valid */
import React from 'react'
import { useDispatch } from 'react-redux'
import moment from 'moment'

import CustomTable from '../../components/CommonComponents/CustomTableComponent'
import CollapsibleSection from './CollapsibleSection'

import { getInvoiceDownloadLink } from '../../redux/actions/auth'

import * as Sentry from '@sentry/react'

const statusList = {
  paid: 'Paid',
  posted: 'Posted',
  payment_due: 'Payment Due',
  not_paid: 'Not Paid',
  voided: 'Voided',
  pending: 'Pending',
}

const BillingInvoice = ({ isLoading, invoices }) => {
  const dispatch = useDispatch()

  const handleDownload = invoiceId => (event) => {
    event.preventDefault()
    dispatch(getInvoiceDownloadLink(invoiceId)).then((response) => {
      if (response.data.url) {
        window.open(response.data.url, '_blank')
      }
    }).catch((error) => {
      Sentry.captureMessage('Failed to get invoice download link.')
      Sentry.captureException(error)
    })
  }

  const renderInvoice = invoice => (
    <>
      <div className="table-col col-status">
        { statusList[invoice.status] || invoice.status }
      </div>
      <div className="table-col col-date">
        { moment.unix(invoice.date).format('DD-MMM-YYYY') }
      </div>
      <div className="table-col">
        { invoice.id }
      </div>
      <div className="table-col">
        { invoice.currency_code } { (invoice.total / 100).toFixed(2) }
        {
          invoice.paid_at && (
            <span className="invoice-paid-at">
              Paid on { moment.unix(invoice.paid_at).format('DD-MMM-YYYY') }
            </span>
          )
        }
      </div>
      <div className="table-col col-download">
        <a href="#" onClick={handleDownload(invoice.id)}>
          Download as PDF
        </a>
      </div>
    </>
  )

  return (
    <CollapsibleSection title="Payment History">
      <CustomTable
        isLoading={isLoading}
        className="table-invoices"
        records={invoices}
        idField="id"
        noCheckBox
        noSearch
        renderRecord={renderInvoice}
      >
        <div className="table-col col-status">Status</div>
        <div className="table-col col-date">Date</div>
        <div className="table-col">Invoice Number</div>
        <div className="table-col">Amount</div>
        <div className="table-col col-download"></div>
      </CustomTable>
    </CollapsibleSection>
  )
}

export default BillingInvoice
