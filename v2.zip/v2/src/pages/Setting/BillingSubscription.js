/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useState } from 'react'
import { useDispatch } from 'react-redux'
import moment from 'moment'

import CustomTable from '../../components/CommonComponents/CustomTableComponent'
import CollapsibleSection from './CollapsibleSection'
import CancellationModal from './CancellationModal'

import { cancelSubscription } from '../../redux/actions/auth'

const statusList = {
  future: 'Future',
  in_trial: 'In Trial',
  active: 'Active',
  non_renewing: 'Non Renewing',
  paused: 'Paused',
  cancelled: 'Cancelled',
}

const getAccountLabel = (account) => {
  if (!account) {
    return ''
  }

  const country = (account.country_id || 'N/A').toUpperCase()
  let brandName
  if (account.brand_name) {
    brandName = account.brand_name
  } else {
    brandName = account.sellerid || 'N/A'
  }
  return `${country} - ${brandName}`
}

const getCouponInfo = (coupon, subscriptionCoupons) => {
  if (!coupon){
    return ''
  }

  let couponInfo = coupon.discount_type === 'percentage' ?  `${coupon.discount_percentage}% ` :  `${coupon.discount_amount} ${coupon.currency_code} `

  if (coupon.duration_type === 'forever'){
    couponInfo += coupon.duration_type
  } else {
    const applyTill = subscriptionCoupons.find((sCoupon) => sCoupon.coupon_id === coupon.id)?.apply_till;
    if (applyTill){
      couponInfo += `till ${moment.unix(applyTill).format('DD-MMM-YYYY')}`
    }

  }
  return couponInfo
}

const BillingSubscription = ({ isLoading, accountList, subscriptions, onCancel }) => {
  const dispatch = useDispatch()

  const [subscriptionIdToCancel, setSubscriptionIdToCancel] = useState(null)

  const handleCancel = (reason) => {
    return dispatch(cancelSubscription(subscriptionIdToCancel, reason)).then((subscription) => {
      onCancel(subscription)
      setSubscriptionIdToCancel(null)
      return subscription
    })
  }

  const renderSubscription = (subscription, _, index) => {
    const account = accountList.find(record => (
      record.subscription_id === subscription.id
    ))

    const timelines = []
    if (subscription.created_at) {
      timelines.push(`Signed up on `
        + `${moment.unix(subscription.created_at).format('DD-MMM-YYYY')}.`)
    }
    if (subscription.trial_start) {
      timelines.push(`Your trial period started on `
        + `${moment.unix(subscription.trial_start).format('DD-MMM-YYYY')}.`)
    }
    if (subscription.trial_end) {
      timelines.push(`Your trial expired on `
        + `${moment.unix(subscription.trial_end).format('DD-MMM-YYYY')}.`)
    }
    if (subscription.activated_at) {
      timelines.push(`Your subscription was activated on `
        + `${moment.unix(subscription.activated_at).format('DD-MMM-YYYY')}.`)
    }
    if (subscription.cancelled_at) {
      timelines.push(`Your subscription was (will be) cancelled on `
        + `${moment.unix(subscription.cancelled_at).format('DD-MMM-YYYY')}.`)
    }
    if (subscription.current_term_start && subscription.current_term_end) {
      timelines.push(`Your current billing term is `
        + `${moment.unix(subscription.current_term_start).format('DD-MMM-YYYY')} to `
        + `${moment.unix(subscription.current_term_end).format('DD-MMM-YYYY')}.`)
    }
    if (subscription.next_billing_at) {
      timelines.push(`Your next billing will be on `
        + `${moment.unix(subscription.next_billing_at).format('DD-MMM-YYYY')}.`)
    }
    if (subscription.billing_period && subscription.billing_period_unit) {
      timelines.push(`Your recurring charges every `
        + `${subscription.billing_period} ${subscription.billing_period_unit}(s).`)
    }

    let statusClass = ''
    if (subscription.status === 'active') {
      statusClass = 'status-active'
    } else if (subscription.status === 'cancelled' || !!subscription.cancelled_at) {
      statusClass = 'status-cancelled'
    }

    const planInfo = subscription.plan_id.indexOf('v2-new-pricing') < 0
      ? `${subscription.currency_code } ${ (subscription.plan_amount / 100).toFixed(2) }`
      : '2.9% of Ad Spend'

    const amountInfo = subscription.plan_id.indexOf('v2-new-pricing') < 0
      ? `${subscription.currency_code } ${ (subscription.plan_amount / 100).toFixed(2) }`
      : 'Calculated at End of cycle'

    return (
      <>
        <div className="table-col col-no">
          { index + 1 }
        </div>
        <div className="table-col col-account">
          { getAccountLabel(account) }<br/>
          <em>
            Subscription:<br/>{subscription.id}
          </em>
        </div>
        <div className={`table-col col-status ${statusClass}`}>
          { statusList[subscription.status] || subscription.status }
        </div>
        <div className="table-col col-amount">
          { planInfo }
        </div>
        <div className="table-col col-amount">
          <ul>
            { subscription.coupons.map((coupon, index) => (
              <li key={index}>
                {getCouponInfo(coupon, subscription.subscription_coupon)}
              </li>
            )) }
          </ul>
        </div>
        <div className="table-col col-amount">
          { amountInfo }
        </div>
        <div className="table-col col-timeline">
          <ul>
            { timelines.reverse().map((change, index) => (
              <li key={index}>
                { change }
              </li>
            )) }
          </ul>
        </div>
        <div className="table-col col-action">
          {
            (!subscription.cancelled_at) && (
              <a
                href="#"
                className="link-cancel"
                onClick={(event) => { event.preventDefault(); setSubscriptionIdToCancel(subscription.id) }}
              >
                Cancel
              </a>
            )
          }
        </div>
      </>
    )
  }

  const associatedSubscriptionIds = accountList.map(account => account.subscription_id)
  const filteredSubscriptions = subscriptions.filter(subscription => (
    associatedSubscriptionIds.indexOf(subscription.id) !== -1
  ))

  return (
    <CollapsibleSection title="Subscriptions">
      <CustomTable
        isLoading={isLoading}
        className="table-subscriptions"
        records={filteredSubscriptions}
        idField="id"
        noCheckBox
        noSearch
        renderRecord={renderSubscription}
      >
        <div className="table-col col-no">No.</div>
        <div className="table-col col-account">Account</div>
        <div className="table-col col-status">Status</div>
        <div className="table-col col-amount">Your Plan</div>
        <div className="table-col col-amount">Discount</div>
        <div className="table-col col-amount">Amount</div>
        <div className="table-col col-timeline">Timeline</div>
        <div className="table-col col-action"></div>
      </CustomTable>
      <CancellationModal
        show={subscriptionIdToCancel !== null}
        onCancel={handleCancel}
        onHide={() => { setSubscriptionIdToCancel(null) }}
      />
    </CollapsibleSection>
  )
}

export default BillingSubscription
