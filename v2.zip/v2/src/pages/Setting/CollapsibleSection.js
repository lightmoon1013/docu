import React, { useState } from 'react'

import { ReactComponent as CaretUpSvg } from '../../assets/svg/caret-up.svg'
import { ReactComponent as CaretDownSvg } from '../../assets/svg/caret-down.svg'

const CollapsibleSection = ({ title, topRight = null, children }) => {
  const [collapsed, setCollapsed] = useState(true)

  return (
    <div className="collapsible-section">
      <div className="collapsible-header">
        <div
          className="collapsible-title"
          onClick={() => { setCollapsed(!collapsed) }}
        >
          { title }
          { collapsed ? <CaretDownSvg /> : <CaretUpSvg /> }
        </div>
        { topRight }
      </div>
      {
        !collapsed && (
          <div className="collapsible-body">
            { children }
          </div>
        )
      }
    </div>
  )
}

export default CollapsibleSection
