import React, { useEffect, useState } from 'react'
import { useDispatch, useStore } from 'react-redux'
import { Tooltip, Whisper } from 'rsuite'

import { ReactComponent as InfoSvg } from '../../assets/svg/info.svg'

import LoaderComponent from '../../components/CommonComponents/LoaderComponent'
import VideoLink from '../../components/CommonComponents/VideoLink'
import { toast } from '../../components/CommonComponents/ToastComponent/toast'

import { saveUniversalSettings } from '../../redux/actions/auth'

const videoList = [
  { title: 'Search Term Optimization Video', url: 'https://www.loom.com/embed/22375f03637344ad8c8a3ed984aed1a4' },
]

const SectionUniversal = () => {
  const store = useStore().getState()
  const dispatch = useDispatch()

  const { header: { selectedUserInfo } } = store

  const [profitMargin, setProfitMargin] = useState(0)
  const [acos, setAcos] = useState(0)
  const [isSaving, setIsSaving] = useState(false)

  // Load current settings.
  useEffect(() => {
    if (!Object.keys(selectedUserInfo).length) {
      return
    }

    const { average_profit, average_acos } = selectedUserInfo
    setProfitMargin(parseFloat(average_profit || 0))
    setAcos(parseFloat(average_acos || 0))
  }, [selectedUserInfo])

  const handleSave = () => {
    if (profitMargin === '' || isNaN(profitMargin)) {
      toast.show({
        title: 'Warning',
        description: 'Please enter the Universal Profit Margin.',
      })
      return
    }

    if (acos === '' || isNaN(acos)) {
      toast.show({
        title: 'Warning',
        description: 'Please enter the Universal ACoS Target Zone.',
      })
      return
    }

    setIsSaving(true)
    dispatch(saveUniversalSettings({
      profitMargin: parseFloat(profitMargin),
      acos: parseFloat(acos),
    })).then(() => {
      setIsSaving(false)
    })
  }

  return (
    <div className={`page-section${isSaving ? ' loading' : ''}`}>
      { isSaving && <LoaderComponent /> }
      <div className="section-title">
        <span>Universal Values</span>
        <VideoLink
          videoList={videoList}
          modalTitle='Universal'
        />
      </div>
      <div className="section-contents section-universal">
        <div className="field-wrapper">
          <label>
            Universal Profit Margin %
            <Whisper placement="right" trigger="hover" speaker={(
              <Tooltip>
                <p>Used to determine profit margins ONLY for those SKU’s
                where a profit margin has not been set.</p>
                <p>To set the profit margin on an individual SKU,
                go to Command Center and update the COG.</p>
              </Tooltip>
            )}>
              <InfoSvg />
            </Whisper>
          </label>
          <input
            type="number"
            value={profitMargin}
            onChange={(event) => { setProfitMargin(event.target.value) }}
          />
        </div>
        <div className="field-wrapper">
          <label>
            Universal ACoS Target %
            <Whisper placement="right" trigger="hover" speaker={(
              <Tooltip>
                <p>We’ll use this as an ACoS target for campaigns that you have not set an ACoS target for.</p>
                <p>To set an ACoS target for a campaign, head to the command center.</p>
              </Tooltip>
            )}>
              <InfoSvg />
            </Whisper>
          </label>
          <input
            type="number"
            value={acos}
            onChange={(event) => { setAcos(event.target.value) }}
          />
        </div>
        <button
          type="button"
          className="btn btn-red"
          onClick={handleSave}
        >
          Save
        </button>
      </div>
    </div>
  )
}

export default SectionUniversal
