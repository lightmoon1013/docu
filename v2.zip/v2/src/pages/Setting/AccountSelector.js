// Used to select Amazon accounts to sign up additional Entourage accounts.
import React, { useMemo } from 'react'

import CustomTable from '../../components/CommonComponents/CustomTableComponent'

const AccountSelector = ({ profileList, accountList, selectedProfileIds, onSelect }) => {
  const extendedProfiles = useMemo(() => {
    const existingProfileIds = accountList.map(profile => parseInt(profile.profile_id, 10))
    return profileList.map(profile => (
      Object.assign({}, profile, {
        id: profile.accountInfo.id,
        name: profile.accountInfo.name,
        brandName: profile.accountInfo.brandName,
        className: existingProfileIds.indexOf(profile.profileId) !== -1 ? 'disabled' : '',
      })
    )).sort((a, b) => (
      a.countryCode.localeCompare(b.countryCode)
    ))
  }, [profileList, accountList])

  const handleSelect = (profileIds) => {
    const existingProfileIds = accountList.map(profile => parseInt(profile.profile_id, 10))
    const filtered = profileIds.filter(profileId => (
      existingProfileIds.indexOf(profileId) === -1
    ))
    onSelect(filtered)
  }

  const renderProfile = profile => (
    <>
      <div className="table-col col-country">
        { profile.countryCode.toUpperCase() }
      </div>
      <div className="table-col col-type">
        { profile.accountInfo.type }
      </div>
      <div className="table-col col-name" title={profile.accountInfo.name || profile.accountInfo.brandName}>
        { profile.accountInfo.name || profile.accountInfo.brandName }
      </div>
      <div className="table-col col-seller-id">
      { profile.accountInfo.id }
      </div>
    </>
  )

  return (
    <CustomTable
      className="table-accounts"
      records={extendedProfiles}
      idField="profileId"
      searchFields={['id', 'name', 'brandName']}
      selectedRecords={selectedProfileIds}
      paginationSelectPlacement="top"
      renderRecord={renderProfile}
      renderTopRight={() => (
        <div>
          Select additional accounts and then click on "Add Additional Accounts" below.
        </div>
      )}
      onChange={handleSelect}
    >
      <div className="table-col col-country">Country</div>
      <div className="table-col col-type">Type</div>
      <div className="table-col col-name">Name</div>
      <div className="table-col col-seller-id">Seller/Entity ID</div>
    </CustomTable>
  )
}

export default AccountSelector
