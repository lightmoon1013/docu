import React, { useState, useMemo } from 'react'
import { useStore } from 'react-redux'
import { CSVLink } from 'react-csv'
import moment from 'moment'

import MainLayout from '../../layout/MainLayout'

import AccountHealthComponent from '../../components/AccountHealthComponent'
import PdfComponent from '../../components/AccountHealthComponent/pdf'
import ReportCustomizer from './ReportCustomizer'

import {
  formatValue,
  formatCurrency,
  parseHealthKpi,
  parsePerformanceSummary,
} from '../../services/helper'

const mainMetricList = [
  { value: 'revenue', label: 'PPC Revenue', decimal: 2 },
  { value: 'sales', label: 'Organic Revenue', decimal: 2 },
  { value: 'acos', label: 'ACoS %', decimal: 2 },
  { value: 'cost', label: 'Ad Spend', decimal: 2 },
  { value: 'impressions', label: 'Impr.', decimal: 0 },
  { value: 'orders', label: 'Orders', decimal: 0 },
  { value: 'clicks', label: 'Clicks', decimal: 0 },
  { value: 'ctr', label: 'CTR %', decimal: 2 },
  { value: 'conv', label: 'Conversion', decimal: 2 },
  { value: 'totalCampaigns', label: 'Total PPC Campaigns', decimal: 0 },
  { value: 'totalKeywords', label: 'Total Keywords', decimal: 0 },
]

const pertMetricList = [
  { value: 'placement', label: 'Placement' },
  { value: 'bid-type', label: 'Bid Type' },
  { value: 'match-type', label: 'Match Type' },
]

const reportMetricList = [
  { value: 'auto-campaign', label: 'Auto Campaigns' },
  { value: 'manual-campaign', label: 'Manual Campaigns' },
  { value: 'campaign-product-target', label: 'Campaigns with Product Targeting' },
  { value: 'sponsored-brand-campaign', label: 'Sponsored Brand Campaigns' },
  { value: 'sponsored-brand-ad', label: 'Sponsored Display Ads' },
]

const AccountHealthPage = () => {
  const store = useStore().getState()

  const {
    header: {
      currencySign,
      currencyRate,
      currentStartDate,
    },
    health: {
      summaryData,
      isLoadingHealthData,
    },
  } = store

  const {
    placementSummary,
    matchTypeSummary,
  } = summaryData

  const [showCustomModal, setShowCustomModal] = useState(false)
  const [selectedMainMetrics, setSelectedMainMetrics] = useState(mainMetricList.map(data => data.value))
  const [selectedPerfMetrics, setSelectedPerfMetrics] = useState(pertMetricList.map(data => data.value))
  const [selectedReportMetrics, setSelectedReportMetrics] = useState(reportMetricList.map(data => data.value))

  const { kpiForThisMonth, kpiForPrevMonth } = useMemo(() => {
    return parseHealthKpi(summaryData)
  }, [summaryData])

  const { bidTotal, placementTotal } = useMemo(() => {
    return parsePerformanceSummary(placementSummary)
  }, [placementSummary])

  const csvToExport = useMemo(() => {
    const csvData = [['Metric', 'This Month', 'Pre Month']]

    mainMetricList.forEach((column) => {
      if (selectedMainMetrics.includes(column.value)) {
        csvData.push([
          column.label,
          formatValue(kpiForThisMonth[column.value], 'number', column.decimal),
          formatValue(kpiForPrevMonth[column.value], 'number', column.decimal),
        ])
      }
    })

    if (selectedPerfMetrics.includes('placement')) {
      csvData.push([])
      csvData.push(['Performance by Placement'])
      csvData.push([
        'Placement',
        'Impressions',
        'Clicks',
        'CTR %',
        'CPC',
        'Orders',
        'Sales',
        'ACoS %',
        'Conversion',
      ])
      csvData.push([
        'Top of search (first page)',
        formatValue(placementTotal['impressionsTop'], 'number', 0),
        formatValue(placementTotal['clicksTop'], 'number', 0),
        formatValue(placementTotal['ctrTop'], 'percent'),
        formatCurrency(placementTotal['cpcTop'], currencySign, currencyRate),
        formatValue(placementTotal['ordersTop'], 'number', 0),
        formatCurrency(placementTotal['revenueTop'], currencySign, currencyRate),
        formatValue(placementTotal['acosTop'], 'percent'),
        formatValue(placementTotal['convTop'], 'percent')
      ])
      csvData.push([
        'Product pages',
        formatValue(placementTotal['impressionsDetail'], 'number', 0),
        formatValue(placementTotal['clicksDetail'], 'number', 0),
        formatValue(placementTotal['ctrDetail'], 'percent'),
        formatCurrency(placementTotal['cpcDetail'], currencySign, currencyRate),
        formatValue(placementTotal['ordersDetail'], 'number', 0),
        formatCurrency(placementTotal['revenueDetail'], currencySign, currencyRate),
        formatValue(placementTotal['acosDetail'], 'percent'),
        formatValue(placementTotal['convDetail'], 'percent')
      ])
      csvData.push([
        'Rest of search',
        formatValue(placementTotal['impressionsOther'], 'number', 0),
        formatValue(placementTotal['clicksOther'], 'number', 0),
        formatValue(placementTotal['ctrOther'], 'percent'),
        formatCurrency(placementTotal['cpcOther'], currencySign, currencyRate),
        formatValue(placementTotal['ordersOther'], 'number', 0),
        formatCurrency(placementTotal['revenueOther'], currencySign, currencyRate),
        formatValue(placementTotal['acosOther'], 'percent'),
        formatValue(placementTotal['convOther'], 'percent')
      ])
    }

    if (selectedPerfMetrics.includes('bid-type')) {
      csvData.push([])
      csvData.push(['Performance by Bid Type'])
      csvData.push([
        'Bid Type',
        'Impressions',
        'Clicks',
        'CTR %',
        'CPC',
        'Orders',
        'Sales',
        'ACoS %',
        'Conversion'
      ])
      csvData.push([
        'Dynamic bids - down only',
        formatValue(bidTotal['impressionsLegacy'], 'number', 0),
        formatValue(bidTotal['clicksLegacy'], 'number', 0),
        formatValue(bidTotal['ctrLegacy'], 'percent'),
        formatCurrency(bidTotal['cpcLegacy'], currencySign, currencyRate),
        formatValue(bidTotal['ordersLegacy'], 'number', 0),
        formatCurrency(bidTotal['revenueLegacy'], currencySign, currencyRate),
        formatValue(bidTotal['acosLegacy'], 'percent'),
        formatValue(bidTotal['convLegacy'], 'percent')
      ])
      csvData.push([
        'Dynamic bids - up and down',
        formatValue(bidTotal['impressionsAuto'], 'number', 0),
        formatValue(bidTotal['clicksAuto'], 'number', 0),
        formatValue(bidTotal['ctrAuto'], 'percent'),
        formatCurrency(bidTotal['cpcAuto'], currencySign, currencyRate),
        formatValue(bidTotal['ordersAuto'], 'number', 0),
        formatCurrency(bidTotal['revenueAuto'], currencySign, currencyRate),
        formatValue(bidTotal['acosAuto'], 'percent'),
        formatValue(bidTotal['convAuto'], 'percent')
      ])
      csvData.push([
        'Fixed Bid',
        formatValue(bidTotal['impressionsManual'], 'number', 0),
        formatValue(bidTotal['clicksManual'], 'number', 0),
        formatValue(bidTotal['ctrManual'], 'percent'),
        formatCurrency(bidTotal['cpcManual'], currencySign, currencyRate),
        formatValue(bidTotal['ordersManual'], 'number', 0),
        formatCurrency(bidTotal['revenueManual'], currencySign, currencyRate),
        formatValue(bidTotal['acosManual'], 'percent'),
        formatValue(bidTotal['convManual'], 'percent')
      ])
    }

    if (selectedPerfMetrics.includes('match-type')) {
      csvData.push([])
      csvData.push(['Performance by Match Type'])
      csvData.push([
        'Match Type',
        'Impressions',
        'Clicks',
        'CTR %',
        'CPC',
        'Orders',
        'Sales',
        'ACoS %',
        'Conversion'
      ]);
      (matchTypeSummary || []).forEach((data) => {
        const ctr = data.impressions ? data.clicks / data.impressions * 100.0 : 0
        const acos = data.revenue ? data.cost / data.revenue * 100.0 : 0
        const conv = data.clicks ? data.orders / data.clicks * 100.0 : 0
        const cpc = data.clicks ? data.cost / data.clicks : 0

        csvData.push([
          data.match_type.charAt(0).toUpperCase() + data.match_type.slice(1),
          formatValue(data['impressions'], 'number', 0),
          formatValue(data['clicks'], 'number', 0),
          formatValue(ctr, 'percent'),
          formatCurrency(cpc, currencySign, currencyRate),
          formatValue(data['orders'], 'number', 0),
          formatCurrency(data['revenue'], currencySign, currencyRate),
          formatValue(acos, 'percent'),
          formatValue(conv, 'percent')
        ])
      })
    }

    return csvData
  }, [selectedMainMetrics, kpiForThisMonth, kpiForPrevMonth,
    selectedPerfMetrics, placementTotal, bidTotal,
    matchTypeSummary, currencySign, currencyRate])

  // if (selectedReportMetrics.includes('auto-campaigns')) {
  //   csvData.push([])
  //   csvData.push(['Auto Campaigns'])
  //   csvData.push([
  //     'Campaigns',
  //     'Target ACoS',
  //     'Actual ACoS',
  //     'ACoS change from last month',
  //     'Sales',
  //     'Sales from last month',
  //     'Impressions',
  //     'Impressions from last month',
  //     'Clicks',
  //     'Clicks from last month',
  //     'CTR %',
  //     'CTR % from last month',
  //     'Conversion',
  //     'Conversion from last month'
  //   ])
  // }

  // if (selectedReportMetrics.includes('manual-campaigns')) {
  //   csvData.push([])
  //   csvData.push(['Manual Campaigns'])
  //   csvData.push([
  //     'Campaigns',
  //     'Target ACoS',
  //     'Actual ACoS',
  //     'ACoS change from last month',
  //     'Sales',
  //     'Sales from last month',
  //     'Impressions',
  //     'Impressions from last month',
  //     'Clicks',
  //     'Clicks from last month',
  //     'CTR %',
  //     'CTR % from last month',
  //     'Conversion',
  //     'Conversion from last month'
  //   ])
  // }

  // if (selectedReportMetrics.includes('campaign-product-target')) {
  //   csvData.push([])
  //   csvData.push(['Campaign with Product Targeting'])
  //   csvData.push([
  //     'Campaigns',
  //     'Target ACoS',
  //     'Actual ACoS',
  //     'ACoS change from last month',
  //     'Sales',
  //     'Sales from last month',
  //     'Impressions',
  //     'Impressions from last month',
  //     'Clicks',
  //     'Clicks from last month',
  //     'CTR %',
  //     'CTR % from last month',
  //     'Conversion',
  //     'Conversion from last month'
  //   ])
  // }

  // if (selectedReportMetrics.includes('sponsored-brand-campaign')) {
  //   csvData.push([])
  //   csvData.push(['Sponsored Brand Campaigns'])
  //   csvData.push([
  //     'Campaigns',
  //     'Target ACoS',
  //     'Actual ACoS',
  //     'ACoS change from last month',
  //     'Sales',
  //     'Sales from last month',
  //     'Impressions',
  //     'Impressions from last month',
  //     'Clicks',
  //     'Clicks from last month',
  //     'CTR %',
  //     'CTR % from last month',
  //     'Conversion',
  //     'Conversion from last month'
  //   ])
  // }

  // if (selectedReportMetrics.includes('sponsored-brand-ad')) {
  //   csvData.push([])
  //   csvData.push(['Sponsored Display Ads'])
  //   csvData.push([
  //     'Campaigns',
  //     'Target ACoS',
  //     'Actual ACoS',
  //     'ACoS change from last month',
  //     'Sales',
  //     'Sales from last month',
  //     'Impressions',
  //     'Impressions from last month',
  //     'Clicks',
  //     'Clicks from last month',
  //     'CTR %',
  //     'CTR % from last month',
  //     'Conversion',
  //     'Conversion from last month'
  //   ])
  // }

  const reportMonthName = moment(currentStartDate).format('MMMM')
  const reportYear = moment(currentStartDate).year()

  return (
    <MainLayout>
      <div className="account-health-page">
        <div className="page-header">
          <div className="page-title">Account Health</div>
          <div className="button-container">
            <button
              type="button"
              className="btn btn-red"
              onClick={() => { setShowCustomModal(true) }}
            >
              Customize Report
            </button>
            <PdfComponent
              summaryData={summaryData}
              mainMetrics={mainMetricList}
              currencyRate={currencyRate}
              currencySign={currencySign}
              matchTypes={matchTypeSummary}
              reportMonthName={reportMonthName}
              reportYear={reportYear}
              selectedMainMetrics={selectedMainMetrics}
              selectedPerfMetrics={selectedPerfMetrics}
              selectedReportMetrics={selectedReportMetrics}
              disabled={isLoadingHealthData}
            />
            <CSVLink
              data={csvToExport}
              filename={`Account Summary (${reportMonthName}, ${reportYear}).csv`}
              className={`btn btn-red${isLoadingHealthData ? ' disabled' : ''}`}
            >
              CSV
            </CSVLink>
          </div>
        </div>
        <div className="page-content">
          <AccountHealthComponent />
        </div>
      </div>
      <ReportCustomizer
        show={showCustomModal}
        mainMetrics={mainMetricList}
        perfMetrics={pertMetricList}
        reportMetrics={reportMetricList}
        selectedMainMetrics={selectedMainMetrics}
        selectedPerfMetrics={selectedPerfMetrics}
        selectedReportMetrics={selectedReportMetrics}
        onSelectMainMetrics={setSelectedMainMetrics}
        onSelectPerfMetrics={setSelectedPerfMetrics}
        onSelectReportMetrics={setSelectedReportMetrics}
        onClose={() => { setShowCustomModal(false) }}
      />
    </MainLayout>
  )
}

export default AccountHealthPage
