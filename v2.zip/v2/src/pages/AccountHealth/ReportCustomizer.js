import React, { useState } from 'react'
import { Modal } from 'rsuite'
import CheckboxComponent from '../../components/CommonComponents/CheckboxComponent'

const TAB_MAIN = 'metric'
const TAB_PERF = 'performance'
const TAB_REPORT = 'report'

const tabList = [
  { key: TAB_MAIN, name: 'Main Metrics' },
  { key: TAB_PERF, name: 'Performance By' },
  // { key: TAB_REPORT, name: 'Campaign Reports' },
]

const ReportCustomizer = ({
  show,
  mainMetrics,
  perfMetrics,
  reportMetrics,
  selectedMainMetrics,
  selectedPerfMetrics,
  selectedReportMetrics,
  onSelectMainMetrics,
  onSelectPerfMetrics,
  onSelectReportMetrics,
  onClose,
}) => {
  const [currentTab, setCurrentTab] = useState(TAB_MAIN)

  const handleMainMetricSelect = (metric, checked) => {
    let metrics = [...selectedMainMetrics]
    if (checked) {
      metrics.push(metric)
    } else {
      metrics = metrics.filter(m => m !== metric)
    }
    onSelectMainMetrics(metrics)
  }

  const handlePerfMetricSelect = (metric, checked) => {
    let metrics = [...selectedPerfMetrics]
    if (checked) {
      metrics.push(metric)
    } else {
      metrics = metrics.filter(m => m !== metric)
    }
    onSelectPerfMetrics(metrics)
  }

  const handleReportMetricSelect = (metric, checked) => {
    let metrics = [...selectedReportMetrics]
    if (checked) {
      metrics.push(metric)
    } else {
      metrics = metrics.filter(m => m !== metric)
    }
    onSelectReportMetrics(metrics)
  }

  const handleReset = () => {
    onSelectMainMetrics(mainMetrics.map(metric => metric.value))
    onSelectPerfMetrics(perfMetrics.map(metric => metric.value))
    onSelectReportMetrics(reportMetrics.map(metric => metric.value))
    onClose()
  }

  return (
    <Modal className="health-report-customizer" show={show}>
      <Modal.Body>
        <div className="tab-list">
          {
            tabList.map(tab => (
              <span
                key={tab.key}
                className={tab.key === currentTab ? 'selected' : ''}
                onClick={() => setCurrentTab(tab.key)}
              >
                { tab.name }
              </span>
            ))
          }
        </div>
        <div className="metric-list">
          <div>Available metrics</div>
          {
            currentTab === TAB_MAIN &&
            mainMetrics.map(metric => (
              <CheckboxComponent
                key={metric.value}
                label={metric.label}
                checked={selectedMainMetrics.includes(metric.value)}
                onChange={(checked) => { handleMainMetricSelect(metric.value, checked) }}
              />
            ))
          }
          {
            currentTab === TAB_PERF &&
            perfMetrics.map(metric => (
              <CheckboxComponent
                key={metric.value}
                label={metric.label}
                checked={selectedPerfMetrics.includes(metric.value)}
                onChange={(checked) => { handlePerfMetricSelect(metric.value, checked) }}
              />
            ))
          }
          {
            currentTab === TAB_REPORT &&
            reportMetrics.map(metric => (
              <CheckboxComponent
                key={metric.value}
                label={metric.label}
                checked={selectedReportMetrics.includes(metric.value)}
                onChange={(checked) => { handleReportMetricSelect(metric.value, checked) }}
              />
            ))
          }
        </div>
      </Modal.Body>
      <Modal.Footer>
        <button type="button" className="rs-btn rs-btn-primary" onClick={handleReset}>
          Reset
        </button>
        <button type="button" className="rs-btn rs-btn-subtle" onClick={() => { onClose() }}>
          Close
        </button>
      </Modal.Footer>
    </Modal>
  )
}

export default ReportCustomizer
