import React from 'react'
import { Switch, Route, useRouteMatch } from 'react-router-dom'

import MainLayout from '../../layout/MainLayout'

import CommandCenter from '../../components/CommandCenterComponent'
import SPCampaignCreator from '../../components/CampaignCreator/SPCampaignCreator'
import SDCampaignCreator from '../../components/CampaignCreator/SDCampaignCreator'
import SBCampaignCreator from '../../components/CampaignCreator/SBCampaignCreator'

const CampaignPage = () => {
  const match = useRouteMatch()

  return (
    <MainLayout>
      <Switch>
        <Route
          path={`${match.url}/`}
          component={CommandCenter}
          exact
        />
        <Route
          path={`${match.url}/new/sp`}
          component={SPCampaignCreator}
          exact
        />
        <Route
          path={`${match.url}/new/sd`}
          component={SDCampaignCreator}
          exact
        />
        <Route
          path={`${match.url}/new/sb`}
          component={SBCampaignCreator}
          exact
        />
      </Switch>
    </MainLayout>
  )
}

export default CampaignPage
