import React, { useState } from 'react'
import { useDispatch, useStore } from 'react-redux'
import { Redirect, Link } from 'react-router-dom'

import { askPasswordReset } from '../../redux/actions/auth'

import EmailSvg from '../../assets/svg/login/email.svg'
import PilotSvg from '../../assets/svg/login/pilot.svg'

import AuthSideComponent from '../../components/AuthSideComponent'
import LoaderComponent from '../../components/CommonComponents/LoaderComponent'
import { toast } from '../../components/CommonComponents/ToastComponent/toast'

const ForgotPasswordPage = () => {
  const dispatch = useDispatch()
  const store = useStore()

  const { isLoggedIn } = store.getState().auth

  const [email, setEmail] = useState('')
  const [isSending, setIsSending] = useState(false)
  const [isSent, setIsSent] = useState(false)

  const onReset = (event) => {
    event.preventDefault()

    setIsSending(true)
    dispatch(askPasswordReset(email)).then(() => {
      setIsSending(false)
      setIsSent(true)
    }).catch(() => {
      setIsSending(false)
      toast.show({
        title: 'Danger',
        description: 'Failed to send an email.',
      })
    })
  }

  if (isLoggedIn) {
    return (
      <Redirect
        to='/dashboard'
      />
    )
  }

  const renderContents = () => {
    if (!isSent) {
      return (
        <form className="auth-form" onSubmit={onReset}>
          <div className="form-title">
            Reset your password
          </div>
          <div className="form-note">
            Enter your user account's verified email address<br />
            and we will send you a password reset link.
          </div>
          <div className="login-email">
            <img src={EmailSvg} alt="email" />
            <input
              type="email"
              placeholder="Enter your email address"
              value={email}
              onChange={(event) => { setEmail(event.target.value) }}
            />
          </div>
          <button type="submit" className="btn btn-red" disabled={isSending || !email}>
            Send password reset email
          </button>
        </form>
      )
    }

    return (
      <div className="auth-form">
        <div className="form-note">
          Check your email for a link to reset your password.<br />
          If it doesn’t appear within a few minutes, check your spam folder.
        </div>
        <Link to="/login">Return to login</Link>
      </div>
    )
  }

  return (
    <div className="auth-layout">
      <AuthSideComponent>
        <img src={PilotSvg} alt="Smart Pilot Manager" />
        <div className="side-pilot-title">Smart Pilot Manager</div>
        <div>
          Now with customizable templates, the all new Smart Pilot allows you
          to make smarter and faster bid optimizations.
        </div>
      </AuthSideComponent>
      <div className={`auth-page${isSending ? ' loading' : ''}`}>
        {isSending && <LoaderComponent />}
        { renderContents() }
      </div>
    </div>
  )
}

export default ForgotPasswordPage
