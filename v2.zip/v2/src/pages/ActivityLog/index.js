import React, { useEffect, useMemo, useState } from 'react'
import { useDispatch, useStore } from 'react-redux'
import moment from 'moment'

import MainLayout from '../../layout/MainLayout'
import APMComponent from '../../components/APMComponent'
import TemplateEditorComponent from '../../components/TemplateEditorComponent'
import LoaderComponent from '../../components/CommonComponents/LoaderComponent'
import PageHeader from './PageHeader'
import Header from './Header'
import LogTable from './LogTable'

import {
  getActivityLog,
} from '../../redux/actions/activityLog'

import { filterLogs } from '../../services/helper'

const TAB_ALL = 'All'
const TAB_AP = 'Smart Pilot'

const ActivityLog = () => {
  const dispatch = useDispatch()
  const store = useStore()

  const {
    activityLog: {
      isLoading,
      logs,
    },
    campaignLog: {
      isRevertingLog,
    },
    pageGlobal: {
      showAPM,
      showTemplateEditor
    },
    header: {
      currentUserId,
    }
  } = store.getState()

  const [activeTab, setActiveTab] = useState(TAB_ALL)
  const [currentType, setCurrentType] = useState('')
  const [range, setRange] = useState([
    moment().subtract(14, 'days'),
    moment(),
  ])

  useEffect(() => {
    dispatch(getActivityLog(range[0], range[1]))
  }, [range, currentUserId]) // eslint-disable-line

  const handleTabChange = tab => (event) => {
    event.preventDefault()
    setActiveTab(tab)
  }

  let filteredLogs = useMemo(() => {
    return filterLogs(logs || [], currentType)
  }, [logs, currentType])

  if (activeTab === TAB_AP) {
    filteredLogs = filteredLogs.filter(log => (
      (log.log_type || '').indexOf('ap_') === 0
    ))
  }

  const groupedLogs = {}
  filteredLogs.forEach((log) => {
    const key = `${moment(log.created_at).local().startOf('day').valueOf()}-${log.name}`
    groupedLogs[key] = (groupedLogs[key] || []).concat([log])
  })

  const flattenGroups = []
  Object.keys(groupedLogs).sort().reverse().forEach((key) => {
    flattenGroups.push({
      key,
      logs: groupedLogs[key],
    })
  })

  return (
    <MainLayout>
      <div className="activity-log">
        <PageHeader />
        <div className={`page-content ${isLoading ? 'loading' : ''}`}>
          { isLoading && <LoaderComponent /> }
          { showAPM && <APMComponent /> }
          { showTemplateEditor && <TemplateEditorComponent /> }
          <Header
            tabList={[TAB_ALL, TAB_AP]}
            activeTab={activeTab}
            currentType={currentType}
            range={range}
            onTabChange={handleTabChange}
            onTypeChange={setCurrentType}
            onRangeChange={setRange}
          />
          <LogTable
            logs={flattenGroups}
            isRevertingLog={isRevertingLog}
          />
        </div>
      </div>
    </MainLayout>
  )
}

export default ActivityLog
