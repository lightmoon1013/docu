/* eslint-disable jsx-a11y/anchor-is-valid */
import React from 'react'
import Select from 'react-select'

import DateRangeComponent from '../../components/CommonComponents/DateRangeComponent'

import { logTypeOptions } from '../../utils/defaultValues'

const Header = ({ tabList, activeTab, currentType, range,
  onTabChange, onTypeChange, onRangeChange }) => {
  return (
    <div className="header-container">
      <div className="tab-container">
        {
          tabList.map(tab => (
            <a
              key={tab}
              href="#"
              className={tab === activeTab ? 'active' : ''}
              onClick={onTabChange(tab)}
            >
              { tab }
            </a>
          ))
        }
      </div>
      <div className="filter-container">
        <Select
          className="type-selector"
          value={currentType}
          options={logTypeOptions}
          onChange={onTypeChange}
        />
        <DateRangeComponent
          placement="bottomEnd"
          value={range}
          onChange={onRangeChange}
        />
      </div>
    </div>
  )
}

export default Header
