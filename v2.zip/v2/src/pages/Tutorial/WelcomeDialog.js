import React, { useState, useEffect } from 'react'
import { useStore } from 'react-redux'
import { Modal } from 'rsuite'
import moment from 'moment'

import { ReactComponent as UnionSvg } from '../../assets/svg/login/union.svg'
import WelcomeBgSvg from '../../assets/svg/welcome-bg.svg'
import WelcomeTimerSvg from '../../assets/svg/welcome-timer.svg'

const TIMER_LIMIT = 24 * 60 * 60

const STORAGE_KEY_FOR_HIDE = 'hide_welcome_dialog'

const WelcomeDialog = () => {
  const store = useStore()
  const { user: currentUser } = store.getState().auth

  const [timeLeft, setTimeLeft] = useState(null)
  const [showVideo, setShowVideo] = useState(false)

  useEffect(() => {
    if (!currentUser.created_at) {
      return
    }

    const createdTime = moment.utc(currentUser.created_at).local()
    const hoursSinceSignup = moment().diff(createdTime, 'second')
    if (hoursSinceSignup >= TIMER_LIMIT) {
      return
    }

    setTimeLeft(TIMER_LIMIT - hoursSinceSignup)
    const interval = setInterval(() => {
      setTimeLeft(prev => prev - 1)
    }, 1000 * 60)

    return () => {
      clearInterval(interval)
    }
  }, []) // eslint-disable-line

  useEffect(() => {
    if (showVideo) {
      let script = document.createElement('script')
      script.src = '//fast.wistia.com/assets/external/E-v1.js'
      script.async = true
      document.head.appendChild(script)

      script = document.createElement('script')
      script.src = '//fast.wistia.com/embed/medias/uabmk40d40.jsonp'
      script.async = true
      document.head.appendChild(script)
    }
  }, [showVideo])

  const handleHide = () => {
    localStorage.setItem(STORAGE_KEY_FOR_HIDE, 'true')
    setShowVideo(true)
  }

  if (showVideo) {
    return (
      <Modal className="welcome-video-dialog" backdrop="static" show>
        <div className="wistia_responsive_padding">
          <div className="wistia_responsive_wrapper">
            <div className="wistia_embed wistia_async_uabmk40d40 autoPlay=true">
              &nbsp;
            </div>
          </div>
        </div>
        <div className="close-button-container">
          <button
            type="button"
            className="btn btn-white"
            onClick={() => { setShowVideo(false) }}
          >
            Close
          </button>
        </div>
      </Modal>
    )
  }

  if (!timeLeft || localStorage.getItem(STORAGE_KEY_FOR_HIDE) !== null) {
    return null
  }

  let hour = Math.floor(timeLeft / 3600)
  if (hour < 10) {
    hour = `0${hour}`
  }

  let minute = Math.floor((timeLeft % 3600) / 60)
  if (minute < 10) {
    minute = `0${minute}`
  }

  return (
    <Modal className="welcome-dialog" backdrop="static" show>
      <div className="left-section">
        <img className="left-bg" src={WelcomeBgSvg} alt="Background" />
        <UnionSvg />
        <div className="timer-image-wrapper">
          <img src={WelcomeTimerSvg} alt="Timer" />
        </div>
        <div className="timer-contents">
          <div className="timer-heading">
            Your data will arrive
          </div>
          <div className="timer-subheading">
            in less than
          </div>
          <div className="timer-value">
            {hour}:{minute}
          </div>
        </div>
      </div>
      <div className="right-section">
        <div className="welcome-heading">
          Welcome to the PPC Entourage Family!
        </div>
        <div className="welcome-email">
          We'll email you as soon as your data has arrived
        </div>
        <div className="welcome-subheading">
          In the meantime...
        </div>
        <div className="welcome-description">
          Watch the welcome video and finish the <strong>Quick Results Flow</strong>.
          This way, you'll be ready to take action as soon as your data comes.
          You'll also earn some Genius Coins which you can redeem
          in the marketplace for cool things like ad creatives, coaching and more.
        </div>
        <div className="button-container">
          <button type="button" className="btn btn-blue" onClick={handleHide}>
            Watch the Welcome Video!
          </button>
        </div>
      </div>
    </Modal>
  )
}

export default WelcomeDialog
