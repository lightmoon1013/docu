import React from 'react'

import FlowContainer from './FlowContainer'
import AttachmentList from './AttachmentList'
import VideoCollection from './VideoCollection'

const attachments = [
  { name: 'Quick Start Flow.pdf', url: 'https://drive.google.com/file/d/1AgUQOlwwGoTKrjaskraXmI8Hvpfzg7ZE/view?usp=sharing' },
]

const videoList = [
  {
    name: 'Quick Start Flow. Let\'s Go!',
    videoId: 'di1ku6gb64',
    url: '//fast.wistia.com/embed/medias/di1ku6gb64.jsonp',
  },
]

const QuickStartFlow = ({ onWatch, ...props }) => {
  return (
    <FlowContainer
      name="Quick Start Flow"
      coin={10}
      {...props}
    >
      <VideoCollection videoList={videoList} onWatch={onWatch}/>
      <div className="flow-timestamps">
        <div className="timestamp-section">
          <div className="title">Quick Start Flow</div>
          <div className="content">
            <span className="timestamp">Genius Coins & Marketplace 0:30</span>
            <span className="timestamp">Dashboards 1:23</span>
            <span className="timestamp">Command Center: My Campaigns 4:17</span>
            <span className="timestamp">Campaign History 8:34</span>
            <span className="timestamp">Command Center: My Products 10:39</span>
          </div>
        </div>
      </div>
      <div className="flow-text">
        <p><strong>Welcome to the Quick Start Flow.</strong></p>
        <p>If you're reading this, it's probably because you are new to Entourage 2.0 and
          are looking for the FASTEST way to learn the software and to start getting results.</p>
        <p>We have good news! The Quick Start Flow is a short tutorial that will teach you exactly how to get started with ease.</p><br/>
        <p><strong>After finishing this flow, you'll be able to</strong></p>
        <ol>
          <li>1) Know what Costs of Goods are (COGS) and how to enter them into the Entourage 2.0 system.</li>
          <li>2) Learn how to customize dashboards to help you drill down into the data with ease.</li>
          <li>3) Learn How to set your target ACOS so that our system can help you optimize in seconds.</li>
          <li>4) Set up customized columns across multiple tables and use the filtering system.</li>
          <li>5) Locate the Smart Pilot, Activity log, Campaign Dashboard, Product Dashboard and more.</li>
        </ol>
        <p>You'll earn an additional 10 Genius Coins for finishing this flow. Let's get started!</p>
      </div>
      <AttachmentList attachments={attachments} />
    </FlowContainer>
  )
}

export default QuickStartFlow
