import React from 'react'

import FlowContainer from './FlowContainer'

const ProductDashboardFlow = ({ onWatch, ...props }) => {
  return (
    <FlowContainer
      name="Product Dashboard Flow (Coming Soon)"
      {...props}
    >
      <div className="flow-timestamps">
        <div className="timestamp-section">
          <div className="title">Product Dashboard</div>
        </div>
        <div className="timestamp-section">
          <div className="title">Keyword Tracking</div>
        </div>
        <div className="timestamp-section">
          <div className="title">A/B testing</div>
        </div>
        <div className="timestamp-section">
          <div className="title">Customer Buying Cycle Cheat Sheet</div>
        </div>
        <div className="timestamp-section">
          <div className="title">Lifecycle of product Advertising and Budget</div>
        </div>
        <div className="timestamp-section">
          <div className="title">Finding Your Audience</div>
        </div>
        <div className="timestamp-section">
          <div className="title">Filling the Advertising Gaps with The Playbook</div>
        </div>
      </div>
      <div className="flow-text">
        <p><strong>Did you know that each product has a dashboard inside of Entourage 2.0 is equipped with a keyword tracker tool?</strong></p>
        <p>The all new product dashboard will allow you to see how how each product is performing with Amazon Advertising.</p>
        <p>We'll help you keep track of vital metrics to maximize performance of each product so you can increase sales.</p>
        <p>Let's go!</p>
      </div>
    </FlowContainer>
  )
}

export default ProductDashboardFlow
