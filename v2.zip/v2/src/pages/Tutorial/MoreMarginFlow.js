import React from 'react'

import FlowContainer from './FlowContainer'
import VideoCollection from './VideoCollection'

const videoList = [
  {
    name: 'Margin Sku',
    videoId: 'dxtdb4yklk',
    url: '//fast.wistia.com/embed/medias/dxtdb4yklk.jsonp',
  },
  {
    name: 'Margin Sales',
    videoId: 'dejgkqzmxw',
    url: '//fast.wistia.com/embed/medias/dejgkqzmxw.jsonp',
  },
  {
    name: 'Margin Fees',
    videoId: '827id2vvhl',
    url: '//fast.wistia.com/embed/medias/827id2vvhl.jsonp',
  },
]

const MoreMarginFlow = ({ onWatch, ...props }) => {
  return (
    <FlowContainer
      name="More Margins Flow"
      coin={10}
      {...props}
    >
      <VideoCollection videoList={videoList} onWatch={onWatch}/>
      <div className="flow-text">
        <p><strong>You can't have a business without solid margins and it is our goal to help you maximize yours!</strong></p>
        <p>Entourage 2.0 comes with the Margins tool, which is like an x-ray machine into the profitability of your business.</p>
        <p>Find out exactly where your business is bleeding money and what to do about it!</p>
        <p>Please note, Entourage 2.0 will be adding the Margins tool directly inside of the UI soon.</p>
        <p>Stay tuned for more details! Get access to Margins tool for free by signing up here {"-->"} <a href="https://ppcentourage.com/the-margins-tool/" target="_blank" rel="noopener noreferrer">https://ppcentourage.com/the-margins-tool/.</a></p>
        <p>FOR FREE ACCESS, USE THE COUPON CODE: MARGINS2</p>
      </div>
    </FlowContainer>
  )
}

export default MoreMarginFlow
