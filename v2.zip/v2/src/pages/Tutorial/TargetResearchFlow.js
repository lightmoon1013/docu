import React from 'react'

import FlowContainer from './FlowContainer'
import AttachmentList from './AttachmentList'
import VideoCollection from './VideoCollection'

const attachments = [
  { name: 'PPC Entourage Keyword/Target Research Cheat Sheet.csv', url: 'https://docs.google.com/spreadsheets/d/1ku9rEtCIbnZYcD2L4w5c529UJ3RjRsIrVlWjZvl-otA/edit#gid=1894739068' },
]

const videoList = [
  {
    name: '10 Steps for Keyword Research for Amazon Advertising',
    videoId: '7fzk1sz6ln',
    url: '//fast.wistia.com/embed/medias/7fzk1sz6ln.jsonp',
  },
  {
    name: 'How to Improve your Amazon Advertising with PRO Level ASIN Targeting!',
    videoId: 'ftsssm5p1a',
    url: '//fast.wistia.com/embed/medias/ftsssm5p1a.jsonp',
  },
  {
    name: 'How to Effectively Identify & Target Your Audience with Amazon Advertising',
    videoId: 'y4tcgu9hpc',
    url: '//fast.wistia.com/embed/medias/y4tcgu9hpc.jsonp',
  },
]

const TargetResearchFlow = ({ onWatch, ...props }) => {
  return (
    <FlowContainer
      name="Keyword and Target Research Flow"
      {...props}
    >
      <AttachmentList attachments={attachments} />
      <div className="flow-text">
        <p><strong>Keyword and ASINS (targets) are the lifeblood of Amazon Advertising.</strong></p>
        <p>It is our mission to help you find the most relevant and profitable targets for your campaigns.</p>
        <p>In this flow, we'll dive into a few tools and strategies that we use and give you a cheat sheet that you can use to find great targets.</p>
      </div>
      <VideoCollection videoList={videoList} onWatch={onWatch}/>
    </FlowContainer>
  )
}

export default TargetResearchFlow
