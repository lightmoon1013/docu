import React from 'react'

import FlowContainer from './FlowContainer'

const ExpansionBasicFlow = ({ onWatch, ...props }) => {
  return (
    <FlowContainer
      name="Expansion Basics Flow (Coming Soon)"
      {...props}
    >
      <div className="flow-timestamps">
        <div className="timestamp-section">
          <div className="title">Setting up campaigns inside of Entourage</div>
        </div>
        <div className="timestamp-section">
          <div className="title">Finding New Targets</div>
        </div>
        <div className="timestamp-section">
          <div className="title">Search Term Expansion</div>
        </div>
        <div className="timestamp-section">
          <div className="title">ASIN Expansion</div>
        </div>
        <div className="timestamp-section">
          <div className="title">Category Expansion</div>
        </div>
        <div className="timestamp-section">
          <div className="title">Bid Expansion</div>
        </div>
      </div>
      <div className="flow-text">
        <p><strong>Now that you have found relevant targets, you can use them along with the Entourage 2.0 Playbook Series to set up some great campaigns for all ad types!</strong></p>
        <p>You'll notice that one of the core principles inside of the Playbook is finding hidden treasures (in the form of converted search terms and ASINS) from the search term report.</p>
        <p>In this flow, we'll show you how to find and take action with that treasure inside of the Entourage 2.0 tool.</p>
        <p>Let's go treasure hunting!</p>
      </div>
    </FlowContainer>
  )
}

export default ExpansionBasicFlow
