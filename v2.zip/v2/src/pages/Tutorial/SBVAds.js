import React from 'react'

import FlowContainer from './FlowContainer'
import AttachmentList from './AttachmentList'

const topAttachments = [
  { name: 'Entourage 2.0 Playbook.pdf', url: 'https://go.ppcentourage.com/hubfs/Amazon%20Ads%20Playbook%20Series%20V2%202021.pdf?hsLang=en' },
]

const SBVAds = ({ ...props }) => {
  return (
    <FlowContainer
      name="Sponsored Brand Video Ads (Coming Soon)"
      {...props}
    >
      <AttachmentList attachments={topAttachments} />
    </FlowContainer>
  )
}

export default SBVAds
