import React from 'react'
import Select from 'react-select'
import { useLocation } from 'react-router-dom'

import { SP_APP_ID, SP_BETA } from '../../config/api'

import { ReactComponent as InfoSvg } from '../../assets/svg/info.svg'

import LoaderComponent from '../../components/CommonComponents/LoaderComponent'
import AccountSelector from './AccountSelector'

import { sellerCentralUrls } from '../../utils/defaultValues'

const AmazonSection = (props) => {
  const { isLoading, spRefreshToken, adRefreshToken, region, regionList,
    profileList, selectedProfileIds, onChange, onSelectProfileIds } = props

  const location = useLocation()

  const handleClickGrantAccess = () => {
    window.gtag('event', 'singup_region_select_button')
  }
  const renderContents = () => {
    if (spRefreshToken && adRefreshToken) {
      return (
        <AccountSelector
          profileList={profileList}
          selectedProfileIds={selectedProfileIds}
          onSelect={onSelectProfileIds}
        />
      )
    }

    const qs = new URLSearchParams(location.search)
    const callbackUrl = qs.get('amazon_callback_uri')

    if (isLoading || callbackUrl || spRefreshToken || adRefreshToken) {
      return <LoaderComponent />
    }

    let url = `${sellerCentralUrls[region.value]}/apps/authorize/consent?application_id=${SP_APP_ID}`
    if (SP_BETA) {
      url = `${url}&version=beta`
    }
    return (
      <div className="region-selector">
        <label>
          Choose Region
        </label>
        <Select
          className="region-list"
          classNamePrefix="region-list"
          value={region}
          options={regionList}
          onChange={onChange}
        />
        <a href={url} onClick={handleClickGrantAccess} className="btn btn-blue">
          Grant Access
        </a>
      </div>
    )
  }

  return (
    <div className="signup-section">
      <div className="section-name">
        Amazon Integration
        {
          (!spRefreshToken || !adRefreshToken) && (
            <div className="amazon-description">
              <InfoSvg />
              Connecting with Amazon is needed in order to receive your customized insights,
              solutions and data attribution to reduce wasted ad spend.
            </div>
          )
        }
        {
          spRefreshToken && adRefreshToken && (
            <span className="amazon-account-select-tip">
              Scroll down to select Amazon accounts and add billing information
            </span>
          )
        }
      </div>
      { renderContents() }
    </div>
  )
}

export default AmazonSection
