import React, { useEffect, useState } from 'react'
import { useDispatch, useStore } from 'react-redux'
import { useLocation, Redirect, useHistory } from 'react-router-dom'
import { Modal } from 'rsuite'
import { Elements, CardElement, useStripe, useElements } from '@stripe/react-stripe-js'
import { loadStripe } from '@stripe/stripe-js'
import * as Sentry from '@sentry/react'

import {
  SP_BETA,
  SP_REDIRECT_URI,
  MARGINS_URL,
  LOGIN_CLIENT_ID,
  STRIPE_PUB_KEY
} from '../../config/api'

import { ReactComponent as InfoSvg } from '../../assets/svg/info.svg'

import { signupSPCode, signupADCode, signup, doLogin } from '../../redux/actions/auth'

import { toast } from '../../components/CommonComponents/ToastComponent/toast'
import CheckboxComponent from '../../components/CommonComponents/CheckboxComponent'
import LoaderComponent from '../../components/CommonComponents/LoaderComponent'
import AmazonSection from './AmazonSection'
import BillingSection from './BillingSection'

import {
  regionList,
  STORAGE_KEY_STATE,
  STORAGE_KEY_REGION
} from '../../utils/defaultValues'
import CouponSection from './CouponSection'

const SignupComplete = () => {
  const dispatch = useDispatch()
  const location = useLocation()
  const history = useHistory()
  const store = useStore().getState()
  const stripe = useStripe()
  const elements = useElements()

  const { auth: {
    isLoggedIn,
    signupBasicInfo,
    isSPCodeGetting,
    spRefreshToken,
    isADCodeGetting,
    adRefreshToken,
    profileList,
  } } = store

  const [coupon, setCoupon] = useState({
    code: '',
  })
  const [region, setRegion] = useState(regionList[0])
  const [selectedProfileIds, setSelectedProfileIds] = useState([])
  const [billing, setBilling] = useState({
    firstName: signupBasicInfo ? signupBasicInfo.firstName : '',
    lastName: signupBasicInfo ? signupBasicInfo.lastName : '',
  })
  const [buyUpsell, setBuyUpsell] = useState(false)
  const [isSigning, setIsSigning] = useState(false)

  // Inject Amazon LWA script.
  useEffect(() => {
    let amazonRoot = document.getElementById('amazon-root')
    if (!amazonRoot) {
      amazonRoot = document.createElement('div')
      amazonRoot.setAttribute('id', 'amazon-root')
      document.body.appendChild(amazonRoot)

      const script = document.createElement('script')
      script.setAttribute('type', 'text/javascript')
      script.innerHTML = `
        window.onAmazonLoginReady = function() {
          amazon.Login.setClientId('${LOGIN_CLIENT_ID}');
        };
        (function(d) {
          var a = d.createElement('script'); a.type = 'text/javascript';
          a.async = true; a.id = 'amazon-login-sdk';
          a.src = 'https://assets.loginwithamazon.com/sdk/na/login1.js';
          d.getElementById('amazon-root').appendChild(a);
        })(document);
      `
      document.body.appendChild(script)
    }
  }, [])

  // Respond to Amazon returns.
  useEffect(() => {
    const qs = new URLSearchParams(location.search)
    const callbackUrl = qs.get('amazon_callback_uri')
    const spCode = qs.get('spapi_oauth_code')
    const code = qs.get('code')

    if (callbackUrl) {
      // After authorizing our app, users are redirected to another page
      // to get the LWA (Login with Amazon) code.
      const amazonState = qs.get('amazon_state')
      const state = (new Date()).valueOf()
      // Save state to sessionStorage for later validation.
      window.sessionStorage.setItem(STORAGE_KEY_STATE, state)

      let url = `${callbackUrl}?redirect_uri=${encodeURI(SP_REDIRECT_URI)}`
        + `&amazon_state=${amazonState}&state=${state}`
      if (SP_BETA) {
        url = `${url}&version=beta`
      }
      window.location.href = url
    } else if (spCode) {
      let state = qs.get('state')

      if (state === 'settings') {
        // This is for Settings page to add accounts.
        history.push({
          pathname: '/settings',
          search: location.search,
        })
      } else if (state === 'migration') {
        // This is for MWS migration.
        history.push({
          pathname: '/dashboard',
          search: location.search,
        })
      } else if (state === 'marginsmigration') {
        // This is for MWS migration in Margins.
        window.location.href = `${MARGINS_URL}${location.search}`
      } else if ((state || '').indexOf('marginsmanager') === 0) {
        // This is for account manager in Margins.
        const accountGroupId = state.substring(14)
        window.location.href = `${MARGINS_URL}/account-manager${location.search}&account_group_id=${accountGroupId}`
      } else {
        const savedState = window.sessionStorage.getItem(STORAGE_KEY_STATE)
        if (state === savedState && !isSPCodeGetting) {
          window.sessionStorage.removeItem(STORAGE_KEY_STATE)

          dispatch(signupSPCode(spCode)).then(() => {
            if (typeof window.amazon === 'undefined') {
              setTimeout(() => {
                if (typeof window.amazon === 'undefined') {
                  toast.show({
                    title: 'Danger',
                    description: 'The Amazon script is not loaded.',
                    duration: 20000,
                  })
                  return
                }
                initiateLWA()
              }, 5000)
              return
            }
            initiateLWA()
          }).catch((error) => {
            toast.show({
              title: 'Danger',
              description: error,
            })
            Sentry.captureMessage(error)
          })
        } else if (state !== savedState) {
          toast.show({
            title: 'Danger',
            description: 'The state value is incorrect.',
            duration: 20000,
          })
        }
      }
    } else if (code) {
      let state = qs.get('state')
      const savedState = window.sessionStorage.getItem(STORAGE_KEY_STATE)
      if (state === savedState && !isADCodeGetting) {
        window.sessionStorage.removeItem(STORAGE_KEY_STATE)

        const savedRegion = window.sessionStorage.getItem(STORAGE_KEY_REGION)
        dispatch(signupADCode(code, SP_REDIRECT_URI, savedRegion || region.value)).catch((error) => {
          toast.show({
            title: 'Danger',
            description: error,
          })
        })
      }
    } else if (signupBasicInfo === null) {
      history.push('/signup')
    }
  }, []) // eslint-disable-line

  if (isLoggedIn) {
    return (
      <Redirect to='/dashboard' />
    )
  }

  const initiateLWA = () => {
    const state = (new Date()).valueOf()
    // Save state to sessionStorage for later validation.
    window.sessionStorage.setItem(STORAGE_KEY_STATE, state)

    window.amazon.Login.authorize({
      scope: [
        'profile',
        'profile:user_id',
        'cpc_advertising:campaign_management',
      ],
      response_type: 'code',
      popup: false,
      state,
    }, SP_REDIRECT_URI)
  }

  const handleRegionChange = (option) => {
    setRegion(option)
    window.sessionStorage.setItem(STORAGE_KEY_REGION, option.value)
  }

  const handleCouponChange = (name,value) => {
    setCoupon(prev => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleBillingChange = (name, value) => {
    setBilling(prev => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleComplete = async () => {
    if (!stripe || !elements) {
      return
    }

    const cardElement = elements.getElement(CardElement)

    setIsSigning(true)
    const { token, error } = await stripe.createToken(cardElement, {
      name: `${billing.firstName} ${billing.lastName}`,
    })

    if (!token) {
      setIsSigning(false)
      Sentry.captureMessage('Failed to create stripe token')
      Sentry.captureException(error)
      toast.show({
        title: 'Danger',
        description: error.message,
      })
      return
    }

    const profiles = []
    profileList.forEach((profile) => {
      if (selectedProfileIds.indexOf(profile.profileId) === -1) {
        return
      }
      profiles.push({
        profileId: profile.profileId,
        countryCode: profile.countryCode.toLowerCase(),
        sellerStringId: profile.accountInfo.sellerStringId,
        brandEntityId: profile.accountInfo.brandEntityId,
        brandName: profile.accountInfo.brandName,
        type: profile.accountInfo.type.toLowerCase(),
      })
    })

    if (!profiles.length) {
      setIsSigning(false)
      toast.show({
        title: 'Danger',
        description: 'Please select accounts.',
      })
      return
    }

    window.sessionStorage.removeItem(STORAGE_KEY_REGION)

    dispatch(signup({
      firstName: signupBasicInfo.firstName,
      lastName: signupBasicInfo.lastName,
      email: signupBasicInfo.email,
      password: signupBasicInfo.password,
      phone: '',
      birthday: null,
      couponCode: coupon.code? coupon.code: null,
      adRefreshToken,
      spRefreshToken,
      billingFirstName: billing.firstName,
      billingLastName: billing.lastName,
      stripeToken: token.id,
      buyUpsell,
      profiles,
    })).then(() => {
      window.gtag('event', 'singup_complete')
      dispatch(doLogin({
        email: signupBasicInfo.email,
        pwd: signupBasicInfo.password,
      })).then(() => {
        setIsSigning(false)
        history.push('/tutorial')
      })
    }).catch((error) => {
      setIsSigning(false)
      toast.show({
        title: 'Danger',
        description: error,
      })
    })
  }

  const isFilled = spRefreshToken
    && adRefreshToken
    && billing.firstName
    && billing.lastName
    && !isSigning
    && selectedProfileIds.length > 0

  const isSelectedAmazon = spRefreshToken && adRefreshToken && selectedProfileIds.length > 0

  return (
    <div className="signup-complete-page">
      <Modal backdrop="static" show size="sm" className="signup-complete-modal">
        <Modal.Header closeButton={false}>
          <Modal.Title>
            Final Step: Choose Your Amazon Accounts
          </Modal.Title>
        </Modal.Header>
        <Modal.Body className={`${(spRefreshToken && adRefreshToken) ? '' : 'overflow-none'}`}>
          { isSigning && <LoaderComponent /> }
          <div className="modal-description">
            <InfoSvg />
            Trusted by thousands of sellers. Money Back Guarantee. Cancel anytime.
          </div>
          <AmazonSection
            isLoading={isSPCodeGetting || isADCodeGetting}
            spRefreshToken={spRefreshToken}
            adRefreshToken={adRefreshToken}
            region={region}
            regionList={regionList}
            profileList={profileList}
            selectedProfileIds={selectedProfileIds}
            onChange={handleRegionChange}
            onSelectProfileIds={setSelectedProfileIds}
          />
          {
            isSelectedAmazon && (
              <>
                <BillingSection
                  billing={billing}
                  onChange={handleBillingChange}
                />
                <CouponSection
                  coupon={coupon}
                  onChange={handleCouponChange}
                />
                <div className="upsell-section">
                  <CheckboxComponent
                    label="YES, Add One Time Coaching Offer for $97"
                    checked={buyUpsell}
                    onChange={setBuyUpsell}
                  />
                  <div className="upsell-contents">
                    <div className="upsell-header">
                      One Time Offer
                    </div>
                    <div className="upsell-description">
                      Take advantage of our huge one-time discount for new Entourage members
                      and become a part of our advanced coaching program for only&nbsp;
                      <span className="upsell-price">$97 (normal price $197).</span>
                    </div>
                    <div className="upsell-warning">
                      After you leave this page, you will never see this offer again.
                    </div>
                  </div>
                </div>
              </>
            )
          }
        </Modal.Body>
        {
          isSelectedAmazon && (
            <Modal.Footer>
              <button
                type="button"
                className="rs-btn rs-btn-primary"
                disabled={!isFilled}
                onClick={handleComplete}
              >
                Start My Free Trial
              </button>
            </Modal.Footer>
          )
        }
      </Modal>
    </div>
  )
}

const WrapperWithStripe = (props) => {
  const [stripePromise, setStripePromise] = useState(null)

  useEffect(() => {
    setStripePromise(loadStripe(STRIPE_PUB_KEY))
  }, [])

  return (
    <Elements stripe={stripePromise}>
      <SignupComplete {...props} />
    </Elements>
  )
}

export default WrapperWithStripe
