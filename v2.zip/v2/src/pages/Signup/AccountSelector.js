import React, { useMemo } from 'react'
import CustomTable from '../../components/CommonComponents/CustomTableComponent'

const AccountSelector = ({ profileList, selectedProfileIds, onSelect }) => {
  const extendedProfiles = useMemo(() => (
    profileList.map(profile => (
      Object.assign({}, profile, {
        id: profile.accountInfo.id,
        name: profile.accountInfo.name,
        brandName: profile.accountInfo.brandName,
      })
    )).sort((a, b) => (
      a.countryCode.localeCompare(b.countryCode)
    ))
  ), [profileList])

  const renderProfile = profile => (
    <>
      <div className="table-col col-country">
        { profile.countryCode.toUpperCase() }
      </div>
      <div className="table-col col-type">
        { profile.accountInfo.type }
      </div>
      <div className="table-col col-name" title={profile.accountInfo.name || profile.accountInfo.brandName}>
        { profile.accountInfo.name || profile.accountInfo.brandName }
      </div>
      <div className="table-col col-seller-id">
      { profile.accountInfo.id }
      </div>
    </>
  )

  return (
    <CustomTable
      className="table-accounts"
      records={extendedProfiles}
      idField="profileId"
      searchFields={['id', 'name', 'brandName']}
      selectedRecords={selectedProfileIds}
      paginationSelectPlacement="top"
      renderRecord={renderProfile}
      onChange={onSelect}
    >
      <div className="table-col col-country">Country</div>
      <div className="table-col col-type">Type</div>
      <div className="table-col col-name">Name</div>
      <div className="table-col col-seller-id">Seller/Entity ID</div>
    </CustomTable>
  )
}

export default AccountSelector
