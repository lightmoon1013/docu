import React from 'react'

const CouponSection = ({ coupon, onChange }) => {
  return (
    <div className="signup-section">
      <div className="section-name">
        Coupon (optional)
      </div>
      <div className="field-row">
        <div className="field-wrapper">
          <label>Coupon code</label>
          <input
            type="text"
            placeholder="Coupon Code"
            value={coupon.code}
            onChange={(event) => { onChange('code', event.target.value) }}
          />
        </div>
      </div>
    </div>
  )
}

export default CouponSection
