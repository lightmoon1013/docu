import React, { useEffect, useRef, useState } from 'react'

import MainLayout from '../../layout/MainLayout'
import ProductSelector from './ProductSelector'
import CoachingInfo from './CoachingInfo'
import OpInfo from './OpInfo'

import VideoLink from '../../components/CommonComponents/VideoLink'

import MarketplaceHeaderPng from '../../assets/img/marketplace-header.png'
import MarketplacePostPng from '../../assets/img/marketplace-post.png'
import MarketplaceHeadlinePng from '../../assets/img/marketplace-headline.png'
import MarketplaceVideoPng from '../../assets/img/marketplace-video.png'

const PRODUCT_COACH = 'coach'
const PRODUCT_OP = 'op'

const videoList = [
  { title: 'Genius Coin Marketplace', url: 'https://www.loom.com/embed/8c2f1bdb1de54db7bb9a091dc62b454f' }
]

const MarketplacePage = () => {
  const [selectedProduct, setSelectedProduct] = useState(null)
  const [needScroll, setNeedScroll] = useState(false)
  const infoRef = useRef(null)

  useEffect(() => {
    if (selectedProduct && needScroll && infoRef.current) {
      infoRef.current.scrollIntoView({ behavior: 'smooth' })
    }
  }, [selectedProduct, needScroll])

  const handleSelect = (product, scrollToBottom = false) => {
    setSelectedProduct(product)
    setNeedScroll(scrollToBottom)
  }

  return (
    <MainLayout>
      <div className="marketplace-page">
        <div className="page-header">
          <div className="page-title">
            <img src={MarketplaceHeaderPng} alt="Market Place Header" />
          </div>
        </div>
        <VideoLink
          videoList={videoList}
          modalTitle='Genius Coin Marketplace'
        />
        <div className="page-content">
          <ProductSelector
            selectedProduct={selectedProduct}
            onSelect={handleSelect}
          />
          {
            selectedProduct === PRODUCT_COACH && (
              <CoachingInfo ref={infoRef} />
            )
          }
          {
            selectedProduct === PRODUCT_OP && (
              <OpInfo ref={infoRef} />
            )
          }
          <div className="page-footer flex">
            <div className="coming">
              <img src={MarketplacePostPng} alt="Market Place Post" />
            </div>
            <div className="coming">
              <img src={MarketplaceHeadlinePng} alt="Market Place Headline" />
            </div>
            <div className="coming">
              <img src={MarketplaceVideoPng} alt="Market Place Video" />
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  )
}

export default MarketplacePage
