import React, { useState } from 'react'
import { useDispatch, useStore } from 'react-redux'
import { Redirect, useLocation, useHistory } from 'react-router-dom'

import { resetPassword } from '../../redux/actions/auth'

import LockSvg from '../../assets/svg/login/lock.svg'
import PilotSvg from '../../assets/svg/login/pilot.svg'

import AuthSideComponent from '../../components/AuthSideComponent'
import LoaderComponent from '../../components/CommonComponents/LoaderComponent'
import { toast } from '../../components/CommonComponents/ToastComponent/toast'

const ResetPasswordPage = () => {
  const dispatch = useDispatch()
  const store = useStore()
  const location = useLocation()
  const history = useHistory()

  const { isLoggedIn } = store.getState().auth

  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [isResetting, setIsResetting] = useState(false)

  const onReset = (event) => {
    event.preventDefault()

    if (!password) {
      toast.show({
        title: 'Warning',
        description: 'Please enter your new password.',
      })
      return
    }

    if (password !== confirmPassword) {
      toast.show({
        title: 'Warning',
        description: 'Passwords do not match.',
      })
      return
    }

    const qs = new URLSearchParams(location.search)

    setIsResetting(true)
    dispatch(resetPassword(qs.get('email'), password, qs.get('hash'))).then(() => {
      history.push('/login')
    }).catch(() => {
      setIsResetting(false)
      toast.show({
        title: 'Danger',
        description: 'Failed to reset password.',
      })
    })
  }

  if (isLoggedIn) {
    return (
      <Redirect
        to='/dashboard'
      />
    )
  }

  return (
    <div className="auth-layout">
      <AuthSideComponent>
        <img src={PilotSvg} alt="Smart Pilot Manager" />
        <div className="side-pilot-title">Smart Pilot Manager</div>
        <div>
          Now with customizable templates, the all new Smart Pilot allows you
          to make smarter and faster bid optimizations.
        </div>
      </AuthSideComponent>
      <div className={`auth-page${isResetting ? ' loading' : ''}`}>
        {isResetting && <LoaderComponent />}
        <form className="auth-form" onSubmit={onReset}>
          <div className="form-title">
            Reset your password
          </div>
          <div className="login-password">
            <img src={LockSvg} alt="locked" />
            <input
              type="password"
              placeholder="Enter new password"
              value={password}
              onChange={(event) => { setPassword(event.target.value) }}
            />
          </div>
          <div className="login-password">
            <img src={LockSvg} alt="locked" />
            <input
              type="password"
              placeholder="Confirm password"
              value={confirmPassword}
              onChange={(event) => { setConfirmPassword(event.target.value) }}
            />
          </div>
          <button type="submit" className="btn btn-red" disabled={isResetting || !password}>
            Reset password
          </button>
        </form>
      </div>
    </div>
  )
}

export default ResetPasswordPage
