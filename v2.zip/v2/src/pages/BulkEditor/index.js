import React, { useState } from 'react'
import { useDispatch, useStore } from 'react-redux'

import MainLayout from '../../layout/MainLayout'
import BulkOp from '../../components/BulkOp'
import BulkExpansion from '../../components/BulkExpansion'
import TargetSearchTable from '../../components/TargetSearchTable'

import { ReactComponent as MaxSvg } from '../../assets/svg/maximize.svg'
import { ReactComponent as MinSvg } from '../../assets/svg/minimize.svg'

import { toggleDashboardTable } from '../../redux/actions/dashboard'

const TAB_BULK_OP = 'bulk_op'
const TAB_BULK_EX = 'bulk_ex'
const TAB_TARGET_SEARCH = 'target_search'

const tabList = [
  { tab: TAB_BULK_OP, name: 'Bulk Optimization' },
  { tab: TAB_BULK_EX, name: 'Bulk Expansion' },
  { tab: TAB_TARGET_SEARCH, name: 'Target Search' },
]

const BulkEditorPage = () => {
  const dispatch = useDispatch()
  const store = useStore().getState()
  const { dashboard: { maxTable } } = store

  const [activeTab, setActiveTab] = useState(TAB_BULK_OP)

  const renderMaxMin = () => {
    if (!maxTable) {
      return <MaxSvg onClick={() => { dispatch(toggleDashboardTable()) }} />
    }
    return <MinSvg onClick={() => { dispatch(toggleDashboardTable()) }} />
  }

  const renderContents = () => {
    if (activeTab === TAB_BULK_OP) {
      return <BulkOp />
    }
    if (activeTab === TAB_BULK_EX) {
      return <BulkExpansion />
    }
    if (activeTab === TAB_TARGET_SEARCH) {
      return <TargetSearchTable />
    }
    return null
  }

  return (
    <MainLayout>
      <div className="bulk-editor-page">
        <div className="page-content">
          <div className="table-collection">
            <div className="table-tabs">
              <div className="table-tab-left">
                {
                  tabList.map(tab => (
                    <button
                      key={tab.tab}
                      type="button"
                      className={`table-tab${activeTab === tab.tab ? ' selected' : ''}`}
                      onClick={() => { setActiveTab(tab.tab) }}
                    >
                      { tab.name }
                    </button>
                  ))
                }
              </div>
              <div className="table-tab-right">
                { renderMaxMin() }
              </div>
            </div>
            { renderContents() }
          </div>
        </div>
      </div>
    </MainLayout>
  )
}

export default BulkEditorPage
