import moment from 'moment'
import { callGet } from '../../services/axios'

import {
  GET_ACTIVITY_LOG_START,
  GET_ACTIVITY_LOG_SUCCEED,
  GET_ACTIVITY_LOG_FAIL,
} from '../actionTypes/activityLog'

import * as Sentry from '@sentry/react'
import { toast } from '../../components/CommonComponents/ToastComponent/toast'

export const getActivityLog = (startDate, endDate) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: GET_ACTIVITY_LOG_START,
  })

  callGet('/campaignlog/loadLogByUserPaging', token, {
    user: currentUserId,
    startDate: moment(startDate).format('YYYY-MM-DD'),
    endDate: moment(endDate).format('YYYY-MM-DD'),
  }).then((response) => {
    dispatch({
      type: GET_ACTIVITY_LOG_SUCCEED,
      data: response.data,
    })
  }).catch((error) => {
    Sentry.captureException(error)
    dispatch({
      type: GET_ACTIVITY_LOG_FAIL,
    })

    toast.show({
      title: 'Danger',
      description: error || 'Failed to load activity log.',
    })
  })
}
