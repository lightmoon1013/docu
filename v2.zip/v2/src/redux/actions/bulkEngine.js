import moment from 'moment'

import { callPost } from '../../services/axios'

import { toast } from '../../components/CommonComponents/ToastComponent/toast'

import {
  GET_BULK_ENGINE_PORTFOLIOS_START,
  GET_BULK_ENGINE_PORTFOLIOS_SUCCEED,
  GET_BULK_ENGINE_PORTFOLIOS_FAIL,
  FIND_TARGETS_START,
  FIND_TARGETS_SUCCEED,
  FIND_TARGETS_FAIL,
  GET_TARGET_CHARTS_START,
  GET_TARGET_CHARTS_SUCCEED,
  GET_TARGET_CHARTS_FAIL,
  ADJUST_KEYWORD_BIDS_START,
  ADJUST_KEYWORD_BIDS_SUCCEED,
  ADJUST_KEYWORD_BIDS_FAIL,
  ADJUST_TARGET_BIDS_START,
  ADJUST_TARGET_BIDS_SUCCEED,
  ADJUST_TARGET_BIDS_FAIL,
  FIND_DUPS_START,
  FIND_DUPS_SUCCEED,
  FIND_DUPS_FAIL,
  UPDATE_KEYWORD_STATES_START,
  UPDATE_KEYWORD_STATES_SUCCEED,
  UPDATE_KEYWORD_STATES_FAIL,
  UPDATE_TARGET_STATES_START,
  UPDATE_TARGET_STATES_SUCCEED,
  UPDATE_TARGET_STATES_FAIL,
  FIND_NEW_TARGETS_START,
  FIND_NEW_TARGETS_SUCCEED,
  FIND_NEW_TARGETS_FAIL,
  GET_ADGROUPS_TO_ADD_TARGETS_START,
  GET_ADGROUPS_TO_ADD_TARGETS_SUCCEED,
  GET_ADGROUPS_TO_ADD_TARGETS_FAIL,
  ADD_TARGETS_EXISTING_CAMPAIGN_START,
  ADD_TARGETS_EXISTING_CAMPAIGN_SUCCEED,
  ADD_TARGETS_EXISTING_CAMPAIGN_FAIL,
  FIND_STS_EX_START,
  FIND_STS_EX_SUCCEED,
  FIND_STS_EX_FAIL,
  FIND_PTS_EX_START,
  FIND_PTS_EX_SUCCEED,
  FIND_PTS_EX_FAIL,
  GET_ADGROUPS_FOR_CAMPAIGNS_START,
  GET_ADGROUPS_FOR_CAMPAIGNS_SUCCEED,
  GET_ADGROUPS_FOR_CAMPAIGNS_FAIL,
  GET_SKU_OP_START,
  GET_SKU_OP_SUCCEED,
  GET_SKU_OP_FAIL,
  UPDATE_PA_STATES_START,
  UPDATE_PA_STATES_SUCCEED,
  UPDATE_PA_STATES_FAIL,
  GET_TARGET_OP_START,
  GET_TARGET_OP_SUCCEED,
  GET_TARGET_OP_FAIL,
  GET_ST_OP_START,
  GET_ST_OP_SUCCEED,
  GET_ST_OP_FAIL,
  ADD_NEGATIVES_OP_START,
  ADD_NEGATIVES_OP_SUCCEED,
  ADD_NEGATIVES_OP_FAIL,
  GET_NEGATIVE_FINDER_START,
  GET_NEGATIVE_FINDER_SUCCEED,
  GET_NEGATIVE_FINDER_FAIL,
  GET_ADVANCED_NEGATIVE_START,
  GET_ADVANCED_NEGATIVE_SUCCEED,
  GET_ADVANCED_NEGATIVE_FAIL,
  UPDATE_NK_STATES_START,
  UPDATE_NK_STATES_SUCCEED,
  UPDATE_NK_STATES_FAIL,
  UPDATE_NT_STATES_START,
  UPDATE_NT_STATES_SUCCEED,
  UPDATE_NT_STATES_FAIL,
  CREATE_AD_GROUP_START,
  CREATE_AD_GROUP_SUCCEED,
  CREATE_AD_GROUP_FAIL,
} from '../actionTypes/bulkEngine'

export const getPortfolios = () => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: GET_BULK_ENGINE_PORTFOLIOS_START,
  })

  return callPost('/bulkEngine/getPortfolios', {
    userId: currentUserId,
  }, token).then((response) => {
    dispatch({
      type: GET_BULK_ENGINE_PORTFOLIOS_SUCCEED,
      data: response.data,
    })
  }).catch(() => {
    dispatch({
      type: GET_BULK_ENGINE_PORTFOLIOS_FAIL,
    })
  })
}

// For target search tool
export const findTargets = (campaignIds, keyword, startDate, endDate) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: FIND_TARGETS_START,
  })

  return callPost('/bulkEngine/findTargets', {
    userId: currentUserId,
    campaignIds,
    keyword,
    startDate: moment(startDate).format('YYYY-MM-DD'),
    endDate: moment(endDate).format('YYYY-MM-DD'),
  }, token).then((response) => {
    dispatch({
      type: FIND_TARGETS_SUCCEED,
      data: response.data,
    })
  }).catch(() => {
    dispatch({
      type: FIND_TARGETS_FAIL,
    })
  })
}

export const getTargetCharts = (campaignIds, keyword, startDate, endDate, type) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: GET_TARGET_CHARTS_START,
  })

  return callPost('/bulkEngine/getTargetCharts', {
    userId: currentUserId,
    campaignIds,
    keyword,
    startDate: moment(startDate).format('YYYY-MM-DD'),
    endDate: moment(endDate).format('YYYY-MM-DD'),
    type,
  }, token).then((response) => {
    dispatch({
      type: GET_TARGET_CHARTS_SUCCEED,
      data: response.data,
    })
  }).catch(() => {
    dispatch({
      type: GET_TARGET_CHARTS_FAIL,
    })
  })
}

export const adjustKeywordBids = keywords => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: ADJUST_KEYWORD_BIDS_START,
  })

  return callPost('/bulkEngine/adjustKeywordBids', {
    userId: currentUserId,
    keywords,
  }, token).then((response) => {
    if (response.data.length) {
      toast.show({
        title: 'Success',
        description: 'Updated successfully.',
      })

      dispatch({
        type: ADJUST_KEYWORD_BIDS_SUCCEED,
        data: response.data,
        payload: keywords,
      })
    } else {
      toast.show({
        title: 'Danger',
        description: 'Failed to update keyword bids.',
      })

      dispatch({
        type: ADJUST_KEYWORD_BIDS_FAIL,
      })
    }

    return response.data
  }).catch(() => {
    toast.show({
      title: 'Danger',
      description: 'Failed to update keyword bids.',
    })

    dispatch({
      type: ADJUST_KEYWORD_BIDS_FAIL,
    })

    return []
  })
}

export const adjustTargetBids = targets => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: ADJUST_TARGET_BIDS_START,
  })

  return callPost('/bulkEngine/adjustTargetBids', {
    userId: currentUserId,
    targets,
  }, token).then((response) => {
    if (response.data.length) {
      toast.show({
        title: 'Success',
        description: 'Updated successfully.',
      })

      dispatch({
        type: ADJUST_TARGET_BIDS_SUCCEED,
        data: response.data,
        payload: targets,
      })
    } else {
      toast.show({
        title: 'Danger',
        description: 'Failed to update target bids.',
      })

      dispatch({
        type: ADJUST_TARGET_BIDS_FAIL,
      })
    }

    return response.data
  }).catch(() => {
    toast.show({
      title: 'Danger',
      description: 'Failed to update target bids.',
    })

    dispatch({
      type: ADJUST_TARGET_BIDS_FAIL,
    })

    return []
  })
}

export const findDups = (campaignIds, startDate, endDate) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: FIND_DUPS_START,
  })

  return callPost('/bulkEngine/findDups', {
    userId: currentUserId,
    campaignIds,
    startDate: moment(startDate).format('YYYY-MM-DD'),
    endDate: moment(endDate).format('YYYY-MM-DD'),
  }, token).then((response) => {
    dispatch({
      type: FIND_DUPS_SUCCEED,
      data: response.data,
    })
  }).catch(() => {
    dispatch({
      type: FIND_DUPS_FAIL,
    })
  })
}

export const updateKeywordStates = (keywords, state) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: UPDATE_KEYWORD_STATES_START,
  })

  return callPost('/bulkEngine/updateKeywordStates', {
    userId: currentUserId,
    keywords,
    state,
  }, token).then((response) => {
    if (response.data.keywordIds.length) {
      toast.show({
        title: 'Success',
        description: 'Updated successfully.',
      })

      dispatch({
        type: UPDATE_KEYWORD_STATES_SUCCEED,
        data: response.data.keywordIds,
        state,
      })

      return response.data.keywordIds
    } else {
      let errorText = 'Failed to update keyword states.'
      if (response.data.errors.length) {
        errorText = response.data.errors.join('<br />')
      }

      toast.show({
        title: 'Danger',
        description: errorText,
      })

      dispatch({
        type: UPDATE_KEYWORD_STATES_FAIL,
      })
    }
  }).catch(() => {
    toast.show({
      title: 'Danger',
      description: 'Failed to update keyword states.',
    })

    dispatch({
      type: UPDATE_KEYWORD_STATES_FAIL,
    })
  })
}

export const updateTargetStates = (targets, state) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: UPDATE_TARGET_STATES_START,
  })

  return callPost('/bulkEngine/updateTargetStates', {
    userId: currentUserId,
    targets,
    state,
  }, token).then((response) => {
    if (response.data.length) {
      toast.show({
        title: 'Success',
        description: 'Updated successfully.',
      })

      dispatch({
        type: UPDATE_TARGET_STATES_SUCCEED,
        data: response.data,
        state,
      })

      return response.data
    } else {
      toast.show({
        title: 'Danger',
        description: 'Failed to update target states.',
      })

      dispatch({
        type: UPDATE_TARGET_STATES_FAIL,
      })
    }
  }).catch(() => {
    toast.show({
      title: 'Danger',
      description: 'Failed to update target states.',
    })

    dispatch({
      type: UPDATE_TARGET_STATES_FAIL,
    })
  })
}

export const findNewTargets = (campaignIds, targets) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: FIND_NEW_TARGETS_START,
  })

  return callPost('/bulkEngine/findNewTargets', {
    userId: currentUserId,
    campaignIds,
    targets,
  }, token).then((response) => {
    dispatch({
      type: FIND_NEW_TARGETS_SUCCEED,
      data: response.data,
    })
  }).catch(() => {
    dispatch({
      type: FIND_NEW_TARGETS_FAIL,
    })
  })
}

export const getAdgroupsToAddTargets = (payload, targetingOnly) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: GET_ADGROUPS_TO_ADD_TARGETS_START,
  })

  return callPost('/bulkEngine/getAdgroupsToAddTargets', {
    userId: currentUserId,
    payload,
    targetingOnly,
  }, token).then((response) => {
    dispatch({
      type: GET_ADGROUPS_TO_ADD_TARGETS_SUCCEED,
      data: response.data,
    })
  }).catch(() => {
    dispatch({
      type: GET_ADGROUPS_TO_ADD_TARGETS_FAIL,
    })
  })
}

export const addTargets = (payload, forCategory, audience, lookback) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: ADD_TARGETS_EXISTING_CAMPAIGN_START,
  })

  return callPost('/bulkEngine/addTargets', {
    userId: currentUserId,
    payload,
    forCategory,
    audience,
    lookback,
  }, token).then((response) => {
    dispatch({
      type: ADD_TARGETS_EXISTING_CAMPAIGN_SUCCEED,
    })

    return response.data
  }).catch((error) => {
    dispatch({
      type: ADD_TARGETS_EXISTING_CAMPAIGN_FAIL,
    })

    return Promise.reject(error?.response?.data || 'Failed to add targets.')
  })
}

export const findSts = (campaignIds, startDate, endDate, acosStart, acosEnd, stOnly = true) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: FIND_STS_EX_START,
  })

  return callPost('/bulkEngine/findSts', {
    userId: currentUserId,
    campaignIds,
    startDate: moment(startDate).format('YYYY-MM-DD'),
    endDate: moment(endDate).format('YYYY-MM-DD'),
    acosStart,
    acosEnd,
    stOnly,
  }, token).then((response) => {
    dispatch({
      type: FIND_STS_EX_SUCCEED,
      data: response.data,
    })
  }).catch(() => {
    dispatch({
      type: FIND_STS_EX_FAIL,
    })
  })
}

export const findPts = (campaignIds, startDate, endDate, acosStart, acosEnd, typeTarget, newAsinOnly) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: FIND_PTS_EX_START,
  })

  return callPost('/bulkEngine/findPts', {
    userId: currentUserId,
    campaignIds,
    startDate: moment(startDate).format('YYYY-MM-DD'),
    endDate: moment(endDate).format('YYYY-MM-DD'),
    acosStart,
    acosEnd,
    typeTarget,
    newAsinOnly,
  }, token).then((response) => {
    dispatch({
      type: FIND_PTS_EX_SUCCEED,
      data: response.data,
    })
  }).catch(() => {
    dispatch({
      type: FIND_PTS_EX_FAIL,
    })
  })
}

export const getAdgroupsForCampaigns = (campaignIds) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: GET_ADGROUPS_FOR_CAMPAIGNS_START,
  })

  return callPost('/bulkEngine/getAdgroupsForCampaigns', {
    userId: currentUserId,
    campaignIds,
  }, token).then((response) => {
    dispatch({
      type: GET_ADGROUPS_FOR_CAMPAIGNS_SUCCEED,
      data: response.data,
    })
  }).catch(() => {
    dispatch({
      type: GET_ADGROUPS_FOR_CAMPAIGNS_FAIL,
    })
  })
}

// For SKU Op
export const getSKUOpData = (campaignIds, adgroupIds, startDate, endDate) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: GET_SKU_OP_START,
  })

  return callPost('/bulkEngine/getSKUOpData', {
    userId: currentUserId,
    campaignIds,
    adgroupIds,
    startDate: moment(startDate).format('YYYY-MM-DD'),
    endDate: moment(endDate).format('YYYY-MM-DD'),
  }, token).then((response) => {
    dispatch({
      type: GET_SKU_OP_SUCCEED,
      data: response.data,
    })
  }).catch(() => {
    dispatch({
      type: GET_SKU_OP_FAIL,
    })
  })
}

export const updatePaStates = (pas, state) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: UPDATE_PA_STATES_START,
  })

  return callPost('/bulkEngine/updatePaStates', {
    userId: currentUserId,
    pas,
    state,
  }, token).then((response) => {
    if (response.data.length) {
      toast.show({
        title: 'Success',
        description: 'Updated successfully.',
      })

      dispatch({
        type: UPDATE_PA_STATES_SUCCEED,
        data: response.data,
        state,
      })
    } else {
      toast.show({
        title: 'Danger',
        description: 'Failed to update product ad states.',
      })

      dispatch({
        type: UPDATE_PA_STATES_FAIL,
      })
    }
  }).catch(() => {
    toast.show({
      title: 'Danger',
      description: 'Failed to update product ad states.',
    })

    dispatch({
      type: UPDATE_PA_STATES_FAIL,
    })
  })
}

// For target Op
export const getTargetOpData = (campaignIds, adgroupIds, startDate, endDate, action = '') => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: GET_TARGET_OP_START,
  })

  return callPost('/bulkEngine/getTargetOpData', {
    userId: currentUserId,
    campaignIds,
    adgroupIds,
    startDate: moment(startDate).format('YYYY-MM-DD'),
    endDate: moment(endDate).format('YYYY-MM-DD'),
    action,
  }, token).then((response) => {
    dispatch({
      type: GET_TARGET_OP_SUCCEED,
      data: response.data,
    })
  }).catch(() => {
    dispatch({
      type: GET_TARGET_OP_FAIL,
    })
  })
}

// For ST Op
export const getStOpData = (campaignIds, adgroupIds, startDate, endDate, newTermOnly = false) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: GET_ST_OP_START,
  })

  return callPost('/bulkEngine/getStOpData', {
    userId: currentUserId,
    campaignIds,
    adgroupIds,
    startDate: moment(startDate).format('YYYY-MM-DD'),
    endDate: moment(endDate).format('YYYY-MM-DD'),
    newTermOnly,
  }, token).then((response) => {
    dispatch({
      type: GET_ST_OP_SUCCEED,
      data: response.data,
    })
  }).catch(() => {
    dispatch({
      type: GET_ST_OP_FAIL,
    })
  })
}

export const addNegatives = (negativeKeywords, negativeTargets, targetLevel, matchType) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: ADD_NEGATIVES_OP_START,
  })

  return callPost('/bulkEngine/addNegatives', {
    userId: currentUserId,
    negativeKeywords,
    negativeTargets,
    targetLevel,
    matchType,
  }, token).then((response) => {
    dispatch({
      type: ADD_NEGATIVES_OP_SUCCEED,
    })

    return response.data
  }).catch((error) => {
    dispatch({
      type: ADD_NEGATIVES_OP_FAIL,
    })

    return Promise.reject(typeof error?.response?.data === 'string' ? error?.response?.data : 'Failed to add negatives.')
  })
}

// For negative finder
export const getNegativeFinderData = (campaignIds, adgroupIds, startDate, endDate, targetAcos) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: GET_NEGATIVE_FINDER_START,
  })

  return callPost('/bulkEngine/getNegativeData', {
    userId: currentUserId,
    campaignIds,
    adgroupIds,
    startDate: moment(startDate).format('YYYY-MM-DD'),
    endDate: moment(endDate).format('YYYY-MM-DD'),
    targetAcos,
  }, token).then((response) => {
    dispatch({
      type: GET_NEGATIVE_FINDER_SUCCEED,
      data: response.data,
    })
  }).catch(() => {
    dispatch({
      type: GET_NEGATIVE_FINDER_FAIL,
    })
  })
}

// For advanced op
export const getAdvancedNegativeData = (campaignIds, adgroupIds) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: GET_ADVANCED_NEGATIVE_START,
  })

  return callPost('/bulkEngine/getAdvancedNegativeData', {
    userId: currentUserId,
    campaignIds,
    adgroupIds,
  }, token).then((response) => {
    dispatch({
      type: GET_ADVANCED_NEGATIVE_SUCCEED,
      data: response.data,
    })
  }).catch(() => {
    dispatch({
      type: GET_ADVANCED_NEGATIVE_FAIL,
    })
  })
}

export const updateNkStates = (negatives, state) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: UPDATE_NK_STATES_START,
  })

  return callPost('/bulkEngine/updateNkStates', {
    userId: currentUserId,
    negatives,
    state,
  }, token).then((response) => {
    if (response.data.length) {
      toast.show({
        title: 'Success',
        description: 'Updated successfully.',
      })

      dispatch({
        type: UPDATE_NK_STATES_SUCCEED,
        data: response.data,
        state,
      })
    } else {
      toast.show({
        title: 'Danger',
        description: 'Failed to update negative keyword states.',
      })

      dispatch({
        type: UPDATE_NK_STATES_FAIL,
      })
    }
  }).catch(() => {
    toast.show({
      title: 'Danger',
      description: 'Failed to update negative keyword states.',
    })

    dispatch({
      type: UPDATE_NK_STATES_FAIL,
    })
  })
}

export const updateNtStates = (negatives, state) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: UPDATE_NT_STATES_START,
  })

  return callPost('/bulkEngine/updateNtStates', {
    userId: currentUserId,
    negatives,
    state,
  }, token).then((response) => {
    if (response.data.length) {
      toast.show({
        title: 'Success',
        description: 'Updated successfully.',
      })

      dispatch({
        type: UPDATE_NT_STATES_SUCCEED,
        data: response.data,
        state,
      })
    } else {
      toast.show({
        title: 'Danger',
        description: 'Failed to update negative target states.',
      })

      dispatch({
        type: UPDATE_NT_STATES_FAIL,
      })
    }
  }).catch(() => {
    toast.show({
      title: 'Danger',
      description: 'Failed to update negative target states.',
    })

    dispatch({
      type: UPDATE_NT_STATES_FAIL,
    })
  })
}

export const createAdgroup = (campaignId, campaignType, name, defaultBid, bidOptimization, tactic, products) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: CREATE_AD_GROUP_START,
  })

  return callPost('/bulkEngine/createAdGroup', {
    userId: currentUserId,
    campaignId,
    campaignType,
    name,
    defaultBid,
    bidOptimization,
    tactic,
    products,
  }, token).then((response) => {
    if (response.data.adgroup_id) {
      toast.show({
        title: 'Success',
        description: 'Created successfully.',
      })

      dispatch({
        type: CREATE_AD_GROUP_SUCCEED,
        data: response.data,
      })
    } else {
      toast.show({
        title: 'Danger',
        description: response.data.text || 'Failed to create ad group.',
      })

      dispatch({
        type: CREATE_AD_GROUP_FAIL,
      })
    }
    return response.data
  }).catch((error) => {
    toast.show({
      title: 'Danger',
      description: error?.response?.data || 'Failed to create ad group.',
    })

    dispatch({
      type: CREATE_AD_GROUP_FAIL,
    })
  })
}
