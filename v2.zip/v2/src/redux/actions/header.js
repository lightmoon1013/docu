import { toast } from '../../components/CommonComponents/ToastComponent/toast'
import { callGet } from '../../services/axios'
import {
  GET_ALL_ACCOUNT_START,
  GET_ALL_ACCOUNT_SUCCEED,
  GET_ALL_ACCOUNT_FAIL,
  SET_SELECTED_USER_INFO,
  GET_CURRENCY_RATE_SUCCEED,
  SET_CURRENCY_INFO,
  SET_DATE_RANGE,
  SET_NOTIFICATION_CHECKED,
  SET_OUT_OF_BUDGET,
  SET_USER_CHANGED,
} from '../actionTypes/header'

import {
  loadOutOfBudgetLog,
} from './campaignLog'

export const appStart = () => (dispatch, getState) => {
  const { header: { currentUserId }, auth: { isLoggedIn } } = getState()

  if (isLoggedIn) {
    dispatch(getAllAccount({ userId: currentUserId }))
    dispatch(getCurrencyRate())
    dispatch(loadOutOfBudgetLog())
  }
}

export const getAllAccount = ({ userId }) => (dispatch, getState) => {
  const { auth: { token } } = getState()
  dispatch({
    type: GET_ALL_ACCOUNT_START,
  })
  callGet('/account/getAllAccounts', token, {
    user: userId,
  }).then((response) => {
    dispatch({
      type: GET_ALL_ACCOUNT_SUCCEED,
      data: response.data,
    })
  }).catch(() => {
    dispatch({
      type: GET_ALL_ACCOUNT_FAIL,
    })
    toast.show({
      title: 'Danger',
      description: 'Failed to get all accounts.'
    })
  })
}

export const setSelectedUserInfo = (data) => (dispatch) => {
  dispatch({
    type: SET_SELECTED_USER_INFO,
    data,
  })

  dispatch(getAllAccount({ userId: data.user }))
  dispatch(getCurrencyRate())
  dispatch(loadOutOfBudgetLog())
}

export const setUserChanged = ({ isChanged }) => (dispatch) => {
  dispatch({
    type: SET_USER_CHANGED,
    data: {
      isChanged,
    },
  })
}

export const getCurrencyRate = () => (dispatch, getState) => {
  const { auth: { token } } = getState()
  callGet('/home/getCurrencyRate/', token).then((response) => {
    dispatch({
      type: GET_CURRENCY_RATE_SUCCEED,
      data: response.data,
    })
  }).catch(() => {
    toast.show({
      title: 'Danger',
      description: 'Failed to get currency rate',
    })
  })
}

export const setCurrencyInfo = (data) => (dispatch) => {
  dispatch({
    type: SET_CURRENCY_INFO,
    data
  })
}

export const setDateRange = ({ startDate, endDate }) => (dispatch) => {
  dispatch({
    type: SET_DATE_RANGE,
    data: { startDate, endDate }
  })
}

export const setNotificationChecked = (data) => {
  return {
    type: SET_NOTIFICATION_CHECKED,
    data,
  }
}

export const setOutOfBudget = (data) => {
  return {
    type: SET_OUT_OF_BUDGET,
    data,
  }
}
