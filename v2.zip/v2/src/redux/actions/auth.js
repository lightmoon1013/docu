import { toast } from '../../components/CommonComponents/ToastComponent/toast'
import { callGet, callPost } from '../../services/axios.js'

import {
  LOGIN_START,
  LOGIN_SUCCEED,
  LOGIN_FAILED,
  LOGOUT_SUCCESS,
  CHANGE_USER_INFO_SUCCEED,
  SAVE_NOTIFICATION_SUCCEED,
  SAVE_UNIVERSAL_SUCCEED,
  CHECK_AUTH_SUCCEED,
  CHECK_AUTH_FAILED,
  SIGNUP_BASIC_START,
  SIGNUP_BASIC_SUCCEED,
  SIGNUP_BASIC_FAILED,
  SP_CODE_START,
  SP_CODE_SUCCEED,
  SP_CODE_FAILED,
  AD_CODE_START,
  AD_CODE_SUCCEED,
  AD_CODE_FAILED,
  SIGNUP_SUCCEED,
  ADD_ACCOUNT_OPEN,
  SAVE_BRAND_NAME_SUCCEED,
  MIGRATE_MWS_SUCCEED,
} from '../actionTypes/auth.js'

import {
  getAllAccount,
  getCurrencyRate,
} from './header'

import {
  loadOutOfBudgetLog,
} from './campaignLog'

export const checkAuth = () => (dispatch, getState) => {
  const { auth: { token } } = getState()

  callGet(`/auth/me`, token).then((response) => {
    dispatch({
      type: CHECK_AUTH_SUCCEED,
      coinHistories: response.data.coinHistories,
    })
  }).catch(() => {
    dispatch({
      type: CHECK_AUTH_FAILED,
    })
  })
}

export const doLogin = data => (dispatch) => {
  dispatch({ type: LOGIN_START })
  return callPost('/login', {
    identifier: data.email,
    password: data.pwd,
  }).then((response) => {
    if (response.data) {
      dispatch({
        type: LOGIN_SUCCEED,
        data: response.data,
      })

      if (response.data.notification)
        toast.show({
          title: 'Warning',
          description: response.data.notification.text,
          duration: 15000,
        })

      dispatch(getAllAccount({ userId: response.data.user.id }))
      dispatch(getCurrencyRate())
      dispatch(loadOutOfBudgetLog())
    } else {
      dispatch({ type: LOGIN_FAILED })
      return Promise.reject()
    }
  }).catch((error) => {
    dispatch({ type: LOGIN_FAILED })
    return Promise.reject()
  })
}

export const doLogout = () => (dispatch) => {
  dispatch({ type: LOGOUT_SUCCESS })
}

export const askPasswordReset = email => () => {
  return callPost('/forgot', {
    email,
    version: 'v2',
  })
}

export const resetPassword = (email, pwd, hash) => () => {
  return callPost('/chgpwd', {
    email,
    pwd,
    hash,
  })
}

export const changeUserInfo = ({ password, firstName, lastName, email }) => (dispatch, getState) => {
  const { auth: { user, token } } = getState()
  return callPost('/update-info', {
    userId: user.id,
    password,
    firstName,
    lastName,
    email,
  }, token).then((response) => {
    if (response.data === 'ok') {
      dispatch({
        type: CHANGE_USER_INFO_SUCCEED,
        data: {
          firstName,
          lastName,
          email,
        },
      })

      toast.show({
        title: 'Success',
        description: 'Changed successfully.',
      })
    } else {
      let error = 'Failed to update the user information.'
      if (response.data === 'notp') {
        error = 'The password is incorrect.'
      }
      toast.show({
        title: 'Danger',
        description: error,
      })
    }
  })
}

export const changePassword = ({ oldpwd, newpwd }) => (dispatch, getState) => {
  const { auth: { user, token } } = getState()
  return callPost('/pchange', {
    userId: user.id,
    oldpwd,
    newpwd,
  }, token).then((response) => {
    if (response.data === 'ok') {
      toast.show({
        title: 'Success',
        description: 'Changed successfully.',
      })
    } else {
      let error = 'Failed to change password.'
      if (response.data === 'notp') {
        error = 'The old password is incorrect.'
      }
      toast.show({
        title: 'Danger',
        description: error,
      })
    }
  })
}

export const saveNotification = ({ monthlyAlert, weeklyAlert, additionalAlert }) => (dispatch, getState) => {
  const { auth: { token }, header: { selectedUserInfo } } = getState()
  return callGet(`/account/saveNotifications`, token, {
    userId: selectedUserInfo.user,
    monthlyAlert,
    weeklyAlert,
    additionalAlert,
  }).then(() => {
    dispatch({
      type: SAVE_NOTIFICATION_SUCCEED,
      data: {
        userId: selectedUserInfo.user,
        monthlyAlert,
        weeklyAlert,
        additionalAlert,
      }
    })

    toast.show({
      title: 'Success',
      description: 'Saved successfully.',
    })
  })
}

export const saveUniversalSettings = ({ profitMargin, acos }) => (dispatch, getState) => {
  const { auth: { token }, header: { selectedUserInfo } } = getState()
  return callGet(`/account/saveUniversalSettings`, token, {
    userId: selectedUserInfo.user,
    profitMargin,
    acos,
  }).then(() => {
    dispatch({
      type: SAVE_UNIVERSAL_SUCCEED,
      data: {
        userId: selectedUserInfo.user,
        profitMargin,
        acos,
      }
    })

    toast.show({
      title: 'Success',
      description: 'Saved successfully.',
    })
  })
}

export const getBillingInfo = () => (dispatch, getState) => {
  const { auth: { token } } = getState()
  return callGet('/account/getBillingInfo', token).then(response => (
    response.data
  ))
}

export const updateCard = stripeToken => (dispatch, getState) => {
  const { auth: { token } } = getState()
  return callGet('/account/updateCard', token, {
    stripeToken,
  }).then(response => (
    response.data
  )).catch(error => {
    return Promise.reject(error)
  })
}

export const updateBillingInfo = billingInfo => (dispatch, getState) => {
  const { auth: { token } } = getState()
  return callPost('/account/updateBillingInfo', {
    billingInfo,
  }, token)
}

export const getInvoiceDownloadLink = invoiceId => (dispatch, getState) => {
  const { auth: { token } } = getState()
  return callGet('/account/getInvoiceDownloadLink', token, {
    invoiceId,
  }, token)
}

export const signupBasic = (firstName, lastName, email, password) => (dispatch) => {
  dispatch({ type: SIGNUP_BASIC_START })
  return callPost('/account/signupBasic', {
    email,
  }).then((response) => {
    dispatch({
      type: SIGNUP_BASIC_SUCCEED,
      data: {
        firstName,
        lastName,
        email,
        password,
      },
    })
    return response.data.isValid
  }).catch((error) => {
    dispatch({ type: SIGNUP_BASIC_FAILED })
    return Promise.reject(error.response.data.message || 'Failed to sign up.')
  })
}

export const signupSPCode = code => (dispatch) => {
  dispatch({ type: SP_CODE_START })
  return callPost('/account/signupSPCode', {
    code,
  }).then((response) => {
    dispatch({
      type: SP_CODE_SUCCEED,
      data: response.data,
    })
  }).catch((error) => {
    dispatch({ type: SP_CODE_FAILED })
    return Promise.reject(error.response.data.message || 'Failed to authorize the Amazon Selling Partner API.')
  })
}

export const signupADCode = (code, redirectUri, region) => (dispatch) => {
  dispatch({ type: AD_CODE_START })
  return callPost('/account/signupADCode', {
    code,
    redirectUri,
    region,
  }).then((response) => {
    dispatch({
      type: AD_CODE_SUCCEED,
      data: response.data,
    })
    return response.data.profiles
  }).catch((error) => {
    dispatch({ type: AD_CODE_FAILED })
    return Promise.reject(error.response.data.message || 'Failed to authorize the Amazon Advertising API.')
  })
}

export const signup = payload => (dispatch) => {
  return callPost('/account/signupV2', payload).then(() => {
    dispatch({ type: SIGNUP_SUCCEED })
  }).catch((error) => {
    return Promise.reject(error.response.data.message || 'Failed to sign up.')
  })
}

export const addAccountOpen = () => (dispatch) => {
  dispatch({ type: ADD_ACCOUNT_OPEN })
}

export const addAccount = (payload) => (dispatch, getState) => {
  const { auth: { user, token } } = getState()

  return callPost('/account/addAccountV2', payload, token).then(() => {
    dispatch(getAllAccount({ userId: user.id }))
  }).catch((error) => {
    return Promise.reject(error.response.data.message || 'Failed to add accounts.')
  })
}

export const cancelSubscription = (subscriptionId, reason) => (dispatch, getState) => {
  const { auth: { user, token } } = getState()

  return callPost('/account/cancelSubscription', {
    subscriptionId,
    reason,
  }, token).then((result) => {
    dispatch(getAllAccount({ userId: user.id }))
    return result.data
  }).catch((error) => {
    return Promise.reject(error.response.data.message || 'Failed to cancel account.')
  })
}

export const saveBrandName = brandName => (dispatch, getState) => {
  const { auth: { token }, header: { selectedUserInfo } } = getState()

  return callPost('/account/changeBrandName', {
    userId: selectedUserInfo.user,
    brandName,
  }, token).then(() => {
    dispatch({
      type: SAVE_BRAND_NAME_SUCCEED,
      data: {
        brandName,
      },
    })
  })
}

export const migrateMws = code => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  return callPost('/account/migrateMws', {
    userId: currentUserId,
    code,
  }, token).then((result) => {
    dispatch({
      type: MIGRATE_MWS_SUCCEED,
      data: result.data,
    })
  }).catch((error) => {
    return Promise.reject(error.response.data.message || 'Failed to authorize Selling Partner API.')
  })
}
