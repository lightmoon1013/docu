import { callGet, callPost } from '../../services/axios'

import {
  GET_SP_SUGGESTIONS_START,
  GET_SP_SUGGESTIONS_SUCCEED,
  GET_SP_SUGGESTIONS_FAIL,
  GET_SUGGESTED_BIDS_START,
  GET_SUGGESTED_BIDS_SUCCEED,
  GET_SUGGESTED_BIDS_FAIL,
  CREATE_CAMPAIGN_START,
  CREATE_CAMPAIGN_FINISH,
  GET_SD_SUGGESTIONS_START,
  GET_SD_SUGGESTIONS_SUCCEED,
  GET_BRANDS_DATA_START,
  GET_BRANDS_DATA_SUCCEED,
  GET_BRANDS_DATA_FAIL,
  GET_BRAND_LOGO_START,
  GET_BRAND_LOGO_SUCCEED,
  GET_BRAND_LOGO_FAIL,
  GET_SB_SUGGESTIONS_START,
  GET_SB_SUGGESTIONS_SUCCEED,
  GET_SB_SUGGESTIONS_FAIL,
  GET_SB_SUGGESTED_BIDS_START,
  GET_SB_SUGGESTED_BIDS_SUCCEED,
  GET_SB_SUGGESTED_BIDS_FAIL,
  CREATE_SBV_MEDIA_START,
  CREATE_SBV_MEDIA_SUCCEED,
  CREATE_SBV_MEDIA_FAIL,
  GET_SB_STOREINFO_START,
  GET_SB_STOREINFO_SUCCEED,
  GET_SB_STOREINFO_FAIL,
  GET_LANDINGPAGE_ASINS_START,
  GET_LANDINGPAGE_ASINS_SUCCEED,
  GET_LANDINGPAGE_ASINS_FAIL,
  GET_STORE_ASINS_START,
  GET_STORE_ASINS_SUCCEED,
  GET_STORE_ASINS_FAIL,
  CREATE_SD_ASSET_START,
  CREATE_SD_ASSET_SUCCEED,
  CREATE_SD_ASSET_FAIL,
  CREATE_SD_CUSTOM_ASSET_START,
  CREATE_SD_CUSTOM_ASSET_SUCCEED,
  CREATE_SD_CUSTOM_ASSET_FAIL,
  GET_SD_SUGGESTIONS_FAILED,
  CREATE_SB_BRANDLOGO_START,
  CREATE_SB_BRANDLOGO_SUCCEED,
  CREATE_SB_BRANDLOGO_FAIL,
  GET_SD_CURRENT_CREATIVE_START,
  GET_SD_CURRENT_CREATIVE_SUCCESS,
  GET_SD_CURRENT_CREATIVE_FAIL,
  GET_SD_PRODUCTS_METADATA_START,
  GET_SD_PRODUCTS_METADATA_SUCCESS,
  GET_SD_PRODUCTS_METADATA_FAILED,
  GET_SD_SUGGESTED_BIDS_START,
  GET_SD_SUGGESTED_BIDS_SUCCESS,
  GET_SD_SUGGESTED_BIDS_FAILED,
  CREATE_SP_AD_GROUP_START,
  CREATE_SP_AD_GROUP_SUCCEED,
  CREATE_SP_AD_GROUP_FAIL,
  CREATE_SD_AD_GROUP_START,
  CREATE_SD_AD_GROUP_SUCCEED,
  CREATE_SD_AD_GROUP_FAIL,
} from '../actionTypes/campaignCreator'

import { toast } from '../../components/CommonComponents/ToastComponent/toast'

export const getSPSuggestions = asins => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: GET_SP_SUGGESTIONS_START,
  })

  callGet('/campaignCreator/getSPSuggestions', token, {
    userId: currentUserId,
    asins: asins.join(','),
  }).then((response) => {
    dispatch({
      type: GET_SP_SUGGESTIONS_SUCCEED,
      data: response.data,
    })
  }).catch(() => {
    dispatch({
      type: GET_SP_SUGGESTIONS_FAIL,
    })
    toast.show({
      title: 'Danger',
      description: 'Failed to retrieve SP suggestions.',
    })
  })
}

export const getSuggestedKeywordBids = keywords => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: GET_SUGGESTED_BIDS_START,
  })

  callGet('/campaignCreator/getSuggestedKeywordBids', token, {
    userId: currentUserId,
    keywords,
  }).then((response) => {
    dispatch({
      type: GET_SUGGESTED_BIDS_SUCCEED,
      data: response.data,
    })
  }).catch(() => {
    dispatch({
      type: GET_SUGGESTED_BIDS_FAIL,
    })
    toast.show({
      title: 'Danger',
      description: 'Failed to retrieve suggested keyword bids.'
    })
  })
}

export const createSPCampaign = (data) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: CREATE_CAMPAIGN_START,
  })

  return callPost('/campaign/createCampaignsAsync/', Object.assign({}, data, {
    user: currentUserId,
  }), token).then((response) => {
    if (response.data.statusCode && response.data.statusCode !== 200) {
      return Promise.reject(response.data.text
        || 'Failed to create a campaign.')
    }

    dispatch({
      type: CREATE_CAMPAIGN_FINISH,
    })
  }).catch((error) => {
    dispatch({
      type: CREATE_CAMPAIGN_FINISH,
    })
    if (typeof error === 'string') {
      return Promise.reject(error)
    }
    if (error.response && error.response.data) {
      return Promise.reject(error.response.data.details
        || error.response.data.text
        || 'Failed to create a campaign.')
    }
    return Promise.reject('Failed to create a campaign.')
  })
}

export const createSPAdgroup = (campaignId, campaignType, name, defaultBid, bidOptimization, tactic, keywords, negativeKws, targets, negatives,products ) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: CREATE_SP_AD_GROUP_START,
  })

  return callPost('/campaignCreator/createSPAdGroup', {
    userId: currentUserId,
    campaignId,
    campaignType,
    name,
    defaultBid,
    bidOptimization,
    tactic,
    keywords,
    negativeKws,
    targets,
    negatives,
    products
  }, token).then((response) => {
    if (response.data.adgroup_id) {
      toast.show({
        title: 'Success',
        description: 'Created successfully.',
      })

      dispatch({
        type: CREATE_SP_AD_GROUP_SUCCEED,
      })
    } else {
      toast.show({
        title: 'Danger',
        description: response.data.text || 'Failed to create ad group.',
      })

      dispatch({
        type: CREATE_SP_AD_GROUP_FAIL,
      })
    }
    return response.data
  }).catch((error) => {
    toast.show({
      title: 'Danger',
      description: error?.response?.data || 'Failed to create ad group.',
    })

    dispatch({
      type: CREATE_SP_AD_GROUP_FAIL,
    })
  })
}

export const createSDAdgroup = (campaignId, campaignType, name, adGroups, productAds, targets, creative) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: CREATE_SD_AD_GROUP_START,
  })

  return callPost('/campaignCreator/createSDAdGroup', {
    userId: currentUserId,
    campaignId,
    campaignType,
    name,
    adGroups,
    productAds,
    targets,
    creative
  }, token).then((response) => {
    if (response.data.adgroup_id) {
      toast.show({
        title: 'Success',
        description: 'Created successfully.',
      })

      dispatch({
        type: CREATE_SD_AD_GROUP_SUCCEED,
      })
    } else {
      toast.show({
        title: 'Danger',
        description: response.data.text || response?.data?.error || 'Failed to create ad group.',
      })

      dispatch({
        type: CREATE_SD_AD_GROUP_FAIL,
      })
    }
    return response.data
  }).catch((error) => {
    toast.show({
      title: 'Danger',
      description: error?.response?.data || 'Failed to create ad group.',
    })

    dispatch({
      type: CREATE_SD_AD_GROUP_FAIL,
    })
  })
}

export const getSDSuggestions = (tactic, asins) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: GET_SD_SUGGESTIONS_START,
  })

  callGet('/campaignCreator/getSDSuggestions', token, {
    userId: currentUserId,
    tactic,
    asins: asins.join(','),
  }).then((response) => {
    dispatch({
      type: GET_SD_SUGGESTIONS_SUCCEED,
      data: response.data,
    })
  }).catch(() => {
    dispatch({
      type: GET_SD_SUGGESTIONS_FAILED
    })
    toast.show({
      title: 'Danger',
      description: 'Failed to retrieve suggestions.',
    })
  })
}

export const getProductsMetaData = (asins) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: GET_SD_PRODUCTS_METADATA_START,
  })

  callPost('/campaignCreator/getProductsMetaData', Object.assign({}, {
    userId: currentUserId,
    asins: asins
  }), token).then((response) => {
    dispatch({
      type: GET_SD_PRODUCTS_METADATA_SUCCESS,
      data: response.data,
    })
  }).catch(() => {
    dispatch({
      type: GET_SD_PRODUCTS_METADATA_FAILED
    })
    toast.show({
      title: 'Danger',
      description: 'Failed to retrieve suggestions.',
    })
  })
}

export const getSDAudiences = path => async (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  return await callGet('/campaignCreator/getSDAudiences', token, {
    userId: currentUserId,
    path,
  }).then(response => response.data)
  .catch((error) => {
    toast.show({
      title: 'Danger',
      description: 'Failed to retrieve SD audiences.',
    })
    return Promise.reject(error)
  })
}

export const createSDCampaign = (data) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()


  dispatch({
    type: CREATE_CAMPAIGN_START,
  })

  return callPost('/campaignCreator/createSDCampaign', Object.assign({}, data, {
    userId: currentUserId,
  }), token).then((response) => {
    if (response.data.errorDetails) {
      return Promise.reject(response.data.errorDetails[0].details || response.data.text || 'Failed to create a campaign.')
    }
    if (response.data.error) {
      return Promise.reject(response.data.error || 'Failed to create a campaign.')
    }
    dispatch({
      type: CREATE_CAMPAIGN_FINISH,
    })
  }).catch((error) => {
    dispatch({
      type: CREATE_CAMPAIGN_FINISH,
    })
    if (typeof error === 'string') {
      return Promise.reject(error)
    }
    if (error.response && error.response.data) {
      return Promise.reject(error.response.data.details
        || error.response.data.text
        || 'Failed to create a campaign.')
    }
    return Promise.reject('Failed to create a campaign.')
  })
}

export const getBrandsData = () => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: GET_BRANDS_DATA_START,
  })

  callGet('/campaignCreator/getBrandsData', token, {
    userId: currentUserId
  }).then((response) => {
    dispatch({
      type: GET_BRANDS_DATA_SUCCEED,
      data: response.data,
    })
  }).catch((error) => {
    dispatch({
      type: GET_BRANDS_DATA_FAIL,
    })

    toast.show({
      title: 'Danger',
      description: error || 'Failed to get UserId.',
    })
  })
}

export const getBrandLogos = (brandEntityId) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: GET_BRAND_LOGO_START,
  })

  callGet('/campaignCreator/getBrandLogos', token, {
    brandEntityId: brandEntityId,
    userId: currentUserId,
  }).then((response) => {
    dispatch({
      type: GET_BRAND_LOGO_SUCCEED,
      data: response.data,
    })
  }).catch((error) => {
    dispatch({
      type: GET_BRAND_LOGO_FAIL,
    })

    toast.show({
      title: 'Danger',
      description: error || 'Failed to get Brand Logos.',
    })
  })
}

export const getSBSuggestions = asins => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: GET_SB_SUGGESTIONS_START,
  })

  callGet('/campaignCreator/getSBSuggestions', token, {
    userId: currentUserId,
    asins: asins.join(','),
  }).then((response) => {
    dispatch({
      type: GET_SB_SUGGESTIONS_SUCCEED,
      data: response.data,
    })
  }).catch((error) => {
    dispatch({
      type: GET_SB_SUGGESTIONS_FAIL,
    })

    toast.show({
      title: 'Danger',
      description: error || 'Failed to get suggested keywords.',
    })
  })
}

export const getSBSuggestedKeywordBids = (keywords, target) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: GET_SB_SUGGESTED_BIDS_START,
  })

  callGet('/campaignCreator/getSBSuggestedKeywordBids', token, {
    userId: currentUserId,
    keywords,
    adFormat: target
  }).then((response) => {
    dispatch({
      type: GET_SB_SUGGESTED_BIDS_SUCCEED,
      data: response.data,
    })
  }).catch((error) => {
    dispatch({
      type: GET_SB_SUGGESTED_BIDS_FAIL,
    })

    toast.show({
      title: 'Danger',
      description: error || 'Failed to get suggested bids.',
    })
  })
}

export const getSDSuggestionBids = (params) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: GET_SD_SUGGESTED_BIDS_START,
  })

  return callPost('/campaignCreator/getSDSuggestionBids', Object.assign({}, {
    userId: currentUserId,
    bidParams: params
  }), token).then((response) => {
    dispatch({
      type: GET_SD_SUGGESTED_BIDS_SUCCESS,
      data: response.data,
    })
    return response.data
  }).catch(err => {
    dispatch({
      type: GET_SD_SUGGESTED_BIDS_FAILED
    })
    toast.show({
      title: 'Danger',
      description: 'Failed to retrieve suggested bids.',
    })
  })
}

export const createSBCampaign = (data) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: CREATE_CAMPAIGN_START,
  })
  return callPost('/campaignCreator/createSBCampaignsAsync/', {
    userId: currentUserId,
    newCampaign: data.newCampaign,
    campaignType: data.campaignType,
  }, token).then((response) => {
    if (response.data.statusCode && response.data.statusCode !== 200) {
      if (response.data.text.includes('Media type mismatch for provided asset')) {
        return Promise.reject('The selected image can’t be used as this type of creative asset. Please upload a different image.')
      } else {
        return Promise.reject(response.data.text
          || 'Failed to create a campaign.')
      }
    }

    dispatch({
      type: CREATE_CAMPAIGN_FINISH,
    })
  }).catch((error) => {
    dispatch({
      type: CREATE_CAMPAIGN_FINISH,
    })
    if (typeof error === 'string') {
      return Promise.reject(error)
    }
    if (error.response && error.response.data) {
      return Promise.reject(error.response.data.details
        || error.response.data.text
        || 'Failed to create a campaign.')
    }
    return Promise.reject('Failed to create a campaign.')
  })
}
export const createSBVMedia = (data) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()


  dispatch({
    type: CREATE_SBV_MEDIA_START,
  })
  return callPost('/campaignCreator/createSBVMedia/', {
    userId: currentUserId,
    newMedia: data,
  }, token).then((response) => {
    if (response.data.status === 'PendingDeepValidation' || response.data.status === 'Available' || response.data.status === 'Processing') {
      dispatch({
        type: CREATE_SBV_MEDIA_SUCCEED,
        data: response.data,
      })
    } else if (response.data.status === 'Failed') {
      dispatch({
        type: CREATE_SBV_MEDIA_FAIL,
      })
      return Promise.reject(response.data.statusMetadata.errors[0].message)
    } else {
      dispatch({
        type: CREATE_SBV_MEDIA_FAIL,
      })
      return Promise.reject(response.data.text
        || 'Failed to upload the video.')
    }
    if (response.data.statusCode && response.data.statusCode !== 200) {
      return Promise.reject(response.data.text
        || 'Failed to upload the video.')
    }

  }).catch((error) => {
    dispatch({
      type: CREATE_SBV_MEDIA_FAIL,
    })
    if (typeof error === 'string') {
      return Promise.reject(error)
    }
    if (error.response && error.response.data) {
      return Promise.reject(error.response.data.details
        || error.response.data.text
        || 'Failed to upload the video.')
    }
    return Promise.reject('Failed to upload the video.')
  })
}
export const createSBVCampaign = (data) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: CREATE_CAMPAIGN_START,
  })
  return callPost('/campaignCreator/createSBVCampaignsAsync/', {
    userId: currentUserId,
    newCampaign: data,
  }, token).then((response) => {
    if (response.data.statusCode && response.data.statusCode !== 200) {
      return Promise.reject(response.data.text
        || 'Failed to create a campaign.')
    }

    dispatch({
      type: CREATE_CAMPAIGN_FINISH,
    })
  }).catch((error) => {
    dispatch({
      type: CREATE_CAMPAIGN_FINISH,
    })
    if (typeof error === 'string') {
      return Promise.reject(error)
    }
    if (error.response && error.response.data) {
      return Promise.reject(error.response.data.text
        || error.response.data.details
        || 'Failed to create a campaign.')
    }
    return Promise.reject('Failed to create a campaign.')
  })
}
export const getMediaStatus = (data) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: CREATE_SBV_MEDIA_START,
  })
  return callGet('/campaignCreator/describeSBVMedia/', token, {
    userId: currentUserId,
    mediaId: data,
  }).then((response) => {
    if (response.data.status === 'PendingDeepValidation' || response.data.status === 'Available' || response.data.status === 'Processing') {
      dispatch({
        type: CREATE_SBV_MEDIA_SUCCEED,
        data: response.data,
      })
    } else if (response.data.status === 'Failed') {
      dispatch({
        type: CREATE_SBV_MEDIA_FAIL,
      })
      return Promise.reject(response.data.statusMetadata.errors[0].message)
    } else {
      dispatch({
        type: CREATE_SBV_MEDIA_FAIL,
      })
      return Promise.reject(response.data.text
        || 'Failed to upload the video.')
    }
    if (response.data.statusCode && response.data.statusCode !== 200) {
      return Promise.reject(response.data.text
        || 'Failed to upload the video.')
    }

  }).catch((error) => {
    dispatch({
      type: CREATE_SBV_MEDIA_FAIL,
    })
    if (typeof error === 'string') {
      return Promise.reject(error)
    }
    if (error.response && error.response.data) {
      return Promise.reject(error.response.data.details
        || error.response.data.text
        || 'Failed to upload the video.')
    }
    return Promise.reject('Failed to upload the video.')
  })
}
export const getStoreInfo = () => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: GET_SB_STOREINFO_START,
  })
  return callGet('/campaignCreator/getStoreInfo/', token, {
    userId: currentUserId,
  }).then((response) => {
    dispatch({
      type: GET_SB_STOREINFO_SUCCEED,
      data: response.data,
    })

  }).catch((error) => {
    dispatch({
      type: GET_SB_STOREINFO_FAIL,
    })
    toast.show({
      title: 'Danger',
      description: error || 'Failed to get storeInfo.',
    })
  })
}
export const getLandingPageAsin = (pageUrl) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: GET_LANDINGPAGE_ASINS_START,
  })
  return callGet('/campaignCreator/getLandingPageAsins/', token, {
    userId: currentUserId,
    pageUrl: pageUrl
  }).then((response) => {
    if(response.data.length === 0) {
      dispatch({
        type: GET_LANDINGPAGE_ASINS_FAIL,
      })
      toast.show({
        title: 'Warning',
        description: `This page doesn't have any products.`,
      })
    } else {
      dispatch({
        type: GET_LANDINGPAGE_ASINS_SUCCEED,
        data: response.data,
      })
    }
  }).catch((error) => {
    dispatch({
      type: GET_LANDINGPAGE_ASINS_FAIL,
    })
    toast.show({
      title: 'Danger',
      description: error || 'Failed to get store information.',
    })
  })
}
export const getStoreAsins = (store) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: GET_STORE_ASINS_START,
  })
  return callGet('/campaignCreator/getStoreAsins/', token, {
    userId: currentUserId,
    store: store
  }).then((response) => {
    if (response.data.length >= 3) {
      dispatch({
        type: GET_STORE_ASINS_SUCCEED,
        data: response.data,
      })
    } else {
      dispatch({
        type: GET_STORE_ASINS_FAIL,
      })
      toast.show({
        title: 'Warning',
        description: `This store doesn't have 4 or more pages, each with 1 or more unique products.`,
      })
    }
  }).catch((error) => {
    dispatch({
      type: GET_STORE_ASINS_FAIL,
    })
    toast.show({
      title: 'Danger',
      description: error || 'Failed to get store pages.',
    })
  })
}
export const createSDCreativeAsset = (data) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: CREATE_SD_ASSET_START,
  })
  return callPost('/campaignCreator/createSDCreativeAsset/', Object.assign({}, data, {
    userId: currentUserId,
    newImage: data
  }), token).then((response) => {
    if (response.data.statusCode && response.data.statusCode !== 200) {
      return Promise.reject(response.data.text
        || 'Failed to upload a image.')
    }
    dispatch({
      type: CREATE_SD_ASSET_SUCCEED,
      data: response.data,
    })
  }).catch((error) => {
    dispatch({
      type: CREATE_SD_ASSET_FAIL,
    })
    if (typeof error === 'string') {
      return Promise.reject(error)
    }
    if (error.response && error.response.data) {
      return Promise.reject(error.response.data.details
        || error.response.data.text
        || 'Failed to upload a image.')
    }
    return Promise.reject('Failed to upload a image.')
  })
}
export const createSDCreativeCustomAsset = (data) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: CREATE_SD_CUSTOM_ASSET_START,
  })
  return callPost('/campaignCreator/createSDCreativeAsset/', Object.assign({}, data, {
    userId: currentUserId,
    newImage: data
  }), token).then((response) => {
    if (response.data.statusCode && response.data.statusCode !== 200) {
      return Promise.reject(response.data.text
        || 'Failed to upload a image.')
    }
    dispatch({
      type: CREATE_SD_CUSTOM_ASSET_SUCCEED,
      data: response.data,
    })
  }).catch((error) => {
    dispatch({
      type: CREATE_SD_CUSTOM_ASSET_FAIL,
    })
    if (typeof error === 'string') {
      return Promise.reject(error)
    }
    if (error.response && error.response.data) {
      return Promise.reject(error.response.data.details
        || error.response.data.text
        || 'Failed to upload a image.')
    }
    return Promise.reject('Failed to upload a image.')
  })
}
export const createSBBrandLogo = (data) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: CREATE_SB_BRANDLOGO_START,
  })
  return callPost('/campaignCreator/createSBBrandLogo/', Object.assign({}, data, {
    userId: currentUserId,
    newImage: data
  }), token).then((response) => {
    if (response.data.statusCode && response.data.statusCode !== 200) {
      return Promise.reject(response.data.text
        || 'Failed to upload a image.')
    }
    dispatch({
      type: CREATE_SB_BRANDLOGO_SUCCEED,
      data: response.data.assetId + ':' + response.data.versionId,
    })
  }).catch((error) => {
    dispatch({
      type: CREATE_SB_BRANDLOGO_FAIL,
    })
    if (typeof error === 'string') {
      return Promise.reject(error)
    }
    if (error.response && error.response.data) {
      return Promise.reject(error.response.data.details
        || error.response.data.text
        || 'Failed to upload a image.')
    }
    return Promise.reject('Failed to upload a image.')
  })
}
export const getCurrentCreative = () => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: GET_SD_CURRENT_CREATIVE_START,
  })

  callGet('/campaignCreator/getCurrentCreative', token, {
    userId: currentUserId,
  }).then((response) => {
    dispatch({
      type: GET_SD_CURRENT_CREATIVE_SUCCESS,
      data: response.data,
    })
  }).catch(() => {
    dispatch({
      type: GET_SD_CURRENT_CREATIVE_FAIL
    })
    toast.show({
      title: 'Danger',
      description: 'Failed to retrieve current sponsored display creative.',
    })
  })
}