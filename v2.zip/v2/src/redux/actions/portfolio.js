import { callGet, callPost } from '../../services/axios'
import { toast } from '../../components/CommonComponents/ToastComponent/toast'

import {
  GET_PORTFOLIOS_SUCCEED,
  GET_PORTFOLIOS_FAIL,
  GET_PORTFOLIOS_START,
  CREATE_PORTFOLIO_START,
  CREATE_PORTFOLIO_SUCCEED,
  CREATE_PORTFOLIO_FAILD,
  ADD_CAMPAIGN_EXISTING_PORTFOLIO_START,
  ADD_CAMPAIGN_EXISTING_PORTFOLIO_SUCCEED,
  ADD_CAMPAIGN_EXISTING_PORTFOLIO_FAIL,
} from '../actionTypes/portfolio'

export const getPortfolios = () => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()
  dispatch({
    type: GET_PORTFOLIOS_START
  })
  callGet('/portfolio/getListPortfolio', token, {
    user: currentUserId,
  }).then((response) => {
    dispatch({
      type: GET_PORTFOLIOS_SUCCEED,
      data: response.data,
    })
  }).catch(() => {
    dispatch({
      type: GET_PORTFOLIOS_FAIL,
    })
  })
}

export const createPortfolio = ( { user, portfolioName }) => (dispatch, getState) => {
  const { auth: { token } } = getState()

  dispatch({
    type: CREATE_PORTFOLIO_START,
  })

  return callPost('/portfolio/createPortfolio', {
    user,
    portfolioName,
  }, token).then((response) => {
    if (!response.data.portfolioId) {
      if (response.data.text === 'Internal error. Please try again later') {
        toast.show({
          title: 'Danger',
          description: 'There was a problem creating your portfolio. Please wait a moment and try again.',
        })
      } else {
        toast.show({
          title: 'Danger',
          description: response.data.text || 'Failed to create portfolio.',
        })
      }
      dispatch({
        type: CREATE_PORTFOLIO_FAILD,
      })
      return Promise.reject()
    }
    toast.show({
      title: 'Success',
      description: `${response.data.portfolioName} has been created.`,
    })

    dispatch({
      type: CREATE_PORTFOLIO_SUCCEED,
      data: response.data,
    })

    return response.data.portfolioId
  }).catch((err) => {
    if (err.statusCode !== 207) {
      toast.show({
        title: 'Danger',
        description: err.text || 'Failed to create portfolio.',
      })
    }
    dispatch({
      type: CREATE_PORTFOLIO_FAILD,
    })
    return Promise.reject()
  })
}

//add campaign to existing portfolio
export const addCampaignToExistingPortfolio = ({ campaigns, user, portfolioId }) => (dispatch, getState) => {
  const { auth: { token } } = getState()
  dispatch({ type: ADD_CAMPAIGN_EXISTING_PORTFOLIO_START })
  return callPost('/campaign/updatePortfolioOfCampaign', {
    user,
    campaigns,
    portfolioId
  }, token).then((response) => {
    dispatch({
      type: ADD_CAMPAIGN_EXISTING_PORTFOLIO_SUCCEED,
      data: response.data,
    })
    toast.show({
      title: 'Success',
      description: campaigns.length === 1 ? 'The portfolio of campaign has been updated.' : 'The portfolio of campaigns has been updated.',
    })
    return
  }).catch((err) => {
    dispatch({ type: ADD_CAMPAIGN_EXISTING_PORTFOLIO_FAIL })
    toast.show({
      title: 'Danger',
      description: 'Failed to update the portfolio of campaign.',
    })
    return Promise.reject()
  })
}
