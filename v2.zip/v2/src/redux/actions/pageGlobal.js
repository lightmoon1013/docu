import {
  COLUMN_EDITOR_SHOW,
  COLUMN_EDITOR_HIDE,
  APM_SHOW,
  APM_HIDE,
  SELECT_COLUMNS,
  APPLY_PRODUCT_COLUMN_CHANGES,
  ANP_SHOW,
  ANP_HIDE,
  AEP_SHOW,
  AEP_HIDE,
  TEMPLATE_EDITOR_HIDE,
  COIN_PANE_TOGGLE,
  NOTIFICATION_PANE_TOGGLE,
  SHOW_FILTER,
  HIDE_FILTER,
  APPLY_FILTER,
} from '../actionTypes/pageGlobal'

export const applyProductColumnChanges = (data) => {
  return {
    type: APPLY_PRODUCT_COLUMN_CHANGES,
    data
  }
}

export const selectColumns = (data, columnEditorId = '') => {
  return {
    type: SELECT_COLUMNS,
    data,
    columnEditorId,
  }
}

export const showColumnEditorAction = (id = '') => {
  return {
    type: COLUMN_EDITOR_SHOW,
    id,
  }
}

export const hideColumnEditorAction = () => {
  return {
    type: COLUMN_EDITOR_HIDE
  }
}

// Show smart pilot manager.
export const showAPMAction = (campaignId) => {
  return {
    type: APM_SHOW,
    campaignId,
  }
}

// Hide smart pilot manager.
export const hideAPMAction = () => {
  return {
    type: APM_HIDE,
  }
}

//show add to new portfolio
export const showANPAction = (campaigns) => {
  return {
    type: ANP_SHOW,
    campaigns
  }
}

// Hide add to new portfolio.
export const hideANPAction = () => {
  return {
    type: ANP_HIDE,
  }
}

//show add to new portfolio
export const showAEPAction = (campaigns) => {
  return {
    type: AEP_SHOW,
    campaigns
  }
}

// Hide add to new portfolio.
export const hideAEPAction = () => {
  return {
    type: AEP_HIDE,
  }
}

// Hide smart pilot template editor.
export const hideTemplateEditor = () => {
  return {
    type: TEMPLATE_EDITOR_HIDE,
  }
}

export const toggleCoinPane = () => {
  return {
    type: COIN_PANE_TOGGLE,
  }
}

export const toggleNotificationPane = () => {
  return {
    type: NOTIFICATION_PANE_TOGGLE,
  }
}

export const showFilter = (filterName) => {
  return {
    type: SHOW_FILTER,
    data: filterName,
  }
}

export const hideFilter = (filterName) => {
  return {
    type: HIDE_FILTER,
    data: filterName,
  }
}

export const applyFilter = (filterName, values) => {
  return {
    type: APPLY_FILTER,
    data: {
      filterName,
      values,
    },
  }
}
