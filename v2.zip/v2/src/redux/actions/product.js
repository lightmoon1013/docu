import moment from 'moment'
import { toast } from '../../components/CommonComponents/ToastComponent/toast'
import { callGet, callPost } from '../../services/axios'

import {
  GET_SKUS_START,
  GET_SKUS_SUCCEED,
  GET_SKUS_FAIL,
  GET_PRODUCT_SUCCEED,
  GET_PRODUCT_FAIL,
  GET_PRODUCT_START,
  GET_PRODUCT_KPI_START,
  GET_PRODUCT_KPI_SUCCEED,
  GET_PRODUCT_KPI_FAIL,
  GET_PRODUCT_CHART_DATA_START,
  GET_PRODUCT_CHART_DATA_SUCCEED,
  GET_PRODUCT_CHART_DATA_FAIL,
  GET_PRODUCTS_START,
  GET_PRODUCTS_SUCCEED,
  GET_PRODUCTS_FAIL,
  UPDATE_BULK_COGS_START,
  UPDATE_BULK_COGS_SUCCESS,
  UPDATE_BULK_COGS_FAIL,
  UPDATE_PRODUCT_MARGIN_START,
  UPDATE_PRODUCT_MARGIN_SUCCESS,
  UPDATE_PRODUCT_MARGIN_FAIL,
  UPDATE_PRODUCT_COG_START,
  UPDATE_PRODUCT_COG_SUCCESS,
  UPDATE_PRODUCT_COG_FAIL,
  GET_PRODUCT_KEYWORDS_START,
  GET_PRODUCT_KEYWORDS_SUCCESS,
  GET_PRODUCT_KEYWORDS_FAIL,
  GET_CAMPAIGNS_FOR_PRODUCT_START,
  GET_CAMPAIGNS_FOR_PRODUCT_SUCCEED,
  GET_CAMPAIGNS_FOR_PRODUCT_FAIL,
} from '../actionTypes/product'

import { getAllTests, filterOrganicKeywords, filterKeywordWithZeroImpression, filterTargetAcosKeywords } from './productDetail'

export const getProductKeywords = ({id, sku}) => (dispatch, getState) => {
  const {auth: { token }, header: { currentStartDate, currentEndDate }, header: { currentUserId }} = getState()

  dispatch({ type: GET_PRODUCT_KEYWORDS_START })
  callGet(`/product/getKeywordsWithOrganicRanking`, token, {
    id,
    sku,
    startDate: moment(currentStartDate).format('YYYY-MM-DD'),
    endDate: moment(currentEndDate).format('YYYY-MM-DD'),
    user: currentUserId,
  }).then((response) => {
    dispatch({ type: GET_PRODUCT_KEYWORDS_SUCCESS, data: response.data })
  }).catch(() => {
    dispatch({
      type: GET_PRODUCT_KEYWORDS_FAIL
    })
  })
}

export const updateProductCog = ({cog, product}) => (dispatch, getState) => {
  const { auth: { token } } = getState()
  dispatch({ type: UPDATE_PRODUCT_COG_START })

  return callGet(`/product/updateMargins`, token, {
    ...product,
    cog
  }).then(() => {
    toast.show({
      title: 'Success',
      description: 'COG updated successfully.',
    })
    dispatch({
      type: UPDATE_PRODUCT_COG_SUCCESS,
      data: {
        product,
        cog
      },
    })
  }).catch(() => {
    dispatch({
      type: UPDATE_PRODUCT_COG_FAIL,
    })
    return Promise.reject('Filed to update product cog.')
  })
}

export const updateProductMargin = (cog) => (dispatch, getState) => {
  const { auth: { token }, product: { curProduct } } = getState()
  dispatch({ type: UPDATE_PRODUCT_MARGIN_START })

  callGet(`/product/updateMargins`, token, {
    ...curProduct,
    cog
  }).then(() => {
    toast.show({
      title: 'Success',
      description: 'COG updated successfully.',
    })
    dispatch({
      type: UPDATE_PRODUCT_MARGIN_SUCCESS,
      data: cog,
    })
  }).catch(() => {
    dispatch({
      type: UPDATE_PRODUCT_MARGIN_FAIL,
    })
  })
}

// Get a list of products for dashboard products table.
export const getProducts = ({ startDate, endDate }) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: GET_PRODUCTS_START,
  })

  callGet('/product/getProductsV2', token, {
    userId: currentUserId,
    startDate,
    endDate,
  }).then((response) => {
    dispatch({
      type: GET_PRODUCTS_SUCCEED,
      data: response.data,
    })
  }).catch(() => {
    dispatch({
      type: GET_PRODUCTS_FAIL
    })
  })
}

export const getSkus = () => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: GET_SKUS_START,
  })

  callGet('/campaignCreator/getSkus', token, {
    userId: currentUserId,
  }).then((response) => {
    dispatch({
      type: GET_SKUS_SUCCEED,
      data: response['data'],
    })
  }).catch(() => {
    dispatch({
      type: GET_SKUS_FAIL
    })
  })
}

export const getProductById = ({ id, startDate, endDate, sku }) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({ type: GET_PRODUCT_START })
  callGet('/product/getById', token, {
    id,
    user: currentUserId,
    startDate,
    endDate,
  }).then((response) => {
    dispatch({ type: GET_PRODUCT_SUCCEED, data: response['data'][0] })
  }).catch(() => {
    dispatch({
      type: GET_PRODUCT_FAIL
    })
  })

  dispatch({ type: GET_PRODUCT_KPI_START })
  callGet('/product/getKpiData', token, {
    id,
    user: currentUserId,
    startDate,
    endDate,
  }).then((response) => {
    dispatch({ type: GET_PRODUCT_KPI_SUCCEED, data: response['data'][0] })
  }).catch(() => {
    dispatch({
      type: GET_PRODUCT_KPI_FAIL
    })
  })

  dispatch({ type: GET_PRODUCT_CHART_DATA_START })
  callGet('/product/getChart', token, {
    id,
    user: currentUserId,
    startDate,
    endDate,
  }).then((response) => {
    dispatch({ type: GET_PRODUCT_CHART_DATA_SUCCEED, data: response.data })
  }).catch(() => {
    dispatch({
      type: GET_PRODUCT_CHART_DATA_FAIL
    })
  })

  dispatch(getAllTests(id))
  dispatch(filterTargetAcosKeywords({
    id,
    sku,
    userId: currentUserId,
    startDate,
    endDate
  }))
  dispatch(filterKeywordWithZeroImpression({
    id,
    sku,
    userId: currentUserId,
    startDate,
    endDate
  }))
  dispatch(filterOrganicKeywords({
    id,
    sku,
    userId: currentUserId,
    startDate,
    endDate
  }))
}

// upload bulk cogs for product table
export const updateBulkCogs = ({ skus }) => (dispatch, getState) => {
  const {
    auth: { token },
    header: { currentUserId },
  } = getState()

  dispatch({
    type: UPDATE_BULK_COGS_START,
  })

  callPost('/product/updateBulkCogs', {
    userId: currentUserId,
    skus,
  }, token).then((response) => {
    toast.show({
      title: 'Success',
      description: `${response.data.successSkus.length} SKUs have been updated.`,
    })
    if (response.data.invalidSkus && response.data.invalidSkus.length > 0) {
      const strInvalidSkus = response.data.invalidSkus.map(sku => sku.sku)
      toast.show({
        title: 'Warning',
        description: `${strInvalidSkus.join(', ')} are invalid.`,
      })
    }
    dispatch({
      type: UPDATE_BULK_COGS_SUCCESS,
      data: {
        successSkus: response.data.successSkus,
      }
    })
  }).catch(() => {
    toast.show({
      title: 'Danger',
      description: 'Failed to update the cogs.',
    })
    dispatch({
      type: UPDATE_BULK_COGS_FAIL,
    })
  })
}

export const getCampaignsForProduct = productId => (dispatch, getState) => {
  const {
    auth: { token },
    header: { currentUserId, currentStartDate, currentEndDate },
  } = getState()
  dispatch({
    type: GET_CAMPAIGNS_FOR_PRODUCT_START,
  })

  callGet('/product/getCampaignsForProduct' , token, {
    userId: currentUserId,
    productId,
    startDate: moment(currentStartDate).format('YYYY-MM-DD'),
    endDate: moment(currentEndDate).format('YYYY-MM-DD'),
  }).then((response) => {
    dispatch({
      type: GET_CAMPAIGNS_FOR_PRODUCT_SUCCEED,
      data: response.data,
    })
  }).catch(() => {
    toast.show({
      title: 'Danger',
      description: 'Failed to load campaigns for a product.',
    })
    dispatch({
      type: GET_CAMPAIGNS_FOR_PRODUCT_FAIL,
    })
  })
}
