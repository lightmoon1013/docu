import { callGet, callPost } from '../../services/axios'

export const loadFilters = type => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  return callGet('/filter/load', token, {
    userId: currentUserId,
    type,
  })
}

export const saveFilter = (type, name, value) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  return callPost('/filter/save', {
    userId: currentUserId,
    type,
    name,
    value,
  }, token)
}

export const deleteFilter = id => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  return callPost('/filter/delete', {
    userId: currentUserId,
    id,
  }, token)
}
