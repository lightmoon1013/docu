import { callPost } from '../../services/axios'

import { toast } from '../../components/CommonComponents/ToastComponent/toast'

import {
  LOAD_TEMPLATE,
  LOAD_TEMPLATE_SUCCESS,
  UPDATE_TEMPLATE,
  UPDATE_TEMPLATE_SUCCESS,
  DELETE_TEMPLATE,
  DELETE_TEMPLATE_SUCCESS,
} from '../actionTypes/templateEditor'

import {
  TEMPLATE_EDITOR_SHOW,
} from '../actionTypes/pageGlobal'

import { getTemplate } from './ap'

export const loadTemplate = (templateId, details = null) => (dispatch) => {
  if (details && templateId === details.id) {
    dispatch({
      type: LOAD_TEMPLATE_SUCCESS,
      data: {
        templateId,
        details,
      },
    })
  } else {
    dispatch({
      type: LOAD_TEMPLATE,
    })

    dispatch(getTemplate(templateId)).then((response) => {
      dispatch({
        type: LOAD_TEMPLATE_SUCCESS,
        data: {
          templateId,
          details: response.data,
        },
      })
    })
  }

  dispatch({
    type: TEMPLATE_EDITOR_SHOW,
  })
}

// Update settings for a given template.
export const updateTemplate = payload => (dispatch, getState) => {
  dispatch({
    type: UPDATE_TEMPLATE,
  })

  const { auth: { token }, header: { currentUserId } } = getState()

  return callPost('/ap/updateTemplate', Object.assign(payload, { user_id: currentUserId }), token).then(() => {
    dispatch({
      type: UPDATE_TEMPLATE_SUCCESS,
      data: payload,
    })

    toast.show({
      title: 'Success',
      description: 'Successfully saved.',
    })
  })
}

// Delete a given template.
export const deleteTemplate = templateId => (dispatch, getState) => {
  dispatch({
    type: DELETE_TEMPLATE,
  })

  const { auth: { token }, header: { currentUserId } } = getState()

  return callPost('/ap/deleteTemplate', {
    userId: currentUserId,
    templateId,
  }, token).then(() => {
    dispatch({
      type: DELETE_TEMPLATE_SUCCESS,
      data: templateId,
    })

    toast.show({
      title: 'Success',
      description: 'Successfully deleted.',
    })
  })
}
