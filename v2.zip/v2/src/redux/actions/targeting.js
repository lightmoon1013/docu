import { toast } from '../../components/CommonComponents/ToastComponent/toast'
import { callGet, callPost } from '../../services/axios'
import {
  GET_ALL_CATEGORIES_START,
  GET_ALL_CATEGORIES_SUCCEED,
  GET_ALL_CATEGORIES_FAILED,
  GET_PRODUCTS_BY_SEARCH_TEXT_START,
  GET_PRODUCTS_BY_SEARCH_TEXT_SUCCEED,
  GET_BRAND_RECOMMENDATION_START,
  GET_BRAND_RECOMMENDATION_SUCCEED,
  GET_REFINE_BRANDS_START,
  GET_REFINE_BRANDS_SUCCEED,
  GET_PRODUCTS_NEGATIVE_TARGETING_START,
  GET_PRODUCTS_NEGATIVE_TARGETING_SUCCEED,
} from '../actionTypes/targeting'

export const getAllCategories = () => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()
  dispatch({
    type: GET_ALL_CATEGORIES_START,
  })
  callGet('/targeting/getCategories', token, {
    user: currentUserId,
  }).then((response) => {
    dispatch({
      type: GET_ALL_CATEGORIES_SUCCEED,
      data: response.data,
    })
  }).catch((e) => {
    dispatch({
      type: GET_ALL_CATEGORIES_FAILED,
    })
  })
}

// Get products by search
export const getProductsBySearchText = (params, forAsins = false) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  if (!forAsins) {
    dispatch({
      type: GET_PRODUCTS_BY_SEARCH_TEXT_START,
    })
  }

  return callGet('/targeting/searchProduct', token, {
    ...params,
    user: currentUserId,
  }).then((response) => {
    if (!forAsins) {
      dispatch({
        type: GET_PRODUCTS_BY_SEARCH_TEXT_SUCCEED,
        data: response.data,
      })
    }
    return response.data
  })
}

// Get Brand Recommandations
export const getBrandRecommendations = (params, forRefine = false) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: !forRefine ? GET_BRAND_RECOMMENDATION_START : GET_REFINE_BRANDS_START,
  })
  callGet('/targeting/getBrandRecommendations', token, {
    ...params,
    user: currentUserId,
  }).then((response) => {
    dispatch({
      type: !forRefine ? GET_BRAND_RECOMMENDATION_SUCCEED : GET_REFINE_BRANDS_SUCCEED,
      data: response.data,
    })
  })
}

// Get Products for negative product targeting
export const getProductsNegativeTargeting = params => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: GET_PRODUCTS_NEGATIVE_TARGETING_START,
  })
  callGet('/targeting/searchProduct', token, {
    ...params,
    user: currentUserId,
  }).then((response) => {
    dispatch({
      type: GET_PRODUCTS_NEGATIVE_TARGETING_SUCCEED,
      data: response.data,
    })
  })
}

export const createNegativeTargets = negatives => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()
  return callPost('/targeting/createCampaignNegativeProductTargets/', {
    userId: currentUserId,
    negatives,
  }, token).then((response) => {
    if (response.data.statusCode !== 207) {
      toast.show({
        title: 'Success',
        description: 'Add negative ains to campaign level success.',
      })
    }
  }).catch(() => {
    toast.show({
      title: 'Danger',
      description: 'Failed to created negative product targets. Server error.',
    })
  })
}

export const createAdgroupNegativeTargets = negatives => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()
  return callPost('/targeting/createNegativeProductTargeting/', {
    userId: currentUserId,
    negatives,
  }, token).then((response) => {
    if (response.data.statusCode !== 207) {
      toast.show({
        title: 'Success',
        description: 'Add negative asins to adgoup success.',
      })
    } else {
      return Promise.reject('Failed to created negative product targets.')
    }
  }).catch(() => {
    toast.show({
      title: 'Danger',
      description: 'Failed to created negative product targets.',
    })
    return Promise.reject('Add negative asins to adgoup success.')
  })
}
