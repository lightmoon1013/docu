import { callGet, callPost } from '../../services/axios'

import {
  GET_OUT_OF_BUDGET_CAMPAIGNS_START,
  GET_OUT_OF_BUDGET_CAMPAIGNS_SUCCESS,
  GET_OUT_OF_BUDGET_CAMPAIGNS_FAIL,
  REVERT_LOG_START,
  REVERT_LOG_SUCCESS,
  REVERT_LOG_FAIL,
} from '../actionTypes/campaignLog'

import { toast } from '../../components/CommonComponents/ToastComponent/toast'

export const loadOutOfBudgetLog = () => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()
  dispatch({
    type: GET_OUT_OF_BUDGET_CAMPAIGNS_START,
  })
  callGet('/campaignlog/loadOutOfBudgetLog', token, {
    user: currentUserId,
  }).then((response) => {
    dispatch({
      type: GET_OUT_OF_BUDGET_CAMPAIGNS_SUCCESS,
      data: response['data'],
    })
  }).catch((error) => {
    dispatch({
      type: GET_OUT_OF_BUDGET_CAMPAIGNS_FAIL,
      error,
    })
    toast.show({
      title: 'Danger',
      description: 'Failed to get the campaigns out of budget.',
    })
  })
}

export const revertLog = (logId, campaignId) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()
  dispatch({
    type: REVERT_LOG_START,
  })

  return callPost('/campaignlog/revert/', {
    userId: currentUserId,
    logId,
  }, token).then((response) => {
    dispatch({
      type: REVERT_LOG_SUCCESS,
      data: {
        logId,
        campaignId,
        bidding: response.data.bidding,
      },
    })

    toast.show({
      title: 'Success',
      description: 'Successfully reverted.',
    })
  }).catch(() => {
    dispatch({
      type: REVERT_LOG_FAIL,
    })

    toast.show({
      title: 'Danger',
      description: 'Failed to revert the log.',
    })
  })
}
