import { callGet } from '../../services/axios'
import { toast } from '../../components/CommonComponents/ToastComponent/toast'

import {
  TOGGLE_DASHBOARD_TABLE,
  GET_DASHBOARD_SALES_STATS_START,
  GET_DASHBOARD_SALES_STATS_SUCCEED,
  GET_DASHBOARD_SALES_STATS_FAIL,
  GET_DASHBOARD_STATS_START,
  GET_DASHBOARD_STATS_SUCCEED,
  GET_DASHBOARD_STATS_FAIL,
} from '../actionTypes/dashboard'

export const toggleDashboardTable = () => {
  return {
    type: TOGGLE_DASHBOARD_TABLE
  }
}

export const getSalesStats = ({ startDate, endDate }) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: GET_DASHBOARD_SALES_STATS_START,
  })

  callGet(`/dashboard/getSalesStats/?userId=${currentUserId}`
    + `&startDate=${startDate}&endDate=${endDate}`, token).then((response) => {
    dispatch({
      type: GET_DASHBOARD_SALES_STATS_SUCCEED,
      data: response['data'],
    })
  }).catch(() => {
    dispatch({
      type: GET_DASHBOARD_SALES_STATS_FAIL
    })
    toast.show({
      title: 'Danger',
      description: 'Failed to get sales stats.',
    })
  })
}

export const getStats = ({ adType, startDate, endDate }) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: GET_DASHBOARD_STATS_START,
  })

  callGet(`/dashboard/getStats/?userId=${currentUserId}&adType=${adType}`
    + `&startDate=${startDate}&endDate=${endDate}`, token).then((response) => {
    dispatch({
      type: GET_DASHBOARD_STATS_SUCCEED,
      data: response['data'],
    })
  }).catch(() => {
    dispatch({
      type: GET_DASHBOARD_STATS_FAIL
    })
    toast.show({
      title: 'Danger',
      description: 'Failed to get stats.',
    })
  })
}
