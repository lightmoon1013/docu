import { toast } from '../../components/CommonComponents/ToastComponent/toast'
import { callGet } from '../../services/axios'

import {
  GET_LIST_CAMPAIGNS_START,
  GET_LIST_CAMPAIGNS_SUCCEED,
  GET_LIST_CAMPAIGNS_FAILED,
  GET_SUMMARY_CHART_START,
  GET_SUMMARY_CHART_SUCCEED,
  GET_SUMMARY_CHART_FAILED,
  SAVE_NOTIFICATION_PLAN_STARTED,
  SAVE_NOTIFICATION_PLAN_SUCCEED,
  SAVE_NOTIFICATION_PLAN_FAIL,
  GET_HEALTH_DATA_START,
  GET_HEALTH_DATA_SUCCEED,
  GET_HEALTH_DATA_FAIL,
} from '../actionTypes/health'

export const saveNotificationPlan = ({ weeklyAlert, monthlyAlert, additionalAlert }) => (dispatch, getState) => {
  const { auth: { token }, header: {currentUserId} } = getState()

  dispatch({
    type: SAVE_NOTIFICATION_PLAN_STARTED
  })
  callGet(`/account/saveNotifications`, token, {
    userId: currentUserId,
    weeklyAlert: weeklyAlert ? 1 : 0,
    monthlyAlert: monthlyAlert ? 1 : 0,
    additionalAlert: additionalAlert ? 1 : 0,
  }).then((response) => {
    dispatch({
      type: SAVE_NOTIFICATION_PLAN_SUCCEED,
      data: response.data,
    })

    toast.show({
      title: 'Success',
      description: 'Notification plan updated successfully.',
    })
  }).catch(() => {
    dispatch({
      type: SAVE_NOTIFICATION_PLAN_FAIL,
    })
    toast.show({
      title: 'Danger',
      description: 'Failed to update Notification plan.',
    })
  })
}

export const getSummaryChart = params => (dispatch, getState) => {
  const { auth: { token }, header: {currentUserId} } = getState()

  dispatch({
    type: GET_SUMMARY_CHART_START,
  })
  callGet(`/account/getSummaryChart`, token, {
    userId: currentUserId,
    ...params,
  }).then((response) => {
    dispatch({
      type: GET_SUMMARY_CHART_SUCCEED,
      data: response.data,
    })
  }).catch(() => {
    dispatch({
      type: GET_SUMMARY_CHART_FAILED,
    })
    toast.show({
      title: 'Danger',
      description: 'Failed to get summary chart.',
    })
  })
}

export const getCampaignData = params => (dispatch, getState) => {
  const { auth: { token }, header: {currentUserId} } = getState()
  dispatch({
    type: GET_LIST_CAMPAIGNS_START
  })
  callGet(`/account/listCampaignsAdType`, token, {
    user: currentUserId,
    ...params,
  }).then((response) => {
    dispatch({
      type: GET_LIST_CAMPAIGNS_SUCCEED,
      data: response.data,
    })
  }).catch((err) => {
    dispatch({ type: GET_LIST_CAMPAIGNS_FAILED })
    toast.show({
      title: 'Danger',
      description: 'Failed to get campaigns.',
    })
  })
}

export const getHealthData = params => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: GET_HEALTH_DATA_START,
  })
  callGet('/account/getHealthData', token, {
    userId: currentUserId,
    ...params,
  }).then((response) => {
    dispatch({
      type: GET_HEALTH_DATA_SUCCEED,
      data: response.data,
    })
  }).catch((err) => {
    dispatch({ type: GET_HEALTH_DATA_FAIL })
    toast.show({
      title: 'Danger',
      description: 'Failed to get health data.',
    })
  })
}
