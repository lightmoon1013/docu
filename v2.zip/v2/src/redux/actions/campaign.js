import { toast } from '../../components/CommonComponents/ToastComponent/toast'
import { callGet, callPost } from '../../services/axios'
import {
  GET_CAMPAIGNS_WITH_PORTFOLIO_START,
  GET_CAMPAIGNS_WITH_PORTFOLIO_SUCCESS,
  GET_CAMPAIGNS_WITH_PORTFOLIO_FAIL,
  GET_CAMPAIGNS_WITH_HISTORY_START,
  GET_CAMPAIGNS_WITH_HISTORY_SUCCESS,
  GET_CAMPAIGNS_WITH_HISTORY_FAIL,
  UPDATE_CAMPAIGN_ACOS_START,
  UPDATE_CAMPAIGN_ACOS_SUCCEED,
  UPDATE_CAMPAIGN_ACOS_FAIL,
  UPDATE_CAMPAIGN_DAILYBUDGET_START,
  UPDATE_CAMPAIGN_DAILYBUDGET_SUCCEED,
  UPDATE_CAMPAIGN_DAILYBUDGET_FAIL,
  UPDATE_CAMPAIGN_STATE_START,
  UPDATE_CAMPAIGN_STATE_SUCCEED,
  UPDATE_CAMPAIGN_NAMES_START,
  UPDATE_CAMPAIGN_NAMES_SUCCEED,
  UPDATE_CAMPAIGN_NAMES_FAIL,
  UPDATE_SP_BID_STRATEGY_START,
  UPDATE_SP_BID_STRATEGY_SUCCEED,
  UPDATE_SP_BID_STRATEGY_FAIL,
  GET_CAMPAIGNS_BUDGET_RULES_START,
  GET_CAMPAIGNS_BUDGET_RULES_SUCCEED,
  GET_CAMPAIGNS_BUDGET_RULES_FAIL,
  DISABLE_CAMPAIGN_BUDGET_RULE_START,
  DISABLE_CAMPAIGN_BUDGET_RULE_SUCCEED,
  DISABLE_CAMPAIGN_BUDGET_RULE_FAIL,
  CREATE_BUDGET_RULE_START,
  CREATE_BUDGET_RULE_SUCCEED,
  CREATE_BUDGET_RULE_FAIL,
  APPLY_CAMPAIGN_BUDGET_RULE_START,
  APPLY_CAMPAIGN_BUDGET_RULE_SUCCEED,
  APPLY_CAMPAIGN_BUDGET_RULE_FAIL,
  UPDATE_SP_PLACEMENT_START,
  UPDATE_SP_PLACEMENT_SUCCEED,
  UPDATE_SP_PLACEMENT_FAIL,
} from '../actionTypes/campaign'

// Create negative keywords - campaign level
export const createNegativeKeywords = (campaignType, campaignNegativeKeywords, adgroupId) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  return callPost('/campaign/createCampaignNegativeKeywords/', {
    user: currentUserId,
    campaignType,
    campaignNegativeKeywords,
    adgroupId,
  }, token).then((response) => {
    if (response.status === 207) {
      const errorText = response.data.text ? response.data.text : 'Failed to add negatives to campaign.'
      toast.show({
        title: 'Danger',
        description: errorText,
      })
      return
    }
    toast.show({
      title: 'Success',
      description: 'Negative Search Term was saved.',
    })
  }).catch(() => {
    toast.show({
      title: 'Danger',
      description: 'Failed to add negatives to campaign.',
    })
  })
}
// Create negative keywords - ad group level
export const createAdgroupNegativeKeywords = (negativeKeywords) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  return callPost('/campaign/createNegativeKeywords/', {
    user: currentUserId,
    negativeKeywords,
  }, token).then((response) => {
    if (response.data.status === 207) {
      const errorText = response.data.text ? response.data.text : 'Failed to Add Negative to Ad Group'
      toast.show({
        title: 'Danger',
        description: errorText,
      })
      return Promise.reject(errorText)
    }
    toast.show({
      title: 'Success',
      description: 'Negative Search Term was saved!',
    })

  }).catch((error) => {
    return Promise.reject(error)
  })
}

// Retrieve campaigns with portfolio.
export const getCampaignsWithPortfolio = (startDate, endDate) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()
  dispatch({
    type: GET_CAMPAIGNS_WITH_PORTFOLIO_START,
  })
  callGet('/campaign/listCampaignsWithPortfolio', token, {
    userId: currentUserId,
    startDate,
    endDate,
  }).then((response) => {
    dispatch({
      type: GET_CAMPAIGNS_WITH_PORTFOLIO_SUCCESS,
      data: response.data,
    })
  }).catch(() => {
    dispatch({
      type: GET_CAMPAIGNS_WITH_PORTFOLIO_FAIL,
    })
    toast.show({
      title: 'Danger',
      description: 'Failed to get campaigns.',
    })
  })
}

// Retrieve campaigns with history.
export const getCampaignsWithHistory = ({ startDate, endDate }) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()
  dispatch({
    type: GET_CAMPAIGNS_WITH_HISTORY_START,
  })
  callGet('/campaign/listCampaignsWithHistory', token, {
    userId: currentUserId,
    startDate,
    endDate,
  }).then((response) => {
    dispatch({
      type: GET_CAMPAIGNS_WITH_HISTORY_SUCCESS,
      data: response.data,
    })
  }).catch(() => {
    dispatch({
      type: GET_CAMPAIGNS_WITH_HISTORY_FAIL,
    })
    toast.show({
      title: 'Danger',
      description: 'Failed to get campaigns.',
    })
  })
}

export const updateCampaignAcos = (campaignId, campaignType, acos) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: UPDATE_CAMPAIGN_ACOS_START,
  })

  callGet('/campaign/updateAcos', token, {
    campaignId,
    campaignType,
    acos,
    user: currentUserId,
  }).then((response) => {
    toast.show({
      title: 'Success',
      description: 'Target ACoS updated successfully.',
    })
    dispatch({
      type: UPDATE_CAMPAIGN_ACOS_SUCCEED,
      data: {
        data: response.data,
        campaignId: campaignId,
        acos: acos,
      },
    })
  }).catch(() => {
    dispatch({
      type: UPDATE_CAMPAIGN_ACOS_FAIL,
    })
    toast.show({
      title: 'Danger',
      description: 'Failed to update target ACoS.',
    })
  })
}

export const updateCampaignsDailyBudget = (campaignId, campaignType, dailyBudget) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: UPDATE_CAMPAIGN_DAILYBUDGET_START,
  })

  callGet('/campaign/updateCampaignsDailyBudget', token, {
    campaignId,
    campaignType,
    dailyBudget,
    user: currentUserId,
  }).then((response) => {
    toast.show({
      title: 'Success',
      description: 'Daily budget updated successfully.',
    })
    dispatch({
      type: UPDATE_CAMPAIGN_DAILYBUDGET_SUCCEED,
      data: {
        data: response.data,
        campaignId: campaignId,
        dailyBudget: dailyBudget,
      },
    })
  }).catch((error) => {
    dispatch({
      type: UPDATE_CAMPAIGN_DAILYBUDGET_FAIL,
    })
    toast.show({
      title: 'Danger',
      description: 'Failed to update daily budget.',
    })
  })
}

// Update campaign state.
export const updateCampaignsState = (campaignsArr, state) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: UPDATE_CAMPAIGN_STATE_START,
  })

  callPost('/campaign/updateCampaignsState', {
    user: currentUserId,
    campaignsArr,
    state,
  }, token).then((response) => {
    dispatch({
      type: UPDATE_CAMPAIGN_STATE_SUCCEED,
      data: response.data,
    })
  })
}

//Update campaign names
export const updateCampaignNames = (campaignsArr) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: UPDATE_CAMPAIGN_NAMES_START,
  })

  callPost('/campaign/updateBulkCampaignNames', {
    user: currentUserId,
    campaignsArr,
  }, token).then((response) => {
    dispatch({
      type: UPDATE_CAMPAIGN_NAMES_SUCCEED,
      data: response.data,
    })
    toast.show({
      title: 'Success',
      description: `Campaign Names have been successfully updated.`
    })
  }).catch(() => {
    dispatch({
      type: UPDATE_CAMPAIGN_NAMES_FAIL,
    })
    toast.show({
      title: 'Danger',
      description: 'Failed to update campaign names.',
    })
  })
}

//Update SP Bid Strategy
export const updateSPBidStrategy = (campaignsArr) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: UPDATE_SP_BID_STRATEGY_START,
  })

  callPost('/campaign/updateBulkSPBidStrategy', {
    user: currentUserId,
    campaignsArr,
  }, token).then((response) => {
    dispatch({
      type: UPDATE_SP_BID_STRATEGY_SUCCEED,
      data: response.data,
    })
    toast.show({
      title: 'Success',
      description: `Bid strategy has been successfully updated.`
    })
  }).catch((err) => {
    dispatch({
      type: UPDATE_SP_BID_STRATEGY_FAIL,
    })
    toast.show({
      title: 'Danger',
      description: 'Failed to update bid strategy.',
    })
  })
}

//Update SP Placement
export const updateSPPlacementStrategy = (campaignsArr) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: UPDATE_SP_PLACEMENT_START,
  })

  callPost('/campaign/updateBulkSPBidStrategy', {
    user: currentUserId,
    campaignsArr,
  }, token).then((response) => {
    dispatch({
      type: UPDATE_SP_PLACEMENT_SUCCEED,
      data: response.data,
    })
    toast.show({
      title: 'Success',
      description: `Placement has been successfully updated.`
    })
  }).catch((err) => {
    dispatch({
      type: UPDATE_SP_PLACEMENT_FAIL,
    })
    toast.show({
      title: 'Danger',
      description: 'Failed to update placement.',
    })
  })
}

//Get Current Budget Rules
export const getCurrentBudgetRules = (campaignsArr) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: GET_CAMPAIGNS_BUDGET_RULES_START,
  })

  callPost('/campaign/getCurrentBudgetRules', {
    user: currentUserId,
    campaignsArr,
  }, token).then((response) => {
    dispatch({
      type: GET_CAMPAIGNS_BUDGET_RULES_SUCCEED,
      data: response.data,
    })
  }).catch((err) => {
    dispatch({
      type: GET_CAMPAIGNS_BUDGET_RULES_FAIL,
    })
    toast.show({
      title: 'Danger',
      description: 'Failed to get current budget rules.',
    })
  })
}

//Disable Campaign Budget Rule
export const disableCampaignsBudgetRule = (campaignArr) => (dispatch, getState) => {

  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: DISABLE_CAMPAIGN_BUDGET_RULE_START,
  })

  callPost('/campaign/disableCampaignsBudgetRule', {
    user: currentUserId,
    campaignArr,
  }, token).then((response) => {
    dispatch({
      type: DISABLE_CAMPAIGN_BUDGET_RULE_SUCCEED,
      data: response.data,
    })
  }).catch((err) => {
    dispatch({
      type: DISABLE_CAMPAIGN_BUDGET_RULE_FAIL,
    })
    toast.show({
      title: 'Danger',
      description: 'Failed to delete budget rule.',
    })
  })
}

//Create a Budget Rule
export const createBudgetRule = (budgetRule) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: CREATE_BUDGET_RULE_START,
  })

  return callPost('/campaign/createBudgetRule', {
    user: currentUserId,
    budgetRule,
  }, token).then((response) => {
    dispatch({
      type: CREATE_BUDGET_RULE_SUCCEED,
    })

    return response.data
  }).catch(() => {
    dispatch({
      type: CREATE_BUDGET_RULE_FAIL,
    })

    return Promise.reject('Failed to create a budget rule.')
  })
}

//Create a Budget Rule
export const createSPPerformanceBudgetRule = (budgetRule) => (dispatch, getState) => {
  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: CREATE_BUDGET_RULE_START,
  })

  return callPost('/campaign/createSPPerformanceBudgetRule', {
    user: currentUserId,
    budgetRule,
  }, token).then((response) => {
    dispatch({
      type: CREATE_BUDGET_RULE_SUCCEED,
    })

    return response.data
  }).catch(() => {
    dispatch({
      type: CREATE_BUDGET_RULE_FAIL,
    })

    return Promise.reject('Failed to create a budget rule.')
  })
}

//Apply Campaign Budget Rule
export const applyCampaignsBudgetRule = (campaignArr) => (dispatch, getState) => {

  const { auth: { token }, header: { currentUserId } } = getState()

  dispatch({
    type: APPLY_CAMPAIGN_BUDGET_RULE_START,
  })

  callPost('/campaign/applyCampaignsBudgetRule', {
    user: currentUserId,
    campaignArr,
  }, token).then((response) => {
    dispatch({
      type: APPLY_CAMPAIGN_BUDGET_RULE_SUCCEED,
    })
    toast.show({
      title: 'Success',
      description: 'New budget rule is applied to these campaigns.',
    })
  }).catch((err) => {
    dispatch({
      type: APPLY_CAMPAIGN_BUDGET_RULE_FAIL,
    })
    toast.show({
      title: 'Danger',
      description: 'Failed to apply budget rule.',
    })
  })
}
