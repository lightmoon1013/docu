import {
  LOAD_TEMPLATE,
  LOAD_TEMPLATE_SUCCESS,
  UPDATE_TEMPLATE,
  UPDATE_TEMPLATE_SUCCESS,
  DELETE_TEMPLATE,
  DELETE_TEMPLATE_SUCCESS,
} from '../actionTypes/templateEditor'

import {
  SAVE_AP_TEMPLATE,
  SAVE_AP_TEMPLATE_SUCCESS,
} from '../actionTypes/ap'

import {
  parseAPSettings,
} from '../../services/helper'

const initialState = {
  templateId: null,
  details: null,
  isLoading: false,
  isSaving: false,
}

export default (state = initialState, action) => {
  switch (action.type) {
    case LOAD_TEMPLATE:
      return {
        ...state,
        isLoading: true,
      }
    case LOAD_TEMPLATE_SUCCESS:
      return {
        ...state,
        templateId: action.data.templateId,
        details: parseAPSettings(action.data.details),
        isLoading: false,
      }
    case UPDATE_TEMPLATE:
    case DELETE_TEMPLATE:
    case SAVE_AP_TEMPLATE:
      return {
        ...state,
        isSaving: true,
      }
    case UPDATE_TEMPLATE_SUCCESS:
    case DELETE_TEMPLATE_SUCCESS:
    case SAVE_AP_TEMPLATE_SUCCESS:
      return {
        ...state,
        isSaving: false,
      }
    default:
      return state
  }
}
