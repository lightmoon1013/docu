import { combineReducers } from 'redux'

import header from './header'
import auth from './auth'
import campaign from './campaign'
import campaignLog from './campaignLog'
import product from './product'
import portfolio from './portfolio'
import dashboard from './dashboard'
import ap from './ap'
import targeting from './targeting'
import health from './health'
import campaignCreator from './campaignCreator'
import coin from './coin'
import activityLog from './activityLog'
import campaignDetail from './campaignDetail'
import productDetail from './productDetail'
import pageGlobal from './pageGlobal'
import templateEditor from './templateEditor'
import bulkEngine from './bulkEngine'

const appReducer = combineReducers({
  header,
  auth,
  campaign,
  campaignLog,
  product,
  dashboard,
  portfolio,
  ap,
  targeting,
  health,
  campaignCreator,
  coin,
  activityLog,
  campaignDetail,
  productDetail,
  pageGlobal,
  templateEditor,
  bulkEngine,
})

const rootReducer = (state, action) => {
  return appReducer(state, action)
}

export default rootReducer
