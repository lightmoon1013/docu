import {
  GET_SP_SUGGESTIONS_START,
  GET_SP_SUGGESTIONS_SUCCEED,
  GET_SP_SUGGESTIONS_FAIL,
  GET_SUGGESTED_BIDS_START,
  GET_SUGGESTED_BIDS_SUCCEED,
  GET_SUGGESTED_BIDS_FAIL,
  CREATE_CAMPAIGN_START,
  CREATE_CAMPAIGN_FINISH,
  GET_SD_SUGGESTIONS_START,
  GET_SD_SUGGESTIONS_SUCCEED,
  GET_BRANDS_DATA_START,
  GET_BRANDS_DATA_SUCCEED,
  GET_BRANDS_DATA_FAIL,
  GET_BRAND_LOGO_START,
  GET_BRAND_LOGO_SUCCEED,
  GET_BRAND_LOGO_FAIL,
  GET_SB_SUGGESTIONS_START,
  GET_SB_SUGGESTIONS_SUCCEED,
  GET_SB_SUGGESTIONS_FAIL,
  GET_SB_SUGGESTED_BIDS_START,
  GET_SB_SUGGESTED_BIDS_SUCCEED,
  GET_SB_SUGGESTED_BIDS_FAIL,
  CREATE_SBV_MEDIA_START,
  CREATE_SBV_MEDIA_SUCCEED,
  CREATE_SBV_MEDIA_FAIL,
  GET_SB_STOREINFO_START,
  GET_SB_STOREINFO_SUCCEED,
  GET_SB_STOREINFO_FAIL,
  GET_LANDINGPAGE_ASINS_START,
  GET_LANDINGPAGE_ASINS_SUCCEED,
  GET_LANDINGPAGE_ASINS_FAIL,
  GET_STORE_ASINS_START,
  GET_STORE_ASINS_SUCCEED,
  GET_STORE_ASINS_FAIL,
  CREATE_SD_ASSET_START,
  CREATE_SD_ASSET_SUCCEED,
  CREATE_SD_ASSET_FAIL,
  CREATE_SD_CUSTOM_ASSET_START,
  CREATE_SD_CUSTOM_ASSET_SUCCEED,
  CREATE_SD_CUSTOM_ASSET_FAIL,
  GET_SD_SUGGESTIONS_FAILED,
  CREATE_SB_BRANDLOGO_START,
  CREATE_SB_BRANDLOGO_SUCCEED,
  CREATE_SB_BRANDLOGO_FAIL,
  GET_SD_CURRENT_CREATIVE_START,
  GET_SD_CURRENT_CREATIVE_SUCCESS,
  GET_SD_CURRENT_CREATIVE_FAIL,
  GET_SD_PRODUCTS_METADATA_START,
  GET_SD_PRODUCTS_METADATA_SUCCESS,
  GET_SD_PRODUCTS_METADATA_FAILED,
  GET_SD_SUGGESTED_BIDS_START,
  GET_SD_SUGGESTED_BIDS_SUCCESS,
  GET_SD_SUGGESTED_BIDS_FAILED,
  CREATE_SD_AD_GROUP_START,
  CREATE_SD_AD_GROUP_SUCCEED,
  CREATE_SD_AD_GROUP_FAIL,
  CREATE_SP_AD_GROUP_START,
  CREATE_SP_AD_GROUP_SUCCEED,
  CREATE_SP_AD_GROUP_FAIL,
} from '../actionTypes/campaignCreator'

const initialState = {
  isSPSuggestionsLoading: false,
  suggestedKeywords: [],
  suggestedSPCategories: [],
  isSuggestedBidsLoading: false,
  suggestedBids: [],
  isCreating: false,
  isSDSuggestionsLoading: false,
  suggestedSDProducts: [],
  suggestedSDCategories: [],
  isSBBrandDataLoading: false,
  sbBrandData: [],
  isSBBrandLogoLoading: false,
  sbBrandLogos: [],
  isSBSuggestionsLoading: false,
  suggestedSBKeywords: [],
  suggestedSBCategories: [],
  isSBSuggestedBidsLoading: false,
  suggestedSBBids: [],
  isUploadingVideo: false,
  uploadedVideoData: {},
  uploadVideoStatus: '',
  isStoreInfoLoading: false,
  sbStoreInfo: [],
  isLandingPageAsinsLoading: false,
  landingPageProducts: [],
  isStorePageAsinsLoading: false,
  storePageProducts: [],
  isUploadingSDImage: false,
  uploadSDImageData: {},
  uploadSDCustomImageData: {},
  isSBBrandLogoCreating: false,
  sbNewBrandAssetId: '',
  isSDCurrentCreativeLoading: false,
  sdCurrentCreatives: [],
  productsMetaData: [],
  isProductsMetaDataLoading: false,
  isSDSuggestedBidLoading: false,
  sdSuggestedBids: [],
  isCreatingAdgroup: false
}

export default (state = initialState, action) => {
  switch (action.type) {
    case GET_SP_SUGGESTIONS_START:
      return {
        ...state,
        isSPSuggestionsLoading: true,
      }
    case GET_SP_SUGGESTIONS_SUCCEED:
      return {
        ...state,
        isSPSuggestionsLoading: false,
        suggestedKeywords: action.data.keywords,
        suggestedSPCategories: action.data.categories.filter(category => category.canBeTargeted),
      }
    case GET_SP_SUGGESTIONS_FAIL:
      return {
        ...state,
        isSPSuggestionsLoading: false,
      }
    case GET_SUGGESTED_BIDS_START:
      return {
        ...state,
        isSuggestedBidsLoading: true,
        suggestedBids: [],
      }
    case GET_SUGGESTED_BIDS_SUCCEED:
      return {
        ...state,
        isSuggestedBidsLoading: false,
        suggestedBids: action.data,
      }
    case GET_SUGGESTED_BIDS_FAIL:
      return {
        ...state,
        isSuggestedBidsLoading: false,
      }
    case CREATE_CAMPAIGN_START:
      return {
        ...state,
        isCreating: true,
      }
    case CREATE_CAMPAIGN_FINISH:
      return {
        ...state,
        isCreating: false,
      }
    case GET_SD_SUGGESTIONS_START:
      return {
        ...state,
        isSDSuggestionsLoading: true,
      }
    case GET_SD_SUGGESTIONS_SUCCEED:
      return {
        ...state,
        isSDSuggestionsLoading: false,
        suggestedSDProducts: action.data.products,
        suggestedSDCategories: action.data.categories,
      }
    case GET_BRANDS_DATA_START:
      return {
        ...state,
        isSBBrandDataLoading: true,
      }
    case GET_BRANDS_DATA_SUCCEED:
      return {
        ...state,
        isSBBrandDataLoading: false,
        sbBrandData: action.data.brandData,
      }
    case GET_BRANDS_DATA_FAIL:
      return {
        ...state,
        isSBBrandDataLoading: false,
      }
    case GET_BRAND_LOGO_START:
      return {
        ...state,
        isSBBrandLogoLoading: true,
      }
    case GET_BRAND_LOGO_SUCCEED:
      return {
        ...state,
        isSBBrandLogoLoading: false,
        sbBrandLogos: action.data.brandLogos,
      }
    case GET_BRAND_LOGO_FAIL:
      return {
        ...state,
        isSBBrandLogoLoading: false,
      }
    case GET_SB_SUGGESTIONS_START:
      return {
        ...state,
        isSBSuggestionsLoading: true,
      }
    case GET_SB_SUGGESTIONS_SUCCEED:
      return {
        ...state,
        isSBSuggestionsLoading: false,
        suggestedSBKeywords: action.data.suggestedSBKeywords,
        suggestedSBCategories: action.data.suggestedSBCategories.filter(category => category.isTargetable),
      }
    case GET_SB_SUGGESTIONS_FAIL:
      return {
        ...state,
        isSBSuggestionsLoading: false,
      }
    case GET_SB_SUGGESTED_BIDS_START:
      return {
        ...state,
        isSBSuggestedBidsLoading: true,
        suggestedSBBids: [],
      }
    case GET_SB_SUGGESTED_BIDS_SUCCEED:
      return {
        ...state,
        isSBSuggestedBidsLoading: false,
        suggestedSBBids: action.data,
      }
    case GET_SB_SUGGESTED_BIDS_FAIL:
      return {
        ...state,
        isSBSuggestedBidsLoading: false,
      }
    case CREATE_SBV_MEDIA_START:
      return {
        ...state,
        isUploadingVideo: true,
      }
    case CREATE_SBV_MEDIA_SUCCEED:
      return {
        ...state,
        isUploadingVideo: false,
        uploadedVideoData: action.data,
        uploadVideoStatus: action.data.status,
      }
    case CREATE_SBV_MEDIA_FAIL:
      return {
        ...state,
        isUploadingVideo: false,
        uploadedVideoData: {},
        uploadVideoStatus: '',
      }
    case GET_SB_STOREINFO_START:
      return {
        ...state,
        isStoreInfoLoading: true,
      }
    case GET_SB_STOREINFO_SUCCEED:
      return {
        ...state,
        isStoreInfoLoading: false,
        sbStoreInfo: action.data,
      }
    case GET_SB_STOREINFO_FAIL:
      return {
        ...state,
        isStoreInfoLoading: false,
        sbStoreInfo: [],
      }
    case GET_LANDINGPAGE_ASINS_START:
      return {
        ...state,
        isLandingPageAsinsLoading: true,
      }
    case GET_LANDINGPAGE_ASINS_SUCCEED:
      return {
        ...state,
        isLandingPageAsinsLoading: false,
        landingPageProducts: action.data,
      }
    case GET_LANDINGPAGE_ASINS_FAIL:
      return {
        ...state,
        isLandingPageAsinsLoading: false,
        landingPageProducts: [],
      }
    case GET_STORE_ASINS_START:
      return {
        ...state,
        isStorePageAsinsLoading: true,
      }
    case GET_STORE_ASINS_SUCCEED:
      return {
        ...state,
        isStorePageAsinsLoading: false,
        storePageProducts: action.data,
      }
    case GET_STORE_ASINS_FAIL:
      return {
        ...state,
        isStorePageAsinsLoading: false,
        storePageProducts: [],
      }
    case CREATE_SD_ASSET_START:
      return {
        ...state,
        isUploadingSDImage: true,
      }
    case CREATE_SD_ASSET_SUCCEED:
      return {
        ...state,
        isUploadingSDImage: false,
        uploadSDImageData: action.data,
      }
    case CREATE_SD_ASSET_FAIL:
      return {
        ...state,
        isUploadingSDImage: false,
        uploadSDImageData: {},
      }
    case CREATE_SD_CUSTOM_ASSET_START:
      return {
        ...state,
        isUploadingSDImage: true,
      }
    case CREATE_SD_CUSTOM_ASSET_SUCCEED:
      return {
        ...state,
        isUploadingSDImage: false,
        uploadSDCustomImageData: action.data,
      }
    case CREATE_SD_CUSTOM_ASSET_FAIL:
      return {
        ...state,
        isUploadingSDImage: false,
        uploadSDCustomImageData: {},
      }
    case GET_SD_SUGGESTIONS_FAILED:
      return {
        ...state,
        isSDSuggestionsLoading: false,
      }
    case CREATE_SB_BRANDLOGO_START:
      return {
        ...state,
        isSBBrandLogoCreating: true,
        sbNewBrandAssetId: ''
      }
    case CREATE_SB_BRANDLOGO_SUCCEED:
      return {
        ...state,
        isSBBrandLogoCreating: false,
        sbNewBrandAssetId: action.data,
      }
    case CREATE_SB_BRANDLOGO_FAIL:
      return {
        ...state,
        isSBBrandLogoCreating: false,
        sbNewBrandAssetId: '',
      }
    case GET_SD_CURRENT_CREATIVE_START:
      return {
        ...state,
        isSDCurrentCreativeLoading: true,
      }
    case GET_SD_CURRENT_CREATIVE_SUCCESS:
      return {
        ...state,
        isSDCurrentCreativeLoading: false,
        sdCurrentCreatives: action.data,
      }
    case GET_SD_CURRENT_CREATIVE_FAIL:
      return {
        ...state,
        isSDCurrentCreativeLoading: false,
        sdCurrentCreatives: [],
      }
    case GET_SD_PRODUCTS_METADATA_START:
      return {
        ...state,
        isProductsMetaDataLoading: true,
      }
    case GET_SD_PRODUCTS_METADATA_SUCCESS:
      return {
        ...state,
        isProductsMetaDataLoading: false,
        productsMetaData: action.data,
      }
    case GET_SD_PRODUCTS_METADATA_FAILED:
      return {
        ...state,
        isProductsMetaDataLoading: false,
        productsMetaData: [],
      }
    case GET_SD_SUGGESTED_BIDS_START:
      return {
        ...state,
        isSDSuggestedBidLoading: true,
      }
    case GET_SD_SUGGESTED_BIDS_SUCCESS:
      return {
        ...state,
        isSDSuggestedBidLoading: false,
        sdSuggestedBids: action.data,
      }
    case GET_SD_SUGGESTED_BIDS_FAILED:
      return {
        ...state,
        isSDSuggestedBidLoading: false,
        sdSuggestedBids: [],
      }
    case CREATE_SP_AD_GROUP_START:
      return {
        ...state,
        isCreatingAdgroup: true,
      }
    case CREATE_SP_AD_GROUP_SUCCEED:
      return {
        ...state,
        isCreatingAdgroup: false,
      }
    case CREATE_SP_AD_GROUP_FAIL:
      return {
        ...state,
        isCreatingAdgroup: false,
      }
    case CREATE_SD_AD_GROUP_START:
      return {
        ...state,
        isCreatingAdgroup: true,
      }
    case CREATE_SD_AD_GROUP_SUCCEED:
      return {
        ...state,
        isCreatingAdgroup: false,
      }
    case CREATE_SD_AD_GROUP_FAIL:
      return {
        ...state,
        isCreatingAdgroup: false,
      }
    default:
      return state
  }
}
