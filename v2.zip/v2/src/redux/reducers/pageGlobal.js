import {
  campaignColumnList,
  productColumnList,
  portfolioColumnList,
  productCampaignColumnList,
} from '../../utils/defaultValues'
import { GET_ALL_ACCOUNT_START } from '../actionTypes/header'
import {
  COLUMN_EDITOR_SHOW,
  COLUMN_EDITOR_HIDE,
  APM_SHOW,
  APM_HIDE,
  SELECT_COLUMNS,
  APPLY_PRODUCT_COLUMN_CHANGES,
  ANP_SHOW,
  ANP_HIDE,
  AEP_SHOW,
  AEP_HIDE,
  TEMPLATE_EDITOR_SHOW,
  TEMPLATE_EDITOR_HIDE,
  COIN_PANE_TOGGLE,
  NOTIFICATION_PANE_TOGGLE,
  SHOW_FILTER,
  HIDE_FILTER,
  APPLY_FILTER,
} from '../actionTypes/pageGlobal'

export const initialState = {
  showColumnEditor: false,
  showAPM: false,
  campaignTableColumns: campaignColumnList.filter(col => col.default).map(col => col.key),
  productCampaignTableColumns: productCampaignColumnList.filter(col => col.default).map(col => col.key),
  productTableColumns: productColumnList.filter(col => col.default).map(col => col.key),
  portfolioTableColumns: portfolioColumnList.filter(col => col.default).map(col => col.key),
  stTableColumns: [],
  showANP: false,
  showAEP: false,
  showTemplateEditor: false,
  showCoinPane: false,
  showNotificationPane: false,
  // The ID of column editor that is opened now.
  visibleColumnEditorId: '',
  // The name of filter that is opened now.
  visibleFilterName: '',
  // Current filter values for various pages.
  filterValues: {},
}

const pageGlobal = (state = initialState, action) => {
  switch (action.type) {
    case GET_ALL_ACCOUNT_START:
      return {
        ...state,
        showColumnEditor: false,
        showAPM: false,
        showANP: false,
        showAEP: false,
        showCoinPane: false,
        showNotificationPane: false,
        visibleFilterName: '',
        filterValues: {},
      }
    case COLUMN_EDITOR_SHOW:
      return {
        ...state,
        showColumnEditor: true,
        visibleColumnEditorId: action.id,
      }
    case COLUMN_EDITOR_HIDE:
      return {
        ...state,
        showColumnEditor: false,
        visibleColumnEditorId: '',
      }
    case APM_SHOW:
      return {
        ...state,
        showAPM: true,
      }
    case APM_HIDE:
      return {
        ...state,
        showAPM: false,
      }
    case SELECT_COLUMNS:
      let key = 'campaignTableColumns'
      if (action.columnEditorId === 'productCampaign') {
        key = 'productCampaignTableColumns'
      } else if (action.columnEditorId === 'portfolioTable') {
        key = 'portfolioTableColumns'
      }
      const newState = {
        ...state,
        showColumnEditor: false,
        [key]: action.data
      }
      if (action.columnEditorId === 'bulkStOpResult'
        || action.columnEditorId === 'stExResult'
        || action.columnEditorId === 'targetSearchSTResult') {
        const stCols = []
        if (action.data.includes('st_impr_rank')) {
          stCols.push('st_impr_rank')
        }
        if (action.data.includes('st_impr_share')) {
          stCols.push('st_impr_share')
        }
        newState.stTableColumns = stCols
      }
      return newState
    case APPLY_PRODUCT_COLUMN_CHANGES:
      return {
        ...state,
        showColumnEditor: false,
        productTableColumns: action.data
      }
    case ANP_SHOW:
      return {
        ...state,
        showANP: true,
      }
    case ANP_HIDE:
      return {
        ...state,
        showANP: false,
      }
    case AEP_SHOW:
      return {
        ...state,
        showAEP: true,
      }
    case AEP_HIDE:
      return {
        ...state,
        showAEP: false,
      }
    case TEMPLATE_EDITOR_SHOW:
      return {
        ...state,
        showTemplateEditor: true,
      }
    case TEMPLATE_EDITOR_HIDE:
      return {
        ...state,
        showTemplateEditor: false,
      }
    case COIN_PANE_TOGGLE:
      return {
        ...state,
        showCoinPane: !state.showCoinPane,
      }
    case NOTIFICATION_PANE_TOGGLE:
      return {
        ...state,
        showNotificationPane: !state.showNotificationPane,
      }
    case SHOW_FILTER:
      return {
        ...state,
        visibleFilterName: action.data,
      }
    case HIDE_FILTER:
      return {
        ...state,
        visibleFilterName: state.visibleFilterName === action.data
          ? ''
          : state.visibleFilterName,
      }
    case APPLY_FILTER:
      return {
        ...state,
        visibleFilterName: state.visibleFilterName === action.data.filterName
          ? ''
          : state.visibleFilterName,
        filterValues: Object.assign({}, state.filterValues, {
          [action.data.filterName]: action.data.values,
        })
      }
    default:
      return state
  }
}

export default pageGlobal
