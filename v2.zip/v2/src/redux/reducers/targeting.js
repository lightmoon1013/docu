import {
  GET_ALL_CATEGORIES_START,
  GET_ALL_CATEGORIES_SUCCEED,
  GET_ALL_CATEGORIES_FAILED,
  GET_PRODUCTS_BY_SEARCH_TEXT_START,
	GET_PRODUCTS_BY_SEARCH_TEXT_SUCCEED,
  GET_BRAND_RECOMMENDATION_START,
  GET_BRAND_RECOMMENDATION_SUCCEED,
  GET_REFINE_BRANDS_START,
  GET_REFINE_BRANDS_SUCCEED,
  GET_PRODUCTS_NEGATIVE_TARGETING_START,
  GET_PRODUCTS_NEGATIVE_TARGETING_SUCCEED,
} from '../actionTypes/targeting'

export const initialState = {
  isAllCategoriesLoading: false,
  isSearchedProductsLoading: false,
  isNegativeTargetingBrandsLoading: false,
  isNegativeTargetingProductsLoading: false,
  isRefineBrandsLoading: false,
  targetingAllCategories: [],
  targetingSearchedProducts: [],
  negativeTargetingBrands: [],
  negativeTargetingProducts: [],
  refineBrands: [],
}
const targeting = (state = initialState, action) => {
  switch (action.type) {
    case GET_ALL_CATEGORIES_START:
      return {
        ...state,
        isAllCategoriesLoading: true
      }
    case GET_ALL_CATEGORIES_SUCCEED:
      return {
        ...state,
        isAllCategoriesLoading: false,
        targetingAllCategories: action.data
      }
    case GET_ALL_CATEGORIES_FAILED:
      return {
        ...state,
        isAllCategoriesLoading: false,
        targetingAllCategories: []
      }
    case GET_PRODUCTS_BY_SEARCH_TEXT_START:
      return {
        ...state,
        isSearchedProductsLoading: true
      }
    case GET_PRODUCTS_BY_SEARCH_TEXT_SUCCEED:
      return {
        ...state,
        isSearchedProductsLoading: false,
        targetingSearchedProducts: action.data.Item
          ? action.data.Item.map(product => Object.assign(product, {
            name: product.ItemAttributes.Title,
          }))
          : []
      }
    case GET_BRAND_RECOMMENDATION_START:
      return {
        ...state,
        isNegativeTargetingBrandsLoading: true
      }
    case GET_BRAND_RECOMMENDATION_SUCCEED:
      return {
        ...state,
        isNegativeTargetingBrandsLoading: false,
        negativeTargetingBrands: action.data
      }
    case GET_REFINE_BRANDS_START:
      return {
        ...state,
        isRefineBrandsLoading: true
      }
    case GET_REFINE_BRANDS_SUCCEED:
      return {
        ...state,
        isRefineBrandsLoading: false,
        refineBrands: action.data
      }
    case GET_PRODUCTS_NEGATIVE_TARGETING_START:
      return {
        ...state,
        isNegativeTargetingProductsLoading: true
      }
    case GET_PRODUCTS_NEGATIVE_TARGETING_SUCCEED:
      return {
        ...state,
        isNegativeTargetingProductsLoading: false,
        negativeTargetingProducts: action.data.Item
          ? action.data.Item.map(product => ({
            ...product,
            name: product.ItemAttributes.Title,
          }))
          : []
      }
    default:
      return state
  }
}
export default targeting