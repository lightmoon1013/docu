import {
  GET_OUT_OF_BUDGET_CAMPAIGNS_START,
  GET_OUT_OF_BUDGET_CAMPAIGNS_SUCCESS,
  GET_OUT_OF_BUDGET_CAMPAIGNS_FAIL,
  REVERT_LOG_START,
  REVERT_LOG_SUCCESS,
  REVERT_LOG_FAIL,
} from '../actionTypes/campaignLog'

import {
  GET_DETAILS_START,
} from '../actionTypes/campaignDetail'

export const initialState = {
  isOutOfBudgetCampaignsLoading: false,
  outOfBudgetCampaignLogs: [],
  isRevertingLog: false,
}

const campaignLog = (state = initialState, action) => {
	switch (action.type) {
    case GET_DETAILS_START:
      return {
        ...state,
        isRevertingLog: false,
      }
    case GET_OUT_OF_BUDGET_CAMPAIGNS_START:
      return {
        ...state,
        isOutOfBudgetCampaignsLoading: true,
      }
    case GET_OUT_OF_BUDGET_CAMPAIGNS_SUCCESS:
      return {
        ...state,
        isOutOfBudgetCampaignsLoading: false,
        outOfBudgetCampaignLogs: action.data,
      }
    case GET_OUT_OF_BUDGET_CAMPAIGNS_FAIL:
      return {
        ...state,
        isOutOfBudgetCampaignsLoading: false,
      }
    case REVERT_LOG_START:
      return {
        ...state,
        isRevertingLog: true,
      }
    case REVERT_LOG_SUCCESS:
    case REVERT_LOG_FAIL:
      return {
        ...state,
        isRevertingLog: false,
      }
    default:
      return state
  }
}

export default campaignLog