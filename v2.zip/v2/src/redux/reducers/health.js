import {
  GET_LIST_CAMPAIGNS_START,
  GET_LIST_CAMPAIGNS_SUCCEED,
  GET_LIST_CAMPAIGNS_FAILED,
  GET_SUMMARY_CHART_START,
  GET_SUMMARY_CHART_SUCCEED,
  GET_SUMMARY_CHART_FAILED,
  SAVE_NOTIFICATION_PLAN_STARTED,
  SAVE_NOTIFICATION_PLAN_SUCCEED,
  SAVE_NOTIFICATION_PLAN_FAIL,
  GET_HEALTH_DATA_START,
  GET_HEALTH_DATA_SUCCEED,
  GET_HEALTH_DATA_FAIL,
} from '../actionTypes/health'

export const initialState = {
  summaryData: {},
  listCampaignData: {},
  summaryChartData: [],
  isLoadingHealthData: false,
  isLoadingListCampaigns: false,
  isLoadingSummaryChart: false,
  isSavingNotificationPlan: false,
}

const header = (state = initialState, action) => {
	switch (action.type) {
    case SAVE_NOTIFICATION_PLAN_STARTED:
      return {
        ...state,
        isSavingNotificationPlan: true
      }
    case SAVE_NOTIFICATION_PLAN_SUCCEED:
      return {
        ...state,
        isSavingNotificationPlan: false,
      }
    case SAVE_NOTIFICATION_PLAN_FAIL:
      return {
        ...state,
        isSavingNotificationPlan: false,
      }
    case GET_LIST_CAMPAIGNS_START:
      return {
        ...state,
        isLoadingListCampaigns: true,
      }
    case GET_LIST_CAMPAIGNS_SUCCEED:
      return {
        ...state,
        listCampaignData: action.data,
        isLoadingListCampaigns: false,
      }
    case GET_LIST_CAMPAIGNS_FAILED:
      return {
        ...state,
        listCampaignData: {},
        isLoadingListCampaigns: false,
      }
    case GET_HEALTH_DATA_START:
      return {
        ...state,
        isLoadingHealthData: true
      }
    case GET_HEALTH_DATA_SUCCEED:
      return {
        ...state,
        summaryData: action.data,
        isLoadingHealthData: false
      }
    case GET_HEALTH_DATA_FAIL:
      return {
        ...state,
        summaryData: {},
        isLoadingHealthData: false
      }
    case GET_SUMMARY_CHART_START:
      return {
        ...state,
        isLoadingSummaryChart: true,
      }
    case GET_SUMMARY_CHART_SUCCEED:
      return {
        ...state,
        summaryChartData: action.data.map(record => Object.assign(record, {
          acos: record.revenue ? record.cost / record.revenue * 100 : 0,
          ctr: record.impressions ? record.clicks / record.impressions * 100 : 0,
          conversion: record.clicks ? record.orders / record.clicks * 100 : 0,
          organicSales: parseFloat(record.sales) - parseFloat(record.revenue),
        })),
        isLoadingSummaryChart: false,
      }
    case GET_SUMMARY_CHART_FAILED:
      return {
        ...state,
        isLoadingSummaryChart: false,
      }
    default:
      return state
  }
}

export default header