import moment from 'moment'

import {
  GET_ALL_ACCOUNT_START,
  GET_ALL_ACCOUNT_SUCCEED,
  GET_ALL_ACCOUNT_FAIL,
  SET_SELECTED_USER_INFO,
  GET_CURRENCY_RATE_SUCCEED,
  SET_CURRENCY_INFO,
  SET_DATE_RANGE,
  SET_NOTIFICATION_CHECKED,
  SET_OUT_OF_BUDGET,
  SET_USER_CHANGED,
} from '../actionTypes/header'

import {
  LOGIN_SUCCEED,
  SAVE_NOTIFICATION_SUCCEED,
  SAVE_UNIVERSAL_SUCCEED,
  SAVE_BRAND_NAME_SUCCEED,
  MIGRATE_MWS_SUCCEED,
} from '../actionTypes/auth'

export const initialState = {
  accountList: [],
  isLoading: false,
  currentUserId: '',
  isUserChanged: false,
  selectedUserInfo: {},
  currencyRateList: {},
  // Country code of a current currency.
  currencyCode: 'us',
  currencyRate: 1,
  currencySign: '$',
  currentStartDate: moment().startOf('day').subtract(29, 'day').toDate(),
  currentEndDate: moment().endOf('day').toDate(),
  isCheckedNotification: false,
  currentOutOfBudgetCampaignLogs: [],
}

const header = (state = initialState, action) => {
	switch (action.type) {
    case GET_ALL_ACCOUNT_START:
      return {
        ...state,
        isLoading: true,
      }
    case GET_ALL_ACCOUNT_SUCCEED:
      return {
        ...state,
        accountList: action.data,
        isLoading: false,
      }
    case GET_ALL_ACCOUNT_FAIL:
      return {
        ...state,
        isLoading: false,
      }
    case LOGIN_SUCCEED:
      return {
        ...state,
        currentUserId: action.data.user.id,
      }
    case SET_SELECTED_USER_INFO:
      return {
        ...state,
        selectedUserInfo: action.data,
        currentUserId: action.data.user,
        currencySign: action.data.currency.sign,
        currencyCode: action.data.currency.code,
      }
    case GET_CURRENCY_RATE_SUCCEED:
      return {
        ...state,
        currencyRateList: action.data && action.data.length > 0 && JSON.parse(action.data[0].response),
      }
    case SET_CURRENCY_INFO:
      return {
        ...state,
        currencyCode: action.data.currencyCode,
        currencyRate: action.data.currencyRate,
        currencySign: action.data.currencySign,
      }
    case SET_DATE_RANGE:
      return {
        ...state,
        currentStartDate: action.data.startDate,
        currentEndDate: action.data.endDate
      }
    case SAVE_NOTIFICATION_SUCCEED:
      const { userId, monthlyAlert, weeklyAlert, additionalAlert } = action.data
      return {
        ...state,
        accountList: state.accountList.map(account => {
          if (account.user === userId) {
            return {
              ...account,
              monthly_alert: monthlyAlert,
              weekly_alert: weeklyAlert,
              additional_alert: additionalAlert,
            }
          }
          return account
        }),
        selectedUserInfo: {
          ...state.selectedUserInfo,
          monthly_alert: monthlyAlert,
          weekly_alert: weeklyAlert,
          additional_alert: additionalAlert,
        },
      }
    case SAVE_UNIVERSAL_SUCCEED:
      const { userId: universalUserId, profitMargin, acos } = action.data
      return {
        ...state,
        accountList: state.accountList.map(account => {
          if (account.user === universalUserId) {
            return {
              ...account,
              average_profit: profitMargin,
              average_acos: acos,
            }
          }
          return account
        }),
        selectedUserInfo: {
          ...state.selectedUserInfo,
          average_profit: profitMargin,
          average_acos: acos,
        },
      }
    case SET_NOTIFICATION_CHECKED:
      return {
        ...state,
        isCheckedNotification: action.data,
      }
    case SET_OUT_OF_BUDGET:
      return {
        ...state,
        currentOutOfBudgetCampaignLogs: action.data,
      }
    case SET_USER_CHANGED:
      return {
        ...state,
        isUserChanged: action.data.isChanged,
      }
    case SAVE_BRAND_NAME_SUCCEED:
      return {
        ...state,
        accountList: state.accountList.map((account) => {
          if (parseInt(account.user, 10) === parseInt(state.selectedUserInfo.user, 10)) {
            return {
              ...account,
              brand_name: action.data.brandName,
            }
          }
          return account
        }),
        selectedUserInfo: {
          ...state.selectedUserInfo,
          brand_name: action.data.brandName,
        },
      }
    case MIGRATE_MWS_SUCCEED:
      return {
        ...state,
        accountList: state.accountList.map((account) => {
          if (action.data.indexOf(parseInt(account.user, 10)) !== -1) {
            return {
              ...account,
              hasSpCode: true,
            }
          }
          return account
        }),
      }
    default:
      return state
  }
}

export default header