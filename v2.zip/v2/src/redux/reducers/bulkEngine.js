import {
  GET_BULK_ENGINE_PORTFOLIOS_START,
  GET_BULK_ENGINE_PORTFOLIOS_SUCCEED,
  GET_BULK_ENGINE_PORTFOLIOS_FAIL,
  FIND_TARGETS_START,
  FIND_TARGETS_SUCCEED,
  FIND_TARGETS_FAIL,
  GET_TARGET_CHARTS_START,
  GET_TARGET_CHARTS_SUCCEED,
  GET_TARGET_CHARTS_FAIL,
  ADJUST_KEYWORD_BIDS_START,
  ADJUST_KEYWORD_BIDS_SUCCEED,
  ADJUST_KEYWORD_BIDS_FAIL,
  ADJUST_TARGET_BIDS_START,
  ADJUST_TARGET_BIDS_SUCCEED,
  ADJUST_TARGET_BIDS_FAIL,
  FIND_DUPS_START,
  FIND_DUPS_SUCCEED,
  FIND_DUPS_FAIL,
  UPDATE_KEYWORD_STATES_START,
  UPDATE_KEYWORD_STATES_SUCCEED,
  UPDATE_KEYWORD_STATES_FAIL,
  UPDATE_TARGET_STATES_START,
  UPDATE_TARGET_STATES_SUCCEED,
  UPDATE_TARGET_STATES_FAIL,
  FIND_NEW_TARGETS_START,
  FIND_NEW_TARGETS_SUCCEED,
  FIND_NEW_TARGETS_FAIL,
  GET_ADGROUPS_TO_ADD_TARGETS_START,
  GET_ADGROUPS_TO_ADD_TARGETS_SUCCEED,
  GET_ADGROUPS_TO_ADD_TARGETS_FAIL,
  ADD_TARGETS_EXISTING_CAMPAIGN_START,
  ADD_TARGETS_EXISTING_CAMPAIGN_SUCCEED,
  ADD_TARGETS_EXISTING_CAMPAIGN_FAIL,
  FIND_STS_EX_START,
  FIND_STS_EX_SUCCEED,
  FIND_STS_EX_FAIL,
  FIND_PTS_EX_START,
  FIND_PTS_EX_SUCCEED,
  FIND_PTS_EX_FAIL,
  GET_ADGROUPS_FOR_CAMPAIGNS_START,
  GET_ADGROUPS_FOR_CAMPAIGNS_SUCCEED,
  GET_ADGROUPS_FOR_CAMPAIGNS_FAIL,
  GET_SKU_OP_START,
  GET_SKU_OP_SUCCEED,
  GET_SKU_OP_FAIL,
  UPDATE_PA_STATES_START,
  UPDATE_PA_STATES_SUCCEED,
  UPDATE_PA_STATES_FAIL,
  GET_TARGET_OP_START,
  GET_TARGET_OP_SUCCEED,
  GET_TARGET_OP_FAIL,
  GET_ST_OP_START,
  GET_ST_OP_SUCCEED,
  GET_ST_OP_FAIL,
  ADD_NEGATIVES_OP_START,
  ADD_NEGATIVES_OP_SUCCEED,
  ADD_NEGATIVES_OP_FAIL,
  GET_NEGATIVE_FINDER_START,
  GET_NEGATIVE_FINDER_SUCCEED,
  GET_NEGATIVE_FINDER_FAIL,
  GET_ADVANCED_NEGATIVE_START,
  GET_ADVANCED_NEGATIVE_SUCCEED,
  GET_ADVANCED_NEGATIVE_FAIL,
  UPDATE_NK_STATES_START,
  UPDATE_NK_STATES_SUCCEED,
  UPDATE_NK_STATES_FAIL,
  UPDATE_NT_STATES_START,
  UPDATE_NT_STATES_SUCCEED,
  UPDATE_NT_STATES_FAIL,
  CREATE_AD_GROUP_START,
  CREATE_AD_GROUP_SUCCEED,
  CREATE_AD_GROUP_FAIL,
} from '../actionTypes/bulkEngine'

export const initialState = {
  isGettingPortfolios: false,
  portfolioList: [],
  // Target search
  isFindingTargets: false,
  findTargetsData: {},
  isGettingTargetCharts: false,
  targetChartsData: {},
  isAdjustingKeywordBids: false,
  isAdjustingTargetBids: false,
  isFindingDups: false,
  findDupsData: {},
  isUpdatingKeywordStates: false,
  isUpdatingTargetStates: false,
  // Target ex
  isFindingNewTargets: false,
  findNewTargetsData: [],
  isGettingAdgroupsToAddTargets: false,
  adgroupsToAddTargetsData: [],
  isAddingTargets: false,
  // Search term ex
  isFindingSts: false,
  findStsData: [],
  // Product targeting ex
  isFindingPts: false,
  findPtsData: [],
  // SKU op
  isGettingAdgroupsForCampaigns: false,
  adgroupsForCampaignsData: [],
  isGettingSkuOp: false,
  skuOpData: [],
  isUpdatingPaStates: false,
  // Target op
  isGettingTargetOp: false,
  targetOpData: {},
  // ST op
  isGettingStOp: false,
  stOpData: {},
  isAddingNegatives: false,
  // Negative finder
  isGettingNegativeFinderData: false,
  negativeFinderData: [],
  // Advanced op
  isGettingAdvancedNegativeData: false,
  advancedNegativeData: {},
  isUpdatingNkStates: false,
  isUpdatingNtStates: false,
  isCreatingAdgroup: false,
}

const bulkEngine = (state = initialState, action) => {
  switch (action.type) {
    case GET_BULK_ENGINE_PORTFOLIOS_START:
      return {
        ...state,
        isGettingPortfolios: true,
        portfolioList: [],
      }
    case GET_BULK_ENGINE_PORTFOLIOS_SUCCEED:
      return {
        ...state,
        isGettingPortfolios: false,
        portfolioList: action.data,
      }
    case GET_BULK_ENGINE_PORTFOLIOS_FAIL:
      return {
        ...state,
        isGettingPortfolios: false,
      }
    case FIND_TARGETS_START:
      return {
        ...state,
        isFindingTargets: true,
        findTargetsData: {},
      }
    case FIND_TARGETS_SUCCEED:
      return {
        ...state,
        isFindingTargets: false,
        findTargetsData: action.data,
      }
    case FIND_TARGETS_FAIL:
      return {
        ...state,
        isFindingTargets: false,
      }
    case GET_TARGET_CHARTS_START:
      return {
        ...state,
        isGettingTargetCharts: true,
        targetChartsData: {},
      }
    case GET_TARGET_CHARTS_SUCCEED:
      return {
        ...state,
        isGettingTargetCharts: false,
        targetChartsData: action.data,
      }
    case GET_TARGET_CHARTS_FAIL:
      return {
        ...state,
        isGettingTargetCharts: false,
      }
    case ADJUST_KEYWORD_BIDS_START:
      return {
        ...state,
        isAdjustingKeywordBids: true,
      }
    case ADJUST_KEYWORD_BIDS_SUCCEED:
      const updatedKeywordsForBid = {}

      Object.keys(state.findDupsData.keywords || {}).forEach((keyword) => {
        updatedKeywordsForBid[keyword] = state.findDupsData.keywords[keyword].map((record) => {
          if (action.data.indexOf(record.keyword_id.toString()) !== -1) {
            const payload = action.payload.find(p => (
              p.keywordId.toString() === record.keyword_id.toString())
            )
            if (payload) {
              return {
                ...record,
                bid: payload.bid,
              }
            }
          }
          return record
        })
      })

      return {
        ...state,
        isAdjustingKeywordBids: false,
        findTargetsData: Object.assign({}, state.findTargetsData, {
          keywords: (state.findTargetsData.keywords || []).map((keyword) => {
            if (action.data.indexOf(keyword.keyword_id.toString()) !== -1) {
              const payload = action.payload.find(record => (
                record.keywordId.toString() === keyword.keyword_id.toString())
              )
              if (payload) {
                return {
                  ...keyword,
                  bid: payload.bid,
                }
              }
            }
            return keyword
          }),
        }),
        targetOpData: Object.assign({}, state.targetOpData, {
          keywords: ((state.targetOpData || {}).keywords || []).map((keyword) => {
            if (action.data.indexOf(keyword.keyword_id.toString()) !== -1) {
              const payload = action.payload.find(record => (
                record.keywordId.toString() === keyword.keyword_id.toString())
              )
              if (payload) {
                return {
                  ...keyword,
                  bid: payload.bid,
                }
              }
            }
            return keyword
          }),
        }),
        findDupsData: Object.assign({}, state.findDupsData, {
          keywords: updatedKeywordsForBid,
        })
      }
    case ADJUST_KEYWORD_BIDS_FAIL:
      return {
        ...state,
        isAdjustingKeywordBids: false,
      }
    case ADJUST_TARGET_BIDS_START:
      return {
        ...state,
        isAdjustingTargetBids: true,
      }
    case ADJUST_TARGET_BIDS_SUCCEED:
      const updatedTargetsForBid = {}

      Object.keys(state.findDupsData.targets || {}).forEach((target) => {
        updatedTargetsForBid[target] = state.findDupsData.targets[target].map((record) => {
          if (action.data.indexOf(record.target_id.toString()) !== -1) {
            const payload = action.payload.find(p => (
              p.targetId.toString() === record.target_id.toString())
            )
            if (payload) {
              return {
                ...record,
                bid: payload.bid,
              }
            }
          }
          return record
        })
      })

      return {
        ...state,
        isAdjustingTargetBids: false,
        findTargetsData: Object.assign({}, state.findTargetsData, {
          targets: (state.findTargetsData.targets || []).map((record) => {
            if (action.data.indexOf(record.target_id.toString()) !== -1) {
              const payload = action.payload.find(p => (
                p.targetId.toString() === record.target_id.toString())
              )
              if (payload) {
                return {
                  ...record,
                  bid: payload.bid,
                }
              }
            }
            return record
          }),
        }),
        targetOpData: Object.assign({}, state.targetOpData, {
          targets: ((state.targetOpData || {}).targets || []).map((target) => {
            if (action.data.indexOf(target.target_id.toString()) !== -1) {
              const payload = action.payload.find(record => (
                record.targetId.toString() === target.target_id.toString())
              )
              if (payload) {
                return {
                  ...target,
                  bid: payload.bid,
                }
              }
            }
            return target
          }),
        }),
        findDupsData: Object.assign({}, state.findDupsData, {
          targets: updatedTargetsForBid,
        })
      }
    case ADJUST_TARGET_BIDS_FAIL:
      return {
        ...state,
        isAdjustingTargetBids: false,
      }
    case FIND_DUPS_START:
      return {
        ...state,
        isFindingDups: true,
        findDupsData: {},
      }
    case FIND_DUPS_SUCCEED:
      return {
        ...state,
        isFindingDups: false,
        findDupsData: action.data,
      }
    case FIND_DUPS_FAIL:
      return {
        ...state,
        isFindingDups: false,
      }
    case UPDATE_KEYWORD_STATES_START:
      return {
        ...state,
        isUpdatingKeywordStates: true,
      }
    case UPDATE_KEYWORD_STATES_SUCCEED:
      const updatedKeywords = {}

      Object.keys(state.findDupsData.keywords || {}).forEach((keyword) => {
        updatedKeywords[keyword] = state.findDupsData.keywords[keyword].map((record) => {
          if (action.data.indexOf(record.keyword_id.toString()) !== -1) {
            return {
              ...record,
              state: action.state,
            }
          }
          return record
        })
      })

      return {
        ...state,
        isUpdatingKeywordStates: false,
        findTargetsData: Object.assign({}, state.findTargetsData, {
          keywords: (state.findTargetsData.keywords || []).map((record) => {
            if (action.data.indexOf(record.keyword_id.toString()) !== -1) {
              return {
                ...record,
                state: action.state,
              }
            }
            return record
          }),
        }),
        findDupsData: Object.assign({}, state.findDupsData, {
          keywords: updatedKeywords,
        }),
        targetOpData: Object.assign({}, state.targetOpData, {
          keywords: ((state.targetOpData || {}).keywords || []).map((record) => {
            if (action.data.indexOf(record.keyword_id.toString()) !== -1) {
              return {
                ...record,
                state: action.state,
              }
            }
            return record
          }),
        }),
      }
    case UPDATE_KEYWORD_STATES_FAIL:
      return {
        ...state,
        isUpdatingKeywordStates: false,
      }
    case UPDATE_TARGET_STATES_START:
      return {
        ...state,
        isUpdatingTargetStates: true,
      }
    case UPDATE_TARGET_STATES_SUCCEED:
      const updatedTargets = {}

      Object.keys(state.findDupsData.targets || {}).forEach((target) => {
        updatedTargets[target] = state.findDupsData.targets[target].map((record) => {
          if (action.data.indexOf(record.target_id.toString()) !== -1) {
            return {
              ...record,
              state: action.state,
            }
          }
          return record
        })
      })

      return {
        ...state,
        isUpdatingTargetStates: false,
        findTargetsData: Object.assign({}, state.findTargetsData, {
          targets: (state.findTargetsData.targets || []).map((record) => {
            if (action.data.indexOf(record.target_id.toString()) !== -1) {
              return {
                ...record,
                state: action.state,
              }
            }
            return record
          }),
        }),
        findDupsData: Object.assign({}, state.findDupsData, {
          targets: updatedTargets,
        }),
        targetOpData: Object.assign({}, state.targetOpData, {
          targets: ((state.targetOpData || {}).targets || []).map((record) => {
            if (action.data.indexOf(record.target_id.toString()) !== -1) {
              return {
                ...record,
                state: action.state,
              }
            }
            return record
          }),
        }),
      }
    case UPDATE_TARGET_STATES_FAIL:
      return {
        ...state,
        isUpdatingTargetStates: false,
      }
    case FIND_NEW_TARGETS_START:
      return {
        ...state,
        isFindingNewTargets: true,
        findNewTargetsData: [],
      }
    case FIND_NEW_TARGETS_SUCCEED:
      return {
        ...state,
        isFindingNewTargets: false,
        findNewTargetsData: action.data,
      }
    case FIND_NEW_TARGETS_FAIL:
      return {
        ...state,
        isFindingNewTargets: false,
      }
    case GET_ADGROUPS_TO_ADD_TARGETS_START:
      return {
        ...state,
        isGettingAdgroupsToAddTargets: true,
        adgroupsToAddTargetsData: [],
      }
    case GET_ADGROUPS_TO_ADD_TARGETS_SUCCEED:
      return {
        ...state,
        isGettingAdgroupsToAddTargets: false,
        adgroupsToAddTargetsData: action.data,
      }
    case GET_ADGROUPS_TO_ADD_TARGETS_FAIL:
      return {
        ...state,
        isGettingAdgroupsToAddTargets: false,
      }
    case ADD_TARGETS_EXISTING_CAMPAIGN_START:
      return {
        ...state,
        isAddingTargets: true,
      }
    case ADD_TARGETS_EXISTING_CAMPAIGN_SUCCEED:
      return {
        ...state,
        isAddingTargets: false,
      }
    case ADD_TARGETS_EXISTING_CAMPAIGN_FAIL:
      return {
        ...state,
        isAddingTargets: false,
    }
    case FIND_STS_EX_START:
      return {
        ...state,
        isFindingSts: true,
      }
    case FIND_STS_EX_SUCCEED:
      return {
        ...state,
        isFindingSts: false,
        findStsData: action.data,
      }
    case FIND_STS_EX_FAIL:
      return {
        ...state,
        isFindingSts: false,
      }
    case FIND_PTS_EX_START:
      return {
        ...state,
        isFindingPts: true,
      }
    case FIND_PTS_EX_SUCCEED:
      return {
        ...state,
        isFindingPts: false,
        findPtsData: action.data,
      }
    case FIND_PTS_EX_FAIL:
      return {
        ...state,
        isFindingPts: false,
      }
    case GET_ADGROUPS_FOR_CAMPAIGNS_START:
      return {
        ...state,
        isGettingAdgroupsForCampaigns: true,
      }
    case GET_ADGROUPS_FOR_CAMPAIGNS_SUCCEED:
      return {
        ...state,
        isGettingAdgroupsForCampaigns: false,
        adgroupsForCampaignsData: action.data,
      }
    case GET_ADGROUPS_FOR_CAMPAIGNS_FAIL:
      return {
        ...state,
        isGettingAdgroupsForCampaigns: false,
      }
    case GET_SKU_OP_START:
      return {
        ...state,
        isGettingSkuOp: true,
      }
    case GET_SKU_OP_SUCCEED:
      return {
        ...state,
        isGettingSkuOp: false,
        skuOpData: action.data,
      }
    case GET_SKU_OP_FAIL:
      return {
        ...state,
        isGettingSkuOp: false,
      }
    case UPDATE_PA_STATES_START:
      return {
        ...state,
        isUpdatingPaStates: true,
      }
    case UPDATE_PA_STATES_SUCCEED:
      return {
        ...state,
        isUpdatingPaStates: false,
        skuOpData: (state.skuOpData || []).map((record) => {
          if (action.data.indexOf(record.ad_id.toString()) !== -1) {
            return {
              ...record,
              state: action.state,
            }
          }
          return record
        }),
      }
    case UPDATE_PA_STATES_FAIL:
      return {
        ...state,
        isUpdatingPaStates: false,
      }
    case GET_TARGET_OP_START:
      return {
        ...state,
        isGettingTargetOp: true,
      }
    case GET_TARGET_OP_SUCCEED:
      return {
        ...state,
        isGettingTargetOp: false,
        targetOpData: action.data,
      }
    case GET_TARGET_OP_FAIL:
      return {
        ...state,
        isGettingTargetOp: false,
      }
    case GET_ST_OP_START:
      return {
        ...state,
        isGettingStOp: true,
      }
    case GET_ST_OP_SUCCEED:
      return {
        ...state,
        isGettingStOp: false,
        stOpData: action.data,
      }
    case GET_ST_OP_FAIL:
      return {
        ...state,
        isGettingStOp: false,
      }
    case ADD_NEGATIVES_OP_START:
      return {
        ...state,
        isAddingNegatives: true,
      }
    case ADD_NEGATIVES_OP_SUCCEED:
      return {
        ...state,
        isAddingNegatives: false,
      }
    case ADD_NEGATIVES_OP_FAIL:
      return {
        ...state,
        isAddingNegatives: false,
      }
    case GET_NEGATIVE_FINDER_START:
      return {
        ...state,
        isGettingNegativeFinderData: true,
      }
    case GET_NEGATIVE_FINDER_SUCCEED:
      return {
        ...state,
        isGettingNegativeFinderData: false,
        negativeFinderData: action.data,
      }
    case GET_NEGATIVE_FINDER_FAIL:
      return {
        ...state,
        isGettingNegativeFinderData: false,
      }
    case GET_ADVANCED_NEGATIVE_START:
      return {
        ...state,
        isGettingAdvancedNegativeData: true,
      }
    case GET_ADVANCED_NEGATIVE_SUCCEED:
      return {
        ...state,
        isGettingAdvancedNegativeData: false,
        advancedNegativeData: action.data,
      }
    case GET_ADVANCED_NEGATIVE_FAIL:
      return {
        ...state,
        isGettingAdvancedNegativeData: false,
      }
    case UPDATE_NK_STATES_START:
      return {
        ...state,
        isUpdatingNkStates: true,
      }
    case UPDATE_NK_STATES_SUCCEED:
      return {
        ...state,
        isUpdatingNkStates: false,
        advancedNegativeData: Object.assign({}, state.advancedNegativeData, {
          negativeKeywords: ((state.advancedNegativeData || {}).negativeKeywords || []).map((record) => {
            if (action.data.indexOf(parseInt(record.keyword_id, 10)) !== -1) {
              return {
                ...record,
                state: action.state,
              }
            }
            return record
          }),
        }),
      }
    case UPDATE_NK_STATES_FAIL:
      return {
        ...state,
        isUpdatingNkStates: false,
      }
    case UPDATE_NT_STATES_START:
      return {
        ...state,
        isUpdatingNtStates: true,
      }
    case UPDATE_NT_STATES_SUCCEED:
      return {
        ...state,
        isUpdatingNtStates: false,
        advancedNegativeData: Object.assign({}, state.advancedNegativeData, {
          negativeTargets: ((state.advancedNegativeData || {}).negativeTargets || []).map((record) => {
            if (action.data.indexOf(parseInt(record.target_id, 10)) !== -1) {
              return {
                ...record,
                state: action.state,
              }
            }
            return record
          }),
        }),
      }
    case UPDATE_NT_STATES_FAIL:
      return {
        ...state,
        isUpdatingNtStates: false,
      }
    case CREATE_AD_GROUP_START:
      return {
        ...state,
        isCreatingAdgroup: true,
      }
    case CREATE_AD_GROUP_SUCCEED:
      return {
        ...state,
        isCreatingAdgroup: false,
        adgroupsToAddTargetsData: [
          ...state.adgroupsToAddTargetsData,
          action.data,
        ],
      }
    case CREATE_AD_GROUP_FAIL:
      return {
        ...state,
        isCreatingAdgroup: false,
      }
    default:
      return state
  }
}

export default bulkEngine
