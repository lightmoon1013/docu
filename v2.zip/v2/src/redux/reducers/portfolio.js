import {
  GET_PORTFOLIOS_SUCCEED,
  GET_PORTFOLIOS_FAIL,
  GET_PORTFOLIOS_START,
  CREATE_PORTFOLIO_START,
  CREATE_PORTFOLIO_SUCCEED,
  CREATE_PORTFOLIO_FAILD,
  ADD_CAMPAIGN_EXISTING_PORTFOLIO_START,
  ADD_CAMPAIGN_EXISTING_PORTFOLIO_SUCCEED,
  ADD_CAMPAIGN_EXISTING_PORTFOLIO_FAIL,
} from '../actionTypes/portfolio'

export const initialState = {
  listPortfolios: [],
  isLoading: false,
  isCreatingPortfolio: false,
  createdPortfolioResponse: '',
  createdPortfolio: [],
  isAddCampaignToExistingPortfolio: false,
}

const portfolio = (state = initialState, action) => {
  switch (action.type) {
    case GET_PORTFOLIOS_START:
      return {
        ...state,
        isLoading: true
      }
    case GET_PORTFOLIOS_SUCCEED:
      return {
        ...state,
        listPortfolios: action.data,
        isLoading: false
      }
    case GET_PORTFOLIOS_FAIL:
      return {
        ...state,
        isLoading: false,
      }
    case CREATE_PORTFOLIO_START:
      return {
        ...state,
        isCreatingPortfolio: true,
        createdPortfolioResponse: {},
      }
    case CREATE_PORTFOLIO_SUCCEED:
      if (action.data.portfolioId) {
        return {
          ...state,
          isCreatingPortfolio: false,
          createdPortfolioResponse: {
            portfolioId: action.data.portfolioId,
            portfolioName: action.data.portfolioName,
          },
        }
      }
      return {
        ...state,
        isCreatingPortfolio: false,
        createdPortfolioResponse: action.data.text,
      }
    case CREATE_PORTFOLIO_FAILD:
      return {
        ...state,
        isCreatingPortfolio: false,
      }
    case ADD_CAMPAIGN_EXISTING_PORTFOLIO_START:
      return {
        ...state,
        isAddCampaignToExistingPortfolio: true
      }
    case ADD_CAMPAIGN_EXISTING_PORTFOLIO_SUCCEED:
      return {
        ...state,
        isAddCampaignToExistingPortfolio: false
      }
    case ADD_CAMPAIGN_EXISTING_PORTFOLIO_FAIL:
      return {
        ...state,
        isAddCampaignToExistingPortfolio: false
      }
    default:
      return state
  }
}

export default portfolio