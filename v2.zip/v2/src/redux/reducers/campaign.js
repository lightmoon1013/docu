import {
  GET_CAMPAIGNS_WITH_PORTFOLIO_START,
  GET_CAMPAIGNS_WITH_PORTFOLIO_SUCCESS,
  GET_CAMPAIGNS_WITH_PORTFOLIO_FAIL,
  GET_CAMPAIGNS_WITH_HISTORY_START,
  GET_CAMPAIGNS_WITH_HISTORY_SUCCESS,
  GET_CAMPAIGNS_WITH_HISTORY_FAIL,
  UPDATE_CAMPAIGN_ACOS_START,
  UPDATE_CAMPAIGN_ACOS_SUCCEED,
  UPDATE_CAMPAIGN_ACOS_FAIL,
  UPDATE_CAMPAIGN_DAILYBUDGET_START,
  UPDATE_CAMPAIGN_DAILYBUDGET_SUCCEED,
  UPDATE_CAMPAIGN_DAILYBUDGET_FAIL,
  UPDATE_CAMPAIGN_STATE_START,
  UPDATE_CAMPAIGN_STATE_SUCCEED,
  UPDATE_CAMPAIGN_NAMES_START,
  UPDATE_CAMPAIGN_NAMES_SUCCEED,
  UPDATE_CAMPAIGN_NAMES_FAIL,
  UPDATE_SP_BID_STRATEGY_START,
  UPDATE_SP_BID_STRATEGY_SUCCEED,
  UPDATE_SP_BID_STRATEGY_FAIL,
  GET_CAMPAIGNS_BUDGET_RULES_START,
  GET_CAMPAIGNS_BUDGET_RULES_SUCCEED,
  GET_CAMPAIGNS_BUDGET_RULES_FAIL,
  DISABLE_CAMPAIGN_BUDGET_RULE_START,
  DISABLE_CAMPAIGN_BUDGET_RULE_SUCCEED,
  DISABLE_CAMPAIGN_BUDGET_RULE_FAIL,
  CREATE_BUDGET_RULE_START,
  CREATE_BUDGET_RULE_SUCCEED,
  CREATE_BUDGET_RULE_FAIL,
  APPLY_CAMPAIGN_BUDGET_RULE_START,
  APPLY_CAMPAIGN_BUDGET_RULE_SUCCEED,
  APPLY_CAMPAIGN_BUDGET_RULE_FAIL,
  UPDATE_SP_PLACEMENT_START,
  UPDATE_SP_PLACEMENT_SUCCEED,
  UPDATE_SP_PLACEMENT_FAIL,
} from '../actionTypes/campaign'

import {
  SAVE_AP_SUCCESS,
  SAVE_AP_TEMPLATE_SUCCESS,
  TURN_AP_BULK_SUCCESS,
  APPLY_TEMPLATE_BULK_SUCCESS,
} from '../actionTypes/ap'

export const initialState = {
  isLoading: false,
  campaignsWithHistory: [],
  campaignsWithPortfolio: [],
  isUpdateCampaignAcos: false,
  isUpdateCampaignDailyBudget: false,
  isUpdatingCampaignState: false,
  isUpdatingCampaignNames: false,
  isUpdatingBidStrategy: false,
  isBudgetRuleLoading: false,
  selCampaigns: [],
  isDisableBugetRuleLoading: false,
  isCreateBudgetRuleLoading: false,
  isApplyBugetRuleLoading: false,
  createdBudgets: []
}

const campaign = (state = initialState, action) => {
  switch (action.type) {
    case GET_CAMPAIGNS_WITH_PORTFOLIO_START:
      return {
        ...state,
        isLoading: true,
        campaignsWithPortfolio: [],
      }
    case GET_CAMPAIGNS_WITH_PORTFOLIO_SUCCESS:
      return {
        ...state,
        isLoading: false,
        campaignsWithPortfolio: [...new Map(action.data.map(campaign => [campaign.campaign_id, campaign])).values()].map(record => Object.assign({}, record, {
          portfolio_id: parseInt(record.portfolio_id || 0, 10),
          clicks: parseInt(record.clicks || 0, 10),
          impressions: parseInt(record.impressions || 0, 10),
          orders: parseInt(record.orders || 0, 10),
          ntb_orders: parseInt(record.ntb_orders || 0, 10),
          conversion: parseFloat(record.conversion || 0),
          cost: parseFloat(record.cost || 0),
          ntb_orders_percent: parseFloat(record.ntb_orders_percent || 0),
          ntb_sales: parseFloat(record.ntb_sales || 0),
          ntb_sales_percent: parseFloat(record.ntb_sales_percent || 0),
          daily_budget: parseFloat(record.daily_budget || 0),
        })),
      }
    case GET_CAMPAIGNS_WITH_PORTFOLIO_FAIL:
      return {
        ...state,
        isLoading: false,
        campaignsWithPortfolio: [],
      }
    case GET_CAMPAIGNS_WITH_HISTORY_START:
      return {
        ...state,
        isLoading: true,
      }
    case GET_CAMPAIGNS_WITH_HISTORY_SUCCESS:
      return {
        ...state,
        isLoading: false,
        campaignsWithHistory: [...new Map(action.data.map(campaign => [campaign.campaign_id, campaign])).values()].map(record => Object.assign({}, record, {
          clicks: parseInt(record.clicks || 0, 10),
          impressions: parseInt(record.impressions || 0, 10),
          orders: parseInt(record.orders || 0, 10),
          ntb_orders: parseInt(record.ntb_orders || 0, 10),
          conversion: parseFloat(record.conversion || 0),
          cost: parseFloat(record.cost || 0),
          ntb_orders_percent: parseFloat(record.ntb_orders_percent || 0),
          ntb_sales: parseFloat(record.ntb_sales || 0),
          ntb_sales_percent: parseFloat(record.ntb_sales_percent || 0),
          daily_budget: parseFloat(record.daily_budget || 0),
          bidding: record.bidding ? (typeof record.bidding === 'object' ? record.bidding : (typeof JSON.parse(record.bidding) === 'object' ? JSON.parse(record.bidding) : JSON.parse(JSON.parse(record.bidding)))) : {},
        })),
      }
    case GET_CAMPAIGNS_WITH_HISTORY_FAIL:
      return {
        ...state,
        campaignsWithHistory: [],
        isLoading: false,
      }
    case SAVE_AP_TEMPLATE_SUCCESS:
      return {
        ...state,
        campaignsWithHistory: state.campaignsWithHistory.map((campaign) => {
          if (!action.data.needApply || action.data.campaignId !== campaign.campaign_id) {
            return campaign
          }
          campaign.is_ap_active = true
          return campaign
        }),
      }
    case TURN_AP_BULK_SUCCESS:
      return {
        ...state,
        campaignsWithHistory: state.campaignsWithHistory.map((campaign) => {
          if (action.data.campaignIds.indexOf(campaign.campaign_id) === -1
            || campaign.is_ap_active === null) {
            return campaign
          }
          campaign.is_ap_active = action.data.state
          return campaign
        }),
      }
    case SAVE_AP_SUCCESS:
    case APPLY_TEMPLATE_BULK_SUCCESS:
      return {
        ...state,
        campaignsWithHistory: state.campaignsWithHistory.map((campaign) => {
          if (action.data.indexOf(campaign.campaign_id) === -1) {
            return campaign
          }
          campaign.is_ap_active = true
          return campaign
        }),
      }
    case UPDATE_CAMPAIGN_ACOS_START:
      return {
        ...state,
        isUpdateCampaignAcos: true
      }
    case UPDATE_CAMPAIGN_ACOS_SUCCEED:
      return {
        ...state,
        isUpdateCampaignAcos: false,
        campaignsWithHistory: state.campaignsWithHistory.map((campaign) => {
          if (action.data.campaignId !== campaign.campaign_id) {
            return campaign
          }
          campaign.target_acos = action.data.acos
          return campaign
        })
      }
    case UPDATE_CAMPAIGN_ACOS_FAIL:
      return {
        ...state,
        isUpdateCampaignAcos: false
      }
    case UPDATE_CAMPAIGN_DAILYBUDGET_START:
      return {
        ...state,
        isUpdateCampaignDailyBudget: true
      }
    case UPDATE_CAMPAIGN_DAILYBUDGET_SUCCEED:
      return {
        ...state,
        isUpdateCampaignDailyBudget: false,
        campaignsWithHistory: state.campaignsWithHistory.map((campaign) => {
          if (action.data.campaignId !== campaign.campaign_id) {
            return campaign
          }
          campaign.daily_budget = action.data.dailyBudget
          return campaign
        })
      }
    case UPDATE_CAMPAIGN_DAILYBUDGET_FAIL:
      return {
        ...state,
        isUpdateCampaignDailyBudget: false
      }
    case UPDATE_CAMPAIGN_STATE_START:
      return {
        ...state,
        isUpdatingCampaignState: true
      }
    case UPDATE_CAMPAIGN_STATE_SUCCEED:
      return {
        ...state,
        isUpdatingCampaignState: false,
        campaignsWithHistory: state.campaignsWithHistory.map((campaign) => {
          action.data.forEach((updated) => {
            if (updated.campaignId === campaign.campaign_id) {
              campaign.state = updated.state
            }
          })
          return campaign
        }),
      }
    case UPDATE_CAMPAIGN_NAMES_START:
      return {
        ...state,
        isUpdatingCampaignNames: true
      }
    case UPDATE_CAMPAIGN_NAMES_SUCCEED:
      return {
        ...state,
        isUpdatingCampaignNames: false,
        campaignsWithHistory: state.campaignsWithHistory.map((campaign) => {
          action.data.forEach((updated) => {
            if (updated.campaignId === campaign.campaign_id) {
              campaign.campaign = updated.name
            }
          })
          return campaign
        })
      }
    case UPDATE_CAMPAIGN_NAMES_FAIL:
      return {
        ...state,
        isUpdatingCampaignNames: false
      }
    case UPDATE_SP_BID_STRATEGY_START:
      return {
        ...state,
        isUpdatingBidStrategy: true
      }
    case UPDATE_SP_BID_STRATEGY_SUCCEED:
      return {
        ...state,
        isUpdatingBidStrategy: false,
        campaignsWithHistory: state.campaignsWithHistory.map((campaign) => {
          action.data.forEach((updated) => {
            if (updated.campaignId === campaign.campaign_id) {
              console.log(updated)

              campaign.bidding.strategy = updated.bidding.strategy
            }
          })
          return campaign
        })
      }
    case UPDATE_SP_BID_STRATEGY_FAIL:
      return {
        ...state,
        isUpdatingBidStrategy: false
      }
    case GET_CAMPAIGNS_BUDGET_RULES_START:
      return {
        ...state,
        isBudgetRuleLoading: true
      }
    case GET_CAMPAIGNS_BUDGET_RULES_SUCCEED:
      return {
        ...state,
        isBudgetRuleLoading: false,
        selCampaigns: action.data
      }
    case GET_CAMPAIGNS_BUDGET_RULES_FAIL:
      return {
        ...state,
        isBudgetRuleLoading: false,
        selCampaigns: []
      }
    case DISABLE_CAMPAIGN_BUDGET_RULE_START:
      return {
        ...state,
        isDisableBugetRuleLoading: true
      }
    case DISABLE_CAMPAIGN_BUDGET_RULE_SUCCEED:
      return {
        ...state,
        isDisableBugetRuleLoading: false,
        selCampaigns: state.selCampaigns.map((campaign) => {
          action.data.forEach((updated) => {
            if (updated.campaignId === campaign.campaignId) {
              delete campaign.budgetId
              delete campaign.budgetRule
            }
          })
          return campaign
        })
      }
    case DISABLE_CAMPAIGN_BUDGET_RULE_FAIL:
      return {
        ...state,
        isDisableBugetRuleLoading: false,
      }
    case CREATE_BUDGET_RULE_START:
      return {
        ...state,
        isCreateBudgetRuleLoading: true
      }
    case CREATE_BUDGET_RULE_SUCCEED:
      return {
        ...state,
        isCreateBudgetRuleLoading: false,
      }
    case CREATE_BUDGET_RULE_FAIL:
      return {
        ...state,
        isCreateBudgetRuleLoading: false,
      }
    case APPLY_CAMPAIGN_BUDGET_RULE_START:
      return {
        ...state,
        isApplyBugetRuleLoading: true
      }
    case APPLY_CAMPAIGN_BUDGET_RULE_SUCCEED:
      return {
        ...state,
        isApplyBugetRuleLoading: false,
      }
    case APPLY_CAMPAIGN_BUDGET_RULE_FAIL:
      return {
        ...state,
        isApplyBugetRuleLoading: false,
      }
    case UPDATE_SP_PLACEMENT_START:
      return {
        ...state,
        isUpdatingBidStrategy: true
      }
    case UPDATE_SP_PLACEMENT_SUCCEED:
      return {
        ...state,
        isUpdatingBidStrategy: false,
        campaignsWithHistory: state.campaignsWithHistory.map((campaign) => {
          action.data.forEach((updated) => {
            if (updated.campaignId === campaign.campaign_id) {
              campaign.bidding.adjustments = updated.bidding.adjustments
            }
          })
          return campaign
        })
      }
    case UPDATE_SP_PLACEMENT_FAIL:
      return {
        ...state,
        isUpdatingBidStrategy: false
      }
    default:
      return state
  }
}

export default campaign
