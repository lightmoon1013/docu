export const COIN_EARNED = 'COIN_EARNED'
