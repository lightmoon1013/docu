import { createStore, applyMiddleware } from 'redux'
import { persistStore, persistReducer } from 'redux-persist'
import storage from 'redux-persist/lib/storage' // defaults to localStorage for web
import thunk from 'redux-thunk'

import rootReducer from './reducers/rootReducer'

const persistConfig = {
    key: 'root',
    storage,
    blacklist: [
        'activityLog',
        'ap',
        'bulkEngine',
        'campaignCreator',
        'campaignDetail',
        'health',
        'productDetail',
        'targeting',
        'templateEditor',
    ],
}

const persistedReducer = persistReducer(persistConfig, rootReducer)

const store = createStore(
    persistedReducer,
    applyMiddleware(thunk)
)

// Used to create the persisted store, persistor will be used in the next step
const  persistor = persistStore(store)

export {
    store,
    persistor,
}
