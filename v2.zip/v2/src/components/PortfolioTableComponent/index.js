import React, { useEffect, useMemo } from 'react'
import { useDispatch, useStore } from 'react-redux'

import SortableTable from '../CommonComponents/SortableTableComponent'
import GroupTable from '../CommonComponents/GroupTableComponent'
import TableCell from '../CommonComponents/TableCell'
import TableCampaignCell from '../CommonComponents/TableCampaignCell'

import { getPortfolios } from '../../redux/actions/portfolio'
import { getCampaignsWithPortfolio } from '../../redux/actions/campaign'
import { portfolioColumnList } from '../../utils/defaultValues'

import {
  calcDerivedMetrics,
  tableSorter,
} from '../../services/helper'

const columns = [
  { key: 'portfolioName', name: 'Portfolio', className: 'col-portfolio', parentOnly: true },
  { key: 'campaign', name: 'Campaign', className: 'col-campaign' },
  ...portfolioColumnList.filter(c => c.key !== 'portfolio'),
]

const PortfolioTableComponent = () => {
  const dispatch = useDispatch()
  const store = useStore()

  const {
    pageGlobal: { portfolioTableColumns },
    header: {
      currencyRate,
      currencySign,
      currentStartDate,
      currentEndDate,
    },
    portfolio: { listPortfolios, isLoading: isPortfolioLoading },
    campaign: {
      campaignsWithPortfolio,
      isLoading: isCampaignLoading,
    },
  } = store.getState()

  useEffect(() => {
    dispatch(getPortfolios())
  }, []) // eslint-disable-line

  useEffect(() => {
    dispatch(getCampaignsWithPortfolio(currentStartDate, currentEndDate))
  }, [currentStartDate, currentEndDate]) // eslint-disable-line

  const portfolioList = useMemo(() => {
    return listPortfolios.map((portfolio) => {
      const campaigns = (campaignsWithPortfolio || []).filter(c =>
        c.portfolio_id === parseInt(portfolio.portfolio_id, 10)
      )

      let daily_budget = 0
      let cost = 0
      let revenue = 0
      let impressions = 0
      let clicks = 0
      let orders = 0
      let ntb_orders = 0
      let ntb_sales = 0

      campaigns.forEach((campaign) => {
        daily_budget += parseFloat(campaign.daily_budget || 0)
        cost += parseFloat(campaign.cost || 0)
        revenue += parseFloat(campaign.revenue || 0)
        impressions += parseInt(campaign.impressions || 0, 10)
        clicks += parseInt(campaign.clicks || 0, 10)
        orders += parseInt(campaign.orders || 0, 10)
        ntb_orders += parseInt(campaign.ntb_orders || 0, 10)
        ntb_sales += parseFloat(campaign.ntb_sales || 0)
      })

      return calcDerivedMetrics({
        ...portfolio,
        daily_budget,
        cost,
        revenue,
        impressions,
        clicks,
        orders,
        ntb_orders,
        ntb_sales,
        children: campaigns.map(c => ({
          ...c,
          name: portfolio.name, // For search
        })),
      })
    })
  }, [listPortfolios, campaignsWithPortfolio])

  const renderPortfolio = record => (
    <>
      <div className="table-col col-portfolio">
        { record.name }
      </div>
      <div className="table-col col-campaign" />
      {
        portfolioColumnList.filter(c => c.key !== 'portfolio').map(column => (
          <TableCell
            key={column.key}
            record={record}
            columnKey={column.key}
            columnSelection={portfolioTableColumns}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  const renderCampaign = record => (
    <>
      <TableCampaignCell record={record} />
      {
        portfolioColumnList.filter(c => c.key !== 'portfolio').map(column => (
          <TableCell
            key={column.key}
            record={record}
            columnKey={column.key}
            columnSelection={portfolioTableColumns}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  const renderTotal = record => (
    <>
      <div className="table-col col-portfolio">
        Totals:
      </div>
      <div className="table-col col-campaign" />
      {
        portfolioColumnList.filter(c => c.key !== 'portfolio').map(column => (
          <TableCell
            key={column.key}
            record={record}
            columnKey={column.key}
            columnSelection={portfolioTableColumns}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  const isLoading = isCampaignLoading || isPortfolioLoading

  return (
    <SortableTable
      tableComponent={GroupTable}
      isLoading={isLoading}
      columns={columns}
      defaultSort={['cost', 'desc']}
      sorter={tableSorter(['name'])}
      className="table-portfolio"
      records={portfolioList}
      idField="portfolio_id"
      searchFields={['name']}
      noCheckBox
      paginationSelectPlacement="top"
      hasSticky
      hasDateRange
      filterName="portfolioTable"
      columnEditorId="portfolioTable"
      columnList={portfolioColumnList}
      columnSelection={portfolioTableColumns}
      columnEditorNoReset={false}
      renderRecord={renderPortfolio}
      renderTotal={renderTotal}
      sorterChild={tableSorter(['campaign'])}
      idFieldChild="campaign_id"
      renderChild={renderCampaign}
    />
  )
}

export default PortfolioTableComponent
