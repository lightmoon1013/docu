import React, { useState } from 'react'
import { useStore } from 'react-redux'
import { Tooltip, Whisper } from 'rsuite'

import { ReactComponent as InfoSvg } from '../../assets/svg/info.svg'

import CheckboxComponent from '../CommonComponents/CheckboxComponent'
import SubSection from './SubSection'
import Frequency from './Frequency'
import Lookback from './Lookback'
import FieldRow from './FieldRow'
import FieldNumber from './FieldNumber'
import ExSkus from './ExSkus'
import ExCampaigns from './ExCampaigns'
import ExProductAdgroups from './ExProductAdgroups'

const ExProduct = ({ campaign, settings, onChange, ...props }) => {
  const store = useStore()

  const { ap: { skus } } = store.getState()
  const [ skusSelected, setSkusSelected ] = useState([])
  const [ isCampaignsLoaded, setIsCampaignsLoaded ] = useState(false)

  return (
    <SubSection name="Product Targeting Expansion" {...props}>
      <div className="checkbox-info-wrapper">
        <CheckboxComponent
          label="Automatically pull winning ASINs from other campaigns into this campaign"
          checked={settings.pt_isactive}
          onChange={(checked) => { onChange('pt_isactive', checked) }}
        />
      </div>
      <Frequency
        disabled={!settings.pt_isactive}
        field="ex_frequency_type"
        weeklyField="ex_freq_weekly"
        monthlyField="ex_freq_month_day"
        settings={settings}
        onChange={onChange}
      />
      <Lookback
        disabled={!settings.pt_isactive}
        field="pt_day_used_auto_pilot"
        settings={settings}
        onChange={onChange}
      />
      <FieldRow disabled={!settings.pt_isactive}>
        <FieldNumber
          label="<strong>Step 1)</strong> Find ASINs with ACoS between 1 and"
          htmlLabel
          field="pt_acos"
          inline
          settings={settings}
          onChange={onChange}
        />
      </FieldRow>
      <ExSkus
        skus={skus}
        selectedSkus={skusSelected}
        disabled={!settings.pt_isactive}
        onChange={setSkusSelected}
      />
      <ExCampaigns
        field="pt_campaign_selected"
        skus={skusSelected}
        forASINs
        settings={settings}
        disabled={!settings.pt_isactive}
        isLoaded={isCampaignsLoaded}
        onLoad={setIsCampaignsLoaded}
        onChange={onChange}
      />
      <div className={`st-criteria-label ${!settings.pt_isactive || !isCampaignsLoaded ? 'disabled' : ''}`}>
        <strong>Step 4)</strong> Pull ASINs with the following criteria.
      </div>
      <FieldRow disabled={!settings.pt_isactive || !isCampaignsLoaded}>
        <FieldNumber
          label="Min orders"
          settings={settings}
          field="pt_minimum_orders"
          tooltip="We'll pull ASINs from campaigns selected that have at least this many orders over the lookback period."
          onChange={onChange}
        />
        <div className="field-wrapper" />
      </FieldRow>
      <FieldRow disabled={!settings.pt_isactive || !isCampaignsLoaded}>
        <div className="field-wrapper">
          <div className="checkbox-info-wrapper">
            <CheckboxComponent
              label="New ASINs only"
              checked={settings.pt_new_asins_only}
              onChange={(checked) => { onChange('pt_new_asins_only', checked) }}
            />
            <Whisper placement="left" trigger="hover" speaker={(
              <Tooltip>
                <p>
                  You may wish to only pull ASINS that are not yet being targeted.
                  For example, let’s say we find an ASIN with the criteria above
                  from an automatic campaign. If you are already targeting that ASIN
                  in another campaign (selected above) and check this box,
                  we will not pull it into this campaign. In that example,
                  we will only pull the new/untargeted ASINS found from the auto campaign.
                </p>
                <p>
                  If you are looking to pull ASINS from automatic campaigns
                  and other product targeting campaigns to enhance coverage
                  across ad types, then we recommend leaving this box unchecked.
                </p>
                <p>
                  If this is confusing, watch the video that Mike has prepared.
                </p>
              </Tooltip>
            )}>
              <InfoSvg />
            </Whisper>
          </div>
        </div>
        <div className="field-wrapper">
          <div className="checkbox-info-wrapper">
            <CheckboxComponent
              label="Add as negative target in parent campaign"
              checked={settings.pt_negate_parent}
              onChange={(checked) => { onChange('pt_negate_parent', checked) }}
            />
            <Whisper placement="left" trigger="hover" speaker={(
              <Tooltip>
                While adding winning search terms or ASINS into a new campaign,
                you may wish to negate them from the previous campaign. If you check this box,
                we'll use a negative exact at the ad group level on the search term/ASIN
                from the campaign which it was found.
              </Tooltip>
            )}>
              <InfoSvg />
            </Whisper>
          </div>
        </div>
      </FieldRow>
      {
        campaign && (
          <ExProductAdgroups
            campaign={campaign}
            settings={settings}
            disabled={!settings.pt_isactive || !isCampaignsLoaded}
            onChange={onChange}
          />
        )
      }
    </SubSection>
  )
}

export default ExProduct
