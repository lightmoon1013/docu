import React, { useState } from 'react'
import { Tooltip, Whisper } from 'rsuite'
import { components } from 'react-select'
import { ReactComponent as InfoSvg } from '../../assets/svg/info.svg'

import SelectAsyncPaginate from '../CommonComponents/SelectAsyncPaginate'
import { getApSkus } from '../../redux/actions/ap'

const Option = (props) => {
  const { innerRef, innerProps, getStyles, data } = props
  return (
    <div
      ref={innerRef}
      {...innerProps}
      style={getStyles('option', props)}
      className="sku-option"
    >
      {
        data.image !== '' ? (
          <img src={data.image} alt={data.name} />
        ) : (
          <span className="placeholder-image" />
        )
      }
      <div className="product-info">
        <span className="product-name" title={data.name}>{data.name}</span>
        <span className="product-sku">SKU: {data.sku}</span>
      </div>
    </div>
  )
}

// https://github.com/JedWatson/react-select/issues/4170#issuecomment-682465724
const ValueContainer = (props) => {
  const { options, children, getValue } = props
  const selectCount = getValue().length
  let contents = children
  if (selectCount > 0) {
    if (selectCount === options.length) {
      contents = (
        <>
          All SKUs selected
          { children[1] }
        </>
      )
    } else if (selectCount >= 10) {
      contents = (
        <>
          { selectCount } SKUs selected
          { children[1] }
        </>
      )
    }
  }
  return (
    <components.ValueContainer {...props}>
      { contents }
    </components.ValueContainer>
  )
}

const MultiValueLabel = (props) => {
  const { data } = props
  return (
    <components.MultiValueLabel {...props}>
      <img src={data.image} className="option-label-img" alt={data.name} />
    </components.MultiValueLabel>
  )
}

const ExSkus = ({ selectedSkus, disabled, onChange }) => {
  const [keyword, setKeyword] = useState('')
  const [loadedSkus, setLoadedSkus] = useState([])

  const handleSelectAll = () => {
    if (selectedSkus.length === loadedSkus.length) {
      // If all is selected, un-select all.
      onChange([])
    } else {
      // Select all.
      onChange(loadedSkus)
    }
  }

  const handleInputChange = (inputValue, { action }) => {
    if (action !== 'input-blur' && action !== 'menu-close' && action !== 'set-value') {
      setKeyword(inputValue)
    }
  }

  return (
    <div className={`step-wrapper ${disabled ? 'disabled' : ''}`}>
      <div className="step-desc">
        <strong>Step 2)</strong> Select SKU's so we can find the right campaigns to pull from.
        Then click on Load Campaigns below.
        <Whisper placement="left" trigger="hover" speaker={(
          <Tooltip>
            <p>In this step, you are selecting which products and campaigns
            you’d like the system to pull data from in order to search
            for potential products to target with your advertising.</p>
            <p>Select a product, and then relevant campaigns in which
            that product appears will become available for selection as well.</p>
          </Tooltip>
        )}>
          <InfoSvg />
        </Whisper>
      </div>
      <div className="smart-select-wrapper">
        <SelectAsyncPaginate
          components={{ Option, ValueContainer, MultiValueLabel }}
          loadSkus={getApSkus}
          selection={selectedSkus}
          isDisabled={disabled}
          keyword={keyword}
          onChange={onChange}
          onInputChange={handleInputChange}
          onLoadedItems={(skus) => setLoadedSkus([...loadedSkus, ...skus])}
        />
        <button
          type="button"
          className="btn btn-white"
          disabled={disabled}
          onClick={handleSelectAll}
        >
          { (selectedSkus.length === 0 || selectedSkus.length !== loadedSkus.length) ? 'Select All' : 'Unselect All' }
        </button>
      </div>
    </div>
  )
}

export default ExSkus
