import React from 'react'

import SubSection from './SubSection'
import OpKeywordBasic from './OpKeywordBasic'
import OpKeywordAdvanced from './OpKeywordAdvanced'
import OpKeywordIgnore from './OpKeywordIgnore'

const OpKeyword = ({ settings, onChange, ...props }) => {
  const { campaign } = props

  let isAutoSP = false
  if (campaign) {
    // For auto targeting Sponsored Products, Advanced settings are disabled.
    isAutoSP = campaign.basic[0].type === 'sp'
      && campaign.basic[0].targeting_type === 'auto'
  }

  return (
    <SubSection name="Target Bid Optimization" templateId={settings.ap_template_id} {...props}>
      <OpKeywordBasic campaign={campaign} settings={settings} onChange={onChange} tutorial videoList={[{ title: 'Keyword Basic Optimization', url: 'https://www.loom.com/embed/6f43e6f51595496aa12bd2e4bd91e2d1' }]} />
      { !isAutoSP && <OpKeywordAdvanced settings={settings} onChange={onChange} tutorial videoList={[{ title: 'Keyword Basic Optimization', url: 'https://www.loom.com/embed/393fe73cb2ce426a946b2561f6185bd1' }]} /> }
      { !isAutoSP && <OpKeywordIgnore field="ignore_keywords" settings={settings} onChange={onChange} /> }
    </SubSection>
  )
}

export default OpKeyword
