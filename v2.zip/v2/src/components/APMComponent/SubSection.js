/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useRef } from 'react'
import { useDispatch } from 'react-redux'
import { Tooltip, Whisper } from 'rsuite'

import { ReactComponent as InfoSvg } from '../../assets/svg/info.svg'
import { ReactComponent as CaretUpSvg } from '../../assets/svg/caret-up.svg'
import { ReactComponent as CaretDownSvg } from '../../assets/svg/caret-down.svg'

import VideoLink from '../CommonComponents/VideoLink'

import { loadTemplate } from '../../redux/actions/templateEditor'

const SubSection = ({ id, name, templateId = null, tooltip = null, tutorial = null, videoList = [], children, activeSubSection, onToggle }) => {
  const dispatch = useDispatch()

  const ref = useRef(null)

  const handleTemplateEdit = (event) => {
    event.preventDefault()
    dispatch(loadTemplate(templateId))
  }

  return (
    <div className="subsection-container" ref={ref}>
      <div className="subsection-header">
        <span onClick={() => { onToggle(id, ref) }}>{ name }</span>
        {
          templateId !== null && templateId !== 0 && (
            <a href="#" onClick={handleTemplateEdit}>
              (from template)
            </a>
          )
        }
        {
          tooltip !== null && (
            <Whisper placement="left" trigger="hover" speaker={(
              <Tooltip>
                { tooltip }
              </Tooltip>
            )}>
              <InfoSvg />
            </Whisper>
          )
        }
        {
          activeSubSection === id
          ? <CaretUpSvg />
          : <CaretDownSvg />
        }
        {
          tutorial !== null && (
            <VideoLink
              videoList={videoList}
            />
          )
        }
      </div>
      {
        activeSubSection === id && (
          <div className={`subsection-body${templateId ? ' read-only' : ''}`}>
            { children }
          </div>
        )
      }
    </div>
  )
}

export default SubSection
