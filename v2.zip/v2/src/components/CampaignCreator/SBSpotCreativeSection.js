import React, { useState, useRef } from 'react'
import { useDispatch } from 'react-redux'

import { Tooltip, Whisper } from 'rsuite'

import SBBrandLogoModal from './SBBrandLogoModal'
import { ReactComponent as InfoSvg } from '../../assets/svg/info.svg'
import AdPreview from './AdPreview'
import SBSpotProductSelectModal from './SBSpotProductSelectModal'
import SBSpotPageSelectModal from './SBSpotPageSelectModal'
import { toast } from '../CommonComponents/ToastComponent/toast'
import { createSBBrandLogo } from '../../redux/actions/campaignCreator'

const SBSpotCreativeSection = ({ basicInfo, products, productPages, spotProductNames, creativeProducts, onChange, setOrderedProducts, storePageProducts, setSelectedBrandLogoData, handleProductNames, setNewLogo }) => {
  const inputRef = useRef()
  const dispatch = useDispatch()

  const [openModal, setOpenModal] = useState(false)
  const [openLogoModal, setOpenLogoModal] = useState(false)
  const [openPageSelectModal, setOpenPageSelectModal] = useState(false)
  const [brandUrl, setBrandUrl] = useState('')
  const [pageIndex, setPageIndex] = useState(0)
  const [selectedPageProducts, setSelectedPageProducts] = useState([])
  const [isWarning, setIsWarning] = useState(false)
  const handlePageSelect = (pageData) => {

    let isInclude = false
    products.map((product) => {
      if(product.id === pageData.products[0].id) {
        isInclude = true
        toast.show({
          title: 'Warning',
          description: 'This product is already selected.',
        })
      }
      return null
    })
    if (!isInclude) {
      setOpenPageSelectModal(false)
      products[pageIndex] = pageData.products[0]
      productPages[pageIndex] = pageData.pageInfo
      let productNames = [...spotProductNames]
      productNames[pageIndex] = pageData.pageInfo.storePageName
      setOrderedProducts(products, productPages, productNames, true)
    }
  }
  const handleProductSelect = (newproduct) => {
    let isInclude = false
    products.map((product) => {
      if(product.id === newproduct.id) {
        isInclude = true
        toast.show({
          title: 'Warning',
          description: 'This product is already selected.',
        })
      }
      return null
    })
    if (!isInclude) {
      setOpenModal(false)
      products[pageIndex] = newproduct
      let productNames = [...spotProductNames]
      setOrderedProducts(products, productPages, productNames, true)
    }
  }
  const openPageSelect = (index) => {
    setPageIndex(index)
    setOpenPageSelectModal(true)
  }
  const openProductSelect = (index, product) => {
    storePageProducts.map((pageData, index)=>{
      if(pageData.products.includes(product)) {
        setSelectedPageProducts(pageData.products)
      }
      return null
    })
    setPageIndex(index)
    setOpenModal(true)
  }
  const handleBrandLogo = (seletedLogo) => {
    setBrandUrl(seletedLogo.url)
    setSelectedBrandLogoData(seletedLogo)
    setOpenLogoModal(false)
    setOpenPageSelectModal(false)
  }

  const handleProductName = (value, index) => {
    let productNames = [...spotProductNames]
    productNames[index] = value
    handleProductNames(productNames)
  }

  const handleHeadline = (headline) => {
    if (headline.length > 50) {
      setIsWarning(true)
    } else {
      setIsWarning(false)
      onChange('headline', headline)

    }
  }

  const handleUploadLogoFile = (e) => {
    if (e.target.files && e.target.files.length > 0) {
      if (e.target.files[0].size > 1048576) {
        toast.show({
          title: 'Warning',
          description: 'File size must be smaller than 1MB.',
        })
        return
      }
      if ((e.target.files[0].type === 'image/jpeg') || (e.target.files[0].type === 'image/png')) {
        let imageName = e.target.files[0].name
        let imageType = e.target.files[0].type
        const reader = new FileReader();
        reader.addEventListener('load', () => {

          let img = document.createElement('img')
          img.addEventListener('load', () => {
            if (img.width < 400 || img.height < 400) {
              toast.show({
                title: 'Warning',
                description: 'Dimensions must be at least 400 x 400 px.',
              })
              return
            }
            setBrandUrl(reader.result)

            if (basicInfo.brandEntityId === '') {
              toast.show({
                title: 'Warning',
                description: 'Please select your brand name.',
              })
              return
            }
            let uploadParam = {
              imageName: imageName,
              imageType: imageType,
              imageData: reader.result,
              brandEntityId: basicInfo.brandEntityId
            }
            setNewLogo(true)

            dispatch(createSBBrandLogo(uploadParam)).then(() => {
              //
            }).catch((description) => {
              setNewLogo(false)

              toast.show({
                title: 'Danger',
                description,
              })
              setBrandUrl('')
              return
            })

          })
          img.src = reader.result
        })
        reader.readAsDataURL(e.target.files[0])
      } else {
        toast.show({
          title: 'Warning',
          description: 'File format must be PNG or JPEG.',
        })
        return
      }
    }
  }

  const renderProductsOrder = () => {
    return (
      <>
        <div className="product-list d-flex">
          {
            creativeProducts.length <=2 ?
            (
              products.slice(0,3).map((product) =>
              <div key={product.id} className="product-list-item">
                <img src={product.image} alt={product.name} />
              </div>
            )) : (
              creativeProducts.slice(0,3).map((product) =>
              <div key={product.id} className="product-list-item">
                <img src={product.image} alt={product.name} />
              </div>
            ))
          }
        </div>
        <div className="product-container">
        {
          products.map((product, index) =>
            <div key={product.id} className="product-box product-item-box">
              <div className="d-flex">
                <img src={product.image} alt={product.name} />
                <div className="product-info">
                  <div className="input-wrapper">
                    <input
                      type="text"
                      value={spotProductNames[index]}
                      onChange={(event) => { handleProductName(event.target.value, index) }}
                    />
                    {
                      spotProductNames[index].length > 50 && (
                        <div className="display-name-warning">
                          Product display name must be less than 50 characters maximum.
                        </div>
                      )
                    }

                  </div>
                  <div className="product-detail">
                    <span>Price: {product.price}</span>
                    <span>ASIN: {product.asin}</span>
                    <span>SKU: {product.sku}</span>
                  </div>
                </div>
              </div>

              <div className="d-flex">
                <button type="button" className="btn btn-blue mr-10" onClick={() => openPageSelect(index)}>
                  Select Page
                </button>
                <button type="button" className="btn btn-blue mr-10" onClick={() => openProductSelect(index, product)}>
                  Select Product
                </button>
              </div>
            </div>
          )
        }
        </div>
      </>
    )
  }

  return (
    <div className="section-container">
      <div className="section-title">
        Creative
      </div>
      <div className="field-row">
        <div className="field-wrapper ">
          <div className="field-name ">
            Brand Name
          </div>
          <div className="d-flex">
            <div className="input-wrapper">
              <input
                type="text"
                value={basicInfo.brandName}
                onChange={(event) => { onChange('brandName', event.target.value) }}
              />
            </div>
          </div>
        </div>
        <div className="field-wrapper "></div>
        <div className="field-wrapper ">
          <div className="field-name ">
            Headline
            <Whisper placement="right" trigger="hover" speaker={(
              <Tooltip>
                <p>Tips to help get your headline approved</p>
                <p>- Check for typos, misspellings, and grammar mistakes</p>
                <p>- Avoid excessive punctuation such as "!!!" or "?!"</p>
                <p>- Avoid random punctuation such as "Your. headline."</p>
                <p>- Avoid extra spacing such as "Y o u r h e a d l i n e"</p>
                <p>- Check for typos, misspellings, and grammar mistakes</p>
                <p>- Sentence case is recommended (i.e. “This is a new headline”)</p>
              </Tooltip>
            )}>
              <InfoSvg />
            </Whisper>
          </div>
          <div className="d-flex">
            <div className="input-wrapper">
              <input
                type="text"
                value={basicInfo.headline}
                onChange={(event) => {handleHeadline(event.target.value)}}
              />
              {isWarning && (
                <div className="headline-warning">
                  Maximum length of headline is 50 characters.
                </div>
              )}
            </div>
          </div>
        </div>
        <div className="field-wrapper "></div>
      </div>

      <div className="field-row">
        <div className="field-wrapper ">
          <div className="field-name ">
            Brand Logo
            <Whisper placement="right" trigger="hover" speaker={(
              <Tooltip>
                <p>Logo specs</p>
                <p>Image size: 400 x 400 px or larger</p>
                <p>File size: 1 MB or smaller</p>
                <p>File format PNG, JPG or GIF</p>
                <p>Content: Logo must fill the image or have a white or transparent background</p>
              </Tooltip>
            )}>
              <InfoSvg />
            </Whisper>
          </div>
          <div className="d-flex">
            <div className="input-wrapper edit-logo-panel">
              <div>
                <button type="button" className="btn btn-blue edit-logo-btn" onClick={() => setOpenLogoModal(true)}>
                  Select Logo
                </button>
                <button type="button" className="btn btn-blue edit-logo-btn" onClick={() => inputRef.current.click()} >
                  Upload New Logo
                </button>
                <input ref={inputRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={handleUploadLogoFile} />
              </div>

              <div className="preview-brand-logo">
                { brandUrl !== '' ? (<img src={brandUrl} alt="Invalid Images" />) : (<p>Select a BrandLogo.</p>)
                }
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="field-row">
        <div className="field-wrapper ">
          <div className="field-name ">
            Store Pages
            <Whisper placement="right" trigger="hover" speaker={(
              <Tooltip>
                <p>You can promote any Store page (except for the home page) in your ad.</p>
              </Tooltip>
            )}>
              <InfoSvg />
            </Whisper>

          </div>
          {renderProductsOrder()}
        </div>
      </div>
      <div className="field-row">
        <div className="field-wrapper ">
          <div className="field-name ">
            Ad Preview
            <Whisper placement="right" trigger="hover" speaker={(
              <Tooltip>
                <p>A campaign name is only visible to you, so choose a name
                that you can easily identify and refer back to later.</p>
              </Tooltip>
            )}>
              <InfoSvg />
            </Whisper>
          </div>
          {
            products.length > 0 && (
              <AdPreview
                products={products}
                creativeProducts={creativeProducts}
                brandUrl={brandUrl}
                spotProductNames={spotProductNames}
                isSpotlight
                basicInfo={basicInfo}
              />
            )
          }
        </div>
      </div>
      {
        openModal && (
          <SBSpotProductSelectModal
            show={openModal}
            selectedPageProducts={selectedPageProducts}
            // onSelect={handleSelect}
            onClose={() => { setOpenModal(false) }}
            onSelect={handleProductSelect}
          />
        )
      }
      {
        openLogoModal && (
          <SBBrandLogoModal
            show={openLogoModal}
            onClose={() => { setOpenLogoModal(false) }}
            setBrandLogo={handleBrandLogo}
          />
        )
      }
      {
        openPageSelectModal && (
          <SBSpotPageSelectModal
            show={openPageSelectModal}
            storePageProducts={storePageProducts}
            onClose={() => { setOpenPageSelectModal(false) }}
            onSelect={handlePageSelect}
          />
        )
      }
    </div>
  )
}

export default SBSpotCreativeSection
