import React, { useState, useRef } from 'react'
import { useDispatch } from 'react-redux'

import { Tooltip, Whisper } from 'rsuite'
import { toast } from '../CommonComponents/ToastComponent/toast'

import ProductsOrderModal from './ProductsOrderModal'
import SBBrandLogoModal from './SBBrandLogoModal'
import { ReactComponent as InfoSvg } from '../../assets/svg/info.svg'
import AdPreview from './AdPreview'
import { createSBBrandLogo } from '../../redux/actions/campaignCreator'

const SBCreativeSection = ({ basicInfo, products, creativeProducts, onChange, setOrderedProducts, setSelectedBrandLogoData, setNewLogo }) => {
  const inputRef = useRef()
  const dispatch = useDispatch()

  const [openModal, setOpenModal] = useState(false)
  const [openLogoModal, setOpenLogoModal] = useState(false)
  const [brandUrl, setBrandUrl] = useState('')
  const [isWarning, setIsWarning] = useState(false)

  const handleOrderedProducts = (orderedProducts) => {
    setOpenModal(false)
    setOrderedProducts(orderedProducts, true)
  }

  const handleBrandLogo = (seletedLogo) => {
    if (seletedLogo.width >= 400 && seletedLogo.height >= 400) {
      setBrandUrl(seletedLogo.url)
      setSelectedBrandLogoData(seletedLogo)
      setOpenLogoModal(false)
    } else {
      toast.show({
        title: 'Warning',
        description : 'Dimensions must be at least 400 x 400 px.',
      })
    }
  }

  const renderProductsOrder = () => {
    return (
      <div className="product-list d-flex">
        {
          creativeProducts.length <= 2 ?
          (
            products.slice(0,3).map((product) =>
            <div key={product.id} className="product-list-item">
              <img src={product.image} alt={product.name} />
            </div>
          )) : (
            creativeProducts.slice(0,3).map((product) =>
            <div key={product.id} className="product-list-item">
              <img src={product.image} alt={product.name} />
            </div>
          ))
        }
        <div className="input-wrapper">
          <button type="button" className="btn btn-blue" onClick={() => setOpenModal(true)}>
            Change Order
          </button>
        </div>
      </div>
    )
  }
  const handleHeadline = (headline) => {
    if (headline.length > 50) {
      setIsWarning(true)
    } else {
      setIsWarning(false)
      onChange('headline', headline)

    }
  }
  const handleUploadLogoFile = (e) => {
    if (e.target.files && e.target.files.length > 0) {
      if (e.target.files[0].size > 1048576) {
        toast.show({
          title: 'Warning',
          description: 'File size must be smaller than 1MB',
        })
        return
      }
      if ((e.target.files[0].type === 'image/jpeg') || (e.target.files[0].type === 'image/png')) {
        let imageName = e.target.files[0].name
        let imageType = e.target.files[0].type
        const reader = new FileReader();
        reader.addEventListener('load', () => {

          let img = document.createElement('img')
          img.addEventListener('load', () => {
            if (img.width < 400 || img.height < 400) {
              toast.show({
                title: 'Warning',
                description: 'Dimensions must be at least 400 x 400 px',
              })
              return
            }
            setBrandUrl(reader.result)

            if (basicInfo.brandEntityId === '') {
              toast.show({
                title: 'Warning',
                description: 'Please select your brand name.',
              })
              return
            }
            let uploadParam = {
              imageName: imageName,
              imageType: imageType,
              imageData: reader.result,
              brandEntityId: basicInfo.brandEntityId
            }
            setNewLogo(true)

            dispatch(createSBBrandLogo(uploadParam)).then(() => {
              //
            }).catch((description) => {
              setNewLogo(false)

              toast.show({
                title: 'Danger',
                description,
              })
              setBrandUrl('')
              return
            })
          })
          img.src = reader.result
        })
        reader.readAsDataURL(e.target.files[0])
      } else {
        toast.show({
          title: 'Warning',
          description: 'File format must be PNG or JPEG',
        })
        return
      }
    }
  }

  return (
    <div className="section-container">
      <div className="section-title">
        Creative
      </div>
      <div className="field-row">
        <div className="field-wrapper ">
          <div className="field-name ">
            Brand Name
          </div>
          <div className="d-flex">
            <div className="input-wrapper">
              <input
                type="text"
                value={basicInfo.brandName}
                onChange={(event) => { onChange('brandName', event.target.value) }}
              />
            </div>
          </div>
        </div>
        <div className="field-wrapper"></div>
        <div className="field-wrapper">
          <div className="field-name">
            Headline
            <Whisper placement="right" trigger="hover" speaker={(
              <Tooltip>
                <p>Tips to help get your headline approved</p>
                <p>- Check for typos, misspellings, and grammar mistakes</p>
                <p>- Avoid excessive punctuation such as "!!!" or "?!"</p>
                <p>- Avoid random punctuation such as "Your. headline."</p>
                <p>- Avoid extra spacing such as "Y o u r h e a d l i n e"</p>
                <p>- Check for typos, misspellings, and grammar mistakes</p>
                <p>- Sentence case is recommended (i.e. “This is a new headline”)</p>
              </Tooltip>
            )}>
              <InfoSvg />
            </Whisper>
          </div>
          <div className="d-flex">
            <div className="input-wrapper">
              <input
                type="text"
                value={basicInfo.headline}
                onChange={(event) => {handleHeadline(event.target.value)}}
              />
              {isWarning && (
                <div className="headline-warning">
                  Maximum length of headline is 50 characters.
                </div>
              )}
            </div>
          </div>
        </div>
        <div className="field-wrapper"></div>
      </div>
      <div className="field-row">
        <div className="field-wrapper">
          <div className="field-name">
            Brand Logo
            <Whisper placement="right" trigger="hover" speaker={(
              <Tooltip>
                <p>Logo specs</p>
                <p>Image size: 400 x 400 px or larger</p>
                <p>File size: 1 MB or smaller</p>
                <p>File format PNG, JPG or GIF</p>
                <p>Content: Logo must fill the image or have a white or transparent background</p>
              </Tooltip>
            )}>
              <InfoSvg />
            </Whisper>
          </div>
          <div className="d-flex">
            <div className="input-wrapper edit-logo-panel">
              <div>
                <button type="button" className="btn btn-blue edit-logo-btn" onClick={() => setOpenLogoModal(true)}>
                  Select Logo
                </button>
                <button type="button" className="btn btn-blue edit-logo-btn" onClick={() => inputRef.current.click()} >
                  Upload New Logo
                </button>
                <input ref={inputRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={handleUploadLogoFile} />
              </div>
              <div className="preview-brand-logo">
                { brandUrl !== '' ? (<img src={brandUrl} alt="Invalid Images" />) : (<p>Select a BrandLogo.</p>) }
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="field-row">
        <div className="field-wrapper ">
          <div className="field-name ">
            Products Order
            <Whisper placement="right" trigger="hover" speaker={(
              <Tooltip>
                <p>Change or reorder products.</p>
              </Tooltip>
            )}>
              <InfoSvg />
            </Whisper>
          </div>
          {renderProductsOrder()}
        </div>
      </div>
      <div className="field-row">
        <div className="field-wrapper ">
          <div className="field-name ">
            Ad Preview
            <Whisper placement="right" trigger="hover" speaker={(
              <Tooltip>
                <p>Your ad may look slightly different than what you see in this preview as we continually test both new and existing features to determine which characteristics drive ad performance.</p>
              </Tooltip>
            )}>
              <InfoSvg />
            </Whisper>
          </div>
          {
            products.length > 0 && (
              <AdPreview
                products={products}
                creativeProducts={creativeProducts}
                brandUrl={brandUrl}
                basicInfo={basicInfo}
              />
            )
          }
        </div>
      </div>
      {
        openModal && (
          <ProductsOrderModal
            show={openModal}
            products={products}
            onClose={() => { setOpenModal(false) }}
            setOrderedProducts={handleOrderedProducts}
          />
        )
      }
      {
        openLogoModal && (
          <SBBrandLogoModal
            show={openLogoModal}
            onClose={() => { setOpenLogoModal(false) }}
            setBrandLogo={handleBrandLogo}
          />
        )
      }
    </div>
  )
}

export default SBCreativeSection
