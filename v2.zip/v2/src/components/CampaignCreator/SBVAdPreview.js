import React from 'react'
import PrimePng from '../../assets/img/prime.png'

const SBVAdPreview = ({ products=[], creativeProducts=[], videoPath }) => {

  // className={`category-tree-container${isLoading ? ' loading' : ''}`}
  return (
    <div className="sbv-preview-container">
      <div className="desktop-preview">
        <div className="preview-left">
          <div className="preview-left-item">
            {/* <img src={videoPath} alt="" className="product-image" /> */}
            <video src={videoPath} width="200" height="120" class="video-responsive" type="video/mp4"></video>
          </div>
        </div>
        <div className="preview-right">
          {
            products.map((product) =>
              <div key={product.id} className="preview-item d-flex">
                <div className="mr-10">
                  <img src={product.image} alt="" className="product-image" />
                </div>
                <div className="product-info">
                  <div className="product-name">SPONSORED</div>
                  <div className="product-name">{product.name.substr(1,100)}</div>
                  <div className="product-name">Asin: {product.asin}</div>
                  <div className="product-name">Price: ${product.price}</div>
                  <div className="product-detail">
                    <img src={PrimePng} alt="" />
                  </div>
                </div>
              </div>
            )
          }
        </div>
      </div>
    </div>
  )
}

export default SBVAdPreview
