import React, { useState } from 'react'
import { Modal } from 'rsuite'
import { toast } from '../CommonComponents/ToastComponent/toast'

const ProductsOrderModal = ({ show, products, onClose, setOrderedProducts }) => {
  const [oldProducts, setOldProducts] = useState(products)
  const [newProducts, setNewProducts] = useState([])

  const onSave = () => {
    if (newProducts.length <=2)
    {
      toast.show({
        title: 'Danger',
        description: 'Select more than 3 products.',
      })
      return
    }
    setOrderedProducts(newProducts)
  }

  const addProduct = (product) => {
    setNewProducts([...newProducts, product])
    const filteredProducts = oldProducts.filter(prod => prod.id !== product.id)
    setOldProducts(filteredProducts)
  }
  const removeProduct = (product) => {
    setOldProducts([...oldProducts, product])
    const filteredProducts = newProducts.filter(prod => prod.id !== product.id)
    setNewProducts(filteredProducts)
  }

  const renderProductsList = () => {
    return (
      <div className="product-order-container">
        <div className="product-order-left-container">
          <div className="product-list">
            {
              oldProducts.map((product) =>
                <div key={product.id} className="product-list-item product-order-img product-item-box d-flex">
                  <div className="d-flex">
                    <img src={product.image} alt={product.name} />
                    <div className="product-info">
                      <div className="product-name">{product.name}</div>
                      <div className="product-detail">
                        <span>Price: {product.price}</span>
                        <span>ASIN: {product.asin}</span>
                        <span>SKU: {product.sku}</span>
                      </div>
                    </div>
                  </div>
                  <div className="d-flex">
                    <button type="button" className="btn btn-blue" onClick={() => addProduct(product)}>
                      Add
                    </button>
                  </div>
                </div>
              )
            }
          </div>
        </div>
        <div className="product-order-right-container">
          <div className="product-list">
            {
              newProducts.map((product) =>
                <div key={product.id} className="product-list-item product-order-img product-item-box d-flex">
                  <div className="d-flex">
                    <img src={product.image} alt={product.name} />
                    <div className="product-info">
                      <div className="product-name">{product.name}</div>
                      <div className="product-detail">
                        <span>Price: {product.price}</span>
                        <span>ASIN: {product.asin}</span>
                        <span>SKU: {product.sku}</span>
                      </div>
                    </div>
                  </div>
                  <div className="d-flex">
                    <button type="button" className="btn btn-blue" onClick={() => removeProduct(product)}>
                      Remove
                    </button>
                  </div>
                </div>
              )
            }
          </div>
        </div>
      </div>
    )
  }


  return (
    <Modal className={`product-ordering-modal`} backdrop="static" show={show} size="full">
      <Modal.Header onHide={() => { onClose() }}>
        <Modal.Title>
          <div className="product-order-header">
            Click products to add them in the order you wish them to appear
          </div>
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        { renderProductsList() }
      </Modal.Body>
      <Modal.Footer>
        <button type="button" className="rs-btn rs-btn-primary" onClick={() => onSave()}>
          Confirm
        </button>
        <button type="button" className="rs-btn rs-btn-subtle" onClick={() => onClose()}>
          Close
        </button>
      </Modal.Footer>
    </Modal>
  )
}
export default ProductsOrderModal