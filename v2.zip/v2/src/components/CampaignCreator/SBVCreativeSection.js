import React, { useRef, useState } from 'react'
import { Tooltip, Whisper } from 'rsuite'
import { useDispatch } from 'react-redux'

import { ReactComponent as InfoSvg } from '../../assets/svg/info.svg'
import SBVAdPreview from './SBVAdPreview'
import { toast } from '../CommonComponents/ToastComponent/toast'

import { createSBVMedia } from '../../redux/actions/campaignCreator'

const SBVCreativeSection = ({ products, creativeProducts }) => {
  const inputRef = useRef()
  const dispatch = useDispatch()

  const [videoPath, setVideoPath] = useState('')

  const getBase64 = (file, cb) => {
    let reader = new FileReader()
    reader.readAsDataURL(file)
    reader.onload = function () {
      cb(reader.result)
    };
    reader.onerror = function () {
      //
    };
  }
  const handleUploadFile = (e) => {
    if(e.target.files[0].type === "video/mp4") {

      if (e.target.files[0].size <= 5524288000) {
        let file = e.target.files[0]
        setVideoPath(URL.createObjectURL(e.target.files[0]))
        getBase64(file, (result) => {
          let b64 = result
          let fileName = Math.floor(Math.random() * Math.floor(1025439))
          let params = {
            base64:b64,
            fileInfo: file,
            fileName: fileName
          }
          dispatch(createSBVMedia(params)).then(() => {
          }).catch((description) => {
            toast.show({
              title: 'Warning',
              description : description + ' Please check Video and Audio specs.',
            })
          })
        })
      } else {
        toast.show({
          title: 'Warning',
          description: 'Only less than 500 MB video file is supported.',
        })
      }
    } else {
      toast.show({
        title: 'Warning',
        description: 'Only mp4 video file is supported.',
      })
    }
  }

  return (
    <div className="section-container">
      <div className="section-title">
        Creative
      </div>
      <div className="field-row">
        <div className="field-wrapper mw-440">
          <div className="field-name">
            Choose a video
            <Whisper placement="right" trigger="hover" speaker={(
              <Tooltip>
                <p>Keep your video brief and relevant. It will autoplay, so make sure the first 2 seconds are highly engaging, and don't rely on sound to communicate your message. If you use text in your video, make sure it's legible.</p>
              </Tooltip>
            )}>
              <InfoSvg />
            </Whisper>
          </div>
          <div className="d-flex mt-10">
            <div className="input-wrapper">
              <button type="button" className="btn btn-blue" onClick={() => inputRef.current.click()}>
                Upload new video
              </button>
              <input ref={inputRef} type="file" style={{ display: 'none' }} onChange={handleUploadFile} />
            </div>
          </div>
          <div class="video-requirement">
            <ul>
              <li><b>Video specs</b></li>
              <li>
                <ul>
                  <li>16:9 aspect ratio</li>
                  <li>1280 x 720px, 1920 x 1080px or 3840 x 2160px</li>
                  <li>23.976, 24, 25, 29.97, 29.98, or 30 fps</li>
                  <li>1 Mbps or higher bit rate</li>
                  <li>H.264 or H.265 codec</li>
                  <li>6-45 sec long</li>
                  <li>500 MB or smaller</li>
                  <li>MP4 or MOV file</li>
                  <li>Main or baseline profile</li>
                  <li>Progressive scan type</li>
                  <li>1 video stream only</li>
                </ul>
              </li>
              <li><b>Audio specs</b></li>
              <li>
                <ul>
                  <li>44.1 kHz or higher sample rate</li>
                  <li>PCM, AAC or MP3 codec</li>
                  <li>96 kbps or higher bit rate</li>
                  <li>Stereo or mono format</li>
                  <li>Not more than 1 audio stream</li>
                </ul>
              </li>
            </ul>
          </div>
        </div>
        <div className="field-wrapper ">
          <div className="field-name ">
            Ad preview
            <Whisper placement="right" trigger="hover" speaker={(
              <Tooltip>
                <p>Your ad may look slightly different than what you see in this preview as we continually test both new and existing features to determine which characteristics drive ad performance.</p>
              </Tooltip>
            )}>
              <InfoSvg />
            </Whisper>
          </div>
          <SBVAdPreview products={products} videoPath={videoPath} creativeProducts={creativeProducts} />
        </div>
      </div>
    </div>
  )
}

export default SBVCreativeSection
