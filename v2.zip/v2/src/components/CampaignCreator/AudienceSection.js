import React, { useState } from 'react'
import Select from 'react-select'
import { useDispatch } from 'react-redux'

import { ReactComponent as CloseSvg } from '../../assets/svg/close.svg'

import AudienceModal from './AudienceModal'
import { getSDSuggestionBids } from '../../redux/actions/campaignCreator'

const suggestedBidOptions = [
  { value: 'suggested', label: 'Suggested' },
  { value: 'min', label: 'Min' },
  { value: 'max', label: 'Max' },
]

const AudienceSection = ({ targetings, dailyBudget, bidInfo, products, onChange }) => {
  const dispatch = useDispatch()

  const [openModal, setOpenModal] = useState(false)
  const [defaultBid, setDefaultBid] = useState(0.75)
  const [suggestedBidType, setSuggestedBidType] = useState(suggestedBidOptions[0])

  const parseTargetings = () => {
    const targets = []
    targetings.filter(targeting => targeting.audienceType === 'views').forEach((targeting) => {
      const payload = {
        bid: targeting.bid,
        targeting: targeting,
        expression: [],
      }
      switch (targeting.type) {
        case 'audience_category':
          payload.expression.push({
            type: targeting.audienceType ? targeting.audienceType : 'views',
            value: [
              {
                type: 'asinCategorySameAs',
                value: targeting.id.toString().replace(targeting.audienceType, ''),
              },
              {
                type: 'lookback',
                value: targeting.lookback ? targeting.lookback.value : '30',
              },
            ],

          })
          break
        case 'audience_product':
          payload.expression.push({
            type: targeting.audienceType ? targeting.audienceType : 'views',
            value: [
              {
                type: targeting.id.replace(targeting.audienceType, ''),
              },
              {
                type: 'lookback',
                value: targeting.lookback ? targeting.lookback.value : '30',
              },
            ],
          })
          break
        case 'audience_refine':
          const values = []
          values.push({
            type: 'asinCategorySameAs',
            value: targeting.id.toString().replace(targeting.audienceType, ''),
          })

          if (targeting.brandId) {
            values.push({
              type: 'asinBrandSameAs',
              value: targeting.brandId.toString(),
            })
          }

          if (targeting.ratingValue) {
            values.push({
              type: 'asinReviewRatingBetween',
              value: targeting.ratingValue,
            })
          }

          if (targeting.priceFrom && targeting.priceTo) {
            values.push({
              type: 'asinPriceBetween',
              value: `${targeting.priceFrom}-${targeting.priceTo}`,
            })
          } else if (targeting.priceFrom && !targeting.priceTo) {
            values.push({
              type: 'asinPriceGreaterThan',
              value: targeting.priceFrom,
            })
          } else if (!targeting.priceFrom && targeting.priceTo) {
            values.push({
              type: 'asinPriceLessThan',
              value: targeting.priceTo,
            })
          }
          values.push({
            type: 'lookback',
            value: targeting.lookback ? targeting.lookback.value : '30',
          })
          payload.expression.push({
            type: targeting.audienceType ? targeting.audienceType : 'views',
            value: values,
          })
          break
        case 'audience':
          payload.expression.push({
            type: 'audience',
            value: [
              {
                type: 'audienceSameAs',
                value: targeting.id.toString(),
              },
            ],
          })
          break
        default:
          break
      }
      if (['audience_category', 'audience_refine', 'audience_product', 'audience'].indexOf(targeting.type) !== -1) {
        targets.push(payload)
      }
    })
    return targets
  }

  const handleBidChange = (event, target) => {
    onChange(targetings.map((item) => {
      if ((item.id === target.id) && (item.audienceType === target.audienceType)) {
        return {
          ...item,
          bid: event.target.value,
        }
      }
      return item
    }))
  }

  const handleRemove = (target) => {
    onChange(targetings.filter(item => {
      if ((target.type !== item.type) && item.audienceType === target.audienceType) {
        return true
      }
      return target.id !== item.id
    }))
  }

  const getTargetingName = (target) => {
    if (target.type === 'audience_category' || target.type === 'audience_refine') {
      return `Category: ${target.name}`
    }
    if (target.type === 'audience_product') {
      return target.name
    }
    if (target.type === 'audience') {
      return `Audiences: ${target.name}`
    }
  }

  const handleGetSuggestedBid = () => {

    let suggestedTargets = parseTargetings(targetings)
    if (products.length > 0 && suggestedTargets.length > 0) {
      let asins = []
      products.map((product) => {
        asins.push({asin: product.asin})
        return true
      })
      let bidParams = []
      suggestedTargets.map((suggestedTarget) => {
        let targetingClauses = []
        // let expressions = []
        // expressions.push(suggestedTarget.expression[0])
        targetingClauses.push({targetingClause: {
          expressionType: 'manual',
          expression: suggestedTarget.expression
        }})
        let getSuggestedParams = {
          products: asins,
          bidOptimization: bidInfo.bidOp.value,
          costType: bidInfo.bidOp.value === 'reach' ? 'vcpm' : 'cpc',
          targetingClauses: targetingClauses
        }
        let bidParam = {targeting: suggestedTarget, param: getSuggestedParams}
        bidParams.push(bidParam)
        return true
      })

      dispatch(getSDSuggestionBids(bidParams)).then(response => {
        if (response && response.length > 0) {
          onChange(targetings.map((targeting) => {
            const suggestedBid = response.filter(bid => (
              bid.targeting.targeting.id === targeting.id
            ))
            if (suggestedBid.length) {
              return {
                ...targeting,
                suggestedBid: suggestedBid[0].suggestedBid,
              }
            }
            return targeting
          }))
        }
      })
    }
    setOpenModal(false)
  }

  const handleApplyBid = (type, target) => {
    if (!target.suggestedBid) {
      return
    }
    let bid = defaultBid
    switch (type) {
      case 'suggest':
        bid = target.suggestedBid.recommended
        break;
      case 'min':
        bid = target.suggestedBid.rangeLower
        break;
      case 'max':
        bid = target.suggestedBid.rangeUpper
        break;
      default:
        bid = defaultBid
        break;
    }

    onChange(targetings.map((item) => {
      if (item.id === target.id) {
        return {
          ...item,
          bid: bid,
        }
      }
      return item
    }))
  }

  const handleDefaultBidApply = () => {
    onChange(targetings.map(item => ({
      ...item,
      bid: defaultBid,
    })))
  }

  const handleSuggestedBidType = (bidType) => {
    setSuggestedBidType(bidType)
  }

  const handleApplyAllSuggested = () => {
    if (suggestedBidType.value === 'max') {
      onChange(targetings.map(target => {
        target.bid = target.suggestedBid ? target.suggestedBid.rangeUpper : target.bid
        return target
      }))
    } else if (suggestedBidType.value === 'min') {
      onChange(targetings.map(target => {
        target.bid = target.suggestedBid ? target.suggestedBid.rangeLower : target.bid
        return target
      }))
    } else {
      onChange(targetings.map(target => {
        target.bid = target.suggestedBid ? target.suggestedBid.recommended : target.bid
        return target
      }))
    }
  }

  const renderTargetings = () => {
    if (!targetings.length) {
      return (
        <div className="no-targeting-desc">
          No targeting added.
        </div>
      )
    }

    return (
      <div className="targeting-list">
        {
          targetings.map(target => (
            <div key={target.id} className="targeting-item">
              <div className="targeting-info">
                <div className="targeting-name">
                  { getTargetingName(target) }
                </div>
                {
                  target.type !== 'audience' && (
                    <div className="targeting-meta">
                      Lookback: {target.lookback ? target.lookback.value : 30} days
                    </div>
                  )
                }
                {
                  target.type === 'audience_refine' && (
                    <div className="targeting-meta">
                      Brand: { target.brandName }
                    </div>
                  )
                }
              </div>
              {
                target.suggestedBid && (
                  <div className="targeting-action mr-8">
                    <div className="apply-section">
                      <div className="mb-8">
                        Suggested Bid:&nbsp;
                        {target.suggestedBid.recommended + ' : ' + target.suggestedBid.rangeLower + '~' + target.suggestedBid.rangeUpper}
                      </div>
                      <button type="button" className="btn btn-blue mr-8" onClick={() => { handleApplyBid('suggest', target) }}>
                        Apply Suggest
                      </button>
                      <button type="button" className="btn btn-blue mr-8" onClick={() => { handleApplyBid('min', target) }}>
                        Apply Min
                      </button>
                      <button type="button" className="btn btn-blue" onClick={() => { handleApplyBid('max', target) }}>
                        Apply Max
                      </button>
                    </div>
                  </div>
                )
              }
              <div className="targeting-action min-width-330">
                <div>
                  <input
                    type="number"
                    value={target.bid}
                    onChange={(event) => { handleBidChange(event, target) }}
                  />
                  {
                    parseFloat(target.bid) >= parseFloat(dailyBudget) / 2 && (
                      <div className="budget-warning">
                        Bid must be less than half the value of your budget.
                      </div>
                    )
                  }
                </div>
                <CloseSvg title="Remove" onClick={() => { handleRemove(target) }}/>
              </div>
            </div>
          ))
        }
      </div>
    )
  }

  return (
    <div className="section-container">
      <div className="section-title">
        <span>Audiences</span>
        <div>
          <button
            type="button"
            className="btn btn-blue"
            onClick={() => { setOpenModal(true) }}
          >
            Choose Audience
          </button>
          {
            targetings.length > 0 && (
              <button type="button" className="btn btn-red" onClick={() => { onChange([]) }}>
                Remove All
              </button>
            )
          }
        </div>
      </div>
      <div className="section-note">
        Reach audiences based on product detail page views, or use our prebuilt audience segments.
      </div>
      <div className="field-row">
        <div className="field-wrapper">
          <div className="default-bid-section">
            Default Bid:&nbsp;
            <input
              type="text"
              value={defaultBid}
              onChange={(event) => { setDefaultBid(event.target.value) }}
            />
            <button type="button" className="btn btn-blue" onClick={handleDefaultBidApply}>
              Apply
            </button>
          </div>
        </div>
        <div className="field-wrapper">
          {
            targetings.length > 0 && (
              <div className="d-flex suggested-bid-select mt-8">
                <span className="suggested-bid-span">Suggested Bid Types:&nbsp;</span>
                <Select
                  classNamePrefix="portfolio-selector"
                  className="bid-option-selector"
                  options={suggestedBidOptions}
                  value={suggestedBidType}
                  onChange={val => handleSuggestedBidType(val)}
                />
                <button
                  type="button"
                  className="btn btn-green btn-suggested-bids ml-10"
                  onClick={handleApplyAllSuggested}
                >
                  Apply To All
                </button>
              </div>
            )
          }
        </div>
      </div>
      { renderTargetings() }
      <AudienceModal
        show={openModal}
        defaultBid={defaultBid}
        targetings={targetings}
        onChange={onChange}
        onClose={handleGetSuggestedBid}
      />
    </div>
  )
}

export default AudienceSection
