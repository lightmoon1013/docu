import React from 'react'

import PrimePng from '../../assets/img/prime.png'

const AdPreview = ({ products = [], creativeProducts = [], brandUrl = '', spotProductNames = [], isSpotlight, basicInfo}) => {
  return (
    <div className="preview-container">
      <div className="desktop-preview">
        <div className="preview-left">
          <div className="preview-left-item ">
            <img src={brandUrl} alt="" />
            <div className="product-info ">
              {
                !isSpotlight && (
                  basicInfo.storeType === 'newpage' && (
                    <div className="product-name">
                      SPONSORED BY {basicInfo.brandName}
                    </div>
                  )
                )
              }
              <div className="product-detail">
                {
                  isSpotlight ? (
                    <>
                      <div className="headline-name">{basicInfo.headline}</div>
                      <a className="shop-now" href={`${basicInfo.storeUrl}`} rel="noopener noreferrer">
                        Shop the store on Amazon
                      </a>
                    </>
                  ) : (
                    basicInfo.storeType === 'newpage' ? (
                      <>
                        <div className="headline-name">{basicInfo.headline}</div>
                        <a
                          className="shop-now"
                          href={`https://www.amazon.com/stores/page/preview?isPreview=1&isSlp=1&asins=${products.map((item)=>item.asin)}`}
                          rel="noopener noreferrer"
                        >
                          Shop now
                        </a>
                      </>
                    ) : (
                      <>
                        <div className="headline-name">{basicInfo.headline}</div>
                        <a
                          className="shop-now"
                          href={`${basicInfo.storeUrl}`}
                          rel="noopener noreferrer"
                        >
                          Shop {basicInfo.brandName}
                        </a>
                      </>
                    )
                  )
                }
              </div>
            </div>
          </div>
        </div>
        {
          basicInfo.storeType === 'newpage' ? (
            <div className="preview-right d-flex">
              {
                creativeProducts.length <= 2 ? (
                  products.slice(0, 3).map(product =>
                    <div key={product.id} className="preview-item">
                      <img src={product.image} alt={product.name} className="product-image" />
                      <div className="product-info">
                        <div className="product-name">{product.name}</div>
                        <div className="product-detail">
                          <img src={PrimePng} alt={product.name} />
                        </div>
                      </div>
                    </div>
                  )
                ) : (
                  creativeProducts.slice(0,3).map(product =>
                    <div key={product.id} className="preview-item">
                      <img src={product.image} alt={product.name} className="product-image" />
                      <div className="product-info">
                        <div className="product-name">{product.name}</div>
                        <div className="product-detail">
                          <img src={PrimePng} alt={product.name} />
                        </div>
                      </div>
                    </div>
                  )
                )
              }
            </div>
          ) : (
            <div className="preview-right d-flex preview-min">
              {
                isSpotlight && (
                  creativeProducts.length <= 2 ? (
                    products.slice(0,3).map((product, index) =>
                      <div key={product.id} className="preview-item">
                        <img src={product.image} alt="" className="product-image" />
                        <div className="product-info">
                          <div className="product-name">{spotProductNames[index]}</div>

                        </div>
                      </div>
                    )
                  ) : (
                    creativeProducts.slice(0,3).map((product, index) =>
                    <div key={product.id} className="preview-item">
                      <img src={product.image} alt="" className="product-image" />
                      <div className="product-info">
                        <div className="product-name">{spotProductNames[index]}</div>
                      </div>
                    </div>
                    )
                  )
                )
              }
            </div>
          )
        }
      </div>
    </div>
  )
}

export default AdPreview
