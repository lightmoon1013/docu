import React, { useState } from 'react'
import { useStore } from 'react-redux'

import { toast } from '../CommonComponents/ToastComponent/toast'
import { ReactComponent as CloseSvg } from '../../assets/svg/close.svg'
import ProductModal from './ProductModal'

const ProductSection = ({ isForSB, isForSBV, products, basicInfo = {}, onChange }) => {
  const store = useStore()
  const {
    header: { selectedUserInfo }
  } = store.getState()
  const [openModal, setOpenModal] = useState(false)

  const handleRemove = (id) => {
    onChange(products.filter(product => product.id !== id))
  }

  const handleSelect = (products) => {
    setOpenModal(false)
    onChange(products)
  }

  const renderDescription = () => {
    if (isForSB) {
      switch (products.length) {
        case 1:
          return (
            <div className="no-product-desc">
              Add 2 more products.
            </div>
          )
        case 2:
          return (
            <div className="no-product-desc">
              Add 1 more product.
            </div>
          )
        default:
          return (
            <div className="no-product-desc">
              Add more products (optional).
              You may have more than three products on that page, but you must highlight three to appear in your ad.
            </div>
          )
      }
    }

    if (isForSBV) {
      return (
        <div className="no-product-desc">
          You have added the maximum number of products.
        </div>
      )
    }

    return null
  }

  const handleProductSelect = () => {
    if (isForSB || isForSBV) {
      if (selectedUserInfo.seller_type === 'seller') {
        if (Object.keys(basicInfo).length && basicInfo.brandEntityId !== '') {
          setOpenModal(true)
        } else {
          toast.show({
            title: 'Warning',
            description : 'Please select a brand name to add products.',
          })
          return
        }
      } else {
        setOpenModal(true)
      }
    } else {
      setOpenModal(true)
    }
  }

  const renderProducts = () => {
    if (!products.length) {
      return (
        <div className="no-product-desc">
          No product added.
        </div>
      )
    }

    return (
      <div className="product-container">
        {
          products.map((product) =>
            <div key={product.id} className="product-box">
              <CloseSvg title="Remove" onClick={() => { handleRemove(product.id) }}/>
              <img src={product.image} alt={product.name} />
              <div className="product-info">
                <div className="product-name">{product.name}</div>
                <div className="product-detail">
                  <span>Price: {product.price}</span>
                  <span>ASIN: {product.asin}</span>
                  <span>SKU: {product.sku}</span>
                </div>
              </div>
            </div>
          )
        }
        { renderDescription() }
      </div>
    )
  }

  return (
    <div className="section-container">
      <div className="section-title">
        Products
        <button
          type="button"
          className="btn btn-blue"
          onClick={() => { handleProductSelect() }}
        >
          Add Products
        </button>
      </div>
      <div className="section-note">
        Add products that you want to promote in this campaign.
      </div>
      { renderProducts() }
      <ProductModal
        show={openModal}
        productsSelected={products}
        onSelect={handleSelect}
        onClose={() => { setOpenModal(false) }}
      />
    </div>
  )
}

export default ProductSection
