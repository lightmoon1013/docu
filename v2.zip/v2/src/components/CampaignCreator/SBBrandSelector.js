import React, { useState } from 'react'
import { Tooltip, Whisper } from 'rsuite'

import SBBrandDataModal from './SBBrandDataModal'
import { ReactComponent as InfoSvg } from '../../assets/svg/info.svg'
const SBBrandSelector = ({ info, onChange }) => {
  const [openModal, setOpenModal] = useState(false)

  const handleSelect = (brandData) => {
    setOpenModal(false)
    onChange(brandData)
  }

  return (
    <div className="field-row">
      <div className="field-wrapper">
        <div className="field-name">
          Brand
          <Whisper placement="right" trigger="hover" speaker={(
            <Tooltip>
              <p>Choose a brand for management of your campaign.</p>
            </Tooltip>
          )}>
            <InfoSvg />
          </Whisper>
        </div>

        <button
          type="button"
          className="btn btn-blue"
          onClick={() => setOpenModal(true)}
        >
          Select Brand Name
        </button>
        {
          info.brandName !== '' &&
          (
            <div className="input-wrapper selected-brand-name">
              <span className="input-prefix">{info.brandName}</span>
            </div>
          )
        }
      </div>
      <div className="field-wrapper"></div>
      <SBBrandDataModal
        show={openModal}
        // productsSelected={products}
        onSelect={handleSelect}
        onClose={() => { setOpenModal(false) }}
      />
    </div>
  )
}

export default SBBrandSelector
