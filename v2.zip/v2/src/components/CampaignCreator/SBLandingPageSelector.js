import React from 'react'

import { Tooltip, Whisper } from 'rsuite'
import Select from 'react-select'

import { ReactComponent as InfoSvg } from '../../assets/svg/info.svg'

const storeTypeOptions =[
  {value: 'store', label: 'Store on Amazon'},
  {value: 'newpage', label: 'New landing page'}]

const SBLandingPageSelector = ({ campaignType, storeType, onStoreChange }) => (
  <>
    <div className="field-row">
      <div className="field-wrapper">
        <div className="field-name ">
          Landing page
          <Whisper placement="right" trigger="hover" speaker={(
            <Tooltip>
              <p>The landing page is where shoppers are directed after they interact with your ad.</p>
            </Tooltip>
          )}>
            <InfoSvg />
          </Whisper>
        </div>
        { campaignType === 'collection' && 
          (
            <Select
              classNamePrefix="portfolio-selector"
              options={storeTypeOptions}
              value={storeTypeOptions.filter(data => data.value === storeType)[0]}
              onChange={(option) => { onStoreChange(option.value) }}
            />
          )
        }
        { campaignType === 'video' &&
          <span> Product detail page</span>
        }
      </div>
      <div className="field-wrapper"></div>
    </div>
    
  </>
)

export default SBLandingPageSelector
