import React from 'react'
import { Modal } from 'rsuite'

const SBSpotProductSelectModal = ({ show, selectedPageProducts, onClose, onSelect }) => {

  const handleProduct = (product) => {
    onSelect(product)
  }

  const renderProductsList = () => {
    return (
      <div className="product-order-container">
        <div className="product-order-left-container">
          <div className="product-list">
            {
              selectedPageProducts.map((product) =>
                <div key={product.id} className="product-list-item product-order-img product-item-box d-flex">
                  <div className="d-flex">
                    <img src={product.image} alt={product.name} />
                    <div className="product-info">
                      <div className="product-name">{product.name}</div>
                      <div className="product-detail">
                        <span>Price: {product.price}</span>
                        <span>ASIN: {product.asin}</span>
                        <span>SKU: {product.sku}</span>
                      </div>
                    </div>
                  </div>
                  <div className="d-flex">
                    <button type="button" className="btn btn-blue" onClick={() => handleProduct(product)}>
                      Select
                    </button>
                  </div>
                </div>
              )
            }
          </div>
        </div>
      </div>
    )
  }

  return (
    <Modal className={`product-ordering-modal`} backdrop="static" show={show} size="lg">
      <Modal.Body>
        { renderProductsList() }
      </Modal.Body>
      <Modal.Footer>
        <button type="button" className="rs-btn rs-btn-subtle" onClick={() => onClose()}>
          Close
        </button>
      </Modal.Footer>
    </Modal>
  )
}
export default SBSpotProductSelectModal