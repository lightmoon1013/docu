import React, { useState, useEffect } from 'react'
import { useDispatch, useStore } from 'react-redux'
import { useHistory, useLocation } from 'react-router-dom'
import moment from 'moment'

import LoaderComponent from '../CommonComponents/LoaderComponent'
import { toast } from '../CommonComponents/ToastComponent/toast'

// components
import SBBasicInfo from './SBBasicInfo'
import SBCampaignTypeSelector from './SBCampaignTypeSelector'
import SBLandingPageSelector from './SBLandingPageSelector'
import SBBrandSelector from './SBBrandSelector'
import ProductSection from './ProductSection'
import SBCreativeSection from './SBCreativeSection'
import SBVCreativeSection from './SBVCreativeSection'
import SBSpotCreativeSection from './SBSpotCreativeSection'
import SBStoreSelection from './SBStoreSelection'

import ManualTargetingSelector from './ManualTargetingSelector'
import SBKeywordSection from './SBKeywordSection'
import SBNegativeKeywordSection from './SBNegativeKeywordSection'
import SBTargetingSection from './SBTargetingSection'
import NegativeTargetingSection from './NegativeTargetingSection'

import {
  getBrandLogos,
  getSBSuggestions,
  getSBSuggestedKeywordBids,
  createSBCampaign,
  getMediaStatus,
  createSBVCampaign,
  getStoreInfo,
} from '../../redux/actions/campaignCreator'
import { getAllCategories, getProductsBySearchText } from '../../redux/actions/targeting'

const campaignTypeList = [
  {
    value: 'collection',
    name: 'Product collection',
    description: 'Promote multiple products from a landing page of your choice.',
  },
  {
    value: 'spotlight',
    name: 'Store spotlight',
    description: 'Drive traffic to a Store, including subpages.',
  },
  {
    value: 'video',
    name: 'Video',
    description: 'Feature a single product with an autoplaying video.',
  },
]

const SBCampaignCreator = () => {
  const dispatch = useDispatch()
  const store = useStore()
  const history = useHistory()
  const location = useLocation()

  const { header, campaignCreator, portfolio } = store.getState()
  const { currentUserId, selectedUserInfo } = header
  const {
    isCreating,
    isStoreInfoLoading,
    isStorePageAsinsLoading,
    isUploadingVideo,
    isSBSuggestionsLoading,
    isLandingPageAsinsLoading,
    isSBSuggestedBidsLoading,
    suggestedSBBids,
    uploadedVideoData,
    uploadVideoStatus,
    landingPageProducts,
    storePageProducts,
    sbStoreInfo,
    sbNewBrandAssetId,
    isSBBrandLogoCreating,
  } = campaignCreator
  const { listPortfolios } = portfolio

  const [basicInfo, setBasicInfo] = useState({
    name: '',
    portfolio: '',
    dailyBudget: 10,
    budgetType: 'daily',
    startDate: new Date(),
    endDate: null,
    brandEntityId: '',
    brandName: '',
    headline: '',
    storeType: 'newpage',
    bidOptimization: true,
    bidMultiplier: 0,
    brandAssetId: '',
    brandLogoUrl: '',
    storeUrl: '',
  })

  const [campaignType, setCampaignType] = useState('collection')
  const [manualTarget, setManualTarget] = useState('keyword')

  const [storeType, setStoreType] = useState('newpage')
  const [bidType, setBidType] = useState('auto')
  const [bidDirect, setBidDirect] = useState('increase')
  const [products, setProducts] = useState([])
  const [keywords, setKeywords] = useState([])
  const [negativeKeywords, setNegativeKeywords] = useState([])
  const [targetings, setTargetings] = useState([])
  const [negativeTargetings, setNegativeTargetings] = useState([])
  const [creativeProducts, setCreativeProducts] = useState([])
  const [productPages, setProductPages] = useState([])
  const [spotProductNames, setSpotProductNames] = useState([])
  const [isNewLogo, setIsNewLogo] = useState(false)

  useEffect(() => {
    dispatch(getAllCategories())
  }, [currentUserId]) // eslint-disable-line

  useEffect(() => {
    if(isNewLogo) {
      handleBasicInfoChange('brandAssetId', sbNewBrandAssetId)
    }
  }, [sbNewBrandAssetId]) // eslint-disable-line

  useEffect(() => {
    if (isSBSuggestedBidsLoading || !suggestedSBBids || suggestedSBBids.length === 0) {
      return
    }
    setKeywords(keywords.map((keyword) => {
      const suggestedBid = suggestedSBBids.suggestedSBBids.filter(bid => (
        bid.keyword.keywordText === keyword.keywordText && bid.keyword.matchType === keyword.matchType
      ))
      if (suggestedBid.length) {
        return {
          ...keyword,
          suggestedBid: suggestedBid[0].recommendedBid,
        }
      }
      return keyword
    }))
  }, [suggestedSBBids, isSBSuggestedBidsLoading]) // eslint-disable-line

  useEffect(() => {
    if(!isUploadingVideo && uploadVideoStatus !== '' && uploadVideoStatus !== 'Available' && uploadVideoStatus !== 'Failed') {
      dispatch(getMediaStatus(uploadedVideoData.mediaId)).then(() => {
      }).catch((description) => {
        toast.show({
          title: 'Warning',
          description : description ,
        })
      })
    }
  }, [uploadVideoStatus]) // eslint-disable-line

  useEffect(() => {
    if (landingPageProducts.length >1 && campaignType === 'collection' && storeType ==='store') {
      handleProductsSelect(landingPageProducts, true)
    }
  }, [landingPageProducts]) // eslint-disable-line

  useEffect(() => {
    if (storePageProducts.length > 3 && campaignType === 'spotlight') {
      const initProducts = []
      const initProductPages = []
      const initProductNames = []
      storePageProducts.slice(0, 3).map((storePageProduct) => {
        initProducts.push(storePageProduct.products[0])
        initProductPages.push(storePageProduct.pageInfo)
        initProductNames.push(storePageProduct.pageInfo.storePageName)
        return null
      })
      setProductPages(initProductPages)
      setSpotProductNames(initProductNames)
      handleProductsSelect(initProducts, true)
      let homeData = sbStoreInfo[0].storePageInfo.filter(page => page.storePageName === 'Home')
      handleBasicInfoChange('storeUrl', homeData[0].storePageUrl)
    }
  }, [storePageProducts]) // eslint-disable-line

  useEffect(() => {
    if (location.state) {
      if (location.state.targets && location.state.targets.length) {
        setKeywords(location.state.targets.map((target, index) => ({
          id: index,
          keywordText: target,
          matchType: 'broad',
          keywordBid: 0,
        })))

        const keywordsToGetBid = location.state.targets.map(target => ({
          keyword: target,
          matchType: 'broad',
        }))

        dispatch(getSBSuggestedKeywordBids(keywordsToGetBid, campaignType))

        const asinTargets = location.state.targets
          .filter(target => /^[0-9a-z]{10}$/ig.test(target))

        if (asinTargets.length) {
          dispatch(getProductsBySearchText({
            asins: asinTargets.join(),
          }, true)).then((response) => {
            setTargetings(response.Item.map(product => ({
              ...product,
              name: product.name || product.ItemAttributes.Title,
              isTargeted: true,
              type: 'product',
              bid: 0,
            })))
          })
        }
      }

      if (location.state.categories && location.state.categories.length) {
        setTargetings(location.state.categories.map(category => ({
          ...category,
          type: 'category',
          bid: 0,
        })))
      }

      if (location.state.productTargeting) {
        setManualTarget('product')
      }
    }
  }, [location.state]) // eslint-disable-line

  const getProductTargets = () => {
    const targets = []
    targetings.forEach((targeting) => {
      const payload = {
        bid: targeting.bid,
        expressions: [],
      }
      switch (targeting.type) {
        case 'category':
          payload.expressions.push({
            type: 'asinCategorySameAs',
            value: targeting.id,
          })
          break
        case 'product':
          payload.expressions.push({
            type: 'asinSameAs',
            value: targeting.ASIN,
          })
          break
        case 'refine':
          payload.expressions.push({
            type: 'asinCategorySameAs',
            value: targeting.id,
          })

          if (targeting.brandId) {
            payload.expressions.push({
              type: 'asinBrandSameAs',
              value: targeting.brandId,
            })
          }

          if (targeting.ratingValue) {
            payload.expressions.push({
              type: 'asinReviewRatingBetween',
              value: targeting.ratingValue,
            })
          }

          if (targeting.priceFrom && targeting.priceTo) {
            payload.expressions.push({
              type: 'asinPriceBetween',
              value: `${targeting.priceFrom}-${targeting.priceTo}`,
            })
          } else if (targeting.priceFrom && !targeting.priceTo) {
            payload.expressions.push({
              type: 'asinPriceGreaterThan',
              value: targeting.priceFrom,
            })
          } else if (!targeting.priceFrom && targeting.priceTo) {
            payload.expressions.push({
              type: 'asinPriceLessThan',
              value: targeting.priceTo,
            })
          }
          break
        default:
          break
      }
      targets.push(payload)
    })
    return targets
  }

  const getNegativeProductTargets = () => {
    const negatives = []
    negativeTargetings.forEach(product => {
      const negativeProduct = {
        expressions: [],
      }
      if (product.type === 'brand') {
        negativeProduct.expressions.push({
          type: 'asinBrandSameAs',
          value: product.id,
        })
      } else if (product.type === 'product') {
        negativeProduct.expressions.push({
          type: 'asinSameAs',
          value: product.ASIN,
        })
      }
      negatives.push(negativeProduct)
    })
    return negatives
  }

  const getCreative = () => {
    if (campaignType === 'video') {
      return {
        videoMediaIds: [uploadedVideoData.mediaId],
        asins: creativeProducts.map(product => product.asin),
        type: 'video',
      }
    }

    if (campaignType === 'spotlight') {
      const subPageInfo = []
      creativeProducts.forEach((product, index) => {
        let sPageInfo = {}
        sPageInfo.asin = product.asin
        sPageInfo.pageTitle = spotProductNames[index]
        sPageInfo.url = productPages[index].storePageUrl
        subPageInfo.push(sPageInfo)
      })

      return {
        brandName: basicInfo.brandName,
        brandLogoAssetID: basicInfo.brandAssetId,
        headline: basicInfo.headline,
        subpages: subPageInfo
      }
    }

    const productAsins = []
    creativeProducts.forEach((product) => {
      productAsins.push(product.asin)
    })

    return {
      brandName: basicInfo.brandName,
      brandLogoAssetID: basicInfo.brandAssetId,
      headline: basicInfo.headline,
      asins: productAsins,
    }
  }

  const getLandingPage = () => {
    if((basicInfo.storeType === 'newpage' && campaignType === 'collection')) {
      const productAsins = []
      products.forEach((product) => {
        productAsins.push(product.asin)
      })
      return {asins: productAsins}
    } else if( campaignType==='spotlight') {
      return {url: basicInfo.storeUrl}
    } else {
      return {url: basicInfo.storeUrl}
    }
  }

  const handleBasicInfoChange = (name, value) => {
    const newInfo = Object.assign({}, basicInfo, {
      [name]: value,
    })
    setBasicInfo(newInfo)
  }

  const handleLandingPage = (value) => {
    setStoreType(value)
    handleBasicInfoChange('storeType', value)
    if(value === 'store') {
      dispatch(getStoreInfo())
    }
  }
  const handleBidTypeChange = (value) => {
    setBidType(value)
    if (bidType === 'auto') {
      handleBasicInfoChange('bidOptimization', true)
    } else {
      handleBasicInfoChange('bidOptimization', false)
    }
  }

  const handleSelectedPageUrl = (value) => {
    if (storeType === 'store' && campaignType === 'collection') {
      handleBasicInfoChange('storeUrl', value)
    }
  }

  const handleBidDirectChange = (value) => {
    setBidDirect(value)
  }

  const handleBidValueChange = (value) => {
    if(bidDirect === 'increase') {
      handleBasicInfoChange('bidMultiplier', value * 1)
    } else {
      handleBasicInfoChange('bidMultiplier', value * -1)
    }

  }
  const handleSpotProductsSelect = (products, productpages, productNames, reload = false) => {
    setProductPages(productpages)
    setSpotProductNames(productNames)
    handleProductsSelect(products, reload)
  }

  const handleOrderedProductsSelect = (orderedproducts, reload = false) => {
    if (storeType === 'store') {
      setCreativeProducts(orderedproducts.slice(0,3))
      if (reload && (orderedproducts.length >= 1)) {
        dispatch(getSBSuggestions(orderedproducts.map(product => product.asin)))
      }
    } else {
      handleProductsSelect(orderedproducts, reload)
    }
  }

  const handleProductsSelect = (products, reload = false) => {
    if (campaignType === 'collection') {
      if(storeType === 'newpage') {
        setProducts(products)
        setCreativeProducts(products.slice(0, 3))
        if (reload && (products.length >= 3)) {
          dispatch(getSBSuggestions(products.map(product => product.asin)))
        }
      } else {
        setProducts(products)
        setCreativeProducts(products.slice(0, 3))
        if (reload && (products.length >= 1)) {
          dispatch(getSBSuggestions(products.map(product => product.asin)))
        }
      }
    } else if (campaignType === 'video') {
      setProducts(products.slice(0, 1))
      setCreativeProducts(products.slice(0, 1))
      if (reload && (products.length > 0)) {
        dispatch(getSBSuggestions(products.map(product => product.asin)))
      }
    } else {
      setProducts(products.slice(0, 3))
      setCreativeProducts(products.slice(0, 3))
      if (reload && (products.length > 0)) {
        dispatch(getSBSuggestions(products.map(product => product.asin)))
      }
    }
  }

  const handleKeywordsSelect = (keywords, reload = false, newKeywords = []) => {
    setKeywords(keywords)
    if (!isSBSuggestedBidsLoading && !isSBSuggestionsLoading && reload && newKeywords.length) {
      dispatch(getSBSuggestedKeywordBids(newKeywords, campaignType))
    }
  }

  const handleBrandData = (branddata) => {
    setBasicInfo({
      ...basicInfo,
      brandEntityId: branddata.brandEntityId,
      brandName: branddata.brandRegistryName
    })
    dispatch(getBrandLogos(branddata.brandEntityId))
  }

  const handleBrandLogoData = (selectedLogo) => {
    setIsNewLogo(false)
    setBasicInfo({
      ...basicInfo,
      brandAssetId: selectedLogo.assetId,
      brandLogoUrl: selectedLogo.url
    })
  }

  const handleCampaignType = (campType) => {
    setCampaignType(campType)
    setProducts([])
    setIsNewLogo(false)
    handleBasicInfoChange('brandAssetId','')
    if (campType === 'spotlight') {
      if (selectedUserInfo.seller_type === 'seller' && basicInfo.brandEntityId === '') {
        toast.show({
          title: 'Warning',
          description : 'Please select a brand name to add products.',
        })
        return
      }
      dispatch(getStoreInfo())
    }
  }

  const renderManualSections = () => {
    return (
      <>
        <ManualTargetingSelector
          manualTarget={manualTarget}
          onChange={setManualTarget}
        />
        {
          manualTarget === 'keyword' && (
            <>
              <SBKeywordSection
                keywords={keywords}
                bidType={bidType}
                campaignType={campaignType}
                bidDirect={bidDirect}
                onChange={handleKeywordsSelect}
                onBidTypeChange={handleBidTypeChange}
                onBidDirectChange={handleBidDirectChange}
                onBidValueChange={handleBidValueChange}
              />
              <SBNegativeKeywordSection
                negativeKeywords={negativeKeywords}
                onChange={setNegativeKeywords}
              />
            </>
          )
        }
        {
          manualTarget === 'product' && (
            <>
              <SBTargetingSection
                targetings={targetings}
                dailyBudget={basicInfo.dailyBudget}
                onChange={setTargetings}
              />
              <NegativeTargetingSection
                negativeTargetings={negativeTargetings}
                onChange={setNegativeTargetings}
              />
            </>
          )
        }
      </>
    )
  }

  const handleIsNewLogo = (value) => {
    setIsNewLogo(value)
    if (value === false) {
      handleBasicInfoChange('brandAssetId', '')
    }
  }

  const handleSave = () => {
    if (!basicInfo.name) {
      toast.show({
        title: 'Warning',
        description: 'Please enter the campaign name.',
      })
      return
    }
    if (!basicInfo.headline && campaignType !== 'video') {
      toast.show({
        title: 'Warning',
        description: 'Please enter the creative headline.',
      })
      return
    }
    if (products.length <3 && campaignType !== 'video') {
      toast.show({
        title: 'Warning',
        description: 'Please select at least 3 products.',
      })
      return
    }
    if (products.length <1 && campaignType === 'video') {
      toast.show({
        title: 'Warning',
        description: 'Please select at least 1 products.',
      })
      return
    }
    if (!basicInfo.brandName) {
      toast.show({
        title: 'Warning',
        description: 'Please enter the campaign brandname.',
      })
      return
    }
    if (basicInfo.budgetType === 'lifetime' && basicInfo.endDate === null) {
      toast.show({
        title: 'Warning',
        description: 'Please enter the campaign end date.',
      })
      return
    }
    if ((basicInfo.brandAssetId === '') && campaignType !== 'video') {
      toast.show({
        title: 'Warning',
        description: 'Please enter the campaign brandlogo.',
      })
      return
    }
    if (basicInfo.dailyBudget < 1 && basicInfo.budgetType ==='daily' ) {
      toast.show({
        title: 'Warning',
        description: 'The daily budget range is from 1 to 1,000,000.',
      })
      return
    }
    if (basicInfo.dailyBudget < 100 && basicInfo.budgetType ==='lifetime' ) {
      toast.show({
        title: 'Warning',
        description: 'The lifetime budget range is from 100 to 20,000,000.',
      })
      return
    }
    if (basicInfo.brandEntityId === '') {
      toast.show({
        title: 'Warning',
        description: 'Please enter the campaign brandEntityId.',
      })
      return
    }
    if (uploadedVideoData.status === 'Failed' && campaignType === 'video') {
      toast.show({
        title: 'Warning',
        description: 'Invalid Video. Please upload another video.',
      })
      return
    }
    if (uploadedVideoData.status === undefined && campaignType === 'video') {
      toast.show({
        title: 'Warning',
        description: 'Please upload a video.',
      })
      return
    }
    if (manualTarget === 'keyword' && keywords.length < 1) {
      toast.show({
        title: 'Warning',
        description: 'Please enter at least 1 keyword.',
      })
      return
    }
    if (manualTarget === 'product' && targetings.length < 1) {
      toast.show({
        title: 'Warning',
        description: 'Please enter at least 1 product target.',
      })
      return
    }
    if (campaignType === 'spotlight') {
      if (spotProductNames[0].length >= 50 || spotProductNames[1].length >= 50 || spotProductNames[2].length >= 50)
      {
        toast.show({
          title: 'Warning',
          description: 'Product display name must be less than 50 characters maximum.',
        })
        return
      }
    }
    const newCampaign = {
      name: basicInfo.name,
      budget: basicInfo.dailyBudget * 1,
      budgetType: basicInfo.budgetType,
      startDate: moment(basicInfo.startDate).format('YYYYMMDD'),
      adFormat: campaignType === 'video' ? 'video' : 'productCollection',
      brandEntityId: basicInfo.brandEntityId,
      portfolioId: basicInfo.portfolio.portfolio_id * 1,
    }

    if (campaignType !== 'video') {
      newCampaign.bidOptimization = basicInfo.bidOptimization
      if (basicInfo.bidOptimization === false) {
        newCampaign.bidMultiplier = basicInfo.bidMultiplier * 1
      }
      newCampaign.creative = getCreative()
      newCampaign.landingPage = getLandingPage()
    } else {
      newCampaign.creative = getCreative()
    }

    if (basicInfo.endDate !== '' && basicInfo.startDate < basicInfo.endDate)  {
      newCampaign.endDate = moment(basicInfo.endDate).format('YYYYMMDD')
    }
    if (manualTarget === 'product') {
      newCampaign.targets = getProductTargets()
      newCampaign.negativeTargets = getNegativeProductTargets()
    } else {
      newCampaign.keywords = keywords.map(kw => ({
        keywordText: kw.keywordText !== '' ? kw.keywordText : kw.search,
        matchType: kw.matchType.toLowerCase(),
        bid: kw.keywordBid,
      }))
      newCampaign.negativeKeywords = negativeKeywords.map(kw => ({
        keywordText: kw.keywordText !== '' ? kw.keywordText : kw.search,
        matchType: kw.matchType,
      }))
    }
    if (campaignType !== 'video') {
      let param = {newCampaign: newCampaign, campaignType: campaignType}
      dispatch(createSBCampaign(param)).then(() => {
        toast.show({
          title: 'Success',
          description: 'The campaign has been successfully created! '
            + 'Your campaign will appear in Entourage as soon as we start collecting data.',
        })
        history.push('/dashboard')
      }).catch((description) => {
        toast.show({
          title: 'Danger',
          description,
        })
      })
    } else {
      dispatch(createSBVCampaign(newCampaign)).then(() => {
        toast.show({
          title: 'Success',
          description: 'The campaign has been successfully created! '
            + 'Your campaign will appear in Entourage as soon as we start collecting data.',
        })

        history.push('/dashboard')
      }).catch((description) => {
        toast.show({
          title: 'Danger',
          description,
        })
      })
    }


  }

  return (
    <div className={`sb-campaign-creator${isCreating ? ' loading' : ''}${isUploadingVideo ? ' loading' : ''}${isStoreInfoLoading ? ' loading' : ''}${isLandingPageAsinsLoading ? ' loading' : ''}${isStorePageAsinsLoading ? ' loading' : ''}${isSBBrandLogoCreating ? ' loading' : ''}`}>
      { isCreating && <LoaderComponent /> }
      { isUploadingVideo && <LoaderComponent /> }
      { isStoreInfoLoading && <LoaderComponent /> }
      { isLandingPageAsinsLoading && <LoaderComponent /> }
      { isStorePageAsinsLoading && <LoaderComponent /> }
      { isSBBrandLogoCreating && <LoaderComponent /> }
      <div className="page-header">
        <div className="page-title">Create Sponsored Brand Campaign</div>
        <button
          type="button"
          className="btn btn-red"
          onClick={handleSave}
        >
          Launch Campaign
        </button>
      </div>
      <div className="page-content">
        <SBBasicInfo
          info={basicInfo}
          portfolios={listPortfolios}
          onChange={handleBasicInfoChange}
        />
        <SBBrandSelector
          info={basicInfo}
          onChange={handleBrandData}
        />
        <SBCampaignTypeSelector
          campaignTypeList={campaignTypeList}
          campaignType={campaignType}
          onChange={handleCampaignType}
        />
        <SBLandingPageSelector
          campaignType={campaignType}
          storeType={storeType}
          onStoreChange={handleLandingPage}
        />
        {
          campaignType === 'collection' && storeType === 'store' && (
            <SBStoreSelection onSelectedPageUrl={handleSelectedPageUrl}/>
          )
        }
        {
          campaignType === 'spotlight' && (
            <SBStoreSelection isSpotlight />
          )
        }
        {
          campaignType === 'collection' && storeType === 'newpage' && (
            <ProductSection
              isForSB
              products={products}
              onChange={handleProductsSelect}
              basicInfo={basicInfo}
            />
          )
        }
        {
          campaignType === 'video' && (
            <ProductSection
              isForSBV
              products={products}
              onChange={handleProductsSelect}
              basicInfo={basicInfo}
            />
          )
        }
        {
          ((campaignType==='collection'
            && storeType==='newpage'
            && products.length >= 3)
            || (campaignType==='collection'
              && storeType==='store'
              && products.length >= 1)) && (
            <>
              <SBCreativeSection
                basicInfo = {basicInfo}
                products={products}
                creativeProducts={creativeProducts}
                onChange={handleBasicInfoChange}
                setOrderedProducts={handleOrderedProductsSelect}
                setSelectedBrandLogoData={handleBrandLogoData}
                setNewLogo={handleIsNewLogo}
              />
              {renderManualSections()}
            </>
          )
        }
        {
          (campaignType==='spotlight' && products.length >= 3) && (
            <>
              <SBSpotCreativeSection
                isSpotlight
                basicInfo = {basicInfo}
                products={products}
                productPages={productPages}
                spotProductNames={spotProductNames}
                creativeProducts={creativeProducts}
                storePageProducts={storePageProducts}
                onChange={handleBasicInfoChange}
                setOrderedProducts={handleSpotProductsSelect}
                setSelectedBrandLogoData={handleBrandLogoData}
                handleProductNames={setSpotProductNames}
                setNewLogo={handleIsNewLogo}
              />
              {renderManualSections()}
            </>
          )
        }
        {
          campaignType==='video' && products.length >= 1 && (
            <>
              <SBVCreativeSection
                basicInfo = {basicInfo}
                products={products}
                creativeProducts={creativeProducts}
                onChange={handleBasicInfoChange}
              />
              {renderManualSections()}
            </>
          )
        }
      </div>
      <div className="page-footer">
        <button
          type="button"
          className="btn btn-red"
          onClick={handleSave}
        >
          Launch Campaign
        </button>
      </div>
    </div>
  )
}

export default SBCampaignCreator
