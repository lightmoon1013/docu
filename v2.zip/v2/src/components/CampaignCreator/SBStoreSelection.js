import React, {useState, useEffect} from 'react'
import { useDispatch, useStore } from 'react-redux'

import Select from 'react-select'

import { getLandingPageAsin, getStoreAsins } from '../../redux/actions/campaignCreator'


const SBStoreSelection = ({ isSpotlight, onSelectedPageUrl }) => {
  const dispatch = useDispatch()
  const store = useStore()
  const { campaignCreator } = store.getState()
  const { sbStoreInfo } = campaignCreator

  const [storeList, setStoreList] = useState([])
  const [storePage, setStorePage] = useState([])
  const [storeUrl, setStoreUrl] = useState('')
  useEffect(() => {
    setStoreList(sbStoreInfo)
  }, [sbStoreInfo]) // eslint-disable-line
  const handleSelectedPage = (option) => {
    setStoreUrl(option.storePageUrl)
    onSelectedPageUrl(option.storePageUrl)
    dispatch(getLandingPageAsin(option.storePageUrl))
  }
  const handleSelectedStore = (option) => {
    setStorePage(option.storePageInfo)
    if(isSpotlight) {
      dispatch(getStoreAsins(option.storePageInfo))
    }
  }
  return (
    <>
      <div className="field-row">
        <div className="field-wrapper">
          <div className="field-name">
            Choose a Store
          </div>
          <Select
            classNamePrefix="portfolio-selector"
            options={storeList}
            getOptionValue={option => option.storeName}
            getOptionLabel={option => option.storeName}
            onChange={(option) => { handleSelectedStore(option) }}
          />
        </div>
        <div className="field-wrapper">
          {!isSpotlight && (
            <>
              <div className="field-name">
                Choose a page
              </div>
              <Select
                classNamePrefix="portfolio-selector"
                options={storePage}
                getOptionValue={option => option.storePageId}
                getOptionLabel={option => option.storePageName}
                // value={selectedStorePage}
                onChange={(option) => { handleSelectedPage(option) }}
              />
            </>
          )}
        </div>
        <div className="field-wrapper">
          {!isSpotlight && (
            <>
              <div className="field-name mb-30">
              </div>
              <a className="shop-now" href={`${storeUrl}`} rel="noopener noreferrer">See page</a>
            </>
          )}
        </div>
        <div className="field-wrapper"></div>
      </div>
    </>
  )
}

export default SBStoreSelection
