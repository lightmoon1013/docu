
import React from 'react'
import { Modal } from 'rsuite'

const SBSpotPageSelectModal = ({ show, storePageProducts, onSelect, onClose }) => {

  return (
    <Modal className={`branddata-modal`} backdrop="static" show={show} size="sm">
      <Modal.Body>
        <div className="brand-modal-body">
        { storePageProducts.length >0 && (<div className="brand-title"> Select Page</div>)}
        {
          storePageProducts.map((pageData) =>
            <div key={pageData.pageInfo.storePageId} className="brand-item-list">
                <div className="brand-info">
                  <div className="brand-name">{ pageData.pageInfo.storePageName}</div>
                </div>
                <button type="button" className="btn btn-blue" onClick={() => onSelect(pageData)}>
                  Select
                </button>
            </div>
          )
        }
        </div>
      </Modal.Body>
      <Modal.Footer>
        <button type="button" className="rs-btn rs-btn-subtle" onClick={() => onClose()}>
          Close
        </button>
      </Modal.Footer>
    </Modal>
  )
}

export default SBSpotPageSelectModal
