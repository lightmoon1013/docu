import React, { useState, useRef } from 'react'
import { useStore, useDispatch } from 'react-redux'
import CheckboxComponent from '../CommonComponents/CheckboxComponent'
import SBBrandDataModal from './SBBrandDataModal'

import { Tooltip, Whisper } from 'rsuite'
import { toast } from '../CommonComponents/ToastComponent/toast'
import { Radio, RadioGroup } from 'rsuite'
import { ReactComponent as InfoSvg } from '../../assets/svg/info.svg'

import 'react-image-crop/dist/ReactCrop.css'
import CropImageModal from './CropImageModal'

import { createSDCreativeAsset, createSDCreativeCustomAsset } from '../../redux/actions/campaignCreator'

const SDCreativeSection = ({ products, onHandleCroppingRect, onChange }) => {
  const inputRef = useRef()
  const dispatch = useDispatch()
  const store = useStore()
  const { header } = store.getState()
  const { selectedUserInfo } = header


  const [isCreativeActive, setIsCreativeActive] = useState(false)
  const [imageType, setImageType] = useState('logoImage')
  const [headline, setHeadline] = useState('')
  const [isWarning, setIsWarning] = useState(false)
  const [openBrandModal, setOpenBrandModal] = useState(false)
  const [openCropModal, setOpenCropModal] = useState(false)

  const [brandName, setBrandName] = useState('')
  const [brandEntityId, setBrandEntityId] = useState('')

  const [src, setSrc] = useState(null)
  const [output, setOutput] = useState(null)
  const [logoCrop, setLogoCrop] = useState(null)
  const [logoImage, setLogoImage] = useState(null)

  const [customSrc, setCustomSrc] = useState(null)
  const [customOutput, setCustomOutput] = useState(null)
  const [customCropOutput, setCustomCropOutput] = useState(null)
  const [customImage, setCustomImage] = useState(null)

  const [customLogoCrop, setCustomLogoCrop] = useState(null)
  const [customSquareCrop, setCustomSquareCrop] = useState(null)

  const [cropSrc, setCropSrc] = useState(null)
  const [cropType, setCropType] = useState('logoImage')
  const [cropRect, setCropRect] = useState(null)
  const [cropImage, setCropImage] = useState(null)

  const handleHeadline = (value) => {
    if (value.length > 50) {
      setIsWarning(true)
    } else {
      setIsWarning(false)
      setHeadline(value)
      onChange('headline', value)

    }
  }

  const handleBrandSelect = (brandData) => {
    setBrandName(brandData.brandRegistryName)
    setBrandEntityId(brandData.brandEntityId)
    setOpenBrandModal(false)
  }

  const renderBrandField = () => {
    if (selectedUserInfo.seller_type === 'sellers') {
      return (
          <div className="field-wrapper">
            <div className="field-name">
              Brand
              <Whisper placement="right" trigger="hover" speaker={(
                <Tooltip>
                  <p>BrandEntityId is requred for sellers.</p>
                </Tooltip>
              )}>
                <InfoSvg />
              </Whisper>
            </div>

            <div className="d-flex">
              <div className="d-flex">
                <button type="button" className="btn btn-blue margin-auto" onClick={() => setOpenBrandModal(true)}>
                  Select brand
                </button>
                <div className="input-wrapper selected-brand-name">
                  <span className="input-prefix">{brandName}</span>
                </div>
              </div>
            </div>
          </div>
      )
    }
  }

  const handleCroppedImage = (croppedImage, croppingCoordinates, cropTypes, image) => {
    if (cropTypes === 'logoImage') {
      setOutput(croppedImage)
      setLogoCrop(croppingCoordinates)
      setLogoImage(image)
      onHandleCroppingRect(croppingCoordinates, null)
    } else if (cropTypes === 'customImage1') {
      setCustomOutput(croppedImage)
      setCustomLogoCrop(croppingCoordinates)
      onHandleCroppingRect(croppingCoordinates, customSquareCrop)
      setCustomImage(image)
    } else if (cropTypes === 'customImage2') {
      setCustomSquareCrop(croppingCoordinates)
      setCustomCropOutput(croppedImage)
      onHandleCroppingRect(customLogoCrop, croppingCoordinates)
    }
    setOpenCropModal(false)

  }

  const handleUploadLogoFile = (e) => {
    if (e.target.files && e.target.files.length > 0) {
      if ((e.target.files[0].size > 1048576) && (imageType === 'logoImage')) {
        toast.show({
          title: 'Warning',
          description: 'File size must be smaller than 1MB',
        })
        return
      }
      if ((e.target.files[0].size > 5242880) && (imageType === 'customImage')) {
        toast.show({
          title: 'Warning',
          description: 'File size must be smaller than 5MB',
        })
        return
      }
      let rawFile = e.target.files[0]
      if ((e.target.files[0].type === 'image/jpeg') || (e.target.files[0].type === 'image/png')) {

        let uploadFileName = e.target.files[0].name
        let uploadFileType = e.target.files[0].type
        const reader = new FileReader();
        reader.addEventListener('load', () => {

          let img = document.createElement('img')
          img.addEventListener('load', () => {
            if ((img.width < 600 || img.height < 100) && (imageType === 'logoImage')) {
              toast.show({
                title: 'Warning',
                description: 'Dimensions must be at least 600 x 100 px',
              })
              return
            }
            if ((img.width < 1200 || img.height < 628) && (imageType === 'customImage')) {
              toast.show({
                title: 'Warning',
                description: 'Dimensions must be at least 1200 x 628 px',
              })
              return
            }
            if (imageType === 'logoImage') {
              setSrc(URL.createObjectURL(rawFile))
              setLogoCrop(null)
              setOutput(URL.createObjectURL(rawFile))
              onHandleCroppingRect(null, null)
            } else {
              setCustomSrc(URL.createObjectURL(rawFile))
              setCustomOutput(URL.createObjectURL(rawFile))
              setCustomCropOutput(URL.createObjectURL(rawFile))
              setCustomLogoCrop(null)
              setCustomSquareCrop(null)
              onHandleCroppingRect(null, null)
            }

            let params = {
              fileName: uploadFileName,
              base64: reader.result,
              brandEntityId: brandEntityId,
              fileType: uploadFileType,
              imageType: imageType
            }
            if (imageType === 'logoImage') {
              dispatch(createSDCreativeAsset(params)).then(() => {
              }).catch((description) => {
                toast.show({
                  title: 'Danger',
                  description,
                })
                setOutput(null)
                return
              })
            } else {
              dispatch(createSDCreativeCustomAsset(params)).then(() => {
              }).catch((description) => {
                toast.show({
                  title: 'Danger',
                  description,
                })
                return
              })
            }
          })
          img.src = reader.result
        });
        reader.readAsDataURL(e.target.files[0]);
      } else {
        toast.show({
          title: 'Warning',
          description: 'File format must be PNG or JPEG',
        })
        return
      }
    }
  }

  const handleChange = (checked) => {
    setIsCreativeActive(checked)
    onChange('isCreative', checked)
  }

  const handleImageType = (value) => {
    setImageType(value)
    onChange('creativeType', value)
  }

  const handleOpenLogoCropModal = () => {
    if (!src) {
      toast.show({
        title: 'Warning',
        description: 'Add a logo image first.',
      })
      return
    } else {
      setCropSrc(src)
      setCropType('logoImage')
      setCropRect(logoCrop)
      setCropImage(logoImage)
      setOpenCropModal(true)
    }
  }

  const handleOpenCustomCropModal = () => {
    if (customSrc) {
      setCropSrc(customSrc)
      setCropType('customImage1')
      setCropRect(customLogoCrop)
      setCropImage(customImage)
      setOpenCropModal(true)
    } else {
      toast.show({
        title: 'Warning',
        description: 'Add a custom image first.',
      })
      return
    }
  }

  const handleOpenCustomSquareCropModal = () => {
    if (customSrc) {
      setCropSrc(customSrc)
      setCropType('customImage2')
      setCropRect(customSquareCrop)
      setCropImage(customImage)
      setOpenCropModal(true)
    } else {
      toast.show({
        title: 'Warning',
        description: 'Add a custom image first.',
      })
    }
  }

  return (
    <div className="section-container">
      <div className="section-title">
        Creative
      </div>
      <div className="field-row">
        <div className="sd-field-fixed-left mr-48">
          <div className="section-title">
            <div className="d-flex mt-10">
              <div className="mr-10" >
                <CheckboxComponent
                  label="Customize your creative"
                  checked={isCreativeActive}
                  onChange={(checked) => { handleChange(checked) }}
                />
              </div>
              <Whisper placement="right" trigger="hover" speaker={(
                <Tooltip>
                  <p>Creative can be customised if your campaign advertises 100 or fewer products.</p>
                </Tooltip>
              )}>
                <InfoSvg />
              </Whisper>
            </div>

          </div>
          <div className={`${!isCreativeActive ? ' disabledDiv' : ''}`}>
            <RadioGroup
              value={imageType}
              onChange={handleImageType}
            >
              <Radio value="logoImage">Add a logo and headline
                <div className="section-note">
                  Help shoppers identify you as the advertiser.
                </div>
              </Radio>
              {imageType === 'logoImage' && (
                <div className="brand-logo-box">
                  <div className="field-row">
                    <div className="field-wrapper ">
                      <div className="field-name">
                        Brand logo
                        <Whisper placement="right" trigger="hover" speaker={(
                          <Tooltip>
                            <p>Logo requirements</p>
                            <p>- Dimensions are at least 600 x 100 px</p>
                            <p>- File size is smaller than 1MB</p>
                            <p>- File format is PNG or JPEG</p>
                          </Tooltip>
                        )}>
                          <InfoSvg />
                        </Whisper>
                      </div>

                      <div className="">
                        <div className="brand-item-logo">
                          <img src={src} alt=''/>
                        </div>
                        <div className="">

                          <button type="button" className="btn btn-blue " onClick={() => inputRef.current.click()}>
                            Add logo
                          </button>
                          <input ref={inputRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={handleUploadLogoFile} />
                          <button type="button" className="btn btn-blue mt-10" onClick={() => handleOpenLogoCropModal()}>
                            Crop logo
                          </button>
                        </div>
                      </div>
                    </div>
                    <div className="field-wrapper ">
                      <div className="field-name">
                        Headline
                        <Whisper placement="right" trigger="hover" speaker={(
                          <Tooltip>
                            <p>Tips to help get your headline approved</p>
                            <p>- Check for typos, misspellings and grammar mistakes</p>
                            <p>- Avoid excessive punctuation such as ‘!!!’ or ‘?!’</p>
                            <p>- Avoid random punctuation such as ‘Your. headline’.</p>
                            <p>- Avoid extra spacing such as ‘Y o u r h e a d l i n e’.</p>
                            <p>- Sentence case is recommended</p>
                          </Tooltip>
                        )}>
                          <InfoSvg />
                        </Whisper>
                      </div>
                      <div className="d-flex">
                        <div className="input-wrapper">
                          <input
                            type="text"
                            value={headline}
                            onChange={(event) => {handleHeadline(event.target.value)}}
                          />
                          {isWarning && (
                            <div className="headline-warning">
                              Maximum length of headline is 50 characters.
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="field-row">
                    {renderBrandField()}
                  </div>
                </div>
              )}
              {/* <Radio value="customImages">Add a custom image
                <div className="section-note">
                  Show your products in context.
                </div>
              </Radio> */}
              {imageType === 'customImage' && (
                <div className="brand-logo-box">
                  <div className="field-row">
                    <div className="field-wrapper ">
                      <div className="field-name">
                        Custom Image
                        <Whisper placement="right" trigger="hover" speaker={(
                          <Tooltip>
                            <p>Image requirements</p>
                            <p>- Image size: 1200 x 628 px or larger</p>
                            <p>- File size: 5MB or smaller</p>
                            <p>- File format: PNG, JPEG, or GIF</p>
                            <p>- Content: No text, graphics, or logo added to the image</p>
                          </Tooltip>
                        )}>
                          <InfoSvg />
                        </Whisper>
                      </div>

                      <div className="">
                        <div className="brand-item-logo">
                          <img src={customSrc} alt=''/>
                        </div>
                        <div className="">
                          <button type="button" className="btn btn-blue " onClick={() => inputRef.current.click()}>
                            Add Image
                          </button>
                          <input ref={inputRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={handleUploadLogoFile} />
                          <button type="button" className="btn btn-blue mt-10" onClick={() => handleOpenCustomCropModal()}>
                            Crop Image
                          </button>
                        </div>
                      </div>
                    </div>
                    <div className="field-wrapper">
                      <div className="field-name">
                        Crop Image
                        <Whisper placement="right" trigger="hover" speaker={(
                          <Tooltip>
                            <p>Your image can show in many ad placements, but it might be too wide for some of them. In case it's too wide, select the part of the image you want to show.</p>
                          </Tooltip>
                        )}>
                          <InfoSvg />
                        </Whisper>
                      </div>

                      <div className="">
                        <div className="brand-item-logo">
                          <img src={customCropOutput} alt=''/>
                        </div>
                        <div className="">
                          <button type="button" className="btn btn-blue mt-10" onClick={() => handleOpenCustomSquareCropModal()}>
                            Crop Image
                          </button>
                        </div>
                      </div>
                    </div>

                    {renderBrandField()}
                  </div>
                </div>
              )}
            </RadioGroup>
          </div>
        </div>
        <div className="sd-field-fixed-right ">
          <div className="field-name mt-10">
            <div className="mr-10 float-left">
              Ad preview
            </div>
            <Whisper placement="right" trigger="hover" speaker={(
              <Tooltip>
                <p>Your ad may look slightly different than what you see in this preview as we continually test both new and existing features to determine which characteristics drive ad performance.</p>
              </Tooltip>
            )}>
              <InfoSvg />
            </Whisper>
          </div>

          <div className="sd-preview-container">
            <div className="sd-product-middle">
              {
                (isCreativeActive && imageType === 'logoImage') && (
                  <div className="sd-preview-left">
                    <div className="preview-left-item canvas-border">
                      {output &&
                        <img src = {output} alt='' />
                      }
                    </div>
                    <div className="text-center">{headline}</div>
                  </div>
                )
              }
              {
                (isCreativeActive && imageType === 'customImage') && (
                  <div className="sd-preview-left">
                    <div className="preview-left-item canvas-border">
                      {customOutput &&
                        <img src = {customOutput} alt='' />
                      }
                    </div>
                  </div>
                )
              }
              {
                isCreativeActive ? (
                  <div className="sd-preview-right">
                    {
                      products.slice(0,1).map((product) =>
                        <div key={product.id} className="product-preview-item">
                          {
                            imageType === 'logoImage' && (
                            <div className="product-image" >
                              <img src={product.image} alt="" className="" />

                            </div>
                            )
                          }
                          <div className="product-info">
                            <div className="product-name">{product.name.substr(1,100)}</div>
                            <div className="product-name">Asin: {product.asin}</div>
                            <div className="product-name">Price: ${product.price}</div>
                          </div>
                        </div>
                      )
                    }
                  </div>
                ) : (
                  <div className="sd-preview-right">
                    {
                      products.slice(0,1).map((product) =>
                        <div key={product.id} className="product-preview-item">
                          <div className="product-image" >
                            <img src={product.image} alt="" className="" />

                          </div>
                          <div className="product-info">
                            <div className="product-name">{product.name.substr(1,100)}</div>
                            <div className="product-name">Asin: {product.asin}</div>
                            <div className="product-name">Price: ${product.price}</div>
                          </div>
                        </div>
                      )
                    }
                  </div>
                )
              }

            </div>
          </div>
        </div>
      </div>
      <SBBrandDataModal
        show={openBrandModal}
        onSelect={handleBrandSelect}
        onClose={() => { setOpenBrandModal(false) }}
      />
      <CropImageModal
        show={openCropModal}
        ImageSrc={cropSrc}
        cropType={cropType}
        cropRect={cropRect}
        cropImage={cropImage}
        onSelect={handleCroppedImage}

        onClose={() => { setOpenCropModal(false) }}
      />
    </div>
  )
}

export default SDCreativeSection
