import React from 'react'
import { DatePicker, Tooltip, Whisper } from 'rsuite'
import Select from 'react-select'
import moment from 'moment'

import { ReactComponent as InfoSvg } from '../../assets/svg/info.svg'

const budgetType = [
  { value: 'daily', label: 'Daily' },
  { value: 'lifetime', label: 'Lifetime' },
]

const SBBasicInfo = ({ info, portfolios = [], onChange }) => (
  <>
    <div className="field-row">
      <div className="field-wrapper">
        <div className="field-name">
          Name
          <Whisper placement="right" trigger="hover" speaker={(
            <Tooltip>
              <p>A campaign name is only visible to you, so choose a name
              that you can easily identify and refer back to later.</p>
            </Tooltip>
          )}>
            <InfoSvg />
          </Whisper>
        </div>
        <input
          type="text"
          value={info.name}
          onChange={(event) => { onChange('name', event.target.value) }}
        />
      </div>
      <div className="field-wrapper">
        <div className="field-name">
          Portfolio
          <Whisper placement="right" trigger="hover" speaker={(
            <Tooltip>
              <p>We recommend selecting a portfolio that best aligns with your marketing needs.</p>
            </Tooltip>
          )}>
            <InfoSvg />
          </Whisper>
        </div>
        <Select
          classNamePrefix="portfolio-selector"
          options={portfolios}
          getOptionValue={option => option.portfolio_id}
          getOptionLabel={option => option.name}
          value={info.portfolio}
          onChange={(option) => { onChange('portfolio', option) }}
        />
      </div>
    </div>
    <div className="field-row">
      <div className="field-wrapper">
        <div className="field-name">
          Budget
          <Whisper placement="right" trigger="hover" speaker={(
            <Tooltip>
              <p>Your budget determines how much you will spend on this campaign. You can edit your campaign to change your budget anytime.</p>
              <p><b>Daily:</b> the amount that you are willing to spend on this campaign each day. If the campaign spends less than your daily budget, the leftover amount can be used to increase your daily budget up to 25% on other days of the calendar month.</p>
              <p><b>Lifetime:</b> The total amount that you are willing to spend on this campaign.</p>
            </Tooltip>
          )}>
            <InfoSvg />
          </Whisper>
        </div>
        <div className="d-flex">
          <div className="input-wrapper maxwidth-125">
            <input
              type="number"
              value={info.dailyBudget}
              onChange={(event) => { onChange('dailyBudget', event.target.value) }}
            />
          </div>
          <div className="input-wrapper minwidth-125">
            <Select
              classNamePrefix="match-select"
              options={budgetType}
              value={budgetType.filter(data => data.value === info.budgetType)[0]}
              onChange={(option) => { onChange('budgetType', option.value) }}
            />
          </div>
        </div>
      </div>
      <div className="field-wrapper"></div>
      <div className="field-wrapper">
        <div className="field-name">
          Start Date
          <Whisper placement="right" trigger="hover" speaker={(
            <Tooltip>
              <p>This is the date your campaign will start.</p>
              <p>You can set a future start date to launch your ad campaign at a later date.</p>
            </Tooltip>
          )}>
            <InfoSvg />
          </Whisper>
        </div>
        <DatePicker
          value={info.startDate}
          format="MMM D, YYYY"
          oneTap
          disabledDate={date => moment(date).isBefore(moment().startOf('day')) }
          onChange={(date) => { onChange('startDate', date) }}
        />
      </div>
      <div className="field-wrapper">
        <div className="field-name">
          End Date
          <Whisper placement="left" trigger="hover" speaker={(
            <Tooltip>
              <p>This is the date your campaign will end.</p>
              <p>To ensure your ads are always active so you don't miss impressions or clicks,
              choose "No end date." </p>
              <p>You can extend, shorten, or end your campaign at any time while it's running.</p>
            </Tooltip>
          )}>
            <InfoSvg />
          </Whisper>
        </div>
        <DatePicker
          value={info.endDate}
          format="MMM D, YYYY"
          placeholder="No end date"
          oneTap
          disabledDate={date => moment(date).isBefore(moment(info.startDate)) }
          onChange={(date) => { onChange('endDate', date) }}
        />
      </div>
    </div>
  </>
)

export default SBBasicInfo
