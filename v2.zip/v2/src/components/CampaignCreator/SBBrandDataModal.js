import React, { useEffect } from 'react'
import { useDispatch, useStore } from 'react-redux'
import { Modal } from 'rsuite'

import { getBrandsData } from '../../redux/actions/campaignCreator'

import LoaderComponent from '../CommonComponents/LoaderComponent'



const SBBrandDataModal = ({ show, onSelect, onClose }) => {
  const dispatch = useDispatch()
  const store = useStore()

  const { campaignCreator } = store.getState()
  const { sbBrandData, isSBBrandDataLoading } = campaignCreator

  useEffect(() => {
    if (show && !isSBBrandDataLoading) {
      dispatch(getBrandsData())
    }
  }, [show]) // eslint-disable-line

  return (
    <Modal className={`branddata-modal${isSBBrandDataLoading ? ' loading' : ''}`} backdrop="static" show={show} size="sm">
      <Modal.Body>
        <div className="brand-modal-body">
        { isSBBrandDataLoading && <LoaderComponent /> }
        { sbBrandData.length >0 && (<div className="brand-title"> Select Brand Name</div>)}
        {
          sbBrandData.map((brandData) =>
            <div key={brandData.brandId} className="brand-item-list">
                <div className="brand-info">
                  <div className="brand-name">{ brandData.brandRegistryName}</div>
                </div>
                <button type="button" className="btn btn-blue" onClick={() => onSelect(brandData)}>
                  Select
                </button>
            </div>
          )
        }
        </div>
      </Modal.Body>
      <Modal.Footer>
        <button type="button" className="rs-btn rs-btn-primary" >
          Confirm
        </button>
        <button type="button" className="rs-btn rs-btn-subtle" onClick={() => onClose()}>
          Close
        </button>
      </Modal.Footer>
    </Modal>
  )
}

export default SBBrandDataModal
