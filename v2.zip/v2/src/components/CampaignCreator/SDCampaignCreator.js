import React, { useState, useEffect } from 'react'
import { useDispatch, useStore } from 'react-redux'
import { useHistory, useLocation } from 'react-router-dom'
import moment from 'moment'

import LoaderComponent from '../CommonComponents/LoaderComponent'
import { toast } from '../CommonComponents/ToastComponent/toast'

import BasicInfo from './BasicInfo'
import TargetingTypeSelector from './TargetingTypeSelector'
import SDBidSection from './SDBidSection'
import AdgroupInfo from './AdgroupInfo'
import ProductSection from './ProductSection'
import SDTargetingSection from './SDTargetingSection'
import AudienceSection from './AudienceSection'
import SDCreativeSection from './SDCreativeSection'

import { createSDCampaign, getSDSuggestions } from '../../redux/actions/campaignCreator'
import { getAllCategories, getProductsBySearchText  } from '../../redux/actions/targeting'

const targetList = [
  {
    value: 'T00020',
    name: 'Product targeting',
    description: 'Choose specific products or categories to target your ads.',
  },
  {
    value: 'T00030',
    name: 'Audiences targeting',
    description: 'Choose which audiences you want to see your ads.',
  },
]

const bidOpList = [
  {
    value: 'clicks',
    label: 'Optimize for page visits',
    description: 'We\'ll optimize your bids for higher click-through rates. '
      + 'Drive product consideration by showing your ads to shoppers more likely to click on your ad.',
  },
  {
    value: 'conversions',
    label: 'Optimize for conversions',
    description: 'We\'ll optimize your bids for higher conversion rates. '
      + 'Drive sales by showing your ad to shoppers more likely to purchase your product.',
  },
  {
    value: 'reach',
    label: 'Optimize for reach',
    description: 'We\'ll optimize your bids for higher viewable impressions. '
      + 'Drive product awareness by showing your ad to relevant audiences on and off Amazon to maximize reach.',
  },
]

const SDCampaignCreator = () => {
  const dispatch = useDispatch()
  const store = useStore()
  const history = useHistory()
  const location = useLocation()

  const { header, campaignCreator, portfolio } = store.getState()
  const { currentUserId } = header
  const { isCreating, isUploadingSDImage, uploadSDImageData, uploadSDCustomImageData, isSDSuggestionsLoading, isSDSuggestedBidLoading } = campaignCreator
  const { listPortfolios } = portfolio

  const [basicInfo, setBasicInfo] = useState({
    name: '',
    dailyBudget: 10,
    acos: 25,
    startDate: new Date(),
    endDate: null,
    headline: '',
    isCreative: false,
    creativeType: 'logoImage',
    portfolio: ''
  })

  const [bidInfo, setBidInfo] = useState({
    bidOp: bidOpList[0],
    defaultBid: 0.45,
  })

  const [adgroupName, setAdgroupName] = useState('Ad group 1')
  const [target, setTarget] = useState('T00020')

  const [products, setProducts] = useState([])
  const [targetings, setTargetings] = useState([])
  const [croppingRect, setCroppingRect] = useState(null)
  const [customCroppingRect, setCustomCroppingRect] = useState(null)
  const [customSquareCroppingRect, setCustomSquareCroppingRect] = useState(null)

  useEffect(() => {
    dispatch(getAllCategories())
  }, [currentUserId]) // eslint-disable-line

  useEffect(() => {
    if (location.state) {
      if (location.state.targets && location.state.targets.length) {
        const asinTargets = location.state.targets
          .filter(target => /^[0-9a-z]{10}$/ig.test(target))

        if (asinTargets.length) {
          dispatch(getProductsBySearchText({
            asins: asinTargets.join(),
          }, true)).then((response) => {
            setTargetings(response.Item.map(product => ({
              ...product,
              name: product.name || product.ItemAttributes.Title,
              isTargeted: true,
              type: 'product',
              suggestedBid: null,
              bid: 0,
            })))
          })
        }
      }

      if (location.state.categories && location.state.categories.length) {
        setTargetings(location.state.categories.map(category => ({
          ...category,
          type: 'category',
          bid: 0,
        })))
      }
    }
  }, [location.state]) // eslint-disable-line

  const parseTargetings = () => {
    const targets = []
    targetings.forEach((targeting) => {
      const payload = {
        bid: targeting.bid,
        expression: [],
      }
      switch (targeting.type) {
        case 'category':
          payload.expression.push({
            type: 'asinCategorySameAs',
            value: targeting.id.toString(),
          })
          break
        case 'product':
          payload.expression.push({
            type: 'asinSameAs',
            value: targeting.ASIN,
          })
          break
        case 'refine':
          payload.expression.push({
            type: 'asinCategorySameAs',
            value: targeting.id.toString(),
          })

          if (targeting.brandId) {
            payload.expression.push({
              type: 'asinBrandSameAs',
              value: targeting.brandId.toString(),
            })
          }

          if (targeting.ratingValue) {
            payload.expression.push({
              type: 'asinReviewRatingBetween',
              value: targeting.ratingValue,
            })
          }

          if (targeting.priceFrom && targeting.priceTo) {
            payload.expression.push({
              type: 'asinPriceBetween',
              value: `${targeting.priceFrom}-${targeting.priceTo}`,
            })
          } else if (targeting.priceFrom && !targeting.priceTo) {
            payload.expression.push({
              type: 'asinPriceGreaterThan',
              value: targeting.priceFrom,
            })
          } else if (!targeting.priceFrom && targeting.priceTo) {
            payload.expression.push({
              type: 'asinPriceLessThan',
              value: targeting.priceTo,
            })
          }
          break
        case 'audience_category':
          payload.expression.push({
            type: targeting.audienceType ? targeting.audienceType : 'views',
            value: [
              {
                type: 'asinCategorySameAs',
                value: targeting.id.toString().replace(targeting.audienceType, ''),
              },
              {
                type: 'lookback',
                value: targeting.lookback ? targeting.lookback.value : '30',
              },
            ],

          })
          break
        case 'audience_product':
          payload.expression.push({
            type: targeting.audienceType ? targeting.audienceType : 'views',
            value: [
              {
                type: targeting.id.replace(targeting.audienceType, ''),
              },
              {
                type: 'lookback',
                value: targeting.lookback ? targeting.lookback.value : '30',
              },
            ],
          })
          break
        case 'audience_refine':
          const values = []
          values.push({
            type: 'asinCategorySameAs',
            value: targeting.id.toString().replace(targeting.audienceType, ''),
          })

          if (targeting.brandId) {
            values.push({
              type: 'asinBrandSameAs',
              value: targeting.brandId.toString(),
            })
          }

          if (targeting.ratingValue) {
            values.push({
              type: 'asinReviewRatingBetween',
              value: targeting.ratingValue,
            })
          }

          if (targeting.priceFrom && targeting.priceTo) {
            values.push({
              type: 'asinPriceBetween',
              value: `${targeting.priceFrom}-${targeting.priceTo}`,
            })
          } else if (targeting.priceFrom && !targeting.priceTo) {
            values.push({
              type: 'asinPriceGreaterThan',
              value: targeting.priceFrom,
            })
          } else if (!targeting.priceFrom && targeting.priceTo) {
            values.push({
              type: 'asinPriceLessThan',
              value: targeting.priceTo,
            })
          }
          values.push({
            type: 'lookback',
            value: targeting.lookback ? targeting.lookback.value : '30',
          })
          payload.expression.push({
            type: targeting.audienceType ? targeting.audienceType : 'views',
            value: values,
          })
          break
        case 'audience':
          payload.expression.push({
            type: 'audience',
            value: [
              {
                type: 'audienceSameAs',
                value: targeting.id.toString(),
              },
            ],
          })
          break
        default:
          break
      }
      if ((target === 'T00020' && ['category', 'refine', 'product'].indexOf(targeting.type) !== -1)
        || (target === 'T00030'
          && ['audience_category', 'audience_refine', 'audience_product', 'audience'].indexOf(targeting.type) !== -1)) {
        targets.push(payload)
      }
    })
    return targets
  }

  const handleBasicInfoChange = (name, value) => {
    const newInfo = Object.assign({}, basicInfo, {
      [name]: value,
    })
    setBasicInfo(newInfo)
  }

  const handleBidChange = (name, value) => {
    const newInfo = Object.assign({}, bidInfo, {
      [name]: value,
    })
    if (value === 'reach') {
      handleBasicInfoChange('portfolio', '')
    }
    setBidInfo(newInfo)
  }

  const handleProductsSelect = (products, reload = false) => {
    setProducts(products)

    if (reload && products.length && !isSDSuggestionsLoading) {
      // dispatch(getProductsMetaData(products.map(product => product.asin)))
      dispatch(getSDSuggestions(target, products.map(product => product.asin)))
    }
  }

  const handleCroppingRect = (croppingCoordinates, squareRect) => {
    if (basicInfo.creativeType === 'logoImage') {
      setCroppingRect(croppingCoordinates)

    } else {
      setCustomCroppingRect(croppingCoordinates)
      setCustomSquareCroppingRect(squareRect)
    }
  }

  const handleSave = () => {
    if (!basicInfo.name) {
      toast.show({
        title: 'Warning',
        description: 'Please enter the campaign name.',
      })
      return
    }
    if (!products.length) {
      toast.show({
        title: 'Warning',
        description: 'Please choose at least 1 product.',
      })
      return
    }
    if (!targetings.length) {
      toast.show({
        title: 'Warning',
        description: 'Please choose at least 1 target.',
      })
      return
    }
    const newCreative = {}
    if (basicInfo.isCreative) {
      if (basicInfo.creativeType === 'logoImage') {
        if (basicInfo.headline === '') {
          toast.show({
            title: 'Warning',
            description: 'Please write a headline.',
          })
          return
        } else {
          if (Object.keys(uploadSDImageData).length) {
            let rectCustomImage = {
              assetId: uploadSDImageData.assetId,
              assetVersion: uploadSDImageData.versionId
            }
            if (croppingRect) {
              rectCustomImage.croppingCoordinates = croppingRect
            }
            let creative = {
              contentType : 'HL',
              headline: basicInfo.headline,
              brandLogo : rectCustomImage
            }
            newCreative.properties = creative
          } else {
            toast.show({
              title: 'Warning',
              description: 'Please choose a creative image.',
            })
            return
          }
        }
      } else if ( basicInfo.creativeType === 'customImage') {
        if (Object.keys(uploadSDCustomImageData).length) {
          let rectCustomImage = {
            assetId: uploadSDCustomImageData.assetId,
            assetVersion: uploadSDCustomImageData.versionId
          }
          if (customCroppingRect) {
            rectCustomImage.croppingCoordinates = customCroppingRect
          }
          let rectSquareImage = {
            assetId: uploadSDCustomImageData.assetId,
            assetVersion: uploadSDCustomImageData.versionId
          }
          if (customSquareCroppingRect) {
            rectSquareImage.croppingCoordinates = customSquareCroppingRect
          }
          let creative = {
            contentType : 'CUSTOM_IMAGE',
            rectCustomImage : rectCustomImage,
            squareCustomImage: rectSquareImage
          }
          newCreative.properties = creative
        } else {
          toast.show({
            title: 'Warning',
            description: 'Please choose a creative image.',
          })
          return
        }
      } else {
        toast.show({
          title: 'Warning',
          description: 'Please choose your creative type.',
        })
        return
      }
    }

    const newCampaign = {
      name: basicInfo.name,
      budget: basicInfo.dailyBudget,
      startDate: moment(basicInfo.startDate).format('YYYYMMDD'),
      tactic: target,
      costType: bidInfo.bidOp.value === 'reach' ? 'vcpm' : 'cpc'
    }
    if (basicInfo.endDate !== '' && basicInfo.startDate < basicInfo.endDate)  {
      newCampaign.endDate = moment(basicInfo.endDate).format('YYYYMMDD')
    }

    if(bidInfo.bidOp.value !== 'reach' && Object.keys(basicInfo.portfolio)) {
      newCampaign.portfolioId = basicInfo.portfolio.portfolio_id
    }

    dispatch(createSDCampaign({
      campaigns: [newCampaign],
      acos: basicInfo.acos,
      adGroups: [{
        name: adgroupName,
        defaultBid: bidInfo.defaultBid,
        bidOptimization: bidInfo.bidOp.value,
        tactic: target,
      }],
      productAds: products.map(product => ({
        sku: product.sku,
        asin: product.asin,
      })),
      targets: parseTargetings(),
      creative: [newCreative],
    })).then(() => {
      toast.show({
        title: 'Success',
        description: 'The campaign has been successfully created! '
          + 'Your campaign will appear in Entourage as soon as we start collecting data.',
      })

      history.push('/dashboard')
    }).catch((description) => {
      toast.show({
        title: 'Danger',
        description,
      })
      history.push('/campaigns')
    })
  }

  return (
    <div className={`sd-campaign-creator${isCreating ? ' loading' : ''}${isUploadingSDImage ? ' loading' : ''}${isSDSuggestedBidLoading ? ' loading' : ''}${isSDSuggestionsLoading ? ' loading' : ''}`}>
      { isCreating && <LoaderComponent /> }
      { isUploadingSDImage && <LoaderComponent /> }
      { isSDSuggestionsLoading && <LoaderComponent /> }
      { isSDSuggestedBidLoading && <LoaderComponent /> }
      <div className="page-header">
        <div className="page-title">Create Sponsored Display Campaign</div>
        <button
          type="button"
          className="btn btn-red"
          onClick={handleSave}
        >
          Launch Campaign
        </button>
      </div>
      <div className="page-content">
        <BasicInfo
          info={basicInfo}
          isForSD
          bidInfo={bidInfo}
          portfolios={listPortfolios}
          onChange={handleBasicInfoChange}
        />
        <TargetingTypeSelector
          targetList={targetList}
          target={target}
          onChange={setTarget}
        />
        <SDBidSection
          info={bidInfo}
          dailyBudget={basicInfo.dailyBudget}
          opList={bidOpList}
          onChange={handleBidChange}
        />
        <AdgroupInfo
          name={adgroupName}
          onChange={setAdgroupName}
        />
        <ProductSection
          products={products}
          onChange={handleProductsSelect}
        />
        {
          target === 'T00020' && (
            <SDTargetingSection
              targetings={targetings}
              dailyBudget={basicInfo.dailyBudget}
              isForSD
              bidInfo={bidInfo}
              products={products}
              onChange={setTargetings}
            />
          )
        }
        {
          target === 'T00030' && (
            <AudienceSection
              targetings={targetings}
              dailyBudget={basicInfo.dailyBudget}
              defaultBid={bidInfo.defaultBid}
              bidInfo={bidInfo}
              products={products}
              onChange={setTargetings}
            />
          )
        }
        {
          products.length > 0 && (
            <SDCreativeSection
              products={products}
              onHandleCroppingRect={handleCroppingRect}
              onChange={handleBasicInfoChange}
            />
          )
        }
      </div>
      <div className="page-footer">
        <button
          type="button"
          className="btn btn-red"
          onClick={handleSave}
        >
          Launch Campaign
        </button>
      </div>
    </div>
  )
}

export default SDCampaignCreator
