import React, { useState } from 'react'
import { useStore, useDispatch } from 'react-redux'
import Select from 'react-select'

import { ReactComponent as CloseSvg } from '../../assets/svg/close.svg'

import TargetingModal from './TargetingModal'
import { getSDSuggestionBids } from '../../redux/actions/campaignCreator'

const suggestedBidOptions = [
  { value: 'suggested', label: 'Suggested' },
  { value: 'min', label: 'Min' },
  { value: 'max', label: 'Max' },
]

const SDTargetingSection = ({ targetings, dailyBudget, isForSD, bidInfo, products, onChange }) => {
  const store = useStore()
  const dispatch = useDispatch()

  const { campaignCreator } = store.getState()
  const {
    isSPSuggestionsLoading,
    isSDSuggestionsLoading,
    suggestedSPCategories,
    suggestedSDCategories,
    suggestedSDProducts,
  } = campaignCreator

  const [openModal, setOpenModal] = useState(false)
  const [defaultBid, setDefaultBid] = useState(0.75)
  const [suggestedBidType, setSuggestedBidType] = useState(suggestedBidOptions[0])

  const parseTargetings = () => {
    const targets = []
    targetings.forEach((targeting) => {
      const payload = {
        bid: targeting.bid,
        targeting: targeting,
        expression: [],
      }
      switch (targeting.type) {
        case 'category':
          payload.expression.push({
            type: 'asinCategorySameAs',
            value: targeting.id.toString(),
          })
          break
        case 'product':
          payload.expression.push({
            type: 'asinSameAs',
            value: targeting.ASIN,
          })
          break
        case 'refine':
          payload.expression.push({
            type: 'asinCategorySameAs',
            value: targeting.id.toString(),
          })

          if (targeting.brandId) {
            payload.expression.push({
              type: 'asinBrandSameAs',
              value: targeting.brandId.toString(),
            })
          }

          if (targeting.ratingValue) {
            payload.expression.push({
              type: 'asinReviewRatingBetween',
              value: targeting.ratingValue,
            })
          }

          if (targeting.priceFrom && targeting.priceTo) {
            payload.expression.push({
              type: 'asinPriceBetween',
              value: `${targeting.priceFrom}-${targeting.priceTo}`,
            })
          } else if (targeting.priceFrom && !targeting.priceTo) {
            payload.expression.push({
              type: 'asinPriceGreaterThan',
              value: targeting.priceFrom,
            })
          } else if (!targeting.priceFrom && targeting.priceTo) {
            payload.expression.push({
              type: 'asinPriceLessThan',
              value: targeting.priceTo,
            })
          }
          break
        default:
          break
      }
      if (['category', 'refine', 'product'].indexOf(targeting.type) !== -1) {
        targets.push(payload)
      }
    })
    return targets
  }

  const handleBidChange = (event, target) => {
    onChange(targetings.map((item) => {
      if (item.id === target.id) {
        return {
          ...item,
          bid: event.target.value,
        }
      }
      return item
    }))
  }

  const handleApplyBid = (type, target) => {
    if (!target.suggestedBid) {
      return
    }
    let bid = defaultBid
    switch (type) {
      case 'suggest':
        bid = target.suggestedBid.recommended
        break;
      case 'min':
        bid = target.suggestedBid.rangeLower
        break;
      case 'max':
        bid = target.suggestedBid.rangeUpper
        break;
      default:
        bid = defaultBid
        break;
    }

    onChange(targetings.map((item) => {
      if (item.type === 'product' && target.type === 'product') {
        if (item.ASIN === target.ASIN) {
          return {
            ...item,
            bid: bid,
          }
        }
      } else {
        if (item.id === target.id) {
          return {
            ...item,
            bid: bid,
          }
        }
      }
      return item
    }))
  }

  const handleDefaultBidApply = () => {
    onChange(targetings.map(item => ({
      ...item,
      bid: defaultBid,
    })))
  }

  const handleSuggestedBidType = (bidType) => {
    setSuggestedBidType(bidType)
  }

  const handleApplyAllSuggested = () => {
    if (suggestedBidType.value === 'max') {
      onChange(targetings.map(target => {
        target.bid = target.suggestedBid ? target.suggestedBid.rangeUpper : target.bid
        return target
      }))
    } else if (suggestedBidType.value === 'min') {
      onChange(targetings.map(target => {
        target.bid = target.suggestedBid ? target.suggestedBid.rangeLower : target.bid
        return target
      }))
    } else {
      onChange(targetings.map(target => {
        target.bid = target.suggestedBid ? target.suggestedBid.recommended : target.bid
        return target
      }))
    }
  }

  const handleGetSuggestedBid = () => {
    if (isForSD && products.length > 0 && targetings.length > 0) {
      let asins = []
      products.map((product) => {
        asins.push({asin: product.asin})
        return true
      })
      let suggestedTargets = parseTargetings(targetings)
      let bidParams = []

      suggestedTargets.map((suggestedTarget) => {
        let targetingClauses = []
        let expressions = []
        expressions.push(suggestedTarget.expression[0])
        targetingClauses.push({targetingClause: {
          expressionType: 'manual',
          expression: expressions
        }})
        let getSuggestedParams = {
          products: asins,
          bidOptimization: bidInfo.bidOp.value,
          costType: bidInfo.bidOp.value === 'reach' ? 'vcpm' : 'cpc',
          targetingClauses: targetingClauses
        }
        let bidParam = {targeting: suggestedTarget, param: getSuggestedParams}
        bidParams.push(bidParam)
        return true
      })

      dispatch(getSDSuggestionBids(bidParams)).then(response => {
        if (response && response.length > 0) {
          onChange(targetings.map((targeting) => {
            const suggestedBid = response.filter(bid => (
              (bid.targeting.targeting.type === 'category' && targeting.type === 'category' && bid.targeting.targeting.id === targeting.id) || (bid.targeting.targeting.type === 'product' && targeting.type  === 'product' && bid.targeting.targeting.ASIN === targeting.ASIN) || (bid.targeting.targeting.type === 'refine' && targeting.type  === 'refine' && bid.targeting.targeting.brandId === targeting.brandId && bid.targeting.targeting.id === targeting.id)
            ))
            if (suggestedBid.length) {
              return {
                ...targeting,
                suggestedBid: suggestedBid[0].suggestedBid,
              }
            }
            return targeting
          }))
        }
        
      })
    }
    setOpenModal(false)
  }

  const handleRemove = (target) => {
    onChange(targetings.filter(item => {
      if (target.type !== item.type) {
        return true
      }
      if (target.type === 'category') {
        return target.id !== item.id
      }
      return target.ASIN !== item.ASIN
    }))
  }

  const renderTargetings = () => {
    if (!targetings.length) {
      return (
        <div className="no-targeting-desc">
          No targeting added.
        </div>
      )
    }

    return (
      <div className="targeting-list">
        {
          targetings.map(target => (
            <div key={target.type === 'product' ? target.ASIN : `${target.id}-${target.brandId || ''}`} className="targeting-item">
              <div className="targeting-info mr-8">
                {
                  target.type !== 'product' && (
                    <div className="category-path">
                      { target.path }
                    </div>
                  )
                }
                <div className="targeting-name">
                  { target.type !== 'product' ? 'Category' : 'Product' }:&nbsp;
                  { target.name }
                </div>
                {
                  target.type === 'product' && (
                    <div className="targeting-meta">
                      ASIN: { target.ASIN }
                    </div>
                  )
                }
                {
                  target.type === 'refine' && (
                    <div className="targeting-meta">
                      Brand: { target.brandName }
                    </div>
                  )
                }
              </div>
              {
                target.suggestedBid && (
                  <div className="targeting-action mr-8">
                    <div className="apply-section">
                      <div className="mb-8">
                        Suggested Bid:&nbsp;
                        {target.suggestedBid.recommended + ' : ' + target.suggestedBid.rangeLower + '~' + target.suggestedBid.rangeUpper}
                      </div>
                      <button type="button" className="btn btn-blue mr-8" onClick={() => { handleApplyBid('suggest', target) }}>
                        Apply Suggest
                      </button>
                      <button type="button" className="btn btn-blue mr-8" onClick={() => { handleApplyBid('min', target) }}>
                        Apply Min
                      </button>
                      <button type="button" className="btn btn-blue" onClick={() => { handleApplyBid('max', target) }}>
                        Apply Max
                      </button>
                    </div>
                  </div>
                )
              }
              
              <div className="targeting-action min-width-330">
                <div>
                  <input
                    type="number"
                    value={target.bid}
                    onChange={(event) => { handleBidChange(event, target) }}
                  />
                  {
                    !isForSD && (parseFloat(target.bid) > parseFloat(dailyBudget)) && (
                      <div className="budget-warning">
                        Exceeds daily budget.
                      </div>
                    )
                  }
                  {
                    isForSD && (parseFloat(target.bid) >= parseFloat(dailyBudget) / 2) && (
                      <div className="budget-warning">
                        Bid must be less than half the value of your budget.
                      </div>
                    )
                  }
                </div>
                <CloseSvg title="Remove" onClick={() => { handleRemove(target) }}/>
              </div>
            </div>
          ))
        }
      </div>
    )
  }

  return (
    <div className="section-container">
      <div className="section-title">
        <span>Products Targeting</span>
        <div>
          <button
            type="button"
            className="btn btn-blue"
            onClick={() => { setOpenModal(true) }}
          >
            Find Categories/ASINs
          </button>
          {
            targetings.length > 0 && (
              <button type="button" className="btn btn-red" onClick={() => { onChange([]) }}>
                Remove All
              </button>
            )
          }
        </div>
      </div>
      <div className="section-note">
        Help shoppers find your product by choosing categories, products,
        brands, or features related to your product.
      </div>

      <div className="field-row">
        <div className="field-wrapper">
          <div className="default-bid-section">
            Default Bid:&nbsp;
            <input
              type="text"
              value={defaultBid}
              onChange={(event) => { setDefaultBid(event.target.value) }}
            />
            <button type="button" className="btn btn-blue" onClick={handleDefaultBidApply}>
              Apply
            </button>
          </div>
        </div>
        <div className="field-wrapper">
          {
            targetings.length > 0 && (
              <div className="d-flex suggested-bid-select mt-8">
                <span className="suggested-bid-span">Suggested Bid Types:&nbsp;</span>
                <Select
                  classNamePrefix="portfolio-selector"
                  className="bid-option-selector"
                  options={suggestedBidOptions}
                  value={suggestedBidType}
                  onChange={val => handleSuggestedBidType(val)}
                />
                <button
                  type="button"
                  className="btn btn-green btn-suggested-bids ml-10"
                  onClick={handleApplyAllSuggested}
                >
                  Apply To All
                </button>
              </div>
            )
          }
        </div>
      </div>

      { renderTargetings() }
      <TargetingModal
        show={openModal}
        defaultBid={defaultBid}
        targetings={targetings}
        isForSD={isForSD}
        isLoading={!isForSD ? isSPSuggestionsLoading : isSDSuggestionsLoading}
        suggestedCategories={!isForSD ? (suggestedSPCategories || []) : (suggestedSDCategories || [])}
        suggestedProducts={suggestedSDProducts}
        onChange={onChange}
        onClose={handleGetSuggestedBid}
      />
    </div>
  )
}

export default SDTargetingSection
