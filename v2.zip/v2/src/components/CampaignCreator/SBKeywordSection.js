import React, { useState } from 'react'
import Select from 'react-select'
import { Tooltip, Whisper } from 'rsuite'

import { ReactComponent as InfoSvg } from '../../assets/svg/info.svg'
import { ReactComponent as CloseSvg } from '../../assets/svg/close.svg'

import SBKeywordModal from './SBKeywordModal'
import { toast } from '../../components/CommonComponents/ToastComponent/toast'

const matchTypeOptions = [
  { value: 'broad', label: 'Broad' },
  { value: 'phrase', label: 'Phrase' },
  { value: 'exact', label: 'Exact' },
]

const suggestedBidOptions = [
  { value: 'suggested', label: 'Suggested' },
  { value: 'min', label: 'Min' },
  { value: 'max', label: 'Max' },
]

const bidTypeOptions =[
  {value: 'auto', label: 'Automated bidding'},
  {value: 'custom', label: 'Custom bidding'}
]
const bidRateOptions =[
  {value: 'increase', label: 'Increase by'},
  {value: 'decrease', label: 'Decrease by'}
]

const SBKeywordSection = ({ keywords, bidType, campaignType, bidDirect, onChange, onBidTypeChange, onBidDirectChange, onBidValueChange }) => {
  const [openModal, setOpenModal] = useState(false)
  const [defaultBid, setDefaultBid] = useState(0.75)
  const [bidRate, setBidRate] = useState(0)
  const [suggestedBidType, setSuggestedBidType] = useState(suggestedBidOptions[0])

  const handleSelect = (keywordsToAdd) => {
    setOpenModal(false)

    let newKeywords = [...keywords]
    const keywordsToGetBid = []

    keywordsToAdd.forEach((keyword) => {
      const duplicate = keywords.find(kw => (
        keyword.keywordText === kw.keywordText
          && keyword.matchType === kw.matchType.toLowerCase()
      ))

      if (!duplicate) {
        newKeywords.push({
          keywordText: keyword.keywordText,
          matchType: keyword.matchType,
          keywordBid: defaultBid,
        })

        keywordsToGetBid.push({
          keyword: keyword.keywordText,
          matchType: keyword.matchType,
        })
      }
    })

    newKeywords = newKeywords.map((keyword, index) => ({
      ...keyword,
      id: keyword.id ? keyword.id : index,
    }))

    onChange(newKeywords, true, keywordsToGetBid)
  }

  const handleMatchTypeChange = (match, keyword) => {
    keyword.matchType = match.value
    onChange(keywords.map((kw) => {
      if (kw.id === keyword.id) {
        return { ...kw, matchType: match.value }
      }
      return kw
    }))
  }

  const handleBidValue = (value) => {
    if(value < 0 || value > 99) {
      toast.show({
        title: 'Warning',
        description: 'Bid value can be set from 0 to 99.',
      })
      return
    }
    setBidRate(value)
    onBidValueChange(value)
  }

  const handleApplyAllSuggested = () => {
    if (suggestedBidType.value === 'max') {
      onChange(keywords.map(keyword => {
        keyword.keywordBid = keyword.suggestedBid ? keyword.suggestedBid.rangeEnd : keyword.keywordBid
        return keyword
      }))
    } else if (suggestedBidType.value === 'min') {
      onChange(keywords.map(keyword => {
        keyword.keywordBid = keyword.suggestedBid ? keyword.suggestedBid.rangeStart : keyword.keywordBid
        return keyword
      }))
    } else {
      onChange(keywords.map(keyword => {
        keyword.keywordBid = keyword.suggestedBid ? keyword.suggestedBid.recommended : keyword.keywordBid
        return keyword
      }))
    }
  }

  const handleApplyBid = (type, keyword) => {
    if (!keyword.suggestedBid) {
      return
    }

    switch (type) {
      case 'suggest':
        keyword.keywordBid = keyword.suggestedBid.recommended
        break;
      case 'min':
        keyword.keywordBid = keyword.suggestedBid.rangeStart
        break;
      case 'max':
        keyword.keywordBid = keyword.suggestedBid.rangeEnd
        break;
      default:
        keyword.keywordBid = defaultBid
        break;
    }

    onChange(keywords.map(kw => {
      if (kw.id === keyword.id) {
        return keyword
      }
      return kw
    }))
  }

  const handleChangeKeywordBid = (e, keyword) => {
    e.preventDefault()
    keyword.keywordBid = e.currentTarget.value
    onChange(keywords.map(kw => {
      if (kw.id === keyword.id) {
        return keyword
      }
      return kw
    }))
  }

  const handleRemove = (id) => {
    onChange(keywords.filter(kw => kw.id !== id))
  }

  const handleDefaultBidApply = () => {
    onChange(keywords.map(item => ({
      ...item,
      keywordBid: defaultBid,
    })))
  }

  const handleSuggestedBidType = (bidType) => {
    setSuggestedBidType(bidType)
  }

  const renderKeywords = () => {
    if (!keywords.length) {
      return (
        <div className="no-keyword-desc">
          No keyword added.
        </div>
      )
    }

    return (
      <div className="keyword-container">
        {
          keywords.map((keyword) => {
            const matchType = matchTypeOptions.find(option => option.value === keyword.matchType)
            return (
              <div key={keyword.id} className="keyword-box">
                <div className="flex justify-space-between align-center box-header">
                  <div className="flex align-center match-selector">
                    <span className="match-title">Match Type</span>
                    <div>
                      <Select
                        classNamePrefix="match-select"
                        options={matchTypeOptions}
                        value={matchType}
                        onChange={val => handleMatchTypeChange(val, keyword)}
                      />
                    </div>
                  </div>
                  {
                    keyword.suggestedBid && (
                      <div className="apply-section">
                        <button type="button" className="btn btn-blue" onClick={() => { handleApplyBid('suggest', keyword) }}>
                          Apply Suggest
                        </button>
                        <button type="button" className="btn btn-blue" onClick={() => { handleApplyBid('min', keyword) }}>
                          Apply Min
                        </button>
                        <button type="button" className="btn btn-blue" onClick={() => { handleApplyBid('max', keyword) }}>
                          Apply Max
                        </button>
                      </div>
                    )
                  }
                  <CloseSvg title="Remove" onClick={() => { handleRemove(keyword.id) }}/>
                </div>
                <div className="box-content">
                  <div>
                    Keyword: {keyword.keywordText}
                  </div>
                  <div>
                    Suggested Bid:&nbsp;
                    { keyword.suggestedBid ? keyword.suggestedBid.recommended + ' : ' + keyword.suggestedBid.rangeStart + '~' + keyword.suggestedBid.rangeEnd : 'N/A' }
                  </div>
                  <div>
                    Keyword Bid:&nbsp;
                    <input type="text" value={keyword.keywordBid} onChange={e => { handleChangeKeywordBid(e, keyword) }} />
                  </div>
                </div>
              </div>
            )
          })
        }
      </div>
    )
  }

  return (
    <div className="section-container">
      <div className="section-title">
        Keywords
        <div>
          <button
            type="button"
            className="btn btn-blue"
            onClick={() => { setOpenModal(true) }}
          >
            Add Keywords
          </button>
        </div>
      </div>
      <div className="section-note">
        Your keywords (word combinations and phrases) are used to match your ads
        with search terms shoppers are using to find products.
      </div>
      {campaignType !=='video' && (
        <div className="field-row">
          <div className="field-wrapper">
            <div className="field-name ">
              Automated Bidding
              <Whisper placement="right" trigger="hover" speaker={(
                <Tooltip>
                  <p>By using automated bidding, you allow Amazon to optimize your bids for placements other than top of search.</p>
                  <p>The keyword bids you provide apply to top of search and are used as a maximum starting point for other placements.</p>
                  <p>Amazon may then decrease your bids for other placements based on your observed conversion rate for those placements.</p>
                </Tooltip>
              )}>
                <InfoSvg />
              </Whisper>
            </div>
            <div className="keyword-section-bid-setting">
              <div className="mr-10">
                <Select
                  classNamePrefix="portfolio-selector"
                  options={bidTypeOptions}
                  value={bidTypeOptions.filter(data => data.value === bidType)[0]}
                  onChange={(option) => { onBidTypeChange(option.value) }}
                />
              </div>
              { bidType === 'custom' && (
                <>
                  <div className="mr-10">
                    <Select
                      classNamePrefix="portfolio-selector mr-10"
                      options={bidRateOptions}
                      value={bidRateOptions.filter(data => data.value === bidDirect)[0]}
                      onChange={(option) => { onBidDirectChange(option.value) }}
                    />
                  </div>
                  
                  <div className="input-wrapper mr-10">
                    <input
                      type="number"
                      value={bidRate}
                      onChange={(event) => { handleBidValue(event.target.value)}}
                    />
                  </div>
                  <span className="mr-10"> % for placements other than top of search</span>
                </>
              )}
            </div>
          </div>
        </div>
      )}
      <div className="field-row">
        <div className="field-wrapper">
          <div className="default-bid-section">
            Default Bid:&nbsp;
            <input
              type="text"
              value={defaultBid}
              onChange={(event) => { setDefaultBid(event.target.value) }}
            />
            <button type="button" className="btn btn-blue" onClick={handleDefaultBidApply}>
              Apply
            </button>
          </div>
        </div>
        <div className="field-wrapper">
          {
            keywords.length > 0 && (
              <div className="d-flex suggested-bid-select mt-8">
                <span className="suggested-bid-span">Suggested Bid Types:&nbsp;</span>
                <Select
                  classNamePrefix="portfolio-selector"
                  className="bid-option-selector"
                  options={suggestedBidOptions}
                  value={suggestedBidType}
                  onChange={val => handleSuggestedBidType(val)}
                />
                <button
                  type="button"
                  className="btn btn-green btn-suggested-bids ml-10"
                  onClick={handleApplyAllSuggested}
                >
                  Apply To All
                </button>
              </div>
            )
          }
        </div>
      </div>
      { renderKeywords() }
      <SBKeywordModal
        show={openModal}
        keywordsSelected={keywords}
        onSelect={handleSelect}
        onClose={() => { setOpenModal(false) }}
      />
    </div>
  )
}

export default SBKeywordSection
