import React from 'react'
import { useStore } from 'react-redux'
import { Modal } from 'rsuite'


const SBBrandLogoModal = ({ show, onClose, setBrandLogo }) => {
  const store = useStore()
  const { campaignCreator } = store.getState()
  const { sbBrandLogos } = campaignCreator

  const selectBrandLogo = (brandLogo) => {
    if (brandLogo === null) {
      return
    }
    setBrandLogo(brandLogo)
  }

  const renderBrandLogosList = () => {
    return (
      <div className="">
        <div className="brand-logo-list">
          {
            sbBrandLogos.map((brandLogo) =>
              <div key={brandLogo.assetId} className="brandlogo-list-item brand-logo-img">
                <div className="brand-logo-item">
                  <img src={brandLogo.url} alt={brandLogo.name} />
                  <div className="product-info">
                    <div className="product-name">{brandLogo.name}</div>
                    <div className="product-detail">
                      <span>Height: {brandLogo.height}px</span>
                      <span>Width: {brandLogo.width}px</span>
                    </div>
                  </div>
                  <button type="button" className="btn btn-blue" onClick={() => selectBrandLogo(brandLogo)}>
                    Select
                  </button>
                </div>
              </div>
            )
          }
        </div>
      </div>
    )
  }


  return (
    <Modal className={`brand-logo-modal`} backdrop="static" show={show} size="lg">
      <Modal.Body>
        { renderBrandLogosList() }
      </Modal.Body>
      <Modal.Footer>
        <button type="button" className="rs-btn rs-btn-subtle" onClick={() => onClose()}>
          Close
        </button>
      </Modal.Footer>
    </Modal>
  )
}
export default SBBrandLogoModal