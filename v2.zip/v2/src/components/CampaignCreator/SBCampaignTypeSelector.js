import React from 'react'

import { ReactComponent as CheckSvg } from '../../assets/svg/check.svg'

const SBCampaignTypeSelector = ({ campaignTypeList, campaignType, onChange }) => (
  <div className="targeting-type-selector">
    <div className="section-title">Ad Format</div>
    <div className="section-note">
      The landing page is where shoppers are directed after they interact with your ad.
    </div>
    <div className="selector-wrapper">
      {
        campaignTypeList.map(campaignInfo => (
          <div
            key={campaignInfo.value}
            className={`selector${campaignType === campaignInfo.value ? ' selected' : ''}`}
            onClick={() => onChange(campaignInfo.value)}
          >
            <CheckSvg />
            <div className="selector-content">
              <div className="selector-title">{ campaignInfo.name }</div>
              <div className="selector-note">{ campaignInfo.description }</div>
            </div>
          </div>
        ))
      }
    </div>

  </div>
)

export default SBCampaignTypeSelector
