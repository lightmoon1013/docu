import React from 'react'
import { useDispatch, useStore } from 'react-redux'
import { useHistory } from "react-router-dom"
import moment from 'moment'

import CustomTable from '../CommonComponents/CustomTableComponent'

import {
  getProductById,
} from '../../redux/actions/product'

const ProductFilterComponent = ({ onClose }) => {
  const dispatch = useDispatch()
  const store = useStore()
  const history = useHistory()

  const {
    header: {
      currentStartDate,
      currentEndDate,
      currentUserId,
    },
    product: {
      isLoading,
      productList,
    },
  } = store.getState()

  const handleProductClick = (record) => {
    dispatch(getProductById({
      id: record.id,
      sku: record.sku,
      startDate: currentStartDate ? moment(currentStartDate).format('YYYY-MM-DD') : moment().format('YYYY-MM-DD'),
      endDate: currentEndDate ? moment(currentEndDate).format('YYYY-MM-DD') : moment().subtract(1, 'months').format('YYYY-MM-DD'),
      userId: currentUserId,
    }))
    history.push(`/product/${record.id}/${record.sku}`)
    onClose()
  }

  const renderProduct = record => (
    <>
      <div className="table-col">
        {
          record['image_sm'] && record['image_sm'] !== '' ? (
            <>
              <img src={record['image_sm']} alt={record['product-name']} />
              <span>{record['product-name']}</span>
            </>
          ) : (
            <span className="no-image">{record['product-name']}</span>
          )
        }
      </div>
    </>
  )

  return (
    <div className="product-filter-component">
      <CustomTable
        isLoading={isLoading}
        className="table-product-selector"
        records={productList}
        idField="id"
        searchFields={['product-name', 'sku']}
        noCheckBox
        paginationSelectPlacement="top"
        searchPlaceholder="Search by name or SKU to find product"
        onClickRecord={handleProductClick}
        renderRecord={renderProduct}
      >
        <div className="table-col">Product</div>
      </CustomTable>
    </div>
  )
}

export default ProductFilterComponent
