import React, { useState } from 'react'
import { useStore, useDispatch } from 'react-redux'
import { Toggle, Radio, Tooltip, Whisper } from 'rsuite'
import { BsCaretUpFill, BsCaretDownFill } from 'react-icons/bs'

import { ReactComponent as InfoSvg } from '../../assets/svg/info.svg'
import { ReactComponent as FilterSvg } from '../../assets/svg/filter.svg'
import ImgLock from '../../assets/img/lock.png'

import CheckboxComponent from '../CommonComponents/CheckboxComponent'
import TableFilter from '../CommonComponents/TableFilter'
import TableFilterShower from '../CommonComponents/TableFilterShower'

import {
  formatValue,
  formatCurrency,
  tableSorter,
  matchFilter,
} from '../../services/helper'

import filterDef from '../../utils/filterDef'

import {
  enableKeywordOrganicRankTracking,
  disableKeywordOrganicRankTracking
} from '../../redux/actions/productDetail'

import {
  showFilter,
} from '../../redux/actions/pageGlobal'

import KeywordOptionComponent from './keyword-select-option'

const ProductKeywordAboveComponent = ({isExtensionInstalled}) => {
  const store = useStore().getState()
  const dispatch = useDispatch()
  const { header, productDetail, pageGlobal } = store
  const { targetAcosKeywords } = productDetail
  const { currencyRate, currencySign } = header
  const { visibleFilterName, filterValues } = pageGlobal

  const [searchKey, setSearchKey] = useState('')
  const [keywordChecking, setKeywordChecking] = useState({})
  const [allKeywordChecking, setAllKeywordChecking] = useState(false)
  const [clipboard, setClipboard] = useState('')
  const [sortColumnName, setSortColumnName] = useState('')
  const [sortDirection, setSortDirection] = useState('asc')

  const columns = [
    {
      name: 'keyword',
      label: 'Keyword'
    },
    {
      name: 'ad_group_name',
      label: 'Ad Group'
    },
    {
      name: 'campaign_name',
      label: 'Campaign'
    },
    {
      name: 'match1',
      label: 'Match',
    },
    {
      name: 'keyword_bid',
      label: 'Keyword Bid',
    },
    {
      name: 'avcpc',
      label: 'Ave CPC',
    },
    {
      name: 'max_cpc',
      label: 'Max CPC',
    },
    {
      name: 'orders',
      label: 'Orders',
    },
    {
      name: 'revenue',
      label: 'Sales',
    },
    {
      name: 'ctr',
      label: 'CTR %',
    },
    {
      name: 'roas',
      label: 'ROAS',
    },
    {
      name: 'conversionrate',
      label: 'Conv %'
    },
    {
      name: 'cost',
      label: 'Spend',
    },
    {
      name: 'acos',
      label: 'ACoS%',
    },
    {
      name: 'impressions',
      label: 'Imp.',
    },
    {
      name: 'clicks',
      label: 'Clicks',
    },
  ]

  const onOrganicRankClick = (keyword) => {
    if (keyword['auto_organic_rank_checking']) {
      dispatch(disableKeywordOrganicRankTracking({
        keyword: keyword['keyword']
      }))
    } else {
      dispatch(enableKeywordOrganicRankTracking({
        keyword: keyword['keyword']
      }))
    }
  }

  const onKeywordCheck = (id) => {
    keywordChecking[id] = !keywordChecking[id]
    setKeywordChecking(keywordChecking)
    setAllKeywordChecking(false)
    let keywordNames = []
    for (let i in keywordChecking) {
      if (keywordChecking[i]) {
        keywordNames.push(targetAcosKeywords.filter(k => k.keyword_id === i)[0]['keyword'])
      }
    }

    if (keywordNames.length) {
      setClipboard(keywordNames.join(', '))
    }
  }

  const sortColumn = (field) => {
    setSortDirection(sortColumnName === field && sortDirection === 'asc' ? 'desc' : 'asc')
    setSortColumnName(field)
  }

  const filteredKeywords = tableSorter(['keyword', 'ad_group_name', 'campaign_name', 'match1'])(targetAcosKeywords, [sortColumnName, sortDirection]).filter(keyword => {
    if (keyword['profit1'] < 0 || !keyword['keyword'].toLowerCase().includes(searchKey.toLowerCase())) {
      return false
    }
    if (!matchFilter(keyword, filterDef.productDetailKeyword, (filterValues || {}).productDetailKeyword || {})) {
      return false
    }
    return true
  })

  const onAllKeywordCheck = () => {
    let tmp = {...keywordChecking}
    for (let i in filteredKeywords) {
      tmp[filteredKeywords[i]['keyword_id']] = !allKeywordChecking
    }
    setKeywordChecking(tmp)
    setAllKeywordChecking(!allKeywordChecking)
  }

  const onShowTableFilter = () => {
    dispatch(showFilter('productDetailKeyword'))
  }

  const rowElements = filteredKeywords.map((keyword) => (
    <div className="table-row" key={keyword['keyword_id']}>
      <div className="table-col">
        <CheckboxComponent
          checked={keywordChecking[keyword['keyword_id']]}
          onChange={()=>onKeywordCheck(keyword['keyword_id'])}
        />
      </div>
      <div className="table-col">{keyword['keyword']}</div>
      <div className="table-col">{keyword['ad_group_name']}</div>
      <div className="table-col min-width-300">{keyword['campaign_name']}</div>
      <div className="table-col">{keyword['match1']}</div>
      <div className="table-col">{keyword['keyword_bid']}</div>
      <div className="table-col">{formatCurrency(keyword['avcpc'], currencySign, currencyRate)}</div>
      <div className="table-col min-width-100">{formatCurrency(keyword['max_cpc'], currencySign, currencyRate)}</div>
      <div className="table-col">{formatValue(keyword['orders'], 'number')}</div>
      <div className="table-col">{formatCurrency(keyword['revenue'], currencySign, currencyRate)}</div>
      <div className="table-col">{formatValue(keyword['ctr'] * 100, 'number')}</div>
      <div className="table-col">{keyword['cost'] ? formatValue(keyword['revenue'] / keyword['cost'], 'number') : 0}</div>
      <div className="table-col">{formatValue(keyword['conversionrate'], 'number')}</div>
      <div className="table-col">{formatCurrency(keyword['cost'], currencySign, currencyRate)}</div>
      <div className="table-col">{formatValue(keyword['acos'] * 100, 'number')}</div>
      <div className="table-col">{formatValue(keyword['impressions'], 'number', 0)}</div>
      <div className="table-col">{formatValue(keyword['clicks'], 'number', 0)}</div>
      <div className="table-col">
        {isExtensionInstalled ?
          <Toggle checked={keyword['auto_organic_rank_checking']} onChange={()=>onOrganicRankClick(keyword)} />
          :
          <Whisper
            trigger="hover"
            placement="auto"
            speaker={
              <Tooltip>
                <p>Install the 'PPC Entourage Chrome Extension' to enable product rank tracking
                property</p>
              </Tooltip>
            }
          >
            <img alt={keyword['keyword']} src={ImgLock} />
          </Whisper>
        }
      </div>
      <div className="table-col">
        {isExtensionInstalled ?
          <Radio checked={keyword['indexing_last_check_date']} />
          :
          <Whisper
            trigger="hover"
            placement="auto"
            speaker={
              <Tooltip>
                <p>Install the 'PPC Entourage Chrome Extension' to see and check the indexing statuses
                property</p>
              </Tooltip>
            }
          >
            <img alt={keyword['keyword']} src={ImgLock} />
          </Whisper>
        }
      </div>
    </div>
  ))

  return (
    <>
      {
        visibleFilterName === 'productDetailKeyword' &&
        <TableFilter filterName="productDetailKeyword" />
      }
      <TableFilterShower filterName="productDetailKeyword" />
      <div className="content-header">
        <input type="text" className="header-search" placeholder="Search..." value={searchKey} onChange={(e)=>setSearchKey(e.target.value)} />
        <KeywordOptionComponent clipboard={clipboard} keywordChecking={keywordChecking} />
        <FilterSvg onClick={onShowTableFilter} />
      </div>
      <div className="keyword-table">
        <div className="table-header table-row">
          <div className="table-col">
            <CheckboxComponent
              checked={allKeywordChecking}
              onChange={onAllKeywordCheck}
            />
          </div>
          {
            columns.map((column) => {
              if (column.name !== 'max_cpc') {
                return (
                  <div key={column.name} className={`table-col ${column.name === 'campaign_name' ? 'min-width-300' : ''}`} onClick={() => { sortColumn(column.name) }}>
                    {column.label}
                    {
                      sortColumnName === column.name && (
                        sortDirection === 'asc' ? <BsCaretUpFill /> : <BsCaretDownFill />
                      )
                    }
                  </div>
                )
              } else {
                return (
                  <div key="max_cpc" className="table-col min-width-100" onClick={() => { sortColumn('max_cpc') }}>
                    Max CPC
                    {
                      sortColumnName === 'max_cpc' && (
                        sortDirection === 'asc' ? <BsCaretUpFill /> : <BsCaretDownFill />
                      )
                    }
                    <Whisper placement="right" trigger="hover" speaker={(
                      <Tooltip>
                        <p>The maximum one can spend per click to break even with PPC.</p>
                        <p>Takes into account the products profit margins and the average amount of clicks to get an order.</p>
                      </Tooltip>
                    )}>
                      <InfoSvg />
                    </Whisper>
                  </div>
                )
              }
            })
          }
          <div className="table-col">Organic Rank Tracker</div>
          <div className="table-col">Indexing State</div>
        </div>
        <div className="table-content">
          {rowElements}
        </div>
      </div>
    </>
  )
}

export default ProductKeywordAboveComponent
