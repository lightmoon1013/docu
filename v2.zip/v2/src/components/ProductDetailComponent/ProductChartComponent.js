import React, { useEffect, useState } from 'react'
import { useDispatch, useStore } from 'react-redux'
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Legend,
  Tooltip,
  ResponsiveContainer,
} from 'recharts'
import moment from 'moment'
import Select from 'react-select'
import DateRangeComponent from '../CommonComponents/DateRangeComponent'
import { ReactComponent as TrashSvg } from '../../assets/svg/trash.svg'
import { ReactComponent as PlusSvg } from '../../assets/svg/add-new-blue.svg'
import * as Sentry from '@sentry/react'

import {
  setDateRange,
} from '../../redux/actions/header'
import {
  formatValue
} from '../../services/helper'

const metricList = [
  { name: 'Gross Revenue', key: 'revenue', color: '#fbab34' },
  { name: 'Ad Spend', key: 'cost', color: '#cfd2f5' },
  { name: 'Orders', key: 'orders', color: '#3dade8' },
  { name: 'Clicks', key: 'clicks', color: '#25c835' },
  { name: 'Impressions', key: 'impressions', color: '#93df8d' },
  { name: 'ACoS %', key: 'acos', color: '#ffd156' },
]
const CHART_METRIC_SETTING = 'PRODUCT_CHART_METRICS'
const METRIC_LIMIT = 6

const ProductChartComponent = ({ revenue, clicks, orders, ...props }) => {
  const store = useStore().getState()
  const dispatch = useDispatch()

  const {
    product,
    header,
  } = store
  const {
    curProductChart,
  } = product

  const {
    currencyRate,
    currencySign,
    currentStartDate,
    currentEndDate,
  } = header

  const [ chartData, setChartData ] = useState([])
  const [ currentCurrencyRate, setCurrentCurrencyRate ] = useState(1)
  const [ startDate, setStartDate ] = useState(moment().startOf('day').subtract(29, 'day').toDate())
  const [ endDate, setEndDate ] = useState(moment().endOf('day').toDate())

  const [chartMetrics, setChartMetrics] = useState([])
  const [isClickedAdd, setIsClickedAdd] = useState(false)

  const visibility = {}
  metricList.forEach((metric) => {
    visibility[metric.key] = metric.key !== 'impressions'
  })

  const [metricVisibility, setMetricVisibility] = useState(visibility)

  useEffect(() => {
    loadSavedMetrics()
  }, [])

  const loadSavedMetrics = () => {
    const savedMetrics = window.localStorage.getItem(CHART_METRIC_SETTING)
    if (savedMetrics) {
      let metrics = []
      try {
        metrics = JSON.parse(savedMetrics)
      } catch (error) {
        Sentry.captureException(error)
        // keep silence
      }
      setChartMetrics(metrics)
    } else {
      setChartMetrics(metricList.slice(0, METRIC_LIMIT))
    }
  }

  const handleMetricToggle = key => () => {
    const visibility = Object.assign({}, metricVisibility, {
      [key]: !metricVisibility[key]
    })
    setMetricVisibility(visibility)
  }

  useEffect(() => {
    if (!currentStartDate || currentStartDate === '' || !currentEndDate || currentEndDate === '') {
      return
    }
    setStartDate(currentStartDate)
    setEndDate(currentEndDate)
  }, [currentStartDate, currentEndDate])

  useEffect(() => {
    if (!currencyRate) {
      return
    }
    if (!currencySign) {
      return
    }
    setCurrentCurrencyRate(currencyRate)
  }, [currencyRate, currencySign])

  useEffect(() => {
    if (!curProductChart || curProductChart.length === 0) {
      return
    }
    setChartData(curProductChart.map(product => (
      {
        'revenue': product.revenue * currentCurrencyRate,
        'cost': product.cost * currentCurrencyRate,
        'orders': product.orders * 1,
        'clicks': product.clicks * 1,
        'impressions': product.impressions * 1,
        'acos': product.revenue ? formatValue(product.cost / product.revenue * 100, 'number') : 0,
        'date': moment(product.startdate ? product.startdate : '0000-00-00').format('yyyy/MM/DD'),
      }
    )))
  }, [curProductChart, currentCurrencyRate])

  const handleChangeDateRange = (val) => {
    dispatch(
      setDateRange({
        startDate: val[0],
        endDate: val[1],
      })
    )
  }

  const handleClickCreateMetric = () => {
    setIsClickedAdd(true)
  }

  const handleDeleteMetric = (index) => {
    let newChartMetrics = [...chartMetrics].filter((metric, ind) => ind !== index)
    setChartMetrics(newChartMetrics)
    window.localStorage.setItem(CHART_METRIC_SETTING, JSON.stringify(newChartMetrics))
  }

  const handleMetricAdd = (metric) => {
    const newChartMetrics = [...chartMetrics]
    const length = newChartMetrics.length
    const selectedMetric = metricList.find(item => item.key === metric.value)
    metricVisibility[selectedMetric.key] = false
    newChartMetrics[length] = selectedMetric
    setChartMetrics(newChartMetrics)
    setIsClickedAdd(false)
    window.localStorage.setItem(CHART_METRIC_SETTING, JSON.stringify(newChartMetrics))
  }

  const tickFormatter = (ts) => {
    if (!ts || isNaN(ts)) {
      return ''
    }
    return moment(ts).format('MM/DD')
  }

  const renderLegend = ({ payload }) => (
    <ul className="legend-list">
      {
        payload.map((entry, index) => {
          const style = {
            borderColor: entry.payload.stroke,
          }

          if (metricVisibility[entry.dataKey]) {
            style.backgroundColor = entry.payload.stroke
          }
          return (
            <li key={entry.dataKey}>
              <button onClick={handleMetricToggle(entry.dataKey)}>
                <span className="bullet" style={style} />
                { entry.value }
              </button>
              <TrashSvg onClick={() => { handleDeleteMetric(index) }}/>
            </li>
          )
        })
      }
      {
        isClickedAdd && (
          <li className="metric-selector-container">
            <Select
              className="metric-selector"
              classNamePrefix="metric-selector"
              options={metricList.filter(metric => chartMetrics.findIndex(item => item.key === metric.key) === -1).map(metric => (
                {
                  label: metric.name,
                  value: metric.key,
                }
              ))}
              onChange={handleMetricAdd}
            />
          </li>
        )
      }
      <li className="add-action">
        <PlusSvg
          title="Add Metric"
          onClick={handleClickCreateMetric}
        />
      </li>
    </ul>
  )

  return (
    <div className="product-chart-component">
      <div className="chart-area">
        <div className="chart-header">
          <DateRangeComponent
            onChange = { handleChangeDateRange }
            value = { [ startDate, endDate ] }
          />
        </div>
        <div className="chart-content">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              width={300 }
              height={300}
              data={chartData}
              margin={{
                top: 10,
                right: 30,
                left: -15,
                bottom: 0,
              }}
            >
              <XAxis dataKey="date" tickFormatter={tickFormatter} />
              <YAxis />
              <Tooltip />
              {
                chartMetrics.map(metric => (
                  metric && <Line
                    key={metric.key}
                    type="monotone"
                    name={metric.name}
                    dataKey={metric.key}
                    stroke={metric.color}
                    strokeWidth={2}
                    dot={{ r: 2, fill: metric.color }}
                    activeDot={true}
                    hide={!metricVisibility[metric.key]}
                  />
                ))
              }
              <Legend
                content={renderLegend}
                wrapperStyle={{
                  bottom: -5,
                }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  )
}

export default ProductChartComponent
