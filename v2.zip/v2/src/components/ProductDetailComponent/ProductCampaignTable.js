import React from 'react'
import { useDispatch, useStore } from 'react-redux'
import { Link } from 'react-router-dom'

import SortableTable from '../CommonComponents/SortableTableComponent'
import TableCell from '../CommonComponents/TableCell'

import APMComponent from '../APMComponent'
import TemplateEditorComponent from '../TemplateEditorComponent'

import { ReactComponent as MoreApmSvg } from '../../assets/svg/more-apm.svg'

import { showAPMAction } from '../../redux/actions/pageGlobal'

import { productCampaignColumnList } from '../../utils/defaultValues'

import { tableSorter } from '../../services/helper'

import { campaignTypeMap } from '../../utils/defaultValues'

const stateLabels = {
  enabled: 'Active',
  paused: 'Paused',
  archived: 'Archived',
}

const columns = [
  { key: 'campaign', name: 'Campaign', className: 'col-campaign' },
  { key: 'impressions', name: 'Imp.' },
  { key: 'clicks', name: 'Clicks' },
  { key: 'ctr', name: 'CTR %' },
  { key: 'cost', name: 'Spend' },
  { key: 'cpc', name: 'Ave CPC' },
  { key: 'orders', name: 'Orders' },
  { key: 'revenue', name: 'Sales' },
  { key: 'acos', name: 'ACoS %' },
  { key: 'roas', name: 'ROAS' },
  { key: 'conversion', name: 'Conv %' },
  { key: 'ntb_orders', name: 'NTB Orders' },
  { key: 'ntb_orders_percent', name: 'NTB Orders %' },
  { key: 'ntb_sales', name: 'NTB Sales' },
  { key: 'ntb_sales_percent', name: 'NTB Sales %' },
]

const ProductCampaignTableComponent = () => {
  const dispatch = useDispatch()
  const store = useStore()

  const {
    header: {
      currencyRate,
      currencySign,
    },
    pageGlobal: {
      showAPM,
      showTemplateEditor,
      productCampaignTableColumns,
    },
    product: {
      campaignsForProduct,
    },
  } = store.getState()

  const handleAPMShow = (campaign) => {
    dispatch(showAPMAction(campaign.campaign_id))
  }

  const renderRecord = (record) => {
    let targetingType
    if (record.campaignType === 'Sponsored Products') {
      if (record.targeting_type === 'auto') {
        targetingType = 'Auto'
      } else {
        targetingType = 'Manual'
      }
    }

    return (
      <>
        <div className="table-col col-campaign">
          <div className="campaign-status">
            <div className={`status ${record.state === 'enabled' ? 'on' : 'off'}`}>
              <div className="bullet"></div>
              <span>{ stateLabels[record.state] }</span>
            </div>
            <div className={`status ${record.is_ap_active ? 'on' : 'off'}`}>
              <div className="bullet"></div>
              <span>Smart Pilot { record.is_ap_active ? 'On' : 'Off' }</span>
            </div>
            <MoreApmSvg
              title="Open Smart Pilot"
              onClick={() => { handleAPMShow(record) }}
            />
          </div>
          <Link
            to={`/campaign/${record.campaign_id}/${record.campaignType}`}
            className="campaign-name"
            title={record.campaign}
          >
            { record.campaign }
          </Link>
          <div className="campaign-detail">
            {
              targetingType && <span>{ targetingType }</span>
            }
            <span>
              { campaignTypeMap[record.campaignType] }
            </span>
          </div>
        </div>
        {
          columns.map((column) => {
            if (column.key === 'campaign') {
              return null
            }
            return (
              <TableCell
                key={column.key}
                record={record}
                columnKey={column.key}
                columnSelection={productCampaignTableColumns}
                currencySign={currencySign}
                currencyRate={currencyRate}
              />
            )
          })
        }
      </>
    )
  }

  const renderTotal = (summary) => {
    summary.roas = 0
    summary.ntb_orders_percent = 0
    summary.ntb_sales_percent = 0

    if (parseFloat(summary.cost || 0)) {
      summary.roas = parseFloat(summary.revenue || 0)
        / parseFloat(summary.cost || 0)
    }
    if (parseInt(summary.orders || 0, 10)) {
      summary.ntb_orders_percent = parseInt(summary.ntb_orders || 0, 10)
        / parseInt(summary.orders || 0, 10) * 100
    }
    if (parseFloat(summary.revenue || 0)) {
      summary.ntb_sales_percent = parseFloat(summary.ntb_sales || 0)
        / parseFloat(summary.revenue || 0) * 100
    }

    return (
      <>
        <div className="table-col col-campaign">
          Totals:
        </div>
        {
          columns.map((column) => {
            if (column.key === 'campaign') {
              return null
            }
            return (
              <TableCell
                key={column.key}
                record={summary}
                columnKey={column.key}
                columnSelection={productCampaignTableColumns}
                currencySign={currencySign}
                currencyRate={currencyRate}
              />
            )
          })
        }
      </>
    )
  }

  return (
    <>
      <SortableTable
        columns={columns}
        defaultSort={['cost', 'desc']}
        sorter={tableSorter(['campaign'])}
        className="table-campaigns"
        records={campaignsForProduct || []}
        idField="campaign_id"
        searchFields={['campaign']}
        noCheckBox
        paginationSelectPlacement="top"
        hasSticky
        filterName="productCampaignTable"
        columnEditorId="productCampaign"
        columnEditorNoReset={false}
        columnList={productCampaignColumnList}
        columnSelection={productCampaignTableColumns}
        renderRecord={renderRecord}
        renderTotal={renderTotal}
      />
      { showAPM && <APMComponent /> }
      { showTemplateEditor && <TemplateEditorComponent /> }
    </>
  )
}

export default ProductCampaignTableComponent
