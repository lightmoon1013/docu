import React, { useState } from 'react'
import { useStore, useDispatch } from 'react-redux'
import moment from 'moment'

import LoaderComponent from '../CommonComponents/LoaderComponent'
import ProductTestingDetailComponent from './testing-detail'
import ProductTestingAddComponent from './testing-add'

import { getTestById, getTestStatsById } from '../../redux/actions/productDetail'

const ProductTestingComponent = () => {
  const dispatch = useDispatch()
  const store = useStore()
  const { product, productDetail } = store.getState()
  const { tests, isAddingNewTest } = productDetail
  const { curProduct } = product

  const [ showAddModal, setShowAddModal ] = useState(false)
  const [ showDetailModal, setShowDetailModal ] = useState(false)
  const [ searchKey, setSearchKey ] = useState('')

  const onDetailTest = (test) => {
    const startDate = moment(test['from_date']).format('YYYY-MM-DD')
    const endDate = moment(test['to_date']).format('YYYY-MM-DD')
    const period = moment(endDate).diff(startDate, 'days')
    const prevStartDate = moment(startDate).subtract(period, 'days').format('YYYY-MM-DD')

    dispatch(getTestById(test['id']))
    dispatch(getTestStatsById(
      curProduct['id'],
      startDate,
      endDate,
      prevStartDate))
    setShowDetailModal(true)
  }


  const testElements = tests.map((data) => {
    if (!data['name'].toLowerCase().includes(searchKey.toLowerCase())) {
      return null
    }

    const subClass = data['green'] ? 'green' : (data['yellow'] ? 'yellow' : '')

    return (
      <div key={data.id} className={"table-row " + subClass} onClick={ () => onDetailTest(data) }>
        <div className="table-col">{data['name']}</div>
        <div className="table-col">{moment(data['from_date']).format('YYYY-MM-DD')}</div>
        <div className="table-col">{moment(data['to_date']).format('YYYY-MM-DD')}</div>
      </div>
    )
  })

  return (
    <div className={`product-detail-testing ${isAddingNewTest ? 'loading' : ''}`}>
      { isAddingNewTest && <LoaderComponent /> }
      <ProductTestingAddComponent
        show={showAddModal}
        onClose={() => { setShowAddModal(false) }}
      />
      <ProductTestingDetailComponent
        show={showDetailModal}
        onClose={() => { setShowDetailModal(false) }}
      />
      <div className="testing-header">
        Click on add A/B test to start.
        You will then name your test, select the length (in days) of your test,
        and enter the before and after values you are testing.
      </div>
      <div className="testing-content">
        <div className="testing-search">
          <input
            type="text"
            value={searchKey}
            placeholder="Search Test"
            onChange={(e)=> { setSearchKey(e.target.value) }}
          />
          <button
            type="button"
            className="btn btn-red"
            onClick={() => { setShowAddModal(true) }}
          >
            Add A/B Test
          </button>
        </div>
        <div className="table-header">
          <div className="table-row">
            <div className="table-col">NAME</div>
            <div className="table-col">DATE STARTED</div>
            <div className="table-col">DATE FINISHED</div>
          </div>
        </div>
        <div className="table-body">
          { testElements }
        </div>
      </div>
    </div>
  )
}

export default ProductTestingComponent
