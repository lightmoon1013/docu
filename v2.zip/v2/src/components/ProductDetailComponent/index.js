import React, { useState, useEffect } from 'react'
import { useDispatch, useStore } from 'react-redux'
import { useParams } from 'react-router-dom'
import moment from 'moment'
import OutsideClickHandler from 'react-outside-click-handler'
import { Tooltip, Whisper } from 'rsuite'

import MainLayout from '../../layout/MainLayout'
import LoaderComponent from '../CommonComponents/LoaderComponent'
import VideoLink from '../CommonComponents/VideoLink'
import ProductDashboardComponent from './dashboard'
import ProductKeywordComponent from './keyword'
import ProductTestingComponent from './testing'
import ProductFilterComponent from './product-filter'

import { ReactComponent as ArrowDownSvg } from '../../assets/svg/arrow-down.svg'
import { ReactComponent as InfoSvg } from '../../assets/svg/info.svg'
import { ReactComponent as ChromeLogo } from '../../assets/svg/chrome-logo.svg'

import {
  getProductById,
  updateProductMargin,
  getCampaignsForProduct,
} from '../../redux/actions/product'

import {
  formatValue
} from '../../services/helper'

const videoList = [
  { title: 'Product Dashboard Video', url: 'https://www.loom.com/embed/0ec635b02a3543f8aa353d607250b3bb' },
]

const ProductDetailComponent = () => {
  const store = useStore()
  const dispatch = useDispatch()
  const params = useParams()

  const { header, product, productDetail } = store.getState()

  const {
    currentStartDate,
    currentEndDate,
  } = header

  const {
    isProductLoading,
    isProductKpiLoading,
    isUpdateProductMargin,
    curProduct,
    curProductKpi,
  } = product

  const { isFiltering, isUpdatingKeyword } = productDetail
  const [ currentTab, setCurrentTab ] = useState('dashboard')
  const [ showProductFilter, setShowProductFilter ] = useState(false)
  const [ productCog, setProductCog ] = useState(0)

  useEffect(() => {
    if (!curProduct || !curProduct['cog']) {
      return
    }
    setProductCog(formatValue(curProduct['cog'], 'number'))
  }, [dispatch, curProduct])

  useEffect(() => {
    const { id, sku } = params
    dispatch(getProductById({
      id,
      sku,
      startDate: moment(currentStartDate).format('YYYY-MM-DD'),
      endDate: moment(currentEndDate).format('YYYY-MM-DD'),
    }))

    const ele = document.getElementsByClassName('main-content')[0]
    ele.scrollTo({
      top: 0,
      left: 0
    })
  }, []) // eslint-disable-line

  useEffect(() => {
    const { id } = params
    dispatch(getCampaignsForProduct(id))
  }, [dispatch, currentStartDate, currentEndDate]) // eslint-disable-line

  const onDownload = () => {
    window.open("https://chrome.google.com/webstore/detail/ppc-entourage-kw-index-ch/cclbjbpflgdponoegbmgkcicpjjdikci")
  }

  const onUpdateAcos = () => {
    dispatch(updateProductMargin(productCog))
  }

  const isLoading = isProductLoading
    || isProductKpiLoading
    || isFiltering
    || isUpdateProductMargin
    || isUpdatingKeyword

  return (
    <MainLayout>
      <div className={`product-detail-component${isLoading ? ' loading' : ''}`}>
        { isLoading && <LoaderComponent /> }
        <div className="page-header">
          { showProductFilter &&
            <OutsideClickHandler onOutsideClick={() => { setShowProductFilter(false) }}>
              <ProductFilterComponent onClose={()=> { setShowProductFilter(false) }} />
            </OutsideClickHandler>
          }
          <div className="page-title-wrapper">
            <div className="page-title" onClick={() => { setShowProductFilter(true) }}>
              {
                curProduct['image_sm'] && curProduct['image_sm'] !== '' ? (
                  <>
                    <img src={ curProduct['image_sm'] } alt={ curProduct['product-name'] }/>
                    <span>{ curProduct['product-name'] }</span>
                  </>
                ) : (
                  <span className="no-image">{curProduct['product-name']}</span>
                )
              }
              <ArrowDownSvg />
            </div>
            <div className="button-wrapper">
              <a
                href={curProduct.url}
                className="btn btn-white"
                target="_blank"
                rel="noreferrer noopener"
              >
                Open in Amazon
              </a>
              <VideoLink
                videoList={videoList}
                modalTitle='Product Dashboard'
              />
            </div>
          </div>
        </div>
        <div className="page-tabs">
          <div className="tab-left">
            <button type="button" className={ currentTab === 'dashboard' ? "page-tab selected" : "page-tab" } onClick={() => setCurrentTab('dashboard')}>Dashboard</button>
            <button type="button" className={ currentTab === 'keyword' ? "page-tab selected" : "page-tab" } onClick={() => setCurrentTab('keyword')}>Keyword Tracking</button>
            <button type="button" className={ currentTab === 'testing' ? "page-tab selected" : "page-tab" } onClick={() => setCurrentTab('testing')}>A/B Split Testing</button>
          </div>
          <div className="tab-right">
            <button type="button" className="btn-download" onClick={onDownload}>
              <ChromeLogo />Download Chrome Extension
            </button>
            <Whisper placement="left" trigger="hover" speaker={(
                <Tooltip>
                  <p>Download and install the PPC Entourage Chrome Extension to check your keywords indexing and track keyword ranking.</p>
                </Tooltip>
              )}>
              <InfoSvg />
            </Whisper>
          </div>
        </div>
        { currentTab === 'dashboard' &&
          <ProductDashboardComponent
            curProductKpi = { curProductKpi }
            curProduct = { curProductKpi }
            productCog = { productCog }
            setProductCog = { setProductCog }
            isProductLoading = { isProductLoading }
            isProductKpiLoading = { isProductKpiLoading }
            onUpdateAcos = { onUpdateAcos }
          />
        }
        { currentTab === 'keyword' &&
          <ProductKeywordComponent />
        }
        { currentTab === 'testing' &&
          <ProductTestingComponent />
        }
      </div>
    </MainLayout>
  )
}

export default ProductDetailComponent
