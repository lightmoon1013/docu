/*global chrome*/
import React, { useEffect, useState } from 'react'
import { useDispatch, useStore } from 'react-redux'
import moment from 'moment'

import DateRangeComponent from '../CommonComponents/DateRangeComponent'

import ProductKeywordBelowComponent from './keyword-below'
import ProductKeywordAboveComponent from './keyword-above'
import ProductKeywordZeroComponent from './keyword-zero'
import ProductKeywordTrackComponent from './keyword-track'

import {
  setDateRange,
} from '../../redux/actions/header'

import {
  filterTargetAcosKeywords,
  filterKeywordWithZeroImpression,
  filterOrganicKeywords
} from '../../redux/actions/productDetail'

import { EXTENSION_ID } from '../../utils/defaultValues'

const ProductKeywordComponent = () => {
  const dispatch = useDispatch()
  const store = useStore().getState()

  const {
    product: { curProduct },
    header: {
      currentUserId,
      currentStartDate,
      currentEndDate,
    },
  } = store

  const [isExtensionInstalled, setIsExtensionInstalled] = useState(false)
  const [activeTab, setActiveTab] = useState('zero')

  const tabs = [
    { value: 'below', label: 'Below Target ACoS'},
    { value: 'above', label: 'Above Target ACoS'},
    { value: 'zero', label: 'Targets With Zero Impressions'},
    { value: 'track', label: 'Track Organic Position'}
  ]

  useEffect(() => {
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
      chrome.runtime.sendMessage(EXTENSION_ID, { type: 'checkIfExtensionInstalled' }, function (response) {
        if (chrome.runtime.lastError) {
          return
        }
        if (response && response.success === true) {
          setIsExtensionInstalled(true)
        }
      });
    }
  })

  useEffect(() => {
    dispatch(filterTargetAcosKeywords({
      id: curProduct['id'],
      sku: curProduct['sku'],
      userId: currentUserId,
      currentStartDate,
      currentEndDate
    }))
    dispatch(filterKeywordWithZeroImpression({
      id: curProduct['id'],
      sku: curProduct['sku'],
      userId: currentUserId,
      currentStartDate,
      currentEndDate
    }))
    dispatch(filterOrganicKeywords({
      id: curProduct['id'],
      sku: curProduct['sku'],
      userId: currentUserId,
      currentStartDate,
      currentEndDate
    }))
  }, [dispatch, curProduct, currentUserId, currentStartDate, currentEndDate])

  const handleChangeDateRange = ([startDate, endDate]) => {
    dispatch(
      setDateRange({
        startDate: moment(startDate).format('YYYY-MM-DD'),
        endDate: moment(endDate).format('YYYY-MM-DD'),
      })
    )
  }

  return (
    <div className="product-detail-keyword">
      <div className="detail-keyword-header">
        <div className="keyword-tabs">
          {
            tabs.map(tab => (
              <div
                key={tab.value}
                className={`tab${activeTab === tab.value ? ' selected' : ''}`}
                onClick={() => { setActiveTab(tab.value) }}
              >
                { tab.label }
              </div>
            ))
          }
        </div>
        <DateRangeComponent
          onChange={handleChangeDateRange}
          value={[currentStartDate, currentEndDate]}
        />
      </div>
      <div className="detail-keyword-content">
        {activeTab === 'below' &&
          <ProductKeywordBelowComponent isExtensionInstalled={isExtensionInstalled} />
        }
        {activeTab === 'above' &&
          <ProductKeywordAboveComponent isExtensionInstalled={isExtensionInstalled} />
        }
        {activeTab === 'zero' &&
          <ProductKeywordZeroComponent isExtensionInstalled={isExtensionInstalled} />
        }
        {activeTab === 'track' &&
          <ProductKeywordTrackComponent isExtensionInstalled={isExtensionInstalled} />
        }
      </div>
    </div>
  )
}

export default ProductKeywordComponent
