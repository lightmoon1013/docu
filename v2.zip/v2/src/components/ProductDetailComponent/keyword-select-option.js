/*global chrome*/
import React, { useState } from 'react'
import { useDispatch, useStore } from 'react-redux'
import Select from 'react-select'
import { toast } from '../../components/CommonComponents/ToastComponent/toast'

import ImgCheck from '../../assets/img/check.png'
import ImgClipboard from '../../assets/img/clipboard.png'
import ImgList from '../../assets/img/list.png'

import {
  enableKeywordOrganicRankTrackingBulk,
  updateKeywordsState
} from '../../redux/actions/productDetail'

import { EXTENSION_ID } from '../../utils/defaultValues'
import { copyToClipboard } from '../../services/helper'

const KeywordOptionComponent = ({clipboard, keywordChecking}) => {
  const dispatch = useDispatch()
  const store = useStore().getState()
  const { product, productDetail } = store

  const { curProduct } = product
  const { targetAcosKeywords } = productDetail

  const [changeState, setChangeState] = useState()

  const idList = []
  for (const [key, value] of Object.entries(keywordChecking)) {
    if (value) {
      idList.push(key)
    }
  }

  const options = [
    {value: 'enabled', label: 'Active'},
    {value: 'paused', label: 'Pause'},
    {value: 'archived', label: 'Archive'}
  ]

  const onTrackOrganicRank = () => {
    let keywordIds = []

    for (let i in keywordChecking) {
      if (keywordChecking[i]) {
        keywordIds.push(i)
      }
    }
    if (keywordIds.length === 0) {
      toast.show({
        title: 'Warning',
        description: 'Please select the keywords.',
      })
      return
    }
    dispatch(enableKeywordOrganicRankTrackingBulk(keywordIds))
  }

  const onCheckIndex = () => {
    if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) {
      toast.show({
        title: 'Warning',
        description: 'Extension is disabled, therefore buttons are inactive',
      })
      return
    }
    const arykeywordsToChecking = targetAcosKeywords.map(keyword => idList.indexOf(keyword.keyword_id) !== -1)
    if (!arykeywordsToChecking || arykeywordsToChecking.length === 0) {
      toast.show({
        title: 'Warning',
        description: "Please select the keywords.",
      })
      return
    }
    const filteredKeywords = arykeywordsToChecking.filter(keyword => keyword.keyword !== '(_targeting_auto_)')
    if (filteredKeywords.length < arykeywordsToChecking.length) {
      toast.show({
        title: 'Warning',
        description: "Returns on auto campaigns can't be checked.",
      })
      if (filteredKeywords.length === 0) {
        return
      }
    }
    const keywordsToCheck = filteredKeywords.map(keyword => ({
      type: 'checkIndexing',
      keyword: keyword.keyword,
      userId: keyword.user_id,
      asin: curProduct.asin,
      isKeyword: true
    }))

    chrome.runtime.sendMessage(EXTENSION_ID, {
      type: 'CHECK_KEYWORDS_INDEXING',
      payload: keywordsToCheck
    }, (response) => {
      if (chrome.runtime.lastError) {
        toast.show({
          title: 'Warning',
          description: 'Extension is disabled, therefore buttons are inactive',
        })
      } else {
        switch (response) {
          case 'extensionDisabled': {
            toast.show({
              title: 'Warning',
              description: 'Extension is disabled. Please enable it to check your keywords indexing and organic positions.',
            })
            break
          }
          default: {
            toast.show({
              title: 'Info',
              description: 'Entourage is checking the keyword\'s indexing.',
            })
          }
        }
      }
    })

  }
  const onChangeState = (st) => {
    setChangeState(st)
    let keywordIds = []

    for (let i in keywordChecking) {
      if (keywordChecking[i]) {
        keywordIds.push(i)
      }
    }

    dispatch(updateKeywordsState({value: st.value, keywordIds}))
  }
  const onCopy = () => {
    copyToClipboard(clipboard)
    toast.show({
      title: 'Success',
      description: 'Successfully copied.',
    })
  }

  return (
    <div className="keyword-option-component">
      <div className="option-col" onClick={onCopy}>
        <img alt="copy-to-clipboard" src={ImgClipboard} />
        <span>Copy</span>
      </div>
      <div className="option-col" onClick={onCheckIndex}>
        <img alt="check-index" src={ImgCheck} />
        <span>Check Indexing</span>
      </div>
      <div className="option-col" onClick={onTrackOrganicRank}>
        <img alt="track-organic-rank" src={ImgList} />
        <span>Track Organic Rank</span>
      </div>
      <div className="option-col">
        <Select classNamePrefix="keyword-status-select" options={options} placeholder="Change State" value={changeState} onChange={onChangeState} />
      </div>
    </div>
  )
}

export default KeywordOptionComponent
