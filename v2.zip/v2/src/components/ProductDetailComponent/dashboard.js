import React from 'react'
import { useStore } from 'react-redux'

import ProductChartComponent from './ProductChartComponent'
import ProductCampaignTable from './ProductCampaignTable'

import {
  formatCurrency,
  formatValue
} from '../../services/helper'

const ProductDashboardComponent = ({curProductKpi, productCog, setProductCog, onUpdateAcos}) => {
  const store = useStore().getState()

  const {
    header,
    product,
  } = store

  const {
    currencyRate,
    currencySign,
  } = header

  const {
    curProduct,
  } = product

  const isSame = formatValue(curProduct['cog'], 'number') === productCog

  return (
    <div className="product-detail-dashboard">
      <div className="section">
        <div className="block-info">
          <div className="info-row">
            <div className="input-row">
              <span>Cost of goods</span>
              <input type="number" min="0" value={ productCog } onChange={e => setProductCog(e.target.value)} />
              { !isSame && <button type="button" className="page-button-new" onClick={ onUpdateAcos }>Save</button> }
            </div>
            <div className="input-row">
              <span>Average selling price ({currencySign})</span>
              <input type="number" value={ formatValue(curProductKpi && curProductKpi['average_selling_price'] ? curProductKpi['average_selling_price'] : 0, 'number', 2)  } disabled />
            </div>
            <div className="input-row">
              <span>Profit margin</span>
              <input type="number" value={ formatValue(curProductKpi && curProductKpi['profit_margin'] ? curProductKpi['profit_margin'] : 0, '', 2) } disabled />
            </div>
            <div className="input-row">
              <span>Profit margin (%)</span>
              <input type="number" value={ formatValue(curProductKpi && curProductKpi['profit_percent'] ? curProductKpi['profit_percent'] : 0, 'number', 2) } disabled />
            </div>
          </div>
        </div>
        <div className="statistics-cards">
          <div className="statistics-cards-row">
            <div className="statistics-card">
              <div className="statistics-card-name">Organic Revenue</div>
              <div className="statistics-card-value">{ formatCurrency(curProductKpi ? ( isFinite(curProductKpi['ppcrevenue']) ? curProductKpi['total_sale'] - curProductKpi['ppcrevenue'] : 0 ) : 0, currencySign, currencyRate) }</div>
            </div>
            <div className="statistics-card">
              <div className="statistics-card-name">PPC Revenue</div>
              <div className="statistics-card-value">{ formatCurrency(curProductKpi && curProductKpi['ppcrevenue'] ? curProductKpi['ppcrevenue'] : 0, currencySign, currencyRate)  }</div>
            </div>
            <div className="statistics-card">
              <div className="statistics-card-name">Spend</div>
              <div className="statistics-card-value">{ formatCurrency(curProductKpi && curProductKpi['cost'] ? curProductKpi['cost'] : 0, currencySign, currencyRate)}</div>
            </div>
            <div className="statistics-card">
              <div className="statistics-card-name">Impressions</div>
              <div className="statistics-card-value">{ formatValue(curProductKpi && curProductKpi['impressions'] ? curProductKpi['impressions'] : 0, 'number', 0) }</div>
            </div>
          </div>
          <div className="statistics-cards-row">
            <div className="statistics-card">
              <div className="statistics-card-name">Orders</div>
              <div className="statistics-card-value">{ formatValue(curProductKpi && curProductKpi['orders'] ? curProductKpi['orders'] : 0, 'number', 0) }</div>
            </div>
            <div className="statistics-card">
              <div className="statistics-card-name">Clicks/CTR</div>
              <div className="statistics-card-value">{`${formatValue(curProductKpi && curProductKpi['clicks'] ? curProductKpi['clicks'] : 0, 'number', 0)}/${formatValue(curProductKpi && curProductKpi['ctr'] ? curProductKpi['ctr'] : 0, 'percent', 2)}`}</div>
            </div>
            <div className="statistics-card">
              <div className="statistics-card-name">Conversion Rate</div>
              <div className="statistics-card-value">
                { formatValue(curProductKpi ? !isFinite(curProductKpi['orders'] / curProductKpi['clicks'] * 100) ? 0 : curProductKpi['orders'] / curProductKpi['clicks'] * 100 : 0, 'percent', 2) }
              </div>
            </div>
            <div className="statistics-card">
              <div className="statistics-card-name">ACOS</div>
              <div className="statistics-card-value">
                { formatValue(curProductKpi ? !isFinite(curProductKpi['cost'] / curProductKpi['revenue'] * 100) ? 0 : curProductKpi['cost'] / curProductKpi['revenue'] * 100 : 0, 'percent', 1) }
              </div>
            </div>
          </div>
        </div>
        <div className="block-chart">
          <ProductChartComponent
            revenue = { curProductKpi && curProductKpi['total_sale'] ? curProductKpi['total_sale'] * currencyRate : 0 }
            orders = { curProductKpi && curProductKpi['orders'] ? curProductKpi['orders'] : 0 }
            clicks = { curProductKpi && curProductKpi['clicks'] ? curProductKpi['clicks'] : 0 }
          />
        </div>
      </div>
      <div className="section">
        <ProductCampaignTable />
      </div>
    </div>
  )
}

export default ProductDashboardComponent
