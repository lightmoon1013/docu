import React, { useState } from 'react'
import { useStore, useDispatch } from 'react-redux'
import { Toggle, Radio, Tooltip, Whisper } from 'rsuite'
import { BsCaretUpFill, BsCaretDownFill } from 'react-icons/bs'

import { ReactComponent as InfoSvg } from '../../assets/svg/info.svg'

import {
  formatValue,
  formatCurrency,
  tableSorter,
} from '../../services/helper'

import {
  enableKeywordOrganicRankTracking,
  disableKeywordOrganicRankTracking
} from '../../redux/actions/productDetail'

import ImgLock from '../../assets/img/lock.png'

const ProductKeywordZeroComponent = ({isExtensionInstalled}) => {
  const store = useStore().getState()
  const dispatch = useDispatch()
  const { header, productDetail } = store
  const { zeroImprKeywords } = productDetail
  const { currencyRate, currencySign } = header

  const [searchKey, setSearchKey] = useState('')

  const [sortColumnName, setSortColumnName] = useState('')
  const [sortDirection, setSortDirection] = useState('asc')

  const columns = [
    {
      name: 'keyword',
      label: 'Keyword'
    },
    {
      name: 'ad_group_name',
      label: 'Ad Group'
    },
    {
      name: 'campaign_name',
      label: 'Campaign'
    },
    {
      name: 'match1',
      label: 'Match',
    },
    {
      name: 'keyword_bid',
      label: 'Keyword Bid',
    }
  ]

  const onOrganicRankClick = (keyword) => {
    if (keyword['auto_organic_rank_checking']) {
      dispatch(disableKeywordOrganicRankTracking({
        keyword: keyword['keyword']
      }))
    } else {
      dispatch(enableKeywordOrganicRankTracking({
        keyword: keyword['keyword']
      }))
    }
  }

  const sortColumn = (field) => {
    setSortDirection(sortColumnName === field && sortDirection === 'asc' ? 'desc' : 'asc')
    setSortColumnName(field)
  }

  const filteredKeywords = tableSorter(['keyword', 'ad_group_name', 'campaign_name', 'match1'])(zeroImprKeywords, [sortColumnName, sortDirection])
  const rowElements = filteredKeywords.map((keyword) => (
    <div className="table-row" key={keyword['keyword_id']}>
      <div className="table-col min-width-100">{keyword['keyword']}</div>
      <div className="table-col">{keyword['ad_group_name']}</div>
      <div className="table-col min-width-300">{keyword['campaign_name']}</div>
      <div className="table-col">{keyword['match1']}</div>
      <div className="table-col">{keyword['keyword_bid']}</div>
      <div className="table-col">{formatCurrency(keyword['avcpc'], currencySign, currencyRate)}</div>
      <div className="table-col min-width-100">{formatCurrency(keyword['max_cpc'], currencySign, currencyRate)}</div>
      <div className="table-col">{formatCurrency(keyword['revenue'], currencySign, currencyRate)}</div>
      <div className="table-col">{formatCurrency(keyword['cost'], currencySign, currencyRate)}</div>
      <div className="table-col">{formatValue(keyword['acos'], 'number', 2)}</div>
      <div className="table-col">{formatValue(keyword['impressions'], 'number', 0)}</div>
      <div className="table-col">{formatValue(keyword['clicks'], 'number', 0)}</div>
      <div className="table-col">
        {isExtensionInstalled ?
          <Toggle checked={keyword['auto_organic_rank_checking']} onChange={()=>onOrganicRankClick(keyword)} />
          :
          <Whisper
            trigger="hover"
            placement="auto"
            speaker={
              <Tooltip>
                <p>Install the 'PPC Entourage Chrome Extension' to enable product rank tracking
                property</p>
              </Tooltip>
            }
          >
            <img alt={keyword['keyword']} src={ImgLock} />
          </Whisper>
        }
      </div>
      <div className="table-col">
        {isExtensionInstalled ?
          <Radio checked={keyword['indexing_last_check_date']} />
          :
          <Whisper
            trigger="hover"
            placement="auto"
            speaker={
              <Tooltip>
                <p>Install the 'PPC Entourage Chrome Extension' to see and check the indexing statuses
                property</p>
              </Tooltip>
            }
          >
            <img alt={keyword['keyword']} src={ImgLock} />
          </Whisper>
        }
      </div>
    </div>
  ))

  return (
    <>
      <div className="content-header">
        <input type="text" className="header-search" placeholder="Search..." value={searchKey} onChange={(e)=>setSearchKey(e.target.value)} />
      </div>
      <div className="keyword-table">
        <div className="table-header table-row">
          {
            columns.map((column) => {
              if (column.name !== 'max_cpc') {
                return (
                  <div key={column.name} className={`table-col ${column.name === 'campaign_name' ? 'min-width-300' :  column.name === 'keyword' ? 'min-width-100' : ''}`} onClick={() => { sortColumn(column.name) }}>
                    {column.label}
                    {
                      sortColumnName === column.name && (
                        sortDirection === 'asc' ? <BsCaretUpFill /> : <BsCaretDownFill />
                      )
                    }
                  </div>
                )
              } else {
                return (
                  <div key="max_cpc" className="table-col min-width-100" onClick={() => { sortColumn('max_cpc') }}>
                    Max CPC
                    {
                      sortColumnName === 'max_cpc' && (
                        sortDirection === 'asc' ? <BsCaretUpFill /> : <BsCaretDownFill />
                      )
                    }
                    <Whisper placement="right" trigger="hover" speaker={(
                      <Tooltip>
                        <p>The maximum one can spend per click to break even with PPC.</p>
                        <p>Takes into account the products profit margins and the average amount of clicks to get an order.</p>
                      </Tooltip>
                    )}>
                      <InfoSvg />
                    </Whisper>
                  </div>
                )
              }
            })
          }
          <div className="table-col">Organic Rank Tracker</div>
          <div className="table-col">Indexing State</div>
        </div>
        <div className="table-content">
          {rowElements}
        </div>
      </div>
    </>
  );
}

export default ProductKeywordZeroComponent
