import React, { useState } from 'react'
import { useDispatch, useStore } from 'react-redux'
import { Radio, RadioGroup, DatePicker } from 'rsuite'
import moment from 'moment'
import CheckboxComponent from '../CommonComponents/CheckboxComponent'

import { Modal } from 'rsuite'

import LoaderComponent from '../CommonComponents/LoaderComponent'
import { toast } from '../CommonComponents/ToastComponent/toast'

import {
  createBudgetRule
} from '../../redux/actions/campaign'


const CreateScheduleBasedBudgetRuleModal = ({ campaigns, show, onSelect, onClose }) => {

  const dispatch = useDispatch()
  const store = useStore()

  const { campaign } = store.getState()
  const { isCreateBudgetRuleLoading } = campaign

  const [budgetInfo, setBudgetInfo] = useState({
    name: ''
  })

  const [increaseValue, setIncreaseValu] = useState(1)
  const [dateRange, setDateRange] = useState({
    startDate: new Date(),
    endDate: null,
  })
  const [daysOfWeek, setDaysOfWeek] = useState({
    MONDAY: false,
    TUESDAY: false,
    WEDNESDAY: false,
    THURSDAY: false,
    FRIDAY: false,
    SATURDAY: false,
    SUNDAY: false
  })
  const [recurrence, setRecurrence] = useState('daily')

  const handleClose = () => {
    onClose()
  }

  const handleCreateNewBudgetRule = () => {

    let budgetDays = []
    Object.keys(daysOfWeek).filter((key)=> {
      return key
    }).map((key) => {
      if (daysOfWeek[key] === true) {
        budgetDays.push(key)
      }
      return true
    })
    if (!budgetInfo.name) {
      toast.show({
        title: 'Warning',
        description: 'Please enter the rule name.',
      })
      return
    }

    let isSameBudgetName = false
    campaigns.map((campaign) => {
      if(campaign.budgetRule && campaign.budgetRule === budgetInfo.name) {
        isSameBudgetName = true
      }
      return true
    })

    if (isSameBudgetName) {
      toast.show({
        title: 'Warning',
        description: 'Some campaigns already have this budget name.',
      })
      return
    }

    if (!dateRange.startDate) {
      toast.show({
        title: 'Warning',
        description: 'Please enter the start date.',
      })
      return
    }

    if (recurrence === 'weekly' && budgetDays.length === 0) {
      toast.show({
        title: 'Warning',
        description: 'Please select effective days.',
      })
      return
    }

    if (increaseValue === 0) {
      toast.show({
        title: 'Warning',
        description: 'Please choose an increase.',
      })
      return
    }

    if (increaseValue < 0) {
      toast.show({
        title: 'Warning',
        description: "Please enter a positive increase.",
      })
      return
    }

    let budgetRule = {
      name: budgetInfo.name,
      ruleType: 'SCHEDULE',
      budgetIncreaseBy: {
        type: "PERCENT",
        value: increaseValue
      }
    }
    if (recurrence === 'daily') {
      budgetRule.recurrence = {
        type: 'DAILY'
      }
    } else {
      budgetRule.recurrence = {
        type: 'WEEKLY',
        daysOfWeek: budgetDays
      }
    }
    if (dateRange.endDate) {
      let dateRangeTypeRuleDuration = {
        dateRangeTypeRuleDuration: {
          startDate: moment(dateRange.startDate).format('YYYYMMDD'),
          endDate: moment(dateRange.endDate).format('YYYYMMDD'),
        }
      }
      budgetRule.duration = dateRangeTypeRuleDuration
    } else {
      let dateRangeTypeRuleDuration = {
        dateRangeTypeRuleDuration: {
          startDate: moment(dateRange.startDate).format('YYYYMMDD'),
        }
      }
      budgetRule.duration = dateRangeTypeRuleDuration
    }


    dispatch(createBudgetRule(
      budgetRule
    )).then((response) => {
      if (response.length > 0) {
        let createdBudgets = {}
        response.map((budget) => {
          if (budget.campaignType === 'SD') {
            createdBudgets.sdbudget = budget
          } else if (budget.campaignType === 'SP') {
            createdBudgets.spbudget = budget
          } else {
            createdBudgets.sbbudget = budget
          }
          return true
        })

        onSelect(createdBudgets)
      } else {
        toast.show({
          title: 'Danger',
          description: 'Failed to create a budget rule.',
        })
        onClose()
      }
    }).catch((error) => {
      toast.show({
        title: 'Danger',
        description: 'Failed to create a budget rule.',
      })
    })
  }

  const handleDateRange = (name, value) => {
    const newInfo = Object.assign({}, dateRange, {
      [name]: value,
    })
    setDateRange(newInfo)
  }

  const handleDaysOfWeek = (value, day) => {
    const newInfo = Object.assign({}, daysOfWeek, {
      [day]: value,
    })
    setDaysOfWeek(newInfo)
  }

  const handleBudgetInfo = (name, value) => {
    const newInfo = Object.assign({}, budgetInfo, {
      [name]: value,
    })
    setBudgetInfo(newInfo)
  }

  const isLoading = isCreateBudgetRuleLoading

  return (
    <Modal className={`ucname-selector-modal${isLoading ? ' loading' : ''}`} backdrop="static" show={show} size="md">
      <Modal.Header onHide={() => { handleClose()}}>
        <Modal.Title>
          <div className="ucname-modal-title">
            Scheduled Budget Rules
          </div>
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
      { isLoading && <LoaderComponent /> }
        <div className="create-budget-rule-modal-body">
          <div className="field-row">
            <div className="left-field-title">
              <span className="input-prefix mt-8">Rule Name</span>
            </div>
            <div className="right-field-content bd-name">
              <input
                type="text"
                className="shrinked-input ml-10"
                value={budgetInfo.name}
                placeholder = "Example: Valentine's Day rule"
                onChange={(event) => { handleBudgetInfo('name', event.target.value) }}
              />
            </div>
          </div>
          <div className="field-empty"></div>
          <div className="field-row">
            <div className="left-field-title">
              <span className="input-prefix">Type</span>
            </div>

            <div className="right-field-content">
              <div className="field-title ml-10">
                <span className="input-prefix">Schedule</span>

              </div>
              <div className="field-note ml-10">
                <span className="input-suffix">Increase your budget during high-traffic or specific date ranges</span>

              </div>
            </div>

          </div>
          <div className="field-empty"></div>
          <div className="field-row">
            <div className="left-field-title">
              <span className="input-prefix">Date range</span>
            </div>

            <div className="right-field-content">
              <div className="field-row">
                <div className="field-wrapper">
                  <div className="field-name">
                    Start Date
                  </div>
                  <DatePicker
                    value={dateRange.startDate}
                    format="MMM D, YYYY"
                    oneTap
                    disabledDate={date => moment(date).isBefore(moment().startOf('day')) }
                    onChange={(date) => { handleDateRange('startDate', date) }}
                  />
                </div>

                <div className="field-wrapper ml-30">
                  <div className="field-name">
                    End Date
                  </div>
                  <DatePicker
                    value={dateRange.endDate}
                    format="MMM D, YYYY"
                    oneTap
                    disabledDate={date => moment(date).isBefore(moment(dateRange.startDate)) }
                    onChange={(date) => { handleDateRange('endDate', date) }}
                  />
                </div>

              </div>
            </div>

          </div>
          <div className="field-empty"></div>
          <div className="field-row">
            <div className="left-field-title">
              <span className="input-prefix mt-8">Recurrence</span>
            </div>

            <div className="right-field-content">
              <div className="field-note ml-10">
                <RadioGroup
                  value={recurrence}
                  onChange={setRecurrence}
                >
                  <Radio value="daily">Daily</Radio>
                  <Radio value="weekly">Weekly</Radio>
                  {recurrence === 'weekly' && (
                    <div className="">
                      <div className="field-row ml-30">
                        <div className="field-wrapper ml-10 recurrence-day">
                          <div className="d-flex">
                            <CheckboxComponent
                              checked={daysOfWeek.MONDAY}
                              onChange={(checked) => { handleDaysOfWeek(checked, "MONDAY") } }
                            />
                            <div className="field-name ml-10">
                              Monday
                            </div>
                          </div>
                        </div>

                        <div className="field-wrapper ml-20 recurrence-day">
                          <div className="d-flex">
                            <CheckboxComponent
                              checked={daysOfWeek.TUESDAY}
                              onChange={(checked) => { handleDaysOfWeek(checked, "TUESDAY") } }
                            />
                            <div className="field-name ml-10">
                              Tuesday
                            </div>
                          </div>
                        </div>

                        <div className="field-wrapper ml-20 recurrence-day">
                          <div className="d-flex">
                            <CheckboxComponent
                              checked={daysOfWeek.WEDNESDAY}
                              onChange={(checked) => { handleDaysOfWeek(checked, "WEDNESDAY") } }
                            />
                            <div className="field-name ml-10">
                              Wednesday
                            </div>
                          </div>
                        </div>

                        <div className="field-wrapper ml-20 recurrence-day">
                          <div className="d-flex">
                            <CheckboxComponent
                              checked={daysOfWeek.THURSDAY}
                              onChange={(checked) => { handleDaysOfWeek(checked, "THURSDAY") } }
                            />
                            <div className="field-name ml-10">
                              Thursday
                            </div>
                          </div>
                        </div>

                      </div>

                      <div className="field-row ml-30">
                        <div className="field-wrapper ml-10 recurrence-day">
                          <div className="d-flex">
                            <CheckboxComponent
                              checked={daysOfWeek.FRIDAY}
                              onChange={(checked) => { handleDaysOfWeek(checked, "FRIDAY") } }
                            />
                            <div className="field-name ml-10">
                              Friday
                            </div>
                          </div>
                        </div>

                        <div className="field-wrapper ml-20 recurrence-day">
                          <div className="d-flex">
                            <CheckboxComponent
                              checked={daysOfWeek.SATURDAY}
                              onChange={(checked) => { handleDaysOfWeek(checked, "SATURDAY") } }
                            />
                            <div className="field-name ml-10">
                              Saturday
                            </div>
                          </div>
                        </div>

                        <div className="field-wrapper ml-20 recurrence-day">
                          <div className="d-flex">
                            <CheckboxComponent
                              checked={daysOfWeek.SUNDAY}
                              onChange={(checked) => { handleDaysOfWeek(checked, "SUNDAY") } }
                            />
                            <div className="field-name ml-10">
                              Sunday
                            </div>
                          </div>
                        </div>
                      </div>

                    </div>
                  )}
                </RadioGroup>

              </div>
            </div>

          </div>
          <div className="field-empty"></div>
          <div className="field-row">
            <div className="left-field-title ">
              <span className="input-prefix mt-8">Increase</span>
            </div>
            <div className="right-field-content d-flex">
              <input
                type="number"
                className="shrinked-input ml-10 bd-increase"
                value={increaseValue}
                onChange={(event) => { setIncreaseValu(event.target.value) }}
              />
              <span className="input-suffix mt-8">%</span>
            </div>
          </div>
        </div>

      </Modal.Body>
      <Modal.Footer>
        <button type="button" className="rs-btn rs-btn-primary" onClick={() => handleCreateNewBudgetRule()}>
          Create & Apply to All
        </button>
        <button type="button" className="rs-btn rs-btn-subtle" onClick={() => handleClose()}>
          Close
        </button>
      </Modal.Footer>
    </Modal>
  )
}

export default CreateScheduleBasedBudgetRuleModal
