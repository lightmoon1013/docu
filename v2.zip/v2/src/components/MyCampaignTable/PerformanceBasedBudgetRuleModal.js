import React, { useState, useEffect } from 'react'
import { useDispatch, useSelector, useStore } from 'react-redux'

import { Modal } from 'rsuite'

import PaginationComponent from '../CommonComponents/PaginationComponent'
import LoaderComponent from '../CommonComponents/LoaderComponent'
import CreatePerformanceBasedBudgetRuleModal from './CreatePerformanceBasedBudgetRuleModal'
import {
  getCurrentBudgetRules, disableCampaignsBudgetRule, applyCampaignsBudgetRule
} from '../../redux/actions/campaign'
import ViewCampaignBudgetRuleModal from './ViewCampaignBudgetRuleModal'


const DEFAULT_PAGE_SIZE = 10

const PerformanceBasedBudgetRuleModal = ({ show, campaigns, onSelect, onClose }) => {

  const dispatch = useDispatch()
  const store = useStore()

  const {selCampaigns} = useSelector(state => state.campaign)
  const { campaign } = store.getState()
  const { isBudgetRuleLoading, isDisableBugetRuleLoading, isApplyBugetRuleLoading } = campaign

  const paginationSelectPlacement = "bottom"
  const paginationNeighbours = 2
  const [selectedCampaigns, setSelectedCampaigns ] = useState([])
  const [pageStart, setPageStart] = useState(0)
  const [pageEnd, setPageEnd] = useState(DEFAULT_PAGE_SIZE)
  const [openCreateBudgetRuleModal, setOpenCreateBudgetRuleModal] = useState(false)
  const [openCampaignBudgetRuleModal, setOpenCampaignBudgetRuleModal] = useState(false)


  useEffect(() => {
    if (show && !isBudgetRuleLoading) {
      dispatch(getCurrentBudgetRules(JSON.parse(JSON.stringify(campaigns))))
    }
  }, [show]) // eslint-disable-line

  useEffect(() => {
    if(selCampaigns.length > 0) {
      setSelectedCampaigns(selCampaigns)
    }
  }, [selCampaigns]) // eslint-disable-line

  const loadData = (pageNum, pageRows) => {
    if (pageRows !== 'all') {
      setPageStart((pageNum - 1) * pageRows)
      setPageEnd(pageNum * pageRows)
    } else {
      setPageStart(0)
      setPageEnd(selectedCampaigns.length)
    }
  }

  const handleClose = () => {
    onClose()
  }

  const handleShowCampaignBudgetRules = () => {
    setOpenCampaignBudgetRuleModal(true)
  }

  const handleApplyAll = (budgetRule) => {
    setOpenCreateBudgetRuleModal(false)

    let budgetCampaigns = []
    selectedCampaigns.map((campaign) => {
      campaign.budgetRule = budgetRule.name
      campaign.budgetId = budgetRule.ruleId
      budgetCampaigns.push(campaign)
      return true
    })

    dispatch(applyCampaignsBudgetRule(selectedCampaigns,budgetRule))
    // onClose()
  }

  const handleDisableBudgetRule = (campaign) => {
    dispatch(disableCampaignsBudgetRule([campaign]))
  }

  const handleDisableAllBudgetRules = () => {
    let disableCampaigns = []
    selectedCampaigns.map((campaign) => {
      if (campaign.budgetRule) {
        disableCampaigns.push(campaign)
      }
      return true
    })
    if (disableCampaigns.length > 0) {
      dispatch(disableCampaignsBudgetRule(disableCampaigns))
    }
  }


  const handleCreateNewBudgetRule = () => {
    setOpenCreateBudgetRuleModal(true)
  }

  const isLoading = isBudgetRuleLoading || isDisableBugetRuleLoading || isApplyBugetRuleLoading

  return (
    <Modal className={`ucname-selector-modal${isLoading ? ' loading' : ''}`} backdrop="static" show={show} size="md">
      <Modal.Header onHide={() => { handleClose()}}>
        <Modal.Title>
          <div className="ucname-modal-title">
            Performance Budget Rules
          </div>
        </Modal.Title>
        <div className="ucname-modal-buttons d-flex">
          <button type="button" className="btn btn-red" onClick={() => handleShowCampaignBudgetRules()}>
            View Budget Rules
          </button>
          <button type="button" className="btn btn-green ml-10" onClick={() => handleCreateNewBudgetRule()}>
            Create Budget Rule
          </button>
          <button type="button" className="rs-btn rs-btn-primary ml-10" onClick={() => handleDisableAllBudgetRules()} >
            Delete All Budget Rules
          </button>
        </div>
      </Modal.Header>
      <Modal.Body>
      { isLoading && <LoaderComponent /> }
        <div className="ucname-modal-body">
          <div className="ucname-list">
            <div className="ucname-table-body">
              <div className="ucname-table-row content-header">
                <div className="table-col col-campaign">Campaign</div>
                <div className="table-col col-bidstrategy">Active Budget Rule</div>
                <div className="table-col col-state">Action</div>
              </div>
            {
              selectedCampaigns.length >0 && selectedCampaigns.slice(pageStart, pageEnd).map((campaign) =>
                <div key={campaign.campaignId} className="ucname-table-row">
                  <div className="col-campaign table-col">
                    {campaign.name}
                  </div>
                  <div className="col-bidstrategy table-col">
                    {campaign.budgetRule ? campaign.budgetRule : ''}
                  </div>
                  <div className="table-col col-state">
                    {
                      campaign.budgetRule ?(
                        <button type="button" className="rs-btn rs-btn-primary" onClick={() => handleDisableBudgetRule(campaign)} >
                          Delete
                        </button>
                      ) : ''
                    }
                  </div>
                </div>
              )
            }
            </div>

          </div>
          <PaginationComponent
            selectPlacement={paginationSelectPlacement}
            pageNeighbours={paginationNeighbours}
            total={selectedCampaigns.length}
            loadData={loadData}
          />

          <CreatePerformanceBasedBudgetRuleModal
            campaigns={selectedCampaigns}
            show={openCreateBudgetRuleModal}
            onSelect={(budgetRule) => handleApplyAll(budgetRule)}
            onClose={() => { setOpenCreateBudgetRuleModal(false) }}
          />
          <ViewCampaignBudgetRuleModal
            campaigns={selectedCampaigns}
            show={openCampaignBudgetRuleModal}
            // onSelect={(budgetRule) => handleApplyAll(budgetRule)}
            onClose={() => { setOpenCampaignBudgetRuleModal(false) }}
          />
        </div>

      </Modal.Body>
      <Modal.Footer>
        
        <button type="button" className="rs-btn rs-btn-subtle" onClick={() => handleClose()}>
          Close
        </button>
      </Modal.Footer>
    </Modal>
  )
}

export default PerformanceBasedBudgetRuleModal
