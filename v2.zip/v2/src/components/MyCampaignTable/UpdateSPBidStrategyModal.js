import React, { useState, useEffect } from 'react'
import { Modal } from 'rsuite'

import PaginationComponent from '../CommonComponents/PaginationComponent'
import Select from 'react-select'

const DEFAULT_PAGE_SIZE = 10

const bidStrategyList = [
  {
    value: 'legacyForSales',
    label: 'Dynamic bids - down only',
  },
  {
    value: 'autoForSales',
    label: 'Dynamic bids - up and down',
  },
  {
    value: 'manual',
    label: 'Fixed bids',
  },
]

const UpdateSPBidStrategyModal = ({ campaigns, onSelect, onClose }) => {

  const paginationSelectPlacement = "bottom"
  const paginationNeighbours = 2
  const [selectedCampaigns, setSelectedCampaigns ] = useState([])
  const [initialCampaigns, setInitialCampaigns] = useState([])
  const [pageStart, setPageStart] = useState(0)
  const [pageEnd, setPageEnd] = useState(DEFAULT_PAGE_SIZE)
  const [allBidStrategy, setAllBidStrategy] = useState(bidStrategyList[0])

  useEffect(() => {
    let initCampaigns = JSON.parse(JSON.stringify(campaigns))
    setInitialCampaigns(initCampaigns)

    initCampaigns.map((campaign) => {
      let bidding = typeof campaign.bidding === 'string' ? JSON.parse(campaign.bidding) : campaign.bidding
      switch(bidding.strategy) {
        case 'legacyForSales':
          campaign.bidInfo = {strategy: {
            value: 'legacyForSales',
            label: 'Dynamic bids - down only',
          }, adjustments: bidding.adjustments}
          break
        case 'autoForSales':
          campaign.bidInfo = {strategy: {
            value: 'autoForSales',
            label: 'Dynamic bids - up and down',
          }, adjustments: bidding.adjustments}
          break
        default:
          campaign.bidInfo = {strategy: {
            value: 'manual',
            label: 'Fixed bids',
          }, adjustments: bidding.adjustments}
          break
      }
      return true
    })
    setSelectedCampaigns(initCampaigns)
  }, [campaigns]) // eslint-disable-line

  const loadData = (pageNum, pageRows) => {
    if (pageRows !== 'all') {
      setPageStart((pageNum - 1) * pageRows)
      setPageEnd(pageNum * pageRows)
    } else {
      setPageStart(0)
      setPageEnd(selectedCampaigns.length)
    }
  }

  const handleUpdatedCampaigns = () => {
    onSelect(selectedCampaigns)
  }

  const handleClose = () => {
    setSelectedCampaigns(initialCampaigns)
    onClose()
  }

  const handleBidStrategy = (campaignId, option) => {

    let newSelectedCampaigns = [...selectedCampaigns]
    newSelectedCampaigns.map((campaign) => {
      if(campaign.campaign_id === campaignId) {
        campaign.bidInfo.strategy = option
      }
      return true;
    })
    setSelectedCampaigns(newSelectedCampaigns)
  }

  const handleApplyAll = () => {
    let newSelectedCampaigns = [...selectedCampaigns]
    newSelectedCampaigns.map((campaign) => {
      campaign.bidInfo.strategy = allBidStrategy
      return true;
    })
    setSelectedCampaigns(newSelectedCampaigns)
  }

  return (
    <Modal className={`ucname-selector-modal`} backdrop="static" show={true} size="md">
      <Modal.Header onHide={() => { handleClose()}}>
        <Modal.Title>
          <div className="ucname-modal-title">
            Update Bidding Strategy (SP Only)
          </div>
        </Modal.Title>
        <div className="ucname-modal-buttons d-flex">
          <Select
            options={bidStrategyList}
            value={allBidStrategy}
            onChange={(option) => { setAllBidStrategy(option) }}
          />
          <button type="button" className="rs-btn rs-btn-primary ml-10" onClick={() => handleApplyAll()} >
            Apply All
          </button>
        </div>
      </Modal.Header>
      <Modal.Body>
        <div className="ucname-modal-body">
          <div className="ucname-list">
            <div className="ucname-table-body">
              <div className="ucname-table-row content-header">
                <div className="table-col col-campaign">Campaign</div>
                <div className="table-col col-campaign">Bid Strategy</div>
                <div className="table-col col-state">State</div>
              </div>

            {
              selectedCampaigns.slice(pageStart, pageEnd).map((campaign) =>
                <div key={campaign.campaign_id} className="ucname-table-row">
                  <div className="col-campaign table-col">
                    {campaign.campaign}
                  </div>
                  <div className="col-bidstrategy table-col">
                  <Select
                    options={bidStrategyList}
                    value={campaign.bidInfo.strategy}
                    onChange={(option) => { handleBidStrategy(campaign.campaign_id, option) }}
                  />
                  </div>
                  <div className="table-col col-state">{ campaign.state}</div>
                </div>
              )
            }
            </div>

          </div>
          <PaginationComponent
            selectPlacement={paginationSelectPlacement}
            pageNeighbours={paginationNeighbours}
            total={selectedCampaigns.length}
            loadData={loadData}
          />
        </div>

      </Modal.Body>
      <Modal.Footer>
        <button type="button" className="rs-btn rs-btn-primary" onClick={() => handleUpdatedCampaigns()}>
          Save
        </button>
        <button type="button" className="rs-btn rs-btn-subtle" onClick={() => handleClose()}>
          Close
        </button>
      </Modal.Footer>
    </Modal>
  )
}

export default UpdateSPBidStrategyModal
