import React, { useState, useEffect } from 'react'
import { useDispatch, useStore } from 'react-redux'
import { Dropdown } from 'rsuite'
import moment from 'moment'

import TemplateSelector from '../CommonComponents/TemplateSelector'
import TemplateEditorComponent from '../TemplateEditorComponent'
import AddToNewPortfolio from './AddToNewPortfolio'
import AddToExistingPortfolio from './AddToExistingPortfolio'
import UpdateCampaignNameModal from './UpdateCampaignNameModal'
import UpdateSPPlacementOpModal from './UpdateSPPlacementOpModal'
import UpdateSPBidStrategyModal from './UpdateSPBidStrategyModal'

import {
  showANPAction,
  showAEPAction,
} from '../../redux/actions/pageGlobal'

import {
  updateCampaignsState, updateCampaignNames, updateSPBidStrategy, updateSPPlacementStrategy
} from '../../redux/actions/campaign'

import {
  getTemplates,
  turnBulk,
  applyTemplateBulk,
} from '../../redux/actions/ap'
import ScheduleBasedBudgetRuleModal from './ScheduleBasedBudgetRuleModal'
import PerformanceBasedBudgetRuleModal from './PerformanceBasedBudgetRuleModal'

const ActionBar = ({ selectedCampaigns }) => {
  const dispatch = useDispatch()
  const store = useStore()

  const {
    header: { currentUserId },
    ap: { templates, isLoadingTemplates, isTemplatesLoaded, isApplyingTemplateBulk },
    pageGlobal: {
      showANP,
      showAEP,
      showTemplateEditor,
    },
  } = store.getState()

  const [templateSelectorVisible, setTemplateSelectorVisible] = useState(false)
  const [showUCN, setShowUCN] = useState(false)
  const [showUSPBS, setShowUSPBS] = useState(false)
  const [showUSBBudget, setShowUSBBudget] = useState(false)
  const [showUPBBudget, setShowUPBBudget] = useState(false)
  const [isBiddingSP, setIsBiddingSP] = useState(false)
  const [showUSPPO, setShowUSPPO] = useState(false)

  useEffect(() => {
    let count = 0
    selectedCampaigns.map((campaign) => {
      if (campaign.campaignType !== 'Sponsored Products') {
        count++
      }
      return true
    })
    if (count === 0) {
      setIsBiddingSP(true)
    } else {
      setIsBiddingSP(false)
    }
  }, [selectedCampaigns]) // eslint-disable-line

  useEffect(() => {
    if (templateSelectorVisible && !isTemplatesLoaded && !isLoadingTemplates && currentUserId) {
      dispatch(getTemplates())
    }
  }, [templateSelectorVisible]) // eslint-disable-line

  // Add to new portfolio.
  const handleANPShow = () => {
    dispatch(showANPAction(selectedCampaigns))
  }

  // Add to existing portfolio.
  const handleAEPShow = () => {
    dispatch(showAEPAction(selectedCampaigns))
  }

  const handleUCNShow = () => {
    setShowUCN(true)
  }

  const handleUCNClose = () => {
    setShowUCN(false)
  }

  const handleUSPBSShow = () => {
    setShowUSPBS(true)
  }

  const handleUSPPOShow = () => {
    setShowUSPPO(true)
  }

  const handleUSPPOClose = () => {
    setShowUSPPO(false)
  }

  const handleUSPBSClose = () => {
    setShowUSPBS(false)
  }

  const handleUSBBudgetShow = () => {
    setShowUSBBudget(true)
  }

  const handleUSBBudgetClose = () => {
    setShowUSBBudget(false)
  }

  const handleUPBBudgetShow = () => {
    setShowUPBBudget(true)
  }

  const handleUPBBudgetClose = () => {
    setShowUPBBudget(false)
  }

  const handleUpdateStateBulk = (state) => {
    const campaignsChanged = selectedCampaigns
      .filter(campaign => campaign.state !== 'archived')
      .map(campaign => ({
        campaignId: campaign.campaign_id,
        campaignType: campaign.campaignType,
      }))

    dispatch(updateCampaignsState(campaignsChanged, state))
  }

  const handleAPTurn = (state) => {
    const campaignIds = selectedCampaigns.map(campaign => campaign.campaign_id)
    dispatch(turnBulk(campaignIds, state))
  }

  const handleUpdatedCampaigns = (updatedCampaigns) => {
    setShowUCN(false)
    const campaignsChanged = updatedCampaigns
      .filter(campaign => campaign.state !== 'archived')
      .map(campaign => ({
        campaignId: campaign.campaign_id,
        name: campaign.campaign,
        campaignType: campaign.campaignType,
      }))
    dispatch(updateCampaignNames(campaignsChanged))
  }

  const handleSPBidCampaigns = (updatedCampaigns) => {
    setShowUSPBS(false)
    const campaignsChanged = updatedCampaigns
      .filter(campaign => campaign.state !== 'archived')
      .map(campaign => ({
        campaignId: campaign.campaign_id,
        bidding: {
          strategy: campaign.bidInfo.strategy.value,
          adjustments: campaign.bidInfo.adjustments
        },
      }))

    dispatch(updateSPBidStrategy(campaignsChanged))
  }

  const handleSPPlacementCampaigns = (updatedCampaigns) => {
    setShowUSPPO(false)
    const campaignsChanged = updatedCampaigns
      .filter(campaign => campaign.state !== 'archived')
      .map(campaign => ({
        campaignId: campaign.campaign_id,
        bidding: {
          strategy: campaign.bidInfo.strategy.value,
          adjustments: campaign.bidInfo.adjustments
        },
      }))

    dispatch(updateSPPlacementStrategy(campaignsChanged))
  }

  const handleSBBudgetRules = (updatedCampaigns) => {
    setShowUSBBudget(false)
  }

  const handlePBBudgetRules = (updatedCampaigns) => {
    setShowUSBBudget(false)
  }

  const handleTemplateApply = (templateId) => {
    const campaignIds = selectedCampaigns.map(campaign => campaign.campaign_id)
    dispatch(applyTemplateBulk(templateId, campaignIds, moment().format('Z'))).then(() => {
      setTemplateSelectorVisible(false)
    })
  }

  return (
    <>
      {
        selectedCampaigns.length > 0 && (
          <>
            <Dropdown title="Bulk Moves">
              <Dropdown.Item onSelect={() => { handleUpdateStateBulk('paused') }}>
                Pause
              </Dropdown.Item>
              <Dropdown.Item onSelect={() => { handleUpdateStateBulk('enabled') }}>
                Unpause
              </Dropdown.Item>
              <Dropdown.Item onSelect={() => { handleANPShow() }}>
                Add To New Portfolio
              </Dropdown.Item>
              <Dropdown.Item onSelect={() => { handleAEPShow() }}>
                Add To Existing Portfolio
              </Dropdown.Item>
              <Dropdown.Item onSelect={() => { handleUCNShow() }}>
                Update Campaign Names
              </Dropdown.Item>
              {
                isBiddingSP ? (
                  <Dropdown.Item onSelect={() => { handleUSPBSShow() }} >
                    Update Bidding Strategy (SP Only)
                  </Dropdown.Item>
                ) : (
                  <Dropdown.Item disabled>
                    Update Bidding Strategy (SP Only)
                  </Dropdown.Item>
                )
              }
              
              <Dropdown.Item onSelect={() => { handleUSBBudgetShow() }}>
                Budget Rules (Schedule Based)
              </Dropdown.Item>
              {
                isBiddingSP ? (
                  <Dropdown.Item onSelect={() => { handleUPBBudgetShow() }}>
                    Budget Rules (Performance Based - SP Only)
                  </Dropdown.Item>
                ) : (
                  <Dropdown.Item disabled>
                    Budget Rules (Performance Based - SP Only)
                  </Dropdown.Item>
                )
              }
              {
                isBiddingSP ? (
                  <Dropdown.Item onSelect={() => { handleUSPPOShow() }} >
                    Placement Optimization (SP Only)
                  </Dropdown.Item>
                ) : (
                  <Dropdown.Item disabled>
                    Placement Optimization (SP Only)
                  </Dropdown.Item>
                )
              }
            </Dropdown>
            <Dropdown title="Smart Pilot">
              <Dropdown.Item onSelect={() => { handleAPTurn('on') }}>
                Turn Smart Pilot On
              </Dropdown.Item>
              <Dropdown.Item onSelect={() => { handleAPTurn('off') }}>
                Turn Smart Pilot Off
              </Dropdown.Item>
              <Dropdown.Item onSelect={() => { setTemplateSelectorVisible(true) }}>
                Apply Template
              </Dropdown.Item>
            </Dropdown>
            <TemplateSelector
              show={templateSelectorVisible}
              templates={templates}
              isLoading={isLoadingTemplates}
              isApplying={isApplyingTemplateBulk}
              onChange={handleTemplateApply}
              onCancel={() => { setTemplateSelectorVisible(false) }}
            />
          </>
        )
      }
      { showTemplateEditor && <TemplateEditorComponent /> }
      { showANP && <AddToNewPortfolio campaigns={selectedCampaigns} /> }
      { showAEP && <AddToExistingPortfolio campaigns={selectedCampaigns} /> }
      { showUCN && <UpdateCampaignNameModal campaigns={selectedCampaigns} onClose={() => { handleUCNClose() }} onSelect={(updatedCampaigns) => handleUpdatedCampaigns(updatedCampaigns)}/> }
      { showUSPBS && <UpdateSPBidStrategyModal campaigns={selectedCampaigns} onClose={() => { handleUSPBSClose() }} onSelect={(updatedCampaigns) => handleSPBidCampaigns(updatedCampaigns)}/> }
      { showUSBBudget && <ScheduleBasedBudgetRuleModal show={showUSBBudget} campaigns={selectedCampaigns} onClose={() => { handleUSBBudgetClose() }} onSelect={(updatedCampaigns) => handleSBBudgetRules(updatedCampaigns)}/> }
      { showUPBBudget && <PerformanceBasedBudgetRuleModal show={showUPBBudget} campaigns={selectedCampaigns} onClose={() => { handleUPBBudgetClose() }} onSelect={(updatedCampaigns) => handlePBBudgetRules(updatedCampaigns)}/> }
      { showUSPPO && <UpdateSPPlacementOpModal campaigns={selectedCampaigns} onClose={() => { handleUSPPOClose() }} onSelect={(updatedCampaigns) => handleSPPlacementCampaigns(updatedCampaigns)}/> }

    </>
  )
}

export default ActionBar
