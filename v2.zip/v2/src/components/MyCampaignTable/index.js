import React from 'react'

import CampaignTableComponent from '../CampaignTableComponent'
import ActionBar from './ActionBar'

const MyCampaignTable = () => {
  return (
    <CampaignTableComponent
      customActionBar={ActionBar}
    />
  )
}

export default MyCampaignTable
