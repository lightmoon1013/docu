import React, { useState, useEffect } from 'react'
import { Modal } from 'rsuite'
import { toast } from '../../components/CommonComponents/ToastComponent/toast'

import PaginationComponent from '../CommonComponents/PaginationComponent'

const DEFAULT_PAGE_SIZE = 10

const UpdateSPPlacementOpModal = ({ campaigns, onSelect, onClose }) => {

  const paginationSelectPlacement = "bottom"
  const paginationNeighbours = 2
  const [selectedCampaigns, setSelectedCampaigns ] = useState([])
  const [initialCampaigns, setInitialCampaigns] = useState([])
  const [pageStart, setPageStart] = useState(0)
  const [pageEnd, setPageEnd] = useState(DEFAULT_PAGE_SIZE)
  const [newTopPercent, setNewTopPercent] = useState(0)
  const [newProductPercent, setNewProductPercent] = useState(0)

  useEffect(() => {
    let initCampaigns = JSON.parse(JSON.stringify(campaigns))
    setInitialCampaigns(initCampaigns)

    initCampaigns.map((campaign) => {
      let bidding = typeof campaign.bidding === 'string' ? JSON.parse(campaign.bidding) : campaign.bidding
      switch(bidding.strategy) {
        case 'legacyForSales':
          campaign.bidInfo = {strategy: {
            value: 'legacyForSales',
            label: 'Dynamic bids - down only',
          }, adjustments: bidding.adjustments}
          break
        case 'autoForSales':
          campaign.bidInfo = {strategy: {
            value: 'autoForSales',
            label: 'Dynamic bids - up and down',
          }, adjustments: bidding.adjustments}
          break
        default:
          campaign.bidInfo = {strategy: {
            value: 'manual',
            label: 'Fixed bids',
          }, adjustments: bidding.adjustments}
          break
      }
      return true
    })
    setSelectedCampaigns(initCampaigns)

  }, [campaigns]) // eslint-disable-line

  const loadData = (pageNum, pageRows) => {
    if (pageRows !== 'all') {
      setPageStart((pageNum - 1) * pageRows)
      setPageEnd(pageNum * pageRows)
    } else {
      setPageStart(0)
      setPageEnd(selectedCampaigns.length)
    }
  }

  const handleUpdatedCampaigns = () => {

    onSelect(selectedCampaigns)
  }

  const handleClose = () => {
    setSelectedCampaigns(initialCampaigns)
    setNewTopPercent(0)
    setNewProductPercent(0)
    onClose()
  }

  const handleNewProductPercent = (value) => {
    if(value*1 <0) {
      toast.show({
        title: 'Warning',
        description: 'Percentage value must be higher than 0.',
      })
      return
    }
    setNewProductPercent(value)
  }

  const handleNewTopPercent = (value) => {
    if(value*1 <0) {
      toast.show({
        title: 'Warning',
        description: 'Percentage value must be higher than 0.',
      })
      return
    }
    setNewTopPercent(value)
  }

  const handlePlacement = (campaignId, placementType, value) => {
    if(value*1 <0) {
      toast.show({
        title: 'Warning',
        description: 'Percentage value must be higher than 0.',
      })
      return
    }

    let newSelectedCampaigns = [...selectedCampaigns]
    newSelectedCampaigns.map((campaign) => {
      if(campaign.campaign_id === campaignId) {
        let newAdjustments = []
        if (campaign.bidInfo.adjustments.length >0) {
          if (placementType === 'placementProductPage') {
            let placeTopPercent = campaign.bidding.adjustments[1]?.predicate === 'placementTop' ? campaign.bidding.adjustments[1].percentage : (campaign.bidding.adjustments[0]?.predicate === 'placementTop' ? campaign.bidding.adjustments[0].percentage : 0)
            newAdjustments = [{predicate: "placementProductPage", percentage: value}, {predicate: "placementTop", percentage: placeTopPercent} ]
          } else {
            let placeProductPercent = campaign.bidding.adjustments[0]?.predicate === 'placementProductPage'  ? campaign.bidding.adjustments[0].percentage : (campaign.bidding.adjustments[1]?.predicate === 'placementProductPage'  ? campaign.bidding.adjustments[1].percentage : 0)
            newAdjustments = [{predicate: "placementProductPage", percentage: placeProductPercent}, {predicate: "placementTop", percentage: value} ]
          }
        } else {

          if (placementType === 'placementProductPage') {
            newAdjustments = [{predicate: "placementProductPage", percentage: value}, {predicate: "placementTop", percentage: 0} ]
          } else {
            newAdjustments = [{predicate: "placementProductPage", percentage: 0}, {predicate: "placementTop", percentage: value} ]
          }
        }
        campaign.bidInfo.adjustments = newAdjustments
        campaign.bidding.adjustments = newAdjustments
      }
      return true;
    })
    setSelectedCampaigns(newSelectedCampaigns)
  }



  const handleApplyAll = () => {
    let newSelectedCampaigns = [...selectedCampaigns]
    newSelectedCampaigns.map((campaign) => {
      let newAdjustments = [{predicate: "placementProductPage", percentage: newProductPercent}, {predicate: "placementTop", percentage: newTopPercent} ]
      campaign.bidInfo.adjustments = newAdjustments
      campaign.bidding.adjustments = newAdjustments
      return true;
    })
    setSelectedCampaigns(newSelectedCampaigns)
  }

  return (
    <Modal className={`ucname-selector-modal`} backdrop="static" show={true} size="md">
      <Modal.Header onHide={() => { handleClose()}}>
        <Modal.Title>
          <div className="ucname-modal-title">
            Placement Optimization (SP Only)
          </div>
        </Modal.Title>
        <div className="ucname-modal-buttons d-flex">
          <div className="ucplacment-title">Product pages (%): </div>
          <input type="number" className="edit-input ml-10" value={newProductPercent} onChange={(event) => { handleNewProductPercent(event.target.value)}}/>
          <div className="ucplacment-title ml-10">Top of search (%): </div>
          <input type="number" className="edit-input ml-10" value={newTopPercent} onChange={(event) => { handleNewTopPercent(event.target.value)}}/>
          <button type="button" className="rs-btn rs-btn-primary ml-10" onClick={() => handleApplyAll()} >
            Apply All
          </button>
        </div>
      </Modal.Header>
      <Modal.Body>
        <div className="ucname-modal-body">
          <div className="ucname-list">
            <div className="ucname-table-body">
              <div className="ucname-table-row content-header">
                <div className="table-col col-campaign">Campaign</div>
                <div className="table-col col-placement">Product pages (%) </div>
                <div className="table-col col-placement">Top of search (%) </div>
              </div>

            {
              selectedCampaigns.slice(pageStart, pageEnd).map((campaign) =>
                <div key={campaign.campaign_id} className="ucname-table-row">
                  <div className="col-campaign table-col">
                    {campaign.campaign}
                  </div>
                  <div className="table-col col-placement">
                    <input type="number" className="edit-input ml-10" value={campaign.bidding.adjustments[0]?.predicate === 'placementProductPage'  ? campaign.bidding.adjustments[0].percentage : (campaign.bidding.adjustments[1]?.predicate === 'placementProductPage'  ? campaign.bidding.adjustments[1].percentage : 0)} onChange={(event) => { handlePlacement(campaign.campaign_id, 'placementProductPage', event.target.value)}}/>
                  </div>
                  <div className="table-col col-placement">
                    <input type="number" className="edit-input ml-10" value={campaign.bidding.adjustments[1]?.predicate === 'placementTop' ? campaign.bidding.adjustments[1].percentage : (campaign.bidding.adjustments[0]?.predicate === 'placementTop' ? campaign.bidding.adjustments[0].percentage : 0)} onChange={(event) => { handlePlacement(campaign.campaign_id, 'placementTop', event.target.value)}}/>
                  </div>
                </div>
              )
            }
            </div>

          </div>
          <PaginationComponent
            selectPlacement={paginationSelectPlacement}
            pageNeighbours={paginationNeighbours}
            total={selectedCampaigns.length}
            loadData={loadData}
          />
        </div>

      </Modal.Body>
      <Modal.Footer>
        <button type="button" className="rs-btn rs-btn-primary" onClick={() => handleUpdatedCampaigns()}>
          Save
        </button>
        <button type="button" className="rs-btn rs-btn-subtle" onClick={() => handleClose()}>
          Close
        </button>
      </Modal.Footer>
    </Modal>
  )
}

export default UpdateSPPlacementOpModal
