import React, { useState } from 'react'
import { useDispatch, useStore } from 'react-redux'
import { Radio, RadioGroup, DatePicker } from 'rsuite'
import moment from 'moment'
import CheckboxComponent from '../CommonComponents/CheckboxComponent'
import Select from 'react-select'

import { Modal } from 'rsuite'

import LoaderComponent from '../CommonComponents/LoaderComponent'
import { toast } from '../CommonComponents/ToastComponent/toast'

import {
  createSPPerformanceBudgetRule
} from '../../redux/actions/campaign'

const metricNames = [
  {
    value: 'ACOS',
    label: 'ACOS',
  },
  {
    value: 'CTR',
    label: 'CTR',
  },
  {
    value: 'CVR',
    label: 'CVR',
  },
  {
    value: 'ROAS',
    label: 'ROAS',
  },
]
const compareOperator = [
  {
    value: 'LESS_THAN',
    label: 'less than',
  },
  {
    value: 'LESS_THAN_OR_EQUAL_TO',
    label: 'less than or equal to',
  },
  {
    value: 'GREATER_THAN',
    label: 'greater than',
  },
  {
    value: 'GREATER_THAN_OR_EQUAL_TO',
    label: 'greater than or equal to',
  },
]

const CreatePerformanceBasedBudgetRuleModal = ({ campaigns, show, onSelect, onClose }) => {

  const dispatch = useDispatch()
  const store = useStore()

  const { campaign } = store.getState()
  const { isCreateBudgetRuleLoading } = campaign

  const [budgetInfo, setBudgetInfo] = useState({
    name: ''
  })

  const [increaseValue, setIncreaseValu] = useState(1)
  const [dateRange, setDateRange] = useState({
    startDate: new Date(),
    endDate: null,
  })
  const [daysOfWeek, setDaysOfWeek] = useState({
    MONDAY: false,
    TUESDAY: false,
    WEDNESDAY: false,
    THURSDAY: false,
    FRIDAY: false,
    SATURDAY: false,
    SUNDAY: false
  })
  const [recurrence, setRecurrence] = useState('daily')

  const [metricName, setMetricName] = useState(metricNames[0])
  const [compare, setCompare] = useState(compareOperator[0])
  const [threshold, setThreshold] = useState(1)

  const handleClose = () => {
    onClose()
  }

  const handleCreateNewBudgetRule = () => {

    let budgetDays = []
    Object.keys(daysOfWeek).filter((key)=> {
      return key
    }).map((key) => {
      if (daysOfWeek[key] === true) {
        budgetDays.push(key)
      }
      return true
    })
    if (!budgetInfo.name) {
      toast.show({
        title: 'Warning',
        description: 'Please enter the rule name.',
      })
      return
    }

    let isSameBudgetName = false
    campaigns.map((campaign) => {
      if(campaign.budgetRule && campaign.budgetRule === budgetInfo.name) {
        isSameBudgetName = true
      }
      return true
    })

    if (isSameBudgetName) {
      toast.show({
        title: 'Warning',
        description: 'Some campaigns already have this budget name.',
      })
      return
    }



    if (!dateRange.startDate) {
      toast.show({
        title: 'Warning',
        description: 'Please enter the start date.',
      })
      return
    }

    if (recurrence === 'weekly' && budgetDays.length === 0) {
      toast.show({
        title: 'Warning',
        description: 'Please select effective days.',
      })
      return
    }

    if (threshold*1 <= 0) {
      toast.show({
        title: 'Warning',
        description: 'Value must be greater than 0',
      })
      return
    }

    if (increaseValue*1 <= 0) {
      toast.show({
        title: 'Warning',
        description: 'Value must be greater than 0',
      })
      return
    }

    let isExistingBudgetName = false
    campaigns.map((campaign) => {
      if(campaign.budgetRule) {
        isExistingBudgetName = true
      }
      return true
    })

    if (isExistingBudgetName) {
      toast.show({
        title: 'Warning',
        description: 'Another budget is already active in some campaigns and can be overriding this rule.',
      })
    }

    let budgetRule = {
      name: budgetInfo.name,
      ruleType: 'PERFORMANCE',
      budgetIncreaseBy: {
        type: "PERCENT",
        value: increaseValue
      },
      performanceMeasureCondition: {
        metricName: metricName.value,
        comparisonOperator: compare.value,
        threshold: threshold
      }
    }
    if (recurrence === 'daily') {
      budgetRule.recurrence = {
        type: 'DAILY'
      }
    } else {
      budgetRule.recurrence = {
        type: 'WEEKLY',
        daysOfWeek: budgetDays
      }
    }
    if (dateRange.endDate) {
      let dateRangeTypeRuleDuration = {
        dateRangeTypeRuleDuration: {
          startDate: moment(dateRange.startDate).format('YYYYMMDD'),
          endDate: moment(dateRange.endDate).format('YYYYMMDD'),
        }
      }
      budgetRule.duration = dateRangeTypeRuleDuration
    } else {
      let dateRangeTypeRuleDuration = {
        dateRangeTypeRuleDuration: {
          startDate: moment(dateRange.startDate).format('YYYYMMDD'),
        }
      }
      budgetRule.duration = dateRangeTypeRuleDuration
    }


    dispatch(createSPPerformanceBudgetRule(
      budgetRule
    )).then((response) => {
      if (response.length > 0) {
        onSelect(response[0])
      } else {
        toast.show({
          title: 'Danger',
          description: 'Failed to create a budget rule.',
        })
        onClose()
      }
    }).catch((error) => {
      toast.show({
        title: 'Danger',
        description: 'Failed to create a budget rule.',
      })
    })
  }

  const handleRecurrence = (value) => {
    setRecurrence(value)
  }

  const handleDateRange = (name, value) => {
    const newInfo = Object.assign({}, dateRange, {
      [name]: value,
    })
    setDateRange(newInfo)
  }

  const handleDaysOfWeek = (value, day) => {
    const newInfo = Object.assign({}, daysOfWeek, {
      [day]: value,
    })
    setDaysOfWeek(newInfo)
  }

  const handleBudgetInfo = (name, value) => {
    const newInfo = Object.assign({}, budgetInfo, {
      [name]: value,
    })
    setBudgetInfo(newInfo)
  }

  const isLoading = isCreateBudgetRuleLoading

  return (
    <Modal className={`ucname-selector-modal${isLoading ? ' loading' : ''}`} backdrop="static" show={show} size="md">
      <Modal.Header onHide={() => { handleClose()}}>
        <Modal.Title>
          <div className="ucname-modal-title">
            Performance Budget Rules
          </div>
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
      { isLoading && <LoaderComponent /> }
        <div className="create-budget-rule-modal-body">
          <div className="field-row">
            <div className="left-field-title">
              <span className="input-prefix mt-8">Rule Name</span>
            </div>
            <div className="right-field-content bd-name">
              <input
                type="text"
                className="shrinked-input ml-10"
                value={budgetInfo.name}
                placeholder = "Example: Valentine's Day rule"
                onChange={(event) => { handleBudgetInfo('name', event.target.value) }}
              />
            </div>
          </div>
          <div className="field-empty"></div>
          <div className="field-row">
            <div className="left-field-title">
              <span className="input-prefix">Type</span>
            </div>

            <div className="right-field-content performance-width">
              <div className="field-title ml-10">
                <span className="input-prefix">Performance</span>

              </div>
              <div className="field-note ml-10">
                <span className="input-suffix">Increases your budget for return on ad spend (ROAS), advertising cost of sale (ACOS), click-through rate (CTR), or conversion rate (CVR)</span>
              </div>
            </div>
          </div>
          <div className="field-empty"></div>
          <div className="field-row">
            <div className="left-field-title">
              <span className="input-prefix">Date range</span>
            </div>

            <div className="right-field-content">
              <div className="field-row ">
                <div className="field-wrapper ">
                  <div className="field-name">
                    Start Date
                  </div>
                  <DatePicker
                    value={dateRange.startDate}
                    format="MMM D, YYYY"
                    oneTap
                    disabledDate={date => moment(date).isBefore(moment().startOf('day')) }
                    onChange={(date) => { handleDateRange('startDate', date) }}
                  />
                </div>

                <div className="field-wrapper ml-30">
                  <div className="field-name">
                    End Date
                  </div>
                  <DatePicker
                    value={dateRange.endDate}
                    format="MMM D, YYYY"
                    oneTap
                    disabledDate={date => moment(date).isBefore(moment(dateRange.startDate)) }
                    onChange={(date) => { handleDateRange('endDate', date) }}
                  />
                </div>

              </div>
            </div>

          </div>
          <div className="field-empty"></div>
          <div className="field-row">
            <div className="left-field-title">
              <span className="input-prefix">Recurrence</span>
            </div>

            <div className="right-field-content">
              <div className="field-title ml-10">
              </div>
              <div className="field-note ">
                <RadioGroup
                  value={recurrence}
                  onChange = {handleRecurrence}
                >
                  <Radio value="daily">Daily</Radio>
                  <Radio value="weekly">Weekly</Radio>
                  {recurrence === 'weekly' && (
                    <div className="">
                      <div className="field-row ml-30">
                        <div className="field-wrapper ml-10 recurrence-day">
                          <div className="d-flex">
                            <CheckboxComponent
                              checked={daysOfWeek.MONDAY}
                              onChange={(checked) => { handleDaysOfWeek(checked, "MONDAY") } }
                            />
                            <div className="field-name ml-10">
                              Monday
                            </div>
                          </div>
                        </div>

                        <div className="field-wrapper ml-20 recurrence-day">
                          <div className="d-flex">
                            <CheckboxComponent
                              checked={daysOfWeek.TUESDAY}
                              onChange={(checked) => { handleDaysOfWeek(checked, "TUESDAY") } }
                            />
                            <div className="field-name ml-10">
                              Tuesday
                            </div>
                          </div>
                        </div>

                        <div className="field-wrapper ml-20 recurrence-day">
                          <div className="d-flex">
                            <CheckboxComponent
                              checked={daysOfWeek.WEDNESDAY}
                              onChange={(checked) => { handleDaysOfWeek(checked, "WEDNESDAY") } }
                            />
                            <div className="field-name ml-10">
                              Wednesday
                            </div>
                          </div>
                        </div>

                        <div className="field-wrapper ml-20 recurrence-day">
                          <div className="d-flex">
                            <CheckboxComponent
                              checked={daysOfWeek.THURSDAY}
                              onChange={(checked) => { handleDaysOfWeek(checked, "THURSDAY") } }
                            />
                            <div className="field-name ml-10">
                              Thursday
                            </div>
                          </div>
                        </div>

                      </div>

                      <div className="field-row ml-30">
                        <div className="field-wrapper ml-10 recurrence-day">
                          <div className="d-flex">
                            <CheckboxComponent
                              checked={daysOfWeek.FRIDAY}
                              onChange={(checked) => { handleDaysOfWeek(checked, "FRIDAY") } }
                            />
                            <div className="field-name ml-10">
                              Friday
                            </div>
                          </div>
                        </div>

                        <div className="field-wrapper ml-20 recurrence-day">
                          <div className="d-flex">
                            <CheckboxComponent
                              checked={daysOfWeek.SATURDAY}
                              onChange={(checked) => { handleDaysOfWeek(checked, "SATURDAY") } }
                            />
                            <div className="field-name ml-10">
                              Saturday
                            </div>
                          </div>
                        </div>

                        <div className="field-wrapper ml-20 recurrence-day">
                          <div className="d-flex">
                            <CheckboxComponent
                              checked={daysOfWeek.SUNDAY}
                              onChange={(checked) => { handleDaysOfWeek(checked, "SUNDAY") } }
                            />
                            <div className="field-name ml-10">
                              Sunday
                            </div>
                          </div>
                        </div>
                      </div>

                    </div>
                  )}
                </RadioGroup>

              </div>
            </div>
          </div>
          <div className="field-empty"></div>
          <div className="field-row">
            <div className="left-field-title">
              <span className="input-prefix">Performance metric</span>
            </div>

            <div className="right-field-content">
              <div className="field-row">
                <div className="field-wrapper sel-metric">
                  <Select
                    options={metricNames}
                    value={metricName}
                    onChange={(option) => { setMetricName(option) }}
                  />
                </div>

                <div className="field-wrapper ml-20 sel-compare">
                  <Select
                    options={compareOperator}
                    value={compare}
                    onChange={(option) => { setCompare(option) }}
                  />
                </div>
                <div className="field-wrapper ml-20  per-threshold">
                  <input
                    type="number"
                    className="shrinked-input ml-10 bd-increase"
                    value={threshold}
                    // placeholder = "Example: Valentine's Day rule"
                    onChange={(event) => { setThreshold(event.target.value) }}
                  />
                </div>
              </div>
            </div>
          </div>
          <div className="field-empty"></div>
          <div className="field-row">
            <div className="left-field-title ">
              <span className="input-prefix mt-8">Increase</span>
            </div>
            <div className="right-field-content d-flex">
              <input
                type="number"
                className="shrinked-input ml-10 bd-increase"
                value={increaseValue}
                onChange={(event) => { setIncreaseValu(event.target.value) }}
              />
              <span className="input-suffix mt-8">%</span>
            </div>
          </div>
        </div>

      </Modal.Body>
      <Modal.Footer>
        <button type="button" className="rs-btn rs-btn-primary" onClick={() => handleCreateNewBudgetRule()}>
          Create & Apply to All
        </button>
        <button type="button" className="rs-btn rs-btn-subtle" onClick={() => handleClose()}>
          Close
        </button>
      </Modal.Footer>
    </Modal>
  )
}

export default CreatePerformanceBasedBudgetRuleModal
