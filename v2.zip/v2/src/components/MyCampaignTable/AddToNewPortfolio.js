// Add Campaign To New Portfolio.
import React, { useState, useRef } from 'react'
import { useDispatch, useStore } from 'react-redux'
import OutsideClickHandler from 'react-outside-click-handler'

import { ReactComponent as CloseSvg } from '../../assets/svg/close.svg'
import LoaderComponent from '../CommonComponents/LoaderComponent'

import { hideANPAction } from '../../redux/actions/pageGlobal'
import { toast } from '../CommonComponents/ToastComponent/toast'

import {
  createPortfolio,
} from "../../redux/actions/portfolio"

import {
  updatePortfolio,
} from '../../redux/actions/campaignDetail'

const AddToNewPortfolio = ({ campaigns }) => {
  const dispatch = useDispatch()
  const store = useStore()
  const { portfolio, header, campaignDetail } = store.getState()
  const {
    listPortfolios,
    isCreatingPortfolio,
  } = portfolio // eslint-disable-line
  const {
    isUpdatingPortfolio
  } = campaignDetail
  const { currentUserId } = header
  const portfolioNameRef = useRef()

  const [step, setStep] = useState(1)
  const [selectedCampaigns, setSelectedCampaigns] = useState(campaigns)
  const [portfolioName, setPortfolioName] = useState()
  const [saveError, setSaveError] = useState(null)

  // Hide Add to new portfolio model popup.
  const onClose = () => {
    dispatch(hideANPAction())
  }

  const onOutsideClick = () => {
    onClose()
  }

  const handleNextStep = () => {
    const inValidCampaigns = selectedCampaigns.filter(item =>
      (item.campaignType === 'Sponsored Displays') && (item.cost_type === 'vcpm')
    )
    if (!inValidCampaigns.length) {
      setStep(2)
    } else {
      toast.show({
        title: 'Warning',
        description: inValidCampaigns.length === 1 ? 'There is a invalid campaign.' : 'There are invalid campaigns.',
      })
    }
  }

  const handlePreviousStep = () => {
    setStep(1)
  }

  const removeCampaign = (campaign_id) => {
    setSelectedCampaigns(selectedCampaigns.filter(item => item.campaign_id !== campaign_id))
  }

  const handleDuplicatePortfolio = (value) => {
    let x = listPortfolios.filter(item => item.name === value)
    if( x.length > 0){
      setSaveError("One of your portfolios already uses this name. Please try another.")
      setPortfolioName()
    }else{
      setSaveError()
      setPortfolioName(value)
    }
  }

  const handleANP = () => {
    dispatch(
      createPortfolio({
        portfolioName: portfolioName,
        user: currentUserId
      })
    ).then((portfolioId) => {
      handleUpdatePortfolio(
        portfolioId,
        portfolioName,
      )
    })
  }

  // update portfolio of campaign
  const handleUpdatePortfolio = (portfolioId, portfolioName) => {
    dispatch(updatePortfolio({
      campaigns: selectedCampaigns.map(item => ({
        campaignId: item.campaign_id,
        campaignType: item.campaignType,
        campaignCostType: item.cost_type,
        portfolioId,
      })),
      portfolioId,
      portfolioName,
    })).then(() => {
      onClose()
    })
  }

  const renderFirstStep = () => {
    return (
      <div className="pane-body">
        <div className="section-container">
          <div className="section-header">
            <div className="text-center">
              <div>Step 1 : Confirm Campaigns Add to New Portfolio</div>
              <div>{selectedCampaigns.length} Campaigns Selected</div>
            </div>
            <div className="section-body">
              <div className="campaign-list"> Campaigns
                { selectedCampaigns &&
                  selectedCampaigns.map((data) => (
                    <div className="campaign-list-item" key={data.campaign_id}>
                      <div className="left-column">
                        <div className="pane-title">{data['campaign']}
                          {
                            data['campaignType'] === 'Sponsored Displays' && data['cost_type'] === 'vcpm' &&
                            <div className="campaign-warning">
                              Portfolios aren't available for this campaign with your selected bid optimization strategy.
                            </div>
                          }
                        </div>
                      </div>
                      <div className="right-column">
                        <CloseSvg
                          className="close-button"
                          title="Remove campaign"
                          onClick={() => removeCampaign(data.campaign_id)}
                        />
                      </div>
                    </div>
                  ))
                }
              </div>
            </div>
          </div>
          { selectedCampaigns && selectedCampaigns.length > 0 &&
            <div className="section-footer">
              <button type="button" className="btn btn-red" onClick={ onClose }>Cancel</button>
              <button type="button" className="btn btn-blue" onClick={ handleNextStep }>Confirm</button>
            </div>
          }
        </div>
      </div>
    )
  }

  const renderSecondStep = () => {
    return (
      <div className={(isCreatingPortfolio || isUpdatingPortfolio) ? "pane-body loading" : "pane-body"}>
        {(isCreatingPortfolio || isUpdatingPortfolio) && <LoaderComponent />}
        <div className="section-container">
          <div className="section-header">
            <div className="text-center">
              <div>Step 2 : Create New Portfolio</div>
              <div>
                Organize your campaigns by business line, product category, or season,
                and manage total spending with budget caps.
              </div>
            </div>
            <div className="text-center bold">
              Portfolio Name
            </div>
            <div className="text-center">
              <input
                type="text"
                className="edit-input"
                ref={portfolioNameRef}
                onChange={(e) =>handleDuplicatePortfolio(e.target.value)}
              />
            </div>
          </div>
          {
            saveError && (
              <div className="save-error">
                { saveError }
              </div>
            )
          }
          {
            selectedCampaigns && selectedCampaigns.length > 0 && (
              <div className="section-footer">
                <button
                  type="button"
                  className="btn btn-gray"
                  onClick={ handlePreviousStep }
                >
                  Back to Previous Step
                </button>
                <button
                  type="button"
                  className="btn btn-red"
                  onClick={ onClose }
                >
                  Cancel
                </button>
                <button
                  type="button"
                  className="btn btn-blue"
                  disabled={!portfolioName}
                  onClick={ handleANP }
                >
                  Confirm
                </button>
              </div>
            )
          }
        </div>
      </div>
    )
  }

  return (
    <OutsideClickHandler onOutsideClick={onOutsideClick}>
      <div className="ap-component">
        <div className="top-container">
          <div className="pane-header">
            <div className="left-column">
              <span className="pane-title">
                Add Campaigns to New Portfolio
              </span>
            </div>
            <div className="right-column">
              <CloseSvg className="close-button" onClick={onClose} />
            </div>
          </div>
        </div>
        { step === 1 && renderFirstStep() }
        { step === 2 && renderSecondStep() }
      </div>
    </OutsideClickHandler>
  )
}

export default AddToNewPortfolio
