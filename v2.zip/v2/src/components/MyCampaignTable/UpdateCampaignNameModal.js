import React, { useState, useEffect } from 'react'
import { Modal } from 'rsuite'
import { useStore } from 'react-redux'


import PaginationComponent from '../CommonComponents/PaginationComponent'
import { toast } from '../CommonComponents/ToastComponent/toast'

const DEFAULT_PAGE_SIZE = 10

const UpdateCampaignNameModal = ({ campaigns, onSelect, onClose }) => {
  const store = useStore().getState()

  const { header } = store
  const {
    selectedUserInfo,
  } = header

  const paginationSelectPlacement = "bottom"
  const paginationNeighbours = 2



  const [selectedCampaigns, setSelectedCampaigns ] = useState([])
  const [initialCampaigns, setInitialCampaigns] = useState([])
  const [pageStart, setPageStart] = useState(0)
  const [pageEnd, setPageEnd] = useState(DEFAULT_PAGE_SIZE)
  const [addedText, setAddedText] = useState('')

  useEffect(() => {
    setInitialCampaigns(JSON.parse(JSON.stringify(campaigns)))
    setSelectedCampaigns(JSON.parse(JSON.stringify(campaigns)))
  }, [campaigns]) // eslint-disable-line

  const loadData = (pageNum, pageRows) => {
    if (pageRows !== 'all') {
      setPageStart((pageNum - 1) * pageRows)
      setPageEnd(pageNum * pageRows)
    } else {
      setPageStart(0)
      setPageEnd(initialCampaigns.length)
    }
  }

  const handleCampaignName = (campaignId, campaignName) => {
    let newSelectedCampaigns = [...initialCampaigns]
    newSelectedCampaigns.map((campaign) => {
      if(campaign.campaign_id === campaignId) {
        campaign.campaign = campaignName
      }
      return true;
    })
    setInitialCampaigns(newSelectedCampaigns)
  }

  const addAcosToCampaignName = () => {
    let newSelectedCampaigns = [...initialCampaigns]
    newSelectedCampaigns.map((campaign) => {
      if(campaign.target_acos !== null) {
        campaign.campaign = campaign.campaign + ' | ' + Math.round(campaign.target_acos * 1) + ' ACOS'
      } else {
        campaign.campaign = campaign.campaign + ' | ' + Math.round(selectedUserInfo.average_acos || 30) + ' ACOS'
      }
      return true;

    })
    setInitialCampaigns(newSelectedCampaigns)
  }

  const addTextAtStart = () => {
    if (addedText === '') {
      toast.show({
        title: 'Warning',
        description: 'Please enter text to add to campaign names.',
      })
      return
    }
    let newSelectedCampaigns = [...initialCampaigns]
    newSelectedCampaigns.map((campaign) => {
      campaign.campaign = addedText + ' | ' + campaign.campaign
      return true;
    })
    setInitialCampaigns(newSelectedCampaigns)
  }

  const addTextAtEnd = () => {
    if (addedText === '') {
      toast.show({
        title: 'Warning',
        description: 'Please enter text to add to campaign names.',
      })
      return
    }
    let newSelectedCampaigns = [...initialCampaigns]
    newSelectedCampaigns.map((campaign) => {
      campaign.campaign = campaign.campaign + ' | ' + addedText
      return true;
    })
    setInitialCampaigns(newSelectedCampaigns)
  }

  const handleUpdatedCampaigns = () => {
    onSelect(initialCampaigns)
  }

  const handleClose = () => {
    setInitialCampaigns(selectedCampaigns)
    onClose()
  }

  const addAdTypeToCampaignName = () => {
    let newSelectedCampaigns = [...initialCampaigns]
    newSelectedCampaigns.map((campaign) => {
      switch(campaign.campaignType) {
        case 'Sponsored Products':
          campaign.campaign = 'SP | ' + campaign.campaign
          break
        case 'Sponsored Displays':
          campaign.campaign = 'SD | ' + campaign.campaign
          break
        case 'Sponsored Brands Video':
          campaign.campaign = 'SBV | ' + campaign.campaign
          break
        case 'Sponsored Brands':
          campaign.campaign = 'SB | ' + campaign.campaign
          break
        default:
          break
      }
      return true;
    })
    setInitialCampaigns(newSelectedCampaigns)
  }

  return (
    <Modal className={`ucname-selector-modal`} backdrop="static" show={true} size="md">
      <Modal.Header onHide={() => { handleClose()}}>
        <Modal.Title>
          <div className="ucname-modal-title">
            Update Campaign Names
          </div>
        </Modal.Title>
        <div className="ucname-modal-buttons">
          <button type="button" className="rs-btn rs-btn-primary " onClick={() => addTextAtStart()} >
            Apply At Start
          </button>
          <button type="button" className="rs-btn rs-btn-primary ml-10" onClick={() => addTextAtEnd()} >
            Apply At End
          </button>
          <button type="button" className="rs-btn rs-btn-primary ml-10" onClick={() => addAcosToCampaignName()} >
            Add Target ACoS (End)
          </button>
          <button type="button" className="rs-btn rs-btn-primary ml-10" onClick={() => addAdTypeToCampaignName()} >
            Add Ad Type (Start)
          </button>
        </div>
        <div className="ucname-modal-buttons1">
          {/* <SearchSvg /> */}
          <input
            type="text"
            className="input-search"
            placeholder="Type text to add to the campaigns."
            onChange={(event) => { setAddedText(event.target.value) }}
          />
        </div>

      </Modal.Header>
      <Modal.Body>
        <div className="ucname-modal-body">
          <div className="ucname-list">
            <div className="ucname-table-body">
              <div className="ucname-table-row content-header">
                <div className="table-col col-campaign">Campaign</div>
                <div className="table-col col-state">State</div>
              </div>

            {
              initialCampaigns.slice(pageStart, pageEnd).map((campaign) =>
                <div key={campaign.campaign_id} className="ucname-table-row">
                  <div className="col-campaign table-col">
                    <input
                      type="text"
                      className="edit-campaign-name"
                      value={campaign.campaign}
                      onChange={(event) => { handleCampaignName(campaign.campaign_id, event.target.value) }}
                    />
                  </div>
                  <div className="table-col col-state">{ campaign.state}</div>
                </div>
              )
            }
            </div>

          </div>
          <PaginationComponent
            selectPlacement={paginationSelectPlacement}
            pageNeighbours={paginationNeighbours}
            total={initialCampaigns.length}
            loadData={loadData}
          />
        </div>
      </Modal.Body>
      <Modal.Footer>
        <button type="button" className="rs-btn rs-btn-primary" onClick={() => handleUpdatedCampaigns()}>
          Save
        </button>
        <button type="button" className="rs-btn rs-btn-subtle" onClick={() => handleClose()}>
          Close
        </button>
      </Modal.Footer>
    </Modal>
  )
}

export default UpdateCampaignNameModal
