import React, { useState, useEffect } from 'react'
import Select from 'react-select'

import { Modal } from 'rsuite'

import PaginationComponent from '../CommonComponents/PaginationComponent'

const DEFAULT_PAGE_SIZE = 10

const ViewCampaignBudgetRuleModal = ({ show, campaigns, onSelect, onClose }) => {

  const paginationSelectPlacement = "bottom"
  const paginationNeighbours = 2
  const [campaignBudgetRules, setCampaignBudgetRules ] = useState([])
  const [pageStart, setPageStart] = useState(0)
  const [pageEnd, setPageEnd] = useState(DEFAULT_PAGE_SIZE)

  const [campaignInfo, setCampaignInfo] = useState([])
  const [selectedCampaign, setSelectedCampaign] = useState(null)

  useEffect(() => {

    if (show && campaigns.length > 0) {
      let campaignList = campaigns.map(campaign =>  ({value: campaign.campaignId, label: campaign.name}))
      setCampaignInfo(campaignList)
    }
  }, [show]) // eslint-disable-line

  useEffect(() => {
    setCampaignBudgetRules([])
    if (selectedCampaign) {
      campaigns.map((campaign) => {
        if(campaign.campaignId === selectedCampaign.value && campaign.budgetRules?.length > 0) {
          setCampaignBudgetRules(campaign.budgetRules)
        }
        return true
      })
    }
  }, [selectedCampaign]) // eslint-disable-line

  const loadData = (pageNum, pageRows) => {
    if (pageRows !== 'all') {
      setPageStart((pageNum - 1) * pageRows)
      setPageEnd(pageNum * pageRows)
    } else {
      setPageStart(0)
      setPageEnd(campaignBudgetRules.length)
    }
  }

  const handleClose = () => {
    onClose()
  }

  const handleCampaignSelect = (option) => {
    setSelectedCampaign(option)
  }

  const parseDate=(value) => {
    if (value) {
      let year = value.substring(0, 4)
      let month = value.substring(4, 6)
      let day = value.substring(6, 8)
      let dateValue = year + '-' + month + '-' + day
      return dateValue
    } else {
      return ''
    }
  }

  return (
    <Modal className={`ucname-selector-modal mh-modal`} backdrop="static" show={show} size="lg">
      <Modal.Header onHide={() => { handleClose()}}>
        <Modal.Title>
          <div className="ucname-modal-title">
            Campaign Budget Rules
          </div>
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <div className="ucname-modal-body mh-modal">
          <div className="d-flex mb-10">
            <span className="campaign-selector-name">
              Select Campaign:
            </span>
            <Select
              className="ad-type-select width-600"
              classNamePrefix="ad-type-select"
              options={campaignInfo}
              value={selectedCampaign}
              placeholder="Select a campaign"
              onChange={handleCampaignSelect}
            />
          
          </div>
          
          <div className="ucname-list">
            <div className="upbudget-table-body">
              <div className="upbudget-table-row content-header">
                <div className="table-col col-campaign">Active</div>
                <div className="table-col col-bidstrategy">Budget Rules</div>
                <div className="table-col col-state">Status</div>
                <div className="table-col col-state">Type</div>
                <div className="table-col col-state">Start Date</div>
                <div className="table-col col-state">End Date</div>
                <div className="table-col col-state">Recurrence</div>
                <div className="table-col col-state">Increase</div>
              </div>
            {
              campaignBudgetRules.length >0 && campaignBudgetRules.slice(pageStart, pageEnd).map((budgetRule) =>
                <div key={budgetRule.ruleId} className="upbudget-table-row">
                  <div className="col-campaign table-col">
                    {budgetRule.ruleState}
                  </div>
                  <div className="col-bidstrategy table-col">
                    {budgetRule.ruleDetails.name}
                  </div>
                  <div className="table-col col-state">{budgetRule.ruleStatus === 'BUDGET_THRESHOLD_NOT_MET' ? 'INELIGIBLE' : budgetRule.ruleStatus}</div>
                  <div className="table-col col-state">
                    {
                      budgetRule.ruleDetails.ruleType === 'SCHEDULE' ? (
                        <>
                        {budgetRule.ruleDetails.ruleType}
                        </>
                      ) : (
                        <>
                          {budgetRule.ruleDetails.ruleType}
                          <div className="campaign-status">
                            <div className={`status off`}>
                              <span>
                                {budgetRule.ruleDetails.performanceMeasureCondition.metricName} &nbsp;
                                {budgetRule.ruleDetails.performanceMeasureCondition.comparisonOperator === 'GREATER_THAN' ? ( '>' ) : (
                                  budgetRule.ruleDetails.performanceMeasureCondition.comparisonOperator === 'LESS_THAN' ? ( '<' ) : (
                                    budgetRule.ruleDetails.performanceMeasureCondition.comparisonOperator === 'LESS_THAN_OR_EQUAL_TO' ? ( '<=' ) : ( '>=' )
                                  )
                                )} &nbsp;
                                {budgetRule.ruleDetails.performanceMeasureCondition.threshold}
                              </span>
                            </div>
                          </div>
                        </>
                      )
                    }
                    
                  </div>
                  <div className="table-col col-state">{parseDate(budgetRule.ruleDetails.duration.dateRangeTypeRuleDuration?.startDate)}</div>
                  <div className="table-col col-state">{parseDate(budgetRule.ruleDetails.duration.dateRangeTypeRuleDuration?.endDate)}</div>
                  <div className="table-col col-state">{budgetRule.ruleDetails.recurrence.type}</div>
                  <div className="table-col col-state">{budgetRule.ruleDetails.budgetIncreaseBy.value}%</div>
                </div>
              )
            }
            </div>

          </div>
          <PaginationComponent
            selectPlacement={paginationSelectPlacement}
            pageNeighbours={paginationNeighbours}
            total={campaignBudgetRules.length}
            loadData={loadData}
          />
        </div>

      </Modal.Body>
      <Modal.Footer>
        <button type="button" className="rs-btn rs-btn-subtle" onClick={() => handleClose()}>
          Close
        </button>
      </Modal.Footer>
    </Modal>
  )
}

export default ViewCampaignBudgetRuleModal
