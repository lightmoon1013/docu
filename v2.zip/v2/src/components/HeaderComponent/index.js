/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useEffect, useState } from 'react'
import { useDispatch, useStore } from 'react-redux'
import { useHistory, Link } from 'react-router-dom'

import { ReactComponent as HomeSvg } from '../../assets/svg/home.svg'
import { ReactComponent as ArrowDown } from '../../assets/svg/arrow-down.svg'

import CoinComponent from './CoinComponent'
import NotificationComponent from './NotificationComponent'

import {
  setSelectedUserInfo,
  setCurrencyInfo,
  setUserChanged,
} from '../../redux/actions/header'

import { currencyList } from '../../utils/defaultValues'
import { getAccountLabel } from '../../services/helper'

const HeaderComponent = () => {
  const dispatch = useDispatch()
  const store = useStore().getState()
  const history = useHistory()

  const {
    header: {
      currentUserId,
      selectedUserInfo,
      accountList,
      currencyRateList,
      currencyCode,
    },
    auth: {
      isLoggedIn,
      user,
    },
  } = store

  const [currenctCurrency, setCurrentCurrency] = useState(currencyList[0])

  const [selectedAccount, setSelectedAccount] = useState(null)
  const [calcCurrencyRateList, setCalcCurrencyRateList] = useState({})

  useEffect(() => {
    if (!selectedUserInfo || !Object.keys(selectedUserInfo).length) {
      return
    }
    setSelectedAccount(selectedUserInfo)
  }, [selectedUserInfo])

  useEffect(() => {
    if (!currencyRateList || !Object.keys(currencyRateList).length) {
      return
    }
    calculateCurrenyRateList()
  }, [currencyRateList]) // eslint-disable-line

  useEffect(() => {
    if (currenctCurrency.code !== currencyCode && currencyCode) {
      const currency = currencyList.find(currency => currency.code === currencyCode)
      setCurrentCurrency(currency)
    }
  }, [currencyCode]) // eslint-disable-line

  useEffect(() => {
    if (!accountList || !accountList.length) {
      return
    }

    accountList.forEach(account => {
      if (parseInt(account.user, 10) !== parseInt(currentUserId, 10)) {
        return
      }

      const accountCurrency = currencyList.find(currency => (
        currency.code === account.country_id
        || (currency.code === 'eu'
          && ['fr', 'de', 'it', 'es', 'nl'].indexOf(account.country_id) !== -1)
      ))

      if (parseInt(selectedUserInfo.user || 0, 10) !== parseInt(currentUserId, 10)) {
        const accountInfo = {
          ...account,
          currency: accountCurrency,
          user: account.user,
          country_id: account.country_id,
          createdat: account.createdat,
          sellerid: account.sellerid,
          plan_id: account.plan_id,
          label: account.country_id + ' - ' + (account.brand_name || account.sellerid),
          average_acos: account.average_acos,
          average_profit: account.average_profit,
          account_type :account.account_type,
          seller_type: account.seller_type,
        }
        dispatch(setSelectedUserInfo(accountInfo))
      } else if (currencyCode !== accountCurrency.code) {
        dispatch(setCurrencyInfo({
          currencyCode: accountCurrency.code,
          currencyRate: 1,
          currencySign: accountCurrency.sign
        }))
      }
    })
  }, [accountList]) // eslint-disable-line

  if (!isLoggedIn) {
    history.push('/login')
  }

  // calcuate the rate with base currency
  const calculateCurrenyRateList = (baseCurrency = 'USD') => {
    let calculatedResult = { ...currencyRateList }

    const baseToUSD = parseFloat(calculatedResult.rates[baseCurrency])
    calculatedResult.base = baseCurrency
    if (baseToUSD !== 1) {
      Object.keys(calculatedResult.rates).forEach(rate => (
        calculatedResult.rates[rate] = parseFloat(calculatedResult.rates[rate] / baseToUSD
      )))
    }

    setCalcCurrencyRateList(calculatedResult)
    return calculatedResult
  }

  const handleCurrencyChange = (event, selectedCurrency) => {
    event.preventDefault()
    setCurrentCurrency(selectedCurrency)

    const accountCurrencyCode = currencyList.find(currency => (
      currency.code === selectedUserInfo.country_id
        || (currency.code === 'eu'
          && ['fr', 'de', 'it', 'es', 'nl'].indexOf(selectedUserInfo.country_id) !== -1)
    )).currencyCode

    const isDefaultCurrency = selectedCurrency.currencyCode === accountCurrencyCode

    let calculatedResult = calcCurrencyRateList
    if (!isDefaultCurrency) {
      calculatedResult = calculateCurrenyRateList(accountCurrencyCode)
    }
    selectedUserInfo.currency = selectedCurrency

    dispatch(setCurrencyInfo({
      currencyCode: selectedCurrency.code,
      currencyRate: isDefaultCurrency ? 1 : calculatedResult.rates[selectedCurrency.currencyCode],
      currencySign: selectedCurrency.sign
    }))
  }

  const handleAccountChange = (event, account) => {
    event.preventDefault()
    const accountCurrency = currencyList.find(currency => (
      currency.code === account.country_id
        || (currency.code === 'eu'
          && ['fr', 'de', 'it', 'es', 'nl'].indexOf(account.country_id) !== -1)
    ))

    dispatch(setSelectedUserInfo({
      ...account,
      currency: accountCurrency,
      user: account.user,
      country_id: account.country_id,
      createdat: account.createdat,
      sellerid: account.sellerid,
      plan_id: account.plan_id,
      label: account.country_id + ' - ' + (account.brand_name || account.sellerid),
      average_acos: account.average_acos,
      average_profit: account.average_profit,
      account_type :account.account_type,
      seller_type: account.seller_type,
    }))

    dispatch(setUserChanged({
      isChanged: true
    }))

    dispatch(setCurrencyInfo({
      currencyCode: accountCurrency.code,
      currencyRate: 1,
      currencySign: accountCurrency.sign
    }))
  }

  const renderAccounts = () => {
    return (accountList || []).map(account => (
      <a
        key={account.user}
        href="#"
        onClick={(event) => { handleAccountChange(event, account) }}
      >
        { getAccountLabel(account) }
      </a>
    ))
  }

  let initials = ''
  if (user && Object.keys(user).length) {
    initials = (user.firstname || '').charAt(0).toUpperCase()
      + (user.lastname || '').charAt(0).toUpperCase()
  }

  return (
    <div className="header-component">
      <div className="header-left">
        <Link to="/dashboard">
          <HomeSvg />
        </Link>
      </div>
      <div className="header-right">
        <CoinComponent />
        <div className="currency dropdown">
          <button className="dropdown-toggle">
            <span className={`flag ${currenctCurrency.flag}`}>&nbsp;</span>
            <span className="value-text">{currenctCurrency.text}</span>
            <span className="value-text">{currenctCurrency.sign}</span>
          </button>
          <div className="dropdown-content">
            {currencyList.map(currency =>
              <a
                key={currency.code}
                href="#"
                onClick={event => { handleCurrencyChange(event, currency) }}
              >
                <span className={`flag ${currency.flag}`}>&nbsp;</span>
                <span className="currency-text">{currency.text}</span>
                <span className="currency-sign">{currency.sign}</span>
              </a>
            )}
          </div>
        </div>
        <NotificationComponent />
        <div className="header-avatar">
          <div className="dropdown">
            <button className="dropdown-toggle">
              { getAccountLabel(selectedAccount) }
              <span className="initials-display">
                { initials }
              </span>
              <ArrowDown />
            </button>
            <div className="dropdown-content">
              { renderAccounts() }
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default HeaderComponent
