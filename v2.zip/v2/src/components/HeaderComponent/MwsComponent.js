import React, { useEffect, useState } from 'react'
import { useDispatch, useStore } from 'react-redux'
import { useLocation } from 'react-router-dom'

import { toast } from '../CommonComponents/ToastComponent/toast'

import { migrateMws } from '../../redux/actions/auth'
import { SP_APP_ID, SP_BETA } from '../../config/api'
import { sellerCentralUrls } from '../../utils/defaultValues'

const MwsComponent = () => {
  const dispatch = useDispatch()
  const store = useStore()
  const location = useLocation()
  const {
    header: { currentUserId, accountList },
  } = store.getState()

  const [isAuthorizing, setIsAuthorizing] = useState(false)

  useEffect(() => {
    const qs = new URLSearchParams(location.search)
    const spCode = qs.get('spapi_oauth_code')

    if (!spCode || isAuthorizing) {
      return
    }

    setIsAuthorizing(true)
    dispatch(migrateMws(spCode)).then(() => {
      setIsAuthorizing(false)
      toast.show({
        title: 'Success',
        description: 'Thank you for authorization.',
      })
    }).catch((error) => {
      setIsAuthorizing(false)
      toast.show({
        title: 'Danger',
        description: error,
      })
    })
  }, []) // eslint-disable-line

  const currentAccount = accountList.find(account => (
    parseInt(account.user, 10) === parseInt(currentUserId, 10)
  ))

  if (!currentAccount || currentAccount.hasSpCode !== false) {
    return null
  }

  let region = 'fe'
  if (['us', 'ca', 'mx', 'br'].indexOf(currentAccount.country_id) !== -1) {
    region = 'na'
  } else if (['gb', 'fr', 'de', 'es', 'it', 'nl', 'in', 'ae', 'se', 'pl', 'tr', 'eg', 'sa']
    .indexOf(currentAccount.country_id) !== -1) {
    region = 'eu'
  }

  let url = `${sellerCentralUrls[region]}/apps/authorize/consent?application_id=${SP_APP_ID}&state=migration`
  if (SP_BETA) {
    url = `${url}&version=beta`
  }

  return (
    <div className="call-component">
      <div className="call-text">
        <div className="call-name">
          Re-authorize Entourage to access your data.
        </div>
        <div className="call-description">
          We’ve switched to the Seller Partner API.
        </div>
      </div>
      <a
        href={url}
        className={`btn btn-red${isAuthorizing ? ' disabled' : ''}`}
      >
        Authorize
      </a>
    </div>
  )
}

export default MwsComponent
