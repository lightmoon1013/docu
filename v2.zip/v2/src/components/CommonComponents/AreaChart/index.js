import React from 'react'
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from 'recharts'
import moment from 'moment'

import {
  formatValue,
  calculateTrendLines,
} from '../../../services/helper'

const COLOR_RED = { stroke: '#EA305C', fill: '#colorUr' }
const COLOR_GREEN = { stroke: '#93DF8D', fill: '#colorUg' }

const getNearValue = (value) => {
  const length = parseInt(value, 10).toString().length
  const divider = Math.pow(10, length)
  return Math.ceil(value / divider) * divider
}

const getColor = (direct, diff) => {
  if (direct) {
    return diff > 0 ? COLOR_RED : COLOR_GREEN
  }
  return diff > 0 ? COLOR_GREEN : COLOR_RED
}

const getChartData = (data, startDate, endDate) => {
  const newAreaData = []
  const start = moment(new Date(startDate)).startOf('day')
  const period = moment(new Date(endDate)).startOf('day').diff(start, 'days')
  for (let index = 0; index <= period; index += 1) {
    const date = moment(start).add(index, 'days').format('yyyy/MM/DD')
    const itemIndex = data.findIndex(item =>
      moment(item.date).format('yyyy/MM/DD') === date
    )
    newAreaData.push({
      value: itemIndex !== -1 ? formatValue(data[itemIndex].value) : 0,
      date,
    })
  }
  return newAreaData
}

const AreaRechartComponent = ({ areaData, direct = false, showXAxis, showYAxis, showToolTip, margin, startDate, endDate }) => {
  const newAreaData = getChartData(areaData, startDate, endDate)
  const [startPoint, endPoint] = calculateTrendLines(newAreaData)
  const values = newAreaData.map(item => item.value || 0)
  const minValue = Math.ceil(Math.min(0, ...values))
  const maxValue = Math.ceil(Math.max(...values)) < 10
    ? Math.ceil(Math.max(...values))
    : getNearValue(Math.ceil(Math.max(...values)))

  return (
    <ResponsiveContainer width="100%" height="100%">
      <AreaChart
        className="area-chart"
        data={newAreaData}
        margin={margin}
      >
        <defs>
          <linearGradient id='colorUr' x1='0' y1='0' x2='0' y2='1'>
            <stop offset='5%' stopColor='#EA305C' stopOpacity={0.8} />
            <stop offset='95%' stopColor='#EA305C' stopOpacity={0} />
          </linearGradient>
          <linearGradient id='colorUg' x1='0' y1='0' x2='0' y2='1'>
            <stop offset='5%' stopColor='#93DF8D' stopOpacity={0.8} />
            <stop offset='95%' stopColor='#93DF8D' stopOpacity={0} />
          </linearGradient>
        </defs>
        {
          showXAxis && <XAxis dataKey="date" />
        }
        {
          showYAxis && <YAxis dataKey="value" domain={[minValue, maxValue]} />
        }
        {
          showToolTip && <Tooltip />
        }
        <Area
          type='monotone'
          dataKey='value'
          stroke={getColor(direct, endPoint.y - startPoint.y > 0)['stroke']}
          fillOpacity={1}
          fill={`url(${getColor(direct, endPoint.y - startPoint.y > 0)['fill']})`}
        />
      </AreaChart>
    </ResponsiveContainer>
  )
}

export default AreaRechartComponent
