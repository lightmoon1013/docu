import React, { useState } from "react"

import { ReactComponent as VideoSvg } from '../../../assets/svg/video.svg'

import VideoModal from '../VideoModal'

const VideoLink = ({ videoList, modalTitle = '', linkName = 'Watch Tutorial' }) => {
  const [showModal, setShowModal] = useState(false)

  return (
    <>
      <button type="button" className="tutorial-link" onClick={() => { setShowModal(true) }}>
        <VideoSvg />
        {linkName}
      </button>
      <VideoModal
        videoList={videoList}
        showModal={showModal}
        onClose={() => { setShowModal(false) }}
        title={modalTitle}
      />
    </>
  )
}
export default VideoLink