import React, { useEffect, useRef } from 'react'

const ImportFileContent = ({ loadData, showFileUpload, hideFileUpload }) => {
  const fileUpload = useRef()

  useEffect(() => {
    if (showFileUpload) {
      fileUpload.current.click()
      hideFileUpload()
    }
    // eslint-disable-next-line
  }, [showFileUpload])

  let fileReader

  const handleFileRead = (e, fileName) => {
    e.preventDefault()
    loadData(fileReader.result, fileName)
  }

  const handleFileChosen = (file) => {
    if (!file
      || (file.type !== 'application/vnd.ms-excel' && file.type !== 'text/csv')) {
      return
    }
    fileReader = new FileReader()
    fileReader.onloadend = e => handleFileRead(e, file.name)
    fileReader.readAsText(file)
  }

  return (
    <div className='upload-component'>
      <input
        type='file'
        accept='.csv'
        ref={fileUpload}
        onChange={e => handleFileChosen(e.target.files[0])}
      />
    </div>
  )
}

export default ImportFileContent
