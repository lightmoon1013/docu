import React from 'react'
import { useDispatch, useStore } from 'react-redux'

import { toast } from '../ToastComponent/toast'

import { ReactComponent as CloseSvg } from '../../../assets/svg/close.svg'

import { applyFilter } from '../../../redux/actions/pageGlobal'
import filterDef from '../../../utils/filterDef'

const TableFilterShower = ({ filterName, noTitle = false, onValidate }) => {
  const dispatch = useDispatch()
  const store = useStore()

  const {
    pageGlobal: {
      filterValues,
    },
  } = store.getState()

  const handleRemove = (key) => {
    const newValues = { ...(filterValues || {})[filterName] || {} }
    delete newValues[key]

    if (onValidate) {
      const error = onValidate(newValues)
      if (error) {
        toast.show({
          title: 'Warning',
          description: error,
        })
        return
      }
    }

    dispatch(applyFilter(filterName, newValues))
  }

  const values = (filterValues || {})[filterName] || {}
  const filterTags = []
  filterDef[filterName].forEach((filter) => {
    if (filter.type === 'select') {
      if ((values[filter.key] || '') !== '') {
        filterTags.push((
          <span key={filter.key}>
            { `${filter.label} = ${values[filter.key].label}` }
            <CloseSvg className="close-button" onClick={() => { handleRemove(filter.key) }} />
          </span>
        ))
      }
    } else if (filter.type === 'target_acos') {
      if (values[filter.key] === true) {
        filterTags.push((
          <span key={filter.key}>
            { filter.label }
            <CloseSvg className="close-button" onClick={() => { handleRemove(filter.key) }} />
          </span>
        ))
      }
    } else {
      if ((values[`${filter.key}Min`] || '') !== '') {
        filterTags.push((
          <span key={`${filter.key}Min`}>
            { `${filter.label} >= ${values[`${filter.key}Min`]}` }
            <CloseSvg className="close-button" onClick={() => { handleRemove(`${filter.key}Min`) }} />
          </span>
        ))
      }

      if ((values[`${filter.key}Max`] || '') !== '') {
        filterTags.push((
          <span key={`${filter.key}Max`}>
            { `${filter.label} <= ${values[`${filter.key}Max`]}` }
            <CloseSvg className="close-button" onClick={() => { handleRemove(`${filter.key}Max`) }} />
          </span>
        ))
      }
    }
  })

  return (
    filterTags.length > 0 && (
      <div className="table-filter-shower">
        {
          !noTitle && (
            <span className="filter-title">
              Filters
            </span>
          )
        }
        <span className="filter-contents">
          { filterTags }
        </span>
      </div>
    )
  )
}

export default TableFilterShower
