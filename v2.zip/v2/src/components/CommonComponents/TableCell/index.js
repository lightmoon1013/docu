import React from 'react'

import AreaRechartComponent from '../AreaChart'

import { formatValue, formatCurrency } from '../../../services/helper'

const TableCell = ({ record, columnKey, columnSelection,
  currencySign, currencyRate, showHistory = false, historyData = [],
  startDate, endDate, onClick = () => {} }) => {
  if (typeof columnSelection !== 'undefined'
    && !columnSelection.includes(columnKey)) {
    return null
  }

  let value
  if (['orders', 'impressions', 'clicks', 'ntb_orders', 'viewable_impressions'].includes(columnKey)) {
    value = formatValue(record[columnKey], 'removeZeroDecimal')
  } else if (['acos', 'ctr', 'conversion', 'ntb_orders_percent', 'ntb_sales_percent'].includes(columnKey)) {
    value = formatValue(record[columnKey], 'percent')
  } else if (['revenue', 'cost', 'cpc', 'ntb_sales', 'daily_budget'].includes(columnKey)) {
    value = formatCurrency(record[columnKey], currencySign, currencyRate)
  } else if (columnKey === 'roas') {
    value = formatValue(record[columnKey], 'number')
  } else if (columnKey === 'st_impr_rank') {
    if (parseFloat(record[columnKey])) {
      value = formatValue(Math.ceil(parseFloat(record[columnKey])), 'removeZeroDecimal')
    }
  } else if (columnKey === 'st_impr_share') {
    if (parseFloat(record[columnKey])) {
      value = formatValue(record[columnKey], 'percent')
    }
  }

  const direct = columnKey === 'cpc' || columnKey === 'acos'

  return (
    <div className="table-col col-history" onClick={onClick}>
      { value }
      {
        showHistory && (
          <>
            <AreaRechartComponent
              areaData={
                historyData.map(item => ({
                  date: item.report_date,
                  value: item[columnKey] || 0,
                }))
              }
              startDate={startDate}
              endDate={endDate}
              direct={direct}
            />
            <span className="tooltiptext">+</span>
          </>
        )
      }
    </div>
  )
}

export default TableCell
