/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useState } from 'react'
import { useDispatch } from 'react-redux'
import OutsideClickHandler from 'react-outside-click-handler';

import CheckboxComponent from '../CheckboxComponent'

import { ReactComponent as CloseSvg } from '../../../assets/svg/close.svg'

import { hideColumnEditorAction } from '../../../redux/actions/pageGlobal'

const ColumnEditor = ({ columnList, currentSelection, noReset = false, onApply }) => {
  const dispatch = useDispatch()

  const [selectedCols, setSelectedCols] = useState([...new Set(currentSelection)])

  const handleCheckAll = (checked) => {
    if (checked) {
      setSelectedCols(columnList.map(col => col.key))
    } else {
      setSelectedCols(columnList.filter(col => col.fixed).map(col => col.key))
    }
  }

  const handleCheck = (checked, column) => {
    const newSelection = [...selectedCols]

    if (checked) {
      if (!selectedCols.includes(column.key)) {
        newSelection.push(column.key)
      }
    } else if (!column.fixed) {
      newSelection.splice(newSelection.indexOf(column.key), 1)
    }

    setSelectedCols(newSelection)
  }

  const handleApply = () => {
    dispatch(onApply(selectedCols))
  }

  const handleReset = (event) => {
    event.preventDefault()
    setSelectedCols(columnList.filter(col => col.default).map(col => col.key))
  }

  const selectedCount = columnList.filter(col => selectedCols.includes(col.key)).length

  return (
    <OutsideClickHandler
      onOutsideClick={() => { dispatch(hideColumnEditorAction()) }}
    >
      <div className="column-editor">
        <div className="pane-header">
          <div className="pane-title">Table Columns</div>
          <CloseSvg className="close-button" onClick={() => { dispatch(hideColumnEditorAction()) }} />
        </div>
        {
          !noReset && (
            <div className="pane-note">
              <span>{ selectedCols.length } columns selected.</span>
              <a href="#" onClick={handleReset}>
                Reset to default
              </a>
            </div>
          )
        }
        <div className="pane-body">
          <CheckboxComponent
            label={selectedCount !== columnList.length ? 'Select all' : 'Deselect all'}
            checked={selectedCount === columnList.length}
            onChange={handleCheckAll}
          />
          {
            columnList.map(column => (
              <CheckboxComponent
                key={column.key}
                label={column.label}
                checked={selectedCols.includes(column.key)}
                disabled={column.fixed}
                onChange={(checked) => handleCheck(checked, column)}
              />
            ))
          }
        </div>
        <div className="pane-footer">
          <button type="button" className="btn btn-blue" onClick={handleApply}>
            Apply
          </button>
        </div>
      </div>
    </OutsideClickHandler>
  )
}

export default ColumnEditor
