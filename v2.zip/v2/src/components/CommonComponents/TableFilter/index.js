import React, { useState }  from 'react'
import { useDispatch, useStore } from 'react-redux'
import OutsideClickHandler from 'react-outside-click-handler'
import Select from 'react-select'
import { Tooltip, Whisper } from 'rsuite'

import CheckboxComponent from '../CheckboxComponent'
import { ReactComponent as CloseSvg } from '../../../assets/svg/close.svg'
import { ReactComponent as InfoSvg } from '../../../assets/svg/info.svg'

import { applyFilter, hideFilter } from '../../../redux/actions/pageGlobal'
import filterDef from '../../../utils/filterDef'

const TableFilter = ({ title = 'Table Filters', filterName }) => {
  const dispatch = useDispatch()
  const store = useStore()

  const {
    pageGlobal: {
      filterValues,
    },
  } = store.getState()

  const [values, setValues] = useState({ ...((filterValues || {})[filterName] || {}) })

  const handleApply = () => {
    dispatch(applyFilter(filterName, values))
  }

  const handleReset = () => {
    const newValues = { ...values }
    filterDef[filterName].forEach((filter) => {
      if (!filter.type || filter.type === 'range') {
        newValues[`${filter.key}Min`] = ''
        newValues[`${filter.key}Max`] = ''
      } else {
        newValues[filter.key] = ''
      }
    })
    setValues(newValues)
    dispatch(applyFilter(filterName, newValues))
  }

  const setFilterValue = (key, value) => {
    setValues({
      ...values,
      [key]: value,
    })
  }

  const renderFilter = (filter) => {
    let contents
    if (filter.type === 'select') {
      contents = (
        <Select
          options={filter.options}
          value={values[filter.key]}
          onChange={(data) => setFilterValue(filter.key, data)}
        />
      )
    } else if (filter.type === 'target_acos') {
      contents = (
        <div className="checkbox-wrapper">
          <CheckboxComponent
            label={filter.label}
            checked={values[filter.key]}
            onChange={(checked) => { setFilterValue(filter.key, checked) }}
          />
          <Whisper placement="right" trigger="hover" speaker={(
            <Tooltip>
              <p>We’ll use your set Target ACoS for each campaign to find what needs to be optimized, fast!</p>
              <p>Results that are above your target ACoS will be revealed for each campaign.</p>
            </Tooltip>
          )}>
            <InfoSvg />
          </Whisper>
        </div>
      )
    } else {
      let isDisabled = false
      if (filter.depends) {
        if (filter.dependValue !== false) {
          isDisabled = values[filter.depends] !== filter.dependValue
        } else {
          isDisabled = values[filter.depends] !== filter.dependValue
            && typeof values[filter.depends] !== 'undefined'
        }
      }
      contents = (
        <div className="filter-row-child">
          <input
            type="number"
            placeholder="Min"
            value={values[`${filter.key}Min`] || ''}
            disabled={isDisabled}
            onChange={(e) => setFilterValue(`${filter.key}Min`, e.target.value)}
          />
          <input
            type="number"
            placeholder="Max"
            value={values[`${filter.key}Max`] || ''}
            disabled={isDisabled}
            onChange={(e) => setFilterValue(`${filter.key}Max`, e.target.value)}
          />
        </div>
      )
    }

    return (
      <div key={filter.key} className="filter-row">
        {
          filter.type !== 'target_acos' && (
            <span>{ filter.label }</span>
          )
        }
        { contents }
      </div>
    )
  }

  return (
    <OutsideClickHandler
      onOutsideClick={() => { dispatch(hideFilter(filterName)) }}
    >
      <div className="table-filter-pane">
        <div className="pane-header">
          <div className="pane-title">{ title }</div>
          <CloseSvg className="close-button" onClick={() => { dispatch(hideFilter(filterName)) }} />
        </div>
        <div className="pane-body">
          { filterDef[filterName].map(renderFilter) }
        </div>
        <div className="pane-footer">
          <button type="button" className="btn btn-white" onClick={handleReset}>Reset</button>
          <button type="button" className="btn btn-blue" onClick={handleApply}>Apply</button>
        </div>
      </div>
    </OutsideClickHandler>
  )
}

export default TableFilter
