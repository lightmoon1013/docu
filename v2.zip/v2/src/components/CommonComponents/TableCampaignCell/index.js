import React from 'react'

import { campaignTypeMap } from '../../../utils/defaultValues'

const TableCampaignCell = ({ record }) => (
  <div className="table-col col-campaign" title={(record.campaignName || record.campaign)}>
    <div className="contents">
      { (record.campaignName || record.campaign) }
    </div>
    <div className="campaign-detail">
      {
        (record.campaignType || record.campaign_type) === 'Sponsored Products' && (
          <span>
            { (record.targetingType || record.targeting_type) === 'auto' ? 'Auto' : 'Manual' }
          </span>
        )
      }
      <span>
        { campaignTypeMap[(record.campaignType || record.campaign_type)] }
      </span>
    </div>
  </div>
)

export default TableCampaignCell
