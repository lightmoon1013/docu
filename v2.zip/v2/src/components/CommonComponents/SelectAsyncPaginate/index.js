import React from 'react'
import { useDispatch } from 'react-redux'
import { AsyncPaginate } from 'react-select-async-paginate'

const SelectAsyncPaginate = ({
  components, loadSkus, selection, onChange, onInputChange,
  keyword, isDisabled = false, isMulti = true,
  isClearable = false, closeMenuOnSelect = false,
  placeholder = 'Select SKUs...',
  onLoadedItems = () => {},
}) => {
  const dispatch = useDispatch()
  const loadOptions = async (searchQuery, loadedOptions, { page }) => {
    const response = await dispatch(
      loadSkus({
        page,
        countPerPage: 10,
        search: searchQuery || '',
      })
    )
    onLoadedItems(response)

    return {
      options: response,
      hasMore: response.length >= 1,
      additional: {
        page: page + 1,
      },
    }
  }

  return (
    <AsyncPaginate
      key="skus"
      loadOptions={loadOptions}
      getOptionLabel={sku => sku.sku}
      getOptionValue={sku => sku.sku}
      value={selection}
      components={components}
      isClearable={isClearable}
      isMulti={isMulti}
      isDisabled={isDisabled}
      closeMenuOnSelect={closeMenuOnSelect}
      hideSelectedOptions={false}
      placeholder={placeholder}
      inputValue={keyword}
      onChange={onChange}
      onInputChange={onInputChange}
      additional={{
        page: 1,
      }}
    />
  )
}

export default SelectAsyncPaginate
