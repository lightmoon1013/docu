import React, { useEffect, useState } from 'react'
import { useStore } from 'react-redux'

import SortableTable from '../CommonComponents/SortableTableComponent'
import TableCell from '../CommonComponents/TableCell'
import DupTargetModal from './DupTargetModal'

import {
  parseAsinTarget,
  tableSorter,
  calcDerivedMetrics,
  getExportValueForColumn,
} from '../../services/helper'

import { bulkBidColumnList } from '../../utils/defaultValues'

const columns = [
  { key: 'target_text', name: 'ASIN', className: 'col-target' },
  ...bulkBidColumnList,
]

const DupTargetTable = ({ onChangeDate }) => {
  const store = useStore()
  const {
    header: {
      currencySign,
      currencyRate,
    },
    pageGlobal: {
      campaignTableColumns,
      filterValues,
    },
    campaign: {
      campaignsWithHistory,
    },
    bulkEngine: {
      findDupsData,
    },
  } = store.getState()

  const [targets, setTargets] = useState([])
  const [selectedTarget, setSelectedTarget] = useState(null)

  useEffect(() => {
    const campaignNamesById = {}
    const campaignTypesById = {}
    const campaignTargetingTypesById = {}
    campaignsWithHistory.forEach((campaign) => {
      campaignNamesById[campaign.campaign_id] = campaign.campaign
      campaignTypesById[campaign.campaign_id] = campaign.campaignType
      campaignTargetingTypesById[campaign.campaign_id] = campaign.targeting_type
    })

    const extendedTargets = [];
    Object.keys(findDupsData.targets || {}).forEach((target) => {
      const total = {
        revenue: 0,
        cost: 0,
        impressions: 0,
        clicks: 0,
        orders: 0,
        units: 0,
        ntb_orders: 0,
        ntb_sales: 0,
        viewable_impressions: 0,
      }

      const children = [];
      findDupsData.targets[target].forEach((record) => {
        const campaignType = campaignTypesById[record.campaign_id] || ''

        // Filter by ad type.
        if (filterValues && filterValues['dupTarget'] && filterValues['dupTarget']['campaignType']) {
          if (campaignType.toLowerCase() !== filterValues['dupTarget']['campaignType'].value) {
            return
          }
        }

        total.revenue += parseFloat(record.revenue || 0)
        total.cost += parseFloat(record.cost || 0)
        total.impressions += parseInt(record.impressions || 0, 10)
        total.clicks += parseInt(record.clicks || 0, 10)
        total.orders += parseInt(record.orders || 0, 10)
        total.units += parseInt(record.units || 0, 10)
        total.ntb_orders += parseInt(record.ntb_orders || 0, 10)
        total.ntb_sales += parseFloat(record.ntb_sales || 0)
        total.viewable_impressions += parseInt(record.viewable_impressions || 0, 10)

        children.push({
          ...calcDerivedMetrics(record),
          campaignName: campaignNamesById[record.campaign_id] || '',
          campaignType,
          targetingType: campaignTargetingTypesById[record.campaign_id] || '',
        })
      })

      if (children.length) {
        extendedTargets.push({
          target_text: target,
          ...calcDerivedMetrics(total),
          children,
        })
      }
    })

    setTargets(extendedTargets)
  }, [findDupsData, campaignsWithHistory, filterValues])

  const renderTarget = record => (
    <>
      <div className="table-col col-target" title={parseAsinTarget(record.target_text)}>
        <strong className="contents">
          { parseAsinTarget(record.target_text) }
        </strong>
      </div>
      {
        bulkBidColumnList.map(column => (
          <TableCell
            key={column.key}
            record={record}
            columnKey={column.key}
            columnSelection={campaignTableColumns}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  // Render aggregation row.
  const renderTotal = summary => (
    <>
      <div className="table-col col-target">Totals:</div>
      {
        bulkBidColumnList.map(column => (
          <TableCell
            key={column.key}
            record={summary}
            columnKey={column.key}
            columnSelection={campaignTableColumns}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  const getExportData = (exportableColumns, record) => (
    exportableColumns.map((column) => {
      if (column.key === 'target_text') {
        return parseAsinTarget(record.target_text)
      }
      return getExportValueForColumn(record, column.key, currencySign, currencyRate)
    })
  )


  return (
    <>
      <SortableTable
        columns={columns}
        defaultSort={['cost', 'desc']}
        sorter={tableSorter(['target_text'])}
        className="table-targets"
        records={targets || []}
        idField="target_text"
        searchFields={['target_text']}
        paginationSelectPlacement="top"
        noCheckBox
        hasSticky
        hasDateRange
        filterName="dupTarget"
        columnEditorId="dupTargetResult"
        columnList={bulkBidColumnList}
        columnSelection={campaignTableColumns}
        exportFileName="Find Duplicate Targets"
        getExportData={getExportData}
        renderRecord={renderTarget}
        renderTotal={renderTotal}
        onClickRecord={setSelectedTarget}
        onChangeDate={onChangeDate}
      />
      <DupTargetModal
        duplicatedTarget={selectedTarget}
        onClose={() => { setSelectedTarget(null) }}
      />
    </>
  )
}

export default DupTargetTable
