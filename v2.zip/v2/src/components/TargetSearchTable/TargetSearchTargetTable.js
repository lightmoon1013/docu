import React, { useEffect, useState } from 'react'
import { useDispatch, useStore } from 'react-redux'
import { Toggle } from 'rsuite'

import SortableTable from '../CommonComponents/SortableTableComponent'
import GroupTable from '../CommonComponents/GroupTableComponent'
import { toast } from '../CommonComponents/ToastComponent/toast'
import TableCell from '../CommonComponents/TableCell'
import TableCampaignCell from '../CommonComponents/TableCampaignCell'
import BidAdjustComponent from '../CommonComponents/BidAdjustComponent'
import ThumbHistory from '../CampaignTableComponent/ThumbHistory'

import { ReactComponent as HistorySvg } from '../../assets/svg/history.svg'

import {
  adjustTargetBids,
  updateTargetStates,
} from '../../redux/actions/bulkEngine'

import {
  formatCurrency,
  parseAsinTarget,
  tableSorter,
  calcDerivedMetrics,
  capitalizeFirstLetter,
  getExportValueForColumn,
  groupRecords,
  copyToClipboard,
} from '../../services/helper'

import {
  bulkBidColumnList,
  adjustBidOptions,
  ADJUST_BID_RAISE,
  ADJUST_BID_LOWER,
  ADJUST_BID_CPC,
} from '../../utils/defaultValues'

const columns = [
  { key: 'target_text', name: 'ASIN', className: 'col-target' },
  { key: 'campaignName', name: 'Campaign', className: 'col-campaign' },
  { key: 'bid', name: 'Current Bid' },
  ...bulkBidColumnList,
]

const columnsGroup = [
  { key: 'campaignName', name: 'Campaign', className: 'col-campaign', parentOnly: true },
  { key: 'checkPlaceholder', name: '', className: 'col-check', exportable: false, parentOnly: true },
  { key: 'target_text', name: 'ASIN', className: 'col-target' },
  { key: 'bid', name: 'Current Bid' },
  ...bulkBidColumnList,
]

const TargetSearchTargetTable = ({ startDate, endDate, onChangeDate, onLoadChart }) => {
  const dispatch = useDispatch()
  const store = useStore()
  const {
    header: {
      currencySign,
      currencyRate,
    },
    pageGlobal: {
      campaignTableColumns,
    },
    campaign: {
      campaignsWithHistory,
    },
    bulkEngine: {
      findTargetsData,
      targetChartsData,
      isAdjustingTargetBids,
      isUpdatingTargetStates,
      isGettingTargetCharts,
    },
  } = store.getState()

  const [groupMode, setGroupMode] = useState(false)
  const [targets, setTargets] = useState([])
  const [groupedTargets, setGroupedTargets] = useState([])
  const [selectedTargets, setSelectedTargets] = useState([])
  const [isShowAdjustBid, setIsShowAdjustBid] = useState(false)
  const [selectedAdjustBidOption, setSelectedAdjustBidOption] = useState(adjustBidOptions[0])
  const [bidValue, setBidValue] = useState(0)
  const [isShowHistory, setIsShowHistory] = useState(false)
  const [historyData, setHistoryData] = useState({})
  const [historyPayload, setHistoryPayload] = useState({})

  useEffect(() => {
    const campaignNamesById = {}
    const campaignTypesById = {}
    const campaignTargetingTypesById = {}
    campaignsWithHistory.forEach((campaign) => {
      campaignNamesById[campaign.campaign_id] = campaign.campaign
      campaignTypesById[campaign.campaign_id] = campaign.campaignType
      campaignTargetingTypesById[campaign.campaign_id] = campaign.targeting_type
    })

    const extendedTargets = (findTargetsData.targets || []).map((record) => ({
      ...calcDerivedMetrics(record),
      campaignName: campaignNamesById[record.campaign_id] || '',
      campaignType: campaignTypesById[record.campaign_id] || '',
      targetingType: campaignTargetingTypesById[record.campaign_id] || '',
    }))

    setTargets(extendedTargets)
    setGroupedTargets(
      groupRecords(
        extendedTargets,
        'campaign_id',
        ['campaignName', 'campaignType', 'targetingType']
      )
    )
  }, [findTargetsData, campaignsWithHistory])

  useEffect(() => {
    const dataByTarget = {};
    (targetChartsData.targets || []).forEach((record) => {
      const key = `${record.campaign_id}-${record.target_id}`
      if (!dataByTarget[key]) {
        dataByTarget[key] = []
      }
      dataByTarget[key].push(calcDerivedMetrics(record))
    })
    setHistoryData(dataByTarget)
  }, [targetChartsData])

  const handleChangeState = (state) => {
    let targetsChanged = []
    targets.filter(record => (
      selectedTargets.indexOf(record.target_id) !== -1
    )).forEach((record) => {
      targetsChanged.push({
        campaignId: record.campaign_id,
        campaignType: record.campaignType,
        adGroupId: record.adgroup_id,
        targetId: record.target_id,
        // Below information are used for logging in backend.
        campaignName: record.campaignName,
        adgroupName: record.adgroup_name,
        target_text: record.target_text,
      })
    })

    // Remove duplicate entries.
    targetsChanged =  [...new Map(targetsChanged.map(item => [item.targetId, item])).values()]

    if (targetsChanged.length) {
      dispatch(updateTargetStates(targetsChanged, state))
    }
  }

  const handleAdjustBid = () => {
    if (selectedAdjustBidOption.value !== ADJUST_BID_CPC
      && (bidValue === '' || isNaN(bidValue))) {
      toast.show({
        title: 'Warning',
        description: 'Please enter the valid bid value.',
      })
      return
    }

    let targetsChanged = []
    targets.filter(record => (
      selectedTargets.indexOf(record.target_id) !== -1
    )).forEach((record) => {
      let newBid = parseFloat(bidValue)
      if (selectedAdjustBidOption.value === ADJUST_BID_RAISE) {
        newBid = parseFloat(record.bid || 0) * (1 + (newBid / 100))
      } else if (selectedAdjustBidOption.value === ADJUST_BID_LOWER) {
        newBid = parseFloat(record.bid || 0) * (1 - (newBid / 100))
      } else if (selectedAdjustBidOption.value === ADJUST_BID_CPC) {
        newBid = parseFloat(record.cpc || 0)
      }

      if (newBid >= 0.15) {
        targetsChanged.push({
          campaignId: record.campaign_id,
          campaignType: record.campaignType,
          adGroupId: record.adgroup_id,
          targetId: record.target_id,
          bid: parseFloat(newBid.toFixed(2)),
          // Below information are used for logging in backend.
          campaignName: record.campaignName,
          adgroupName: record.adgroup_name,
          target_text: record.target_text,
          originalBid: record.bid,
        })
      }
    })

    // Remove duplicate entries.
    targetsChanged =  [...new Map(targetsChanged.map(item => [item.targetId, item])).values()]

    if (!targetsChanged.length) {
      toast.show({
        title: 'Warning',
        description: 'The minimum bid allowed is $0.15. Please check your targets.',
      })
      return
    }

    dispatch(adjustTargetBids(targetsChanged))
  }

  const handleShowHistory = () => {
    if (!isShowHistory) {
      onLoadChart('targets')
      setIsShowHistory(true)
    } else {
      setIsShowHistory(false)
    }
  }

  const handleHistoryClick = (record, column) => {
    if (!isShowHistory) {
      return
    }

    setHistoryPayload({
      metric: column.label,
      asin: parseAsinTarget(record.target_text),
      direct: column.key === 'cpc' || column.key === 'acos',
      data: (historyData[`${record.campaign_id}-${record.target_id}`] || []).map(item => ({
        date: item.report_date,
        value: item[column.key] || 0,
      })),
    })
  }

  const handleCopy = () => {
    const dataToCopy = targets.filter(record => (
      selectedTargets.indexOf(record.target_id) !== -1
    )).map(record => parseAsinTarget(record.target_text))

    copyToClipboard(dataToCopy.join('\n'))

    toast.show({
      title: 'Success',
      description: `Successfully copied ${dataToCopy.length} target${dataToCopy.length > 1 ? 's' : ''}.`
    })
  }

  const renderFilter = () => {
    return (
      <div className="filter-container">
        <div className="toggle-wrapper">
          <Toggle
            checked={groupMode}
            checkedChildren="Organize by campaigns"
            unCheckedChildren="By ASINs"
            onChange={setGroupMode}
          />
        </div>
      </div>
    )
  }

  const renderAction = () => {
    if (!selectedTargets.length) {
      return null
    }

    if (!isShowAdjustBid) {
      const isEnableDisabled = typeof targets.find(record => (
        selectedTargets.indexOf(record.target_id) !== -1
        && record.state !== 'enabled'
      )) === 'undefined'

      const isPauseDisabled = typeof targets.find(record => (
        selectedTargets.indexOf(record.target_id) !== -1
        && record.state !== 'paused'
      )) === 'undefined'

      return (
        <>
          <button
            type="button"
            className="btn btn-green"
            onClick={() => { handleCopy() }}
          >
            Copy
          </button>
          <button
            type="button"
            className="btn btn-green"
            disabled={isUpdatingTargetStates || isEnableDisabled}
            onClick={() => { handleChangeState('enabled') }}
          >
            Enable
          </button>
          <button
            type="button"
            className="btn btn-red"
            disabled={isUpdatingTargetStates || isPauseDisabled}
            onClick={() => { handleChangeState('paused') }}
          >
            Pause
          </button>
          <button
            type="button"
            className="btn btn-light-blue"
            onClick={() => { setIsShowAdjustBid(true) }}
          >
            Adjust Bid
          </button>
        </>
      )
    }

    return (
      <BidAdjustComponent
        adjustBidOption={selectedAdjustBidOption}
        bidValue={bidValue}
        isAdjusting={isAdjustingTargetBids}
        onChangeAdjustBidOption={setSelectedAdjustBidOption}
        onChangeBidValue={setBidValue}
        onApply={handleAdjustBid}
        onCancel={() => { setIsShowAdjustBid(false) }}
      />
    )
  }

  const renderSecondaryAction = () => {
    return (
      <HistorySvg title="History" onClick={handleShowHistory}/>
    )
  }

  const renderTarget = record => (
    <>
      <div className="table-col col-target" title={parseAsinTarget(record.target_text)}>
        <strong>
          { parseAsinTarget(record.target_text) }
        </strong>
        <div className="meta-data">
          { capitalizeFirstLetter(record.state) }
        </div>
      </div>
      <TableCampaignCell record={record} />
      <div className="table-col">
        { formatCurrency(record.bid, currencySign, currencyRate) }
      </div>
      {
        bulkBidColumnList.map(column => (
          <TableCell
            key={column.key}
            record={record}
            columnKey={column.key}
            columnSelection={campaignTableColumns}
            currencySign={currencySign}
            currencyRate={currencyRate}
            showHistory={isShowHistory && !isGettingTargetCharts}
            historyData={historyData[`${record.campaign_id}-${record.target_id}`] || []}
            startDate={startDate}
            endDate={endDate}
            onClick={() => { handleHistoryClick(record, column) }}
          />
        ))
      }
    </>
  )

  // Render aggregation row.
  const renderTotal = summary => (
    <>
      <div className="table-col col-target">Totals:</div>
      <div className="table-col col-campaign" />
      <div className="table-col" />
      {
        bulkBidColumnList.map(column => (
          <TableCell
            key={column.key}
            record={summary}
            columnKey={column.key}
            columnSelection={campaignTableColumns}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  const getExportData = (exportableColumns, record) => (
    exportableColumns.map((column) => {
      if (column.key === 'target_text') {
        return `${parseAsinTarget(record.target_text)} (${capitalizeFirstLetter(record.state)})`
      }
      if (column.key === 'bid') {
        return formatCurrency(record.bid, currencySign, currencyRate)
      }
      return getExportValueForColumn(record, column.key, currencySign, currencyRate)
    })
  )

  // For grouped table.
  const renderParent = record => (
    <>
      <TableCampaignCell record={record} />
      <div className="table-col col-check" />
      <div className="table-col col-target">
        { record.children.length } targets
      </div>
      <div className="table-col" />
      {
        bulkBidColumnList.map(column => (
          <TableCell
            key={column.key}
            record={record}
            columnKey={column.key}
            columnSelection={campaignTableColumns}
            currencySign={currencySign}
            currencyRate={currencyRate}
            showHistory={isShowHistory && !isGettingTargetCharts}
            historyData={historyData[`${record.campaign_id}-${record.target_id}`] || []}
            startDate={startDate}
            endDate={endDate}
            onClick={() => { handleHistoryClick(record, column) }}
          />
        ))
      }
    </>
  )

  const renderChild = record => (
    <>
      <div className="table-col col-target" title={parseAsinTarget(record.target_text)}>
        <strong>
          { parseAsinTarget(record.target_text) }
        </strong>
        <div className="meta-data">
          { capitalizeFirstLetter(record.state) }
        </div>
      </div>
      <div className="table-col">
        { formatCurrency(record.bid, currencySign, currencyRate) }
      </div>
      {
        bulkBidColumnList.map(column => (
          <TableCell
            key={column.key}
            record={record}
            columnKey={column.key}
            columnSelection={campaignTableColumns}
            currencySign={currencySign}
            currencyRate={currencyRate}
            showHistory={isShowHistory && !isGettingTargetCharts}
            historyData={historyData[`${record.campaign_id}-${record.target_id}`] || []}
            startDate={startDate}
            endDate={endDate}
            onClick={() => { handleHistoryClick(record, column) }}
          />
        ))
      }
    </>
  )

  const renderTotalGroup = summary => (
    <>
      <div className="table-col col-campaign">Totals:</div>
      <div className="table-col col-check" />
      <div className="table-col col-target" />
      <div className="table-col" />
      {
        bulkBidColumnList.map(column => (
          <TableCell
            key={column.key}
            record={summary}
            columnKey={column.key}
            columnSelection={campaignTableColumns}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  const isLoading = isAdjustingTargetBids
    || isUpdatingTargetStates
    || isGettingTargetCharts

  return (
    <>
      { renderFilter() }
      {
        groupMode ? (
          <SortableTable
            tableComponent={GroupTable}
            columns={columnsGroup}
            defaultSort={['cost', 'desc']}
            sorter={tableSorter(['campaignName'])}
            className="table-grouped-targets"
            records={groupedTargets}
            idField="campaign_id"
            searchFields={['target_text']}
            exactSearch
            searchPlaceholder="Exact match search"
            selectedRecords={selectedTargets}
            paginationSelectPlacement="top"
            hasSticky
            hasDateRange
            filterName="targetSearchTarget"
            columnEditorId="targetSearchTargetResult"
            columnList={bulkBidColumnList}
            columnSelection={campaignTableColumns}
            isLoading={isLoading}
            exportFileName="Target Search"
            getExportData={getExportData}
            renderRecord={renderParent}
            renderTotal={renderTotalGroup}
            renderTopRight={renderAction}
            renderTopRightSecondary={renderSecondaryAction}
            onChange={setSelectedTargets}
            onChangeDate={onChangeDate}
            sorterChild={tableSorter(['state', 'target_text'])}
            idFieldChild="target_id"
            renderChild={renderChild}
          />
        ) : (
          <SortableTable
            columns={columns}
            defaultSort={['cost', 'desc']}
            sorter={tableSorter(['campaignName', 'state', 'target_text'])}
            className="table-targets"
            records={targets || []}
            idField="target_id"
            searchFields={['target_text']}
            exactSearch
            searchPlaceholder="Exact match search"
            selectedRecords={selectedTargets}
            paginationSelectPlacement="top"
            hasSticky
            hasDateRange
            filterName="targetSearchTarget"
            columnEditorId="targetSearchTargetResult"
            columnList={bulkBidColumnList}
            columnSelection={campaignTableColumns}
            isLoading={isLoading}
            exportFileName="Target Search"
            getExportData={getExportData}
            renderRecord={renderTarget}
            renderTotal={renderTotal}
            renderTopRight={renderAction}
            renderTopRightSecondary={renderSecondaryAction}
            onChange={setSelectedTargets}
            onChangeDate={onChangeDate}
          />
        )
      }
      <ThumbHistory
        title={`Target: ${historyPayload.asin}`}
        areaData={historyPayload.data || []}
        metric={historyPayload.metric}
        direct={historyPayload.direct}
        startDate={startDate}
        endDate={endDate}
        onClose={() => { setHistoryPayload({}) }}
      />
    </>
  )
}

export default TargetSearchTargetTable
