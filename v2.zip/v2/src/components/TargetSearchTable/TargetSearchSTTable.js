import React, { useEffect, useState, useMemo } from 'react'
import { useStore } from 'react-redux'
import { Toggle } from 'rsuite'
import Select from 'react-select'

import SortableTable from '../CommonComponents/SortableTableComponent'
import GroupTable from '../CommonComponents/GroupTableComponent'
import { toast } from '../CommonComponents/ToastComponent/toast'
import TableCell from '../CommonComponents/TableCell'
import TableCampaignCell from '../CommonComponents/TableCampaignCell'
import NegativeCreatorModal from '../BulkOp/NegativeCreatorModal'
import ThumbHistory from '../CampaignTableComponent/ThumbHistory'

import { ReactComponent as HistorySvg } from '../../assets/svg/history.svg'

import {
  capitalizeFirstLetter,
  copyToClipboard,
  tableSorter,
  calcDerivedMetrics,
  getExportValueForColumn,
  groupRecords,
} from '../../services/helper'

import { bulkSTColumnList } from '../../utils/defaultValues'

import { matchTypes } from '../../utils/filterDef'

const columns = [
  { key: 'search', name: 'Search Term', className: 'col-search-term' },
  { key: 'keyword', name: 'Associated Target', className: 'col-associated-target' },
  { key: 'matchType', name: 'Match Type' },
  { key: 'campaignName', name: 'Campaign', className: 'col-campaign' },
  ...bulkSTColumnList,
]

const columnsGroup = [
  { key: 'campaignName', name: 'Campaign', className: 'col-campaign', parentOnly: true },
  { key: 'checkPlaceholder', name: '', className: 'col-check', exportable: false, parentOnly: true },
  { key: 'search', name: 'Search Term', className: 'col-search-term' },
  { key: 'keyword', name: 'Associated Target', className: 'col-associated-target' },
  { key: 'matchType', name: 'Match Type' },
  ...bulkSTColumnList,
]

const TargetSearchSTTable = ({ startDate, endDate, onChangeDate, onLoadChart }) => {
  const store = useStore()
  const {
    header: {
      currencySign,
      currencyRate,
    },
    pageGlobal: {
      campaignTableColumns,
      stTableColumns,
    },
    campaign: {
      campaignsWithHistory,
    },
    bulkEngine: {
      findTargetsData,
      targetChartsData,
      isGettingTargetCharts,
    },
  } = store.getState()

  const [groupMode, setGroupMode] = useState(false)
  const [searchTerms, setSearchTerms] = useState([])
  const [groupedSearchTerms, setGroupedSearchTerms] = useState([])
  const [selectedSearchTerms, setSelectedSearchTerms] = useState([])
  const [selectedMatchType, setSelectedMatchType] = useState(matchTypes[0])
  const [showNegativeCreatorModal, setShowNegativeCreatorModal] = useState(false)
  const [isShowHistory, setIsShowHistory] = useState(false)
  const [historyData, setHistoryData] = useState({})
  const [historyPayload, setHistoryPayload] = useState({})

  useEffect(() => {
    const campaignNamesById = {}
    const campaignTypesById = {}
    const campaignTargetingTypesById = {}
    campaignsWithHistory.forEach((campaign) => {
      campaignNamesById[campaign.campaign_id] = campaign.campaign
      campaignTypesById[campaign.campaign_id] = campaign.campaignType
      campaignTargetingTypesById[campaign.campaign_id] = campaign.targeting_type
    })

    const extendedSTs = [];
    (findTargetsData.searchTerms || []).forEach((record) => {
      if (selectedMatchType.value !== '') {
        if ((record.match_type || '').toLowerCase() !== selectedMatchType.value) {
          return
        }
      }

      extendedSTs.push({
        ...calcDerivedMetrics(record),
        id: `${record.campaign_id}-${record.adgroup_id}-`
          + `${record.search}-${record.keyword}-${record.match_type}`,
        campaignName: campaignNamesById[record.campaign_id] || '',
        campaignType: campaignTypesById[record.campaign_id] || '',
        targetingType: campaignTargetingTypesById[record.campaign_id] || '',
        adgroupName: record.adgroup_name || '',
        keyword: record.keyword === '(_targeting_auto_)' ? '*' : record.keyword,
        matchType: capitalizeFirstLetter(record.match_type),
      })
    })

    setSearchTerms(extendedSTs)
    setGroupedSearchTerms(
      groupRecords(
        extendedSTs,
        'campaign_id',
        ['campaignName', 'campaignType', 'targetingType']
      )
    )
  }, [findTargetsData, campaignsWithHistory, selectedMatchType])

  useEffect(() => {
    const dataBySt = {};
    (targetChartsData.searchTerms || []).forEach((record) => {
      const key = `${record.campaign_id}-${record.adgroup_id}-`
        + `${record.search}-${record.keyword}-${record.match_type}`
      if (!dataBySt[key]) {
        dataBySt[key] = []
      }
      dataBySt[key].push(calcDerivedMetrics(record))
    })
    setHistoryData(dataBySt)
  }, [targetChartsData])

  const columnSelection = useMemo(() => {
    const selection = [...campaignTableColumns]
    if ((stTableColumns || []).includes('st_impr_rank')) {
      selection.push('st_impr_rank')
    }
    if ((stTableColumns || []).includes('st_impr_share')) {
      selection.push('st_impr_share')
    }
    return selection
  }, [campaignTableColumns, stTableColumns])

  const handleCopy = () => {
    const sts = searchTerms.filter(st => (
      selectedSearchTerms.indexOf(st.id) !== -1
    )).map(st => st.search.trim())

    copyToClipboard([...new Set(sts)].join('\n'))

    toast.show({
      title: 'Success',
      description: `Successfully copied ${selectedSearchTerms.length} search term${selectedSearchTerms.length > 1 ? 's' : ''}.`
    })
  }

  const handleShowHistory = () => {
    if (!isShowHistory) {
      onLoadChart('searchTerms')
      setIsShowHistory(true)
    } else {
      setIsShowHistory(false)
    }
  }

  const handleHistoryClick = (record, column) => {
    if (!isShowHistory) {
      return
    }

    const key = `${record.campaign_id}-${record.adgroup_id}-`
      + `${record.search}-${record.keyword}-${record.match_type}`

    setHistoryPayload({
      metric: column.label,
      search: record.search,
      direct: column.key === 'cpc' || column.key === 'acos',
      data: (historyData[key] || []).map(item => ({
        date: item.report_date,
        value: item[column.key] || 0,
      })),
    })
  }

  const renderFilter = () => {
    return (
      <div className="filter-container">
        <div className="toggle-wrapper">
          <Toggle
            checked={groupMode}
            checkedChildren="Organize by campaigns"
            unCheckedChildren="By search terms"
            onChange={setGroupMode}
          />
        </div>
        <div className="select-wrapper">
          <span>Match Type</span>
          <Select
            classNamePrefix="match-type-selector"
            options={matchTypes}
            value={selectedMatchType}
            onChange={setSelectedMatchType}
          />
        </div>
      </div>
    )
  }

  const renderAction = () => {
    if (!selectedSearchTerms.length) {
      return null
    }

    return (
      <>
        <button
          type="button"
          className="btn btn-blue"
          onClick={() => { setShowNegativeCreatorModal(true) }}
        >
          Add Negative{selectedSearchTerms.length > 1 ? 's' : ''} to Campaign{selectedSearchTerms.length > 1 ? 's' : ''}
        </button>
        <button
          type="button"
          className="btn btn-green"
          onClick={() => { handleCopy() }}
        >
          Copy
        </button>
      </>
    )
  }

  const renderSecondaryAction = () => {
    return (
      <HistorySvg title="History" onClick={handleShowHistory}/>
    )
  }

  const renderST = record => (
    <>
      <div className="table-col col-search-term" title={record.search}>
        <strong className="contents">
          { record.search }
        </strong>
      </div>
      <div className="table-col col-associated-target" title={record.keyword}>
        <span className="contents">
          { record.keyword }
        </span>
      </div>
      <div className="table-col">
        { record.matchType }
      </div>
      <TableCampaignCell record={record} />
      {
        bulkSTColumnList.map(column => (
          <TableCell
            key={column.key}
            record={record}
            columnKey={column.key}
            columnSelection={columnSelection}
            currencySign={currencySign}
            currencyRate={currencyRate}
            showHistory={isShowHistory && !isGettingTargetCharts}
            historyData={historyData[`${record.campaign_id}-${record.adgroup_id}-`
              + `${record.search}-${record.keyword}-${record.match_type}`] || []}
            startDate={startDate}
            endDate={endDate}
            onClick={() => { handleHistoryClick(record, column) }}
          />
        ))
      }
    </>
  )

  // Render aggregation row.
  const renderTotal = summary => (
    <>
      <div className="table-col col-search-term">Totals:</div>
      <div className="table-col col-associated-target" />
      <div className="table-col" />
      <div className="table-col col-campaign" />
      {
        bulkSTColumnList.map(column => (
          <TableCell
            key={column.key}
            record={summary}
            columnKey={column.key}
            columnSelection={columnSelection}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  const getExportData = (exportableColumns, record) => (
    exportableColumns.map((column) => {
      if (column.key === 'search') {
        return record.search
      }
      if (column.key === 'keyword') {
        return record.keyword
      }
      if (column.key === 'matchType') {
        return record.matchType
      }
      return getExportValueForColumn(record, column.key, currencySign, currencyRate)
    })
  )

  // For grouped table.
  const renderParent = record => (
    <>
      <TableCampaignCell record={record} />
      <div className="table-col col-check" />
      <div className="table-col col-search-term">
        { record.children.length } search terms
      </div>
      <div className="table-col col-associated-target" />
      <div className="table-col" />
      {
        bulkSTColumnList.map(column => (
          <TableCell
            key={column.key}
            record={record}
            columnKey={column.key}
            columnSelection={columnSelection}
            currencySign={currencySign}
            currencyRate={currencyRate}
            showHistory={isShowHistory && !isGettingTargetCharts}
            historyData={historyData[`${record.campaign_id}-${record.adgroup_id}-`
              + `${record.search}-${record.keyword}-${record.match_type}`] || []}
            startDate={startDate}
            endDate={endDate}
            onClick={() => { handleHistoryClick(record, column) }}
          />
        ))
      }
    </>
  )

  const renderChild = record => (
    <>
      <div className="table-col col-search-term" title={record.search}>
        <strong className="contents">
          { record.search }
        </strong>
      </div>
      <div className="table-col col-associated-target" title={record.keyword}>
        <span className="contents">
          { record.keyword }
        </span>
      </div>
      <div className="table-col">
        { record.matchType }
      </div>
      {
        bulkSTColumnList.map(column => (
          <TableCell
            key={column.key}
            record={record}
            columnKey={column.key}
            columnSelection={columnSelection}
            currencySign={currencySign}
            currencyRate={currencyRate}
            showHistory={isShowHistory && !isGettingTargetCharts}
            historyData={historyData[`${record.campaign_id}-${record.adgroup_id}-`
              + `${record.search}-${record.keyword}-${record.match_type}`] || []}
            startDate={startDate}
            endDate={endDate}
            onClick={() => { handleHistoryClick(record, column) }}
          />
        ))
      }
    </>
  )

  const renderTotalGroup = summary => (
    <>
      <div className="table-col col-campaign">Totals:</div>
      <div className="table-col col-check" />
      <div className="table-col col-search-term" />
      <div className="table-col col-associated-target" />
      <div className="table-col" />
      {
        bulkSTColumnList.map(column => (
          <TableCell
            key={column.key}
            record={summary}
            columnKey={column.key}
            columnSelection={columnSelection}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  const sts = searchTerms.filter(st => (
    selectedSearchTerms.indexOf(st.id) !== -1
  ))

  return (
    <>
      { renderFilter() }
      {
        groupMode ? (
          <SortableTable
            tableComponent={GroupTable}
            columns={columnsGroup}
            defaultSort={['cost', 'desc']}
            sorter={tableSorter(['campaignName'])}
            className="table-grouped-search-terms"
            records={groupedSearchTerms}
            idField="campaign_id"
            searchFields={['search', 'keyword']}
            exactSearch
            searchPlaceholder="Exact match search"
            selectedRecords={selectedSearchTerms}
            paginationSelectPlacement="top"
            hasSticky
            hasDateRange
            filterName="targetSearchST"
            columnEditorId="targetSearchSTResult"
            columnList={bulkSTColumnList}
            columnSelection={columnSelection}
            isLoading={isGettingTargetCharts}
            exportFileName="Target Search"
            getExportData={getExportData}
            renderRecord={renderParent}
            renderTotal={renderTotalGroup}
            renderTopRight={renderAction}
            renderTopRightSecondary={renderSecondaryAction}
            onChange={setSelectedSearchTerms}
            onChangeDate={onChangeDate}
            sorterChild={tableSorter(['search', 'keyword', 'matchType'])}
            idFieldChild="id"
            renderChild={renderChild}
          />
        ) : (
          <SortableTable
            columns={columns}
            defaultSort={['cost', 'desc']}
            sorter={tableSorter(['campaignName', 'search', 'keyword', 'matchType'])}
            className="table-search-terms"
            records={searchTerms || []}
            idField="id"
            searchFields={['search', 'keyword']}
            exactSearch
            searchPlaceholder="Exact match search"
            selectedRecords={selectedSearchTerms}
            paginationSelectPlacement="top"
            hasSticky
            hasDateRange
            filterName="targetSearchST"
            columnEditorId="targetSearchSTResult"
            columnList={bulkSTColumnList}
            columnSelection={columnSelection}
            isLoading={isGettingTargetCharts}
            exportFileName="Target Search"
            getExportData={getExportData}
            renderRecord={renderST}
            renderTotal={renderTotal}
            renderTopRight={renderAction}
            renderTopRightSecondary={renderSecondaryAction}
            onChange={setSelectedSearchTerms}
            onChangeDate={onChangeDate}
          />
        )
      }
      <NegativeCreatorModal
        show={showNegativeCreatorModal}
        searchTerms={sts}
        onClose={() => { setShowNegativeCreatorModal(false) }}
      />
      <ThumbHistory
        title={`Search Term: ${historyPayload.search}`}
        areaData={historyPayload.data || []}
        metric={historyPayload.metric}
        direct={historyPayload.direct}
        startDate={startDate}
        endDate={endDate}
        onClose={() => { setHistoryPayload({}) }}
      />
    </>
  )
}

export default TargetSearchSTTable
