/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useState, useEffect } from 'react'
import { useDispatch, useStore } from 'react-redux'
import { Dropdown, Tooltip, Whisper } from 'rsuite'

import LoaderComponent from '../CommonComponents/LoaderComponent'
import CampaignTableComponent from '../CampaignTableComponent'
import VideoLink from '../CommonComponents/VideoLink'
import TargetSearchResult from './TargetSearchResult'
import DupResult from './DupResult'

import { ReactComponent as InfoSvg } from '../../assets/svg/info.svg'

import {
  findTargets,
  findDups,
  getTargetCharts,
} from '../../redux/actions/bulkEngine'

const MODULE_TARGET_SEARCH = 'target_search'
const MODULE_DUPLICATE_TARGETS = 'duplicate_targets'

const MODULE_NAME_TARGET_SEARCH = 'Target Search'
const MODULE_NAME_DUPLICATE_TARGETS = 'Find Duplicate Targets'

const moduleList = [
  {
    key: MODULE_TARGET_SEARCH,
    name: MODULE_NAME_TARGET_SEARCH,
    description: (
      <>
        <p>Research any target across your campaigns in seconds.</p>
        <p>Find valuable information such as profit, match type and ad spend.</p>
      </>
    ),
  },
  {
    key: MODULE_DUPLICATE_TARGETS,
    name: MODULE_NAME_DUPLICATE_TARGETS,
    description: (
      <>
        <p>
          Discover where your duplicate targets are performing
          at their peak and where they are not.
        </p>
      </>
    )
  },
]

export const tutorialList = {
  '': {
    title: 'Bulk Engine Overview',
    videoList: [
      { title: 'Bulk Engine Overview', url: 'https://www.loom.com/embed/8aade68f957449d5ab685182612c39ad' },
    ],
  },
  [MODULE_TARGET_SEARCH]: {
    title: MODULE_NAME_TARGET_SEARCH,
    videoList: [
      { title: MODULE_NAME_TARGET_SEARCH, url: 'https://www.loom.com/embed/50c79aa6dbfc4848ae9cc6d5e4a4fd58' },
    ],
  },
  [MODULE_DUPLICATE_TARGETS]: {
    title: MODULE_NAME_DUPLICATE_TARGETS,
    videoList: [
      { title: MODULE_NAME_DUPLICATE_TARGETS, url: 'https://www.loom.com/embed/594877045af04ad4ac9161330ce2ca23' },
    ],
  },
}

const TargetSearchTable = () => {
  const dispatch = useDispatch()
  const store = useStore().getState()

  const {
    header: {
      currentUserId,
      currentStartDate,
      currentEndDate,
    },
    bulkEngine: {
      isFindingTargets,
      isFindingDups,
    },
  } = store

  const [activeModule, setActiveModule] = useState('')
  const [keyword, setKeyword] = useState('')
  const [selectedCampaigns, setSelectedCampaigns] = useState([])
  const [internalStartDate, setInternalStartDate] = useState()
  const [internalEndDate, setInternalEndDate] = useState()
  const [hasResults, setHasResults] = useState(false)
  const [isCampaignsExpanded, setIsCampaignsExpanded] = useState(false)

  useEffect(() => {
    setSelectedCampaigns([])
    setHasResults(false)
    setIsCampaignsExpanded(false)
  }, [currentUserId])

  const handleModuleSelect = (module) => {
    setActiveModule(module.key)
    setHasResults(false)
  }

  const doSearch = (startDate, endDate) => {
    setInternalStartDate(startDate)
    setInternalEndDate(endDate)

    if (activeModule === MODULE_TARGET_SEARCH) {
      return dispatch(findTargets(
        selectedCampaigns.map(campaign => campaign.campaign_id),
        keyword,
        startDate,
        endDate
      ))
    }

    return dispatch(findDups(
      selectedCampaigns.map(campaign => campaign.campaign_id),
      startDate,
      endDate
    ))
  }

  const handleSearch = () => {
    setHasResults(false)
    doSearch(currentStartDate, currentEndDate).then(() => {
      setHasResults(true)
      setIsCampaignsExpanded(false)
    })
  }

  const handleDateChange = (startDate, endDate) => {
    doSearch(startDate, endDate)
  }

  const handleChartLoad = (type) => {
    dispatch(getTargetCharts(
      selectedCampaigns.map(campaign => campaign.campaign_id),
      keyword,
      internalStartDate,
      internalEndDate,
      type,
    ))
  }

  const renderTopSection = () => {
    if (hasResults && !isCampaignsExpanded) {
      return null
    }

    if (activeModule === MODULE_TARGET_SEARCH) {
      return (
        <div className="keyword-search-box">
          <input
            type="text"
            placeholder="Enter a target to search..."
            value={keyword}
            onChange={(event) => { setKeyword(event.target.value) }}
          />
          <button
            type="button"
            className="btn btn-blue"
            disabled={keyword === '' || !selectedCampaigns.length}
            onClick={handleSearch}
          >
            { !selectedCampaigns.length ? 'Select Campaigns to Continue' : 'Search' }
          </button>
          <Whisper placement="right" trigger="hover" speaker={(
            <Tooltip>
              <p>
                See how your top targets are performing across your ads.
              </p>
              <p>
                Enter a Keyword or ASIN, select campaigns and click "Search".
              </p>
            </Tooltip>
          )}>
            <InfoSvg />
          </Whisper>
        </div>
      )
    }

    if (activeModule === MODULE_DUPLICATE_TARGETS) {
      return (
        <div className="keyword-search-box">
          <button
            type="button"
            className="btn btn-blue"
            disabled={!selectedCampaigns.length}
            onClick={handleSearch}
          >
            { !selectedCampaigns.length ? 'Select Campaigns to Continue' : 'Search' }
          </button>
          <Whisper placement="right" trigger="hover" speaker={(
            <Tooltip>
              <p>
                Discover where your targets are performing at their peak and where they are not.
              </p>
              <p>
                Select campaigns below and click "Search".
              </p>
            </Tooltip>
          )}>
            <InfoSvg />
          </Whisper>
        </div>
      )
    }
    return null
  }

  const renderModuleSelector = (dropdownLabel) => {
    return (
      <div className="module-selector-container">
        <div className="module-selector-left">
          <Dropdown title={dropdownLabel}>
            {
              moduleList.map(module => (
                <Dropdown.Item
                  key={module.key}
                  active={module.key === activeModule}
                  onSelect={() => { handleModuleSelect(module) }}
                >
                  { module.name }
                  <Whisper placement="right" trigger="hover" speaker={(
                    <Tooltip>
                      { module.description }
                    </Tooltip>
                  )}>
                    <InfoSvg />
                  </Whisper>
                </Dropdown.Item>
              ))
            }
          </Dropdown>
          { renderTopSection() }
        </div>
        <VideoLink
          modalTitle={tutorialList[activeModule].title}
          videoList={tutorialList[activeModule].videoList}
        />
      </div>
    )
  }

  const renderCampaignSelection = () => {
    if (hasResults && !isCampaignsExpanded) {
     return (
       <div className="campaign-seletion-state">
         <strong>{ selectedCampaigns.length }</strong> campaigns selected.
         <a
           href="#"
           onClick={(event) => { event.preventDefault(); setIsCampaignsExpanded(true) }}
         >
           Change
         </a>
       </div>
     )
   }
   return null
  }

  const renderResults = () => {
    if (!hasResults) {
      return null
    }

    if (activeModule === MODULE_TARGET_SEARCH) {
      return (
        <TargetSearchResult
          startDate={internalStartDate}
          endDate={internalEndDate}
          onChangeDate={handleDateChange}
          onLoadChart={handleChartLoad}
        />
      )
    }
    if (activeModule === MODULE_DUPLICATE_TARGETS) {
      return (
        <DupResult
          onChangeDate={handleDateChange}
        />
      )
    }
    return null
  }

  let dropdownLabel = 'Choose Module'
  if (activeModule) {
    const active = moduleList.find(module => module.key === activeModule)
    if (active) {
      dropdownLabel = active.name
    }
  }

  const isLoading = isFindingTargets || isFindingDups

  return (
    <div className={`bulk-engine-container target-search-container${isLoading ? ' loading' : ''}`}>
      { isLoading && <LoaderComponent /> }
      { renderModuleSelector(dropdownLabel) }
      { renderCampaignSelection() }
      <CampaignTableComponent
        className={hasResults && !isCampaignsExpanded ? 'hidden' : ''}
        fromBulkEngine
        customCallbacks={{
          onSelectCampaigns: setSelectedCampaigns,
        }}
      />
      { renderResults() }
    </div>
  )
}

export default TargetSearchTable
