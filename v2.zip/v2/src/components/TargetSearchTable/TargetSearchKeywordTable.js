import React, { useEffect, useState } from 'react'
import { useDispatch, useStore } from 'react-redux'
import { Toggle } from 'rsuite'
import Select from 'react-select'

import SortableTable from '../CommonComponents/SortableTableComponent'
import GroupTable from '../CommonComponents/GroupTableComponent'
import { toast } from '../CommonComponents/ToastComponent/toast'
import TableCell from '../CommonComponents/TableCell'
import TableCampaignCell from '../CommonComponents/TableCampaignCell'
import BidAdjustComponent from '../CommonComponents/BidAdjustComponent'
import ThumbHistory from '../CampaignTableComponent/ThumbHistory'

import { ReactComponent as HistorySvg } from '../../assets/svg/history.svg'

import {
  adjustKeywordBids,
  updateKeywordStates,
} from '../../redux/actions/bulkEngine'

import {
  formatCurrency,
  capitalizeFirstLetter,
  tableSorter,
  calcDerivedMetrics,
  getExportValueForColumn,
  groupRecords,
  copyToClipboard,
} from '../../services/helper'

import {
  bulkBidColumnList,
  adjustBidOptions,
  ADJUST_BID_RAISE,
  ADJUST_BID_LOWER,
  ADJUST_BID_CPC,
} from '../../utils/defaultValues'

import { matchTypes } from '../../utils/filterDef'

const columns = [
  { key: 'keyword', name: 'Keyword', className: 'col-keyword' },
  { key: 'campaignName', name: 'Campaign', className: 'col-campaign' },
  { key: 'bid', name: 'Current Bid' },
  ...bulkBidColumnList,
]

const columnsGroup = [
  { key: 'campaignName', name: 'Campaign', className: 'col-campaign', parentOnly: true },
  { key: 'checkPlaceholder', name: '', className: 'col-check', exportable: false, parentOnly: true },
  { key: 'keyword', name: 'Keyword', className: 'col-keyword' },
  { key: 'bid', name: 'Current Bid' },
  ...bulkBidColumnList,
]

const TargetSearchKeywordTable = ({ startDate, endDate, onChangeDate, onLoadChart }) => {
  const dispatch = useDispatch()
  const store = useStore()
  const {
    header: {
      currencySign,
      currencyRate,
    },
    pageGlobal: {
      campaignTableColumns,
    },
    campaign: {
      campaignsWithHistory,
    },
    bulkEngine: {
      findTargetsData,
      targetChartsData,
      isAdjustingKeywordBids,
      isUpdatingKeywordStates,
      isGettingTargetCharts,
    },
  } = store.getState()

  const [groupMode, setGroupMode] = useState(false)
  const [keywords, setKeywords] = useState([])
  const [groupedKeywords, setGroupedKeywords] = useState([])
  const [selectedKeywords, setSelectedKeywords] = useState([])
  const [isShowAdjustBid, setIsShowAdjustBid] = useState(false)
  const [selectedAdjustBidOption, setSelectedAdjustBidOption] = useState(adjustBidOptions[0])
  const [bidValue, setBidValue] = useState(0)
  const [selectedMatchType, setSelectedMatchType] = useState(matchTypes[0])
  const [isShowHistory, setIsShowHistory] = useState(false)
  const [historyData, setHistoryData] = useState({})
  const [historyPayload, setHistoryPayload] = useState({})

  useEffect(() => {
    const campaignNamesById = {}
    const campaignTypesById = {}
    const campaignTargetingTypesById = {}
    campaignsWithHistory.forEach((campaign) => {
      campaignNamesById[campaign.campaign_id] = campaign.campaign
      campaignTypesById[campaign.campaign_id] = campaign.campaignType
      campaignTargetingTypesById[campaign.campaign_id] = campaign.targeting_type
    })

    const extendedKeywords = [];
    (findTargetsData.keywords || []).forEach((record) => {
      if (selectedMatchType.value !== '') {
        if ((record.match_type || '').toLowerCase() !== selectedMatchType.value) {
          return
        }
      }

      extendedKeywords.push({
        ...calcDerivedMetrics(record),
        campaignName: campaignNamesById[record.campaign_id] || '',
        campaignType: campaignTypesById[record.campaign_id] || '',
        targetingType: campaignTargetingTypesById[record.campaign_id] || '',
        matchType: capitalizeFirstLetter(record.match_type),
      })
    })

    setKeywords(extendedKeywords)
    setGroupedKeywords(
      groupRecords(
        extendedKeywords,
        'campaign_id',
        ['campaignName', 'campaignType', 'targetingType']
      )
    )
  }, [findTargetsData, campaignsWithHistory, selectedMatchType])

  useEffect(() => {
    const dataByKeyword = {};
    (targetChartsData.keywords || []).forEach((record) => {
      const key = `${record.campaign_id}-${record.keyword_id}`
      if (!dataByKeyword[key]) {
        dataByKeyword[key] = []
      }
      dataByKeyword[key].push(calcDerivedMetrics(record))
    })
    setHistoryData(dataByKeyword)
  }, [targetChartsData])

  const handleChangeState = (state) => {
    let keywordsChanged = []
    keywords.filter(record => (
      selectedKeywords.indexOf(record.keyword_id) !== -1
      && record.keyword !== '(_targeting_auto_)'
    )).forEach((record) => {
      keywordsChanged.push({
        campaignId: record.campaign_id,
        campaignType: record.campaignType,
        adGroupId: record.adgroup_id,
        keywordId: record.keyword_id,
        // Below information are used for logging in backend.
        campaignName: record.campaignName,
        adgroupName: record.adgroup_name,
        keyword: record.keyword,
        matchType: record.matchType,
      })
    })

    // Remove duplicate entries.
    keywordsChanged =  [...new Map(keywordsChanged.map(item => [item.keywordId, item])).values()]

    if (keywordsChanged.length) {
      dispatch(updateKeywordStates(keywordsChanged, state))
    }
  }

  const handleAdjustBid = () => {
    if (selectedAdjustBidOption.value !== ADJUST_BID_CPC
      && (bidValue === '' || isNaN(bidValue))) {
      toast.show({
        title: 'Warning',
        description: 'Please enter the valid bid value.',
      })
      return
    }

    let keywordsChanged = []
    keywords.filter(record => (
      selectedKeywords.indexOf(record.keyword_id) !== -1
      && record.keyword !== '(_targeting_auto_)'
    )).forEach((record) => {
      let newBid = parseFloat(bidValue)
      if (selectedAdjustBidOption.value === ADJUST_BID_RAISE) {
        newBid = parseFloat(record.bid || 0) * (1 + (newBid / 100))
      } else if (selectedAdjustBidOption.value === ADJUST_BID_LOWER) {
        newBid = parseFloat(record.bid || 0) * (1 - (newBid / 100))
      } else if (selectedAdjustBidOption.value === ADJUST_BID_CPC) {
        newBid = parseFloat(record.cpc || 0)
      }

      if (newBid >= 0.15) {
        keywordsChanged.push({
          campaignId: record.campaign_id,
          campaignType: record.campaignType,
          adGroupId: record.adgroup_id,
          keywordId: record.keyword_id,
          bid: parseFloat(newBid.toFixed(2)),
          // Below information are used for logging in backend.
          campaignName: record.campaignName,
          adgroupName: record.adgroup_name,
          keyword: record.keyword,
          originalBid: record.bid,
          matchType: record.matchType,
        })
      }
    })

    // Remove duplicate entries.
    keywordsChanged =  [...new Map(keywordsChanged.map(item => [item.keywordId, item])).values()]

    if (!keywordsChanged.length) {
      toast.show({
        title: 'Warning',
        description: 'The minimum bid allowed is $0.15. Please check your keywords.',
      })
      return
    }

    dispatch(adjustKeywordBids(keywordsChanged))
  }

  const handleShowHistory = () => {
    if (!isShowHistory) {
      onLoadChart('keywords')
      setIsShowHistory(true)
    } else {
      setIsShowHistory(false)
    }
  }

  const handleHistoryClick = (record, column) => {
    if (!isShowHistory) {
      return
    }

    setHistoryPayload({
      metric: column.label,
      keyword: record.keyword,
      direct: column.key === 'cpc' || column.key === 'acos',
      data: (historyData[`${record.campaign_id}-${record.keyword_id}`] || []).map(item => ({
        date: item.report_date,
        value: item[column.key] || 0,
      })),
    })
  }

  const handleCopy = () => {
    const dataToCopy = keywords.filter(record => (
      selectedKeywords.indexOf(record.keyword_id) !== -1
    )).map(record => record.keyword.trim())

    copyToClipboard(dataToCopy.join('\n'))

    toast.show({
      title: 'Success',
      description: `Successfully copied ${dataToCopy.length} keyword${dataToCopy.length > 1 ? 's' : ''}.`
    })
  }

  const renderFilter = () => {
    return (
      <div className="filter-container">
        <div className="toggle-wrapper">
          <Toggle
            checked={groupMode}
            checkedChildren="Organize by campaigns"
            unCheckedChildren="By keywords"
            onChange={setGroupMode}
          />
        </div>
        <div className="select-wrapper">
          <span>Match Type</span>
          <Select
            classNamePrefix="match-type-selector"
            options={matchTypes}
            value={selectedMatchType}
            onChange={setSelectedMatchType}
          />
        </div>
      </div>
    )
  }

  const renderAction = () => {
    if (!selectedKeywords.length) {
      return null
    }

    if (!isShowAdjustBid) {
      const isEnableDisabled = typeof keywords.find(record => (
        selectedKeywords.indexOf(record.keyword_id) !== -1
        && record.state !== 'enabled'
      )) === 'undefined'

      const isPauseDisabled = typeof keywords.find(record => (
        selectedKeywords.indexOf(record.keyword_id) !== -1
        && record.state !== 'paused'
      )) === 'undefined'

      return (
        <>
          <button
            type="button"
            className="btn btn-green"
            onClick={() => { handleCopy() }}
          >
            Copy
          </button>
          <button
            type="button"
            className="btn btn-green"
            disabled={isUpdatingKeywordStates || isEnableDisabled}
            onClick={() => { handleChangeState('enabled') }}
          >
            Enable
          </button>
          <button
            type="button"
            className="btn btn-red"
            disabled={isUpdatingKeywordStates || isPauseDisabled}
            onClick={() => { handleChangeState('paused') }}
          >
            Pause
          </button>
          <button
            type="button"
            className="btn btn-light-blue"
            onClick={() => { setIsShowAdjustBid(true) }}
          >
            Adjust Bid
          </button>
        </>
      )
    }

    return (
      <BidAdjustComponent
        adjustBidOption={selectedAdjustBidOption}
        bidValue={bidValue}
        isAdjusting={isAdjustingKeywordBids}
        onChangeAdjustBidOption={setSelectedAdjustBidOption}
        onChangeBidValue={setBidValue}
        onApply={handleAdjustBid}
        onCancel={() => { setIsShowAdjustBid(false) }}
      />
    )
  }

  const renderSecondaryAction = () => {
    return (
      <HistorySvg title="History" onClick={handleShowHistory}/>
    )
  }

  const renderKeyword = record => (
    <>
      <div className="table-col col-keyword" title={record.keyword}>
        <strong>
          { record.keyword }
        </strong>
        <div className="meta-data">
          { record.matchType } | { capitalizeFirstLetter(record.state) }
        </div>
      </div>
      <TableCampaignCell record={record} />
      <div className="table-col">
        { formatCurrency(record.bid, currencySign, currencyRate) }
      </div>
      {
        bulkBidColumnList.map(column => (
          <TableCell
            key={column.key}
            record={record}
            columnKey={column.key}
            columnSelection={campaignTableColumns}
            currencySign={currencySign}
            currencyRate={currencyRate}
            showHistory={isShowHistory && !isGettingTargetCharts}
            historyData={historyData[`${record.campaign_id}-${record.keyword_id}`] || []}
            startDate={startDate}
            endDate={endDate}
            onClick={() => { handleHistoryClick(record, column) }}
          />
        ))
      }
    </>
  )

  // Render aggregation row.
  const renderTotal = summary => (
    <>
      <div className="table-col col-keyword">Totals:</div>
      <div className="table-col col-campaign" />
      <div className="table-col" />
      {
        bulkBidColumnList.map(column => (
          <TableCell
            key={column.key}
            record={summary}
            columnKey={column.key}
            columnSelection={campaignTableColumns}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  const getExportData = (exportableColumns, record) => (
    exportableColumns.map((column) => {
      if (column.key === 'keyword') {
        return `${record.keyword} (${record.matchType} | ${capitalizeFirstLetter(record.state)})`
      }
      if (column.key === 'bid') {
        return formatCurrency(record.bid, currencySign, currencyRate)
      }
      return getExportValueForColumn(record, column.key, currencySign, currencyRate)
    })
  )

  // For grouped table.
  const renderParent = record => (
    <>
      <TableCampaignCell record={record} />
      <div className="table-col col-check" />
      <div className="table-col col-keyword">
        { record.children.length } keywords
      </div>
      <div className="table-col" />
      {
        bulkBidColumnList.map(column => (
          <TableCell
            key={column.key}
            record={record}
            columnKey={column.key}
            columnSelection={campaignTableColumns}
            currencySign={currencySign}
            currencyRate={currencyRate}
            showHistory={isShowHistory && !isGettingTargetCharts}
            historyData={historyData[`${record.campaign_id}-${record.keyword_id}`] || []}
            startDate={startDate}
            endDate={endDate}
            onClick={() => { handleHistoryClick(record, column) }}
          />
        ))
      }
    </>
  )

  const renderChild = record => (
    <>
      <div className="table-col col-keyword" title={record.keyword}>
        <strong>
          { record.keyword }
        </strong>
        <div className="meta-data">
          { record.matchType } | { capitalizeFirstLetter(record.state) }
        </div>
      </div>
      <div className="table-col">
        { formatCurrency(record.bid, currencySign, currencyRate) }
      </div>
      {
        bulkBidColumnList.map(column => (
          <TableCell
            key={column.key}
            record={record}
            columnKey={column.key}
            columnSelection={campaignTableColumns}
            currencySign={currencySign}
            currencyRate={currencyRate}
            showHistory={isShowHistory && !isGettingTargetCharts}
            historyData={historyData[`${record.campaign_id}-${record.keyword_id}`] || []}
            startDate={startDate}
            endDate={endDate}
            onClick={() => { handleHistoryClick(record, column) }}
          />
        ))
      }
    </>
  )

  const renderTotalGroup = summary => (
    <>
      <div className="table-col col-campaign">Totals:</div>
      <div className="table-col col-check" />
      <div className="table-col col-keyword" />
      <div className="table-col" />
      {
        bulkBidColumnList.map(column => (
          <TableCell
            key={column.key}
            record={summary}
            columnKey={column.key}
            columnSelection={campaignTableColumns}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  const isLoading = isAdjustingKeywordBids
    || isUpdatingKeywordStates
    || isGettingTargetCharts

  return (
    <>
      { renderFilter() }
      {
        groupMode ? (
          <SortableTable
            tableComponent={GroupTable}
            columns={columnsGroup}
            defaultSort={['cost', 'desc']}
            sorter={tableSorter(['campaignName'])}
            className="table-grouped-keywords"
            records={groupedKeywords}
            idField="campaign_id"
            searchFields={['keyword']}
            exactSearch
            searchPlaceholder="Exact match search"
            selectedRecords={selectedKeywords}
            paginationSelectPlacement="top"
            hasSticky
            hasDateRange
            filterName="targetSearchKeyword"
            columnEditorId="targetSearchKeywordResult"
            columnList={bulkBidColumnList}
            columnSelection={campaignTableColumns}
            isLoading={isLoading}
            exportFileName="Target Search"
            getExportData={getExportData}
            renderRecord={renderParent}
            renderTotal={renderTotalGroup}
            renderTopRight={renderAction}
            renderTopRightSecondary={renderSecondaryAction}
            onChange={setSelectedKeywords}
            onChangeDate={onChangeDate}
            sorterChild={tableSorter(['state', 'keyword', 'matchType'])}
            idFieldChild="keyword_id"
            renderChild={renderChild}
          />
        ) : (
          <SortableTable
            columns={columns}
            defaultSort={['cost', 'desc']}
            sorter={tableSorter(['campaignName', 'state', 'keyword', 'matchType'])}
            className="table-keywords"
            records={keywords || []}
            idField="keyword_id"
            searchFields={['keyword']}
            exactSearch
            searchPlaceholder="Exact match search"
            selectedRecords={selectedKeywords}
            paginationSelectPlacement="top"
            hasSticky
            hasDateRange
            filterName="targetSearchKeyword"
            columnEditorId="targetSearchKeywordResult"
            columnList={bulkBidColumnList}
            columnSelection={campaignTableColumns}
            isLoading={isLoading}
            exportFileName="Target Search"
            getExportData={getExportData}
            renderRecord={renderKeyword}
            renderTotal={renderTotal}
            renderTopRight={renderAction}
            renderTopRightSecondary={renderSecondaryAction}
            onChange={setSelectedKeywords}
            onChangeDate={onChangeDate}
          />
        )
      }
      <ThumbHistory
        title={`Keyword: ${historyPayload.keyword}`}
        areaData={historyPayload.data || []}
        metric={historyPayload.metric}
        direct={historyPayload.direct}
        startDate={startDate}
        endDate={endDate}
        onClose={() => { setHistoryPayload({}) }}
      />
    </>
  )
}

export default TargetSearchKeywordTable
