import React, { useState } from 'react'

import BulkResultContainer from '../BulkResultContainer'
import DupKeywordTable from './DupKeywordTable'
import DupTargetTable from './DupTargetTable'

const TAB_KEYWORD = 'keyword'
const TAB_TARGET = 'target'

const tabList = [
  {
    value: TAB_KEYWORD,
    label: 'Keywords',
  },
  {
    value: TAB_TARGET,
    label: 'ASINs',
  },
]

const DupResult = ({ onChangeDate }) => {
  const [currentTab, setCurrentTab] = useState(TAB_KEYWORD)

  return (
    <BulkResultContainer>
      <div className="target-search-result-container dup-result-container">
        <div className="tab-list">
          {
            tabList.map((tab) => (
              <button
                key={tab.value}
                type="button"
                className={currentTab === tab.value ? "tab selected" : "tab"}
                onClick={() => { setCurrentTab(tab.value)}}
              >
                { tab.label }
              </button>
            ))
          }
        </div>
        <div className="section-label">
          Click the Keyword or ASIN to see locations of duplicates
        </div>
        {
          currentTab === TAB_KEYWORD && (
            <DupKeywordTable
              onChangeDate={onChangeDate}
            />
          )
        }
        {
          currentTab === TAB_TARGET && (
            <DupTargetTable
              onChangeDate={onChangeDate}
            />
          )
        }
      </div>
    </BulkResultContainer>
  )
}

export default DupResult
