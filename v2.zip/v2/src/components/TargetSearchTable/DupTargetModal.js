import React, { useEffect, useState } from 'react'
import { useDispatch, useStore } from 'react-redux'
import { Modal } from 'rsuite'

import SortableTable from '../CommonComponents/SortableTableComponent'
import TableCell from '../CommonComponents/TableCell'
import { toast } from '../CommonComponents/ToastComponent/toast'
import BidAdjustComponent from '../CommonComponents/BidAdjustComponent'

import {
  updateTargetStates,
  adjustTargetBids,
} from '../../redux/actions/bulkEngine'

import {
  formatCurrency,
  parseAsinTarget,
  tableSorter,
} from '../../services/helper'

import {
  bulkBidColumnList,
  campaignTypeMap,
  adjustBidOptions,
  ADJUST_BID_RAISE,
  ADJUST_BID_LOWER,
  ADJUST_BID_CPC,
} from '../../utils/defaultValues'

const columns = [
  { key: 'campaignName', name: 'Campaign', className: 'col-campaign' },
  { key: 'adgroup_name', name: 'Ad Group', className: 'col-adgroup' },
  { key: 'state', name: 'State' },
  { key: 'bid', name: 'Current Bid' },
  ...bulkBidColumnList,
]

const DupTargetModal = ({ duplicatedTarget, onClose }) => {
  const dispatch = useDispatch()
  const store = useStore()
  const {
    header: {
      currencySign,
      currencyRate,
    },
    pageGlobal: {
      campaignTableColumns,
    },
    bulkEngine: {
      isUpdatingTargetStates,
      isAdjustingTargetBids,
    },
  } = store.getState()

  const [targets, setTargets] = useState([])
  const [selectedTargets, setSelectedTargets] = useState([])
  const [isShowAdjustBid, setIsShowAdjustBid] = useState(false)
  const [selectedAdjustBidOption, setSelectedAdjustBidOption] = useState(adjustBidOptions[0])
  const [bidValue, setBidValue] = useState(0)

  useEffect(() => {
    if (duplicatedTarget) {
      setTargets(duplicatedTarget.children)
    }
  }, [duplicatedTarget])

  const handlePause = () => {
    let targetsChanged = []
    targets.filter(record => (
      selectedTargets.indexOf(record.target_id) !== -1
    )).forEach((record) => {
      targetsChanged.push({
        campaignId: record.campaign_id,
        campaignType: record.campaignType,
        adGroupId: record.adgroup_id,
        targetId: record.target_id,
        // Below information are used for logging in backend.
        campaignName: record.campaignName,
        adgroupName: record.adgroup_name,
        target_text: duplicatedTarget.target_text,
      })
    })

    // Remove duplicate entries.
    targetsChanged =  [...new Map(targetsChanged.map(item => [item.targetId, item])).values()]

    if (targetsChanged.length) {
      dispatch(updateTargetStates(targetsChanged, 'paused')).then((targetIdsUpdated) => {
        setTargets(duplicatedTarget.children.map((record) => {
          if (targetIdsUpdated.indexOf(parseInt(record.target_id, 10)) !== -1) {
            return {
              ...record,
              state: 'paused',
            }
          }
          return record
        }))
      })
    }
  }

  const handleAdjustBid = () => {
    if (selectedAdjustBidOption.value !== ADJUST_BID_CPC
      && (bidValue === '' || isNaN(bidValue))) {
      toast.show({
        title: 'Warning',
        description: 'Please enter the valid bid value.',
      })
      return
    }

    let targetsChanged = []
    targets.filter(record => (
      selectedTargets.indexOf(record.target_id) !== -1
    )).forEach((record) => {
      let newBid = parseFloat(bidValue)
      if (selectedAdjustBidOption.value === ADJUST_BID_RAISE) {
        newBid = parseFloat(record.bid || 0) * (1 + (newBid / 100))
      } else if (selectedAdjustBidOption.value === ADJUST_BID_LOWER) {
        newBid = parseFloat(record.bid || 0) * (1 - (newBid / 100))
      } else if (selectedAdjustBidOption.value === ADJUST_BID_CPC) {
        newBid = parseFloat(record.cpc || 0)
      }

      if (newBid >= 0.15) {
        targetsChanged.push({
          campaignId: record.campaign_id,
          campaignType: record.campaignType,
          adGroupId: record.adgroup_id,
          targetId: record.target_id,
          bid: parseFloat(newBid.toFixed(2)),
          // Below information are used for logging in backend.
          campaignName: record.campaignName,
          adgroupName: record.adgroup_name,
          target_text: duplicatedTarget.target_text,
          originalBid: record.bid,
        })
      }
    })

    // Remove duplicate entries.
    targetsChanged =  [...new Map(targetsChanged.map(item => [item.targetId, item])).values()]

    if (!targetsChanged.length) {
      toast.show({
        title: 'Warning',
        description: 'The minimum bid allowed is $0.15. Please check your targets.',
      })
      return
    }

    dispatch(adjustTargetBids(targetsChanged)).then((targetIdsUpdated) => {
      setTargets(duplicatedTarget.children.map((record) => {
        if (targetIdsUpdated.indexOf(parseInt(record.target_id, 10)) !== -1) {
          const payload = targetsChanged.find(p => (
            parseInt(p.targetId, 10) === parseInt(record.target_id, 10))
          )
          if (payload) {
            return {
              ...record,
              bid: payload.bid,
            }
          }
        }
        return record
      }))
    })
  }

  const renderAction = () => {
    if (!selectedTargets.length) {
      return null
    }

    if (!isShowAdjustBid) {
      const isPauseDisabled = typeof targets.find(record => (
        selectedTargets.indexOf(record.target_id) !== -1
        && record.state !== 'paused'
      )) === 'undefined'

      return (
        <>
          <button
            type="button"
            className="btn btn-red"
            disabled={isUpdatingTargetStates || isPauseDisabled}
            onClick={handlePause}
          >
            Pause
          </button>
          <button
            type="button"
            className="btn btn-light-blue"
            onClick={() => { setIsShowAdjustBid(true) }}
          >
            Adjust Bid
          </button>
        </>
      )
    }

    return (
      <BidAdjustComponent
        adjustBidOption={selectedAdjustBidOption}
        bidValue={bidValue}
        isAdjusting={isAdjustingTargetBids}
        onChangeAdjustBidOption={setSelectedAdjustBidOption}
        onChangeBidValue={setBidValue}
        onApply={handleAdjustBid}
        onCancel={() => { setIsShowAdjustBid(false) }}
      />
    )
  }

  const renderTarget = record => (
    <>
      <div className="table-col col-campaign" title={record.campaignName}>
        <div className="contents">
          { record.campaignName }
        </div>
        <div className="campaign-detail">
          {
            record.campaignType === 'Sponsored Products' && (
              <span>
                { record.targetingType === 'auto' ? 'Auto' : 'Manual' }
              </span>
            )
          }
          <span>
            { campaignTypeMap[record.campaignType] }
          </span>
        </div>
      </div>
      <div className="table-col col-adgroup" title={record.adgroup_name}>
        <span className="contents">
          { record.adgroup_name }
        </span>
      </div>
      <div className="table-col col-state">
        { record.state }
      </div>
      <div className="table-col">
        { formatCurrency(record.bid, currencySign, currencyRate) }
      </div>
      {
        bulkBidColumnList.map(column => (
          <TableCell
            key={column.key}
            record={record}
            columnKey={column.key}
            columnSelection={campaignTableColumns}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  return (
    <Modal className="dup-target-modal" backdrop="static" full show={duplicatedTarget !== null}>
      <Modal.Header onHide={() => { onClose() }}>
        <Modal.Title>
          Duplicated Target: { duplicatedTarget ? parseAsinTarget(duplicatedTarget.target_text) : '' }
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <SortableTable
          columns={columns}
          defaultSort={['cost', 'desc']}
          sorter={tableSorter(['campaignName', 'adgroup_name', 'state'])}
          className="table-targets"
          records={targets || []}
          idField="target_id"
          searchFields={['campaignName', 'adgroup_name']}
          selectedRecords={selectedTargets}
          paginationSelectPlacement="top"
          hasSticky
          columnEditorId="dupTargetModal"
          columnList={bulkBidColumnList}
          columnSelection={campaignTableColumns}
          isLoading={isUpdatingTargetStates || isAdjustingTargetBids}
          renderRecord={renderTarget}
          renderTopRight={renderAction}
          onChange={setSelectedTargets}
        />
      </Modal.Body>
      <Modal.Footer>
        <button type="button" className="rs-btn rs-btn-subtle" onClick={() => onClose()}>
          Close
        </button>
      </Modal.Footer>
    </Modal>
  )
}

export default DupTargetModal
