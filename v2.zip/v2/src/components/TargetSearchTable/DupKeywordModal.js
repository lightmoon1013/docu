import React, { useEffect, useState } from 'react'
import { useDispatch, useStore } from 'react-redux'
import { Modal } from 'rsuite'
import Select from 'react-select'

import SortableTable from '../CommonComponents/SortableTableComponent'
import TableCell from '../CommonComponents/TableCell'
import { toast } from '../CommonComponents/ToastComponent/toast'
import BidAdjustComponent from '../CommonComponents/BidAdjustComponent'

import {
  updateKeywordStates,
  adjustKeywordBids,
} from '../../redux/actions/bulkEngine'

import {
  formatCurrency,
  tableSorter,
  capitalizeFirstLetter,
} from '../../services/helper'

import {
  bulkBidColumnList,
  campaignTypeMap,
  adjustBidOptions,
  ADJUST_BID_RAISE,
  ADJUST_BID_LOWER,
  ADJUST_BID_CPC,
} from '../../utils/defaultValues'

import { matchTypes } from '../../utils/filterDef'

const columns = [
  { key: 'campaignName', name: 'Campaign', className: 'col-campaign' },
  { key: 'adgroup_name', name: 'Ad Group', className: 'col-adgroup' },
  { key: 'state', name: 'State' },
  { key: 'matchType', name: 'Match Type' },
  { key: 'bid', name: 'Current Bid' },
  ...bulkBidColumnList,
]

const DupKeywordModal = ({ duplicatedKeyword, onClose }) => {
  const dispatch = useDispatch()
  const store = useStore()
  const {
    header: {
      currencySign,
      currencyRate,
    },
    pageGlobal: {
      campaignTableColumns,
    },
    bulkEngine: {
      isUpdatingKeywordStates,
      isAdjustingKeywordBids,
    },
  } = store.getState()

  const [keywords, setKeywords] = useState([])
  const [selectedKeywords, setSelectedKeywords] = useState([])
  const [isShowAdjustBid, setIsShowAdjustBid] = useState(false)
  const [selectedAdjustBidOption, setSelectedAdjustBidOption] = useState(adjustBidOptions[0])
  const [bidValue, setBidValue] = useState(0)
  const [selectedMatchType, setSelectedMatchType] = useState(matchTypes[0])

  useEffect(() => {
    if (duplicatedKeyword) {
      let records = duplicatedKeyword.children
      if (selectedMatchType.value !== '') {
        records = records.filter(record =>
          (record.match_type || '').toLowerCase() === selectedMatchType.value
        )
      }
      setKeywords(records)
    }
  }, [duplicatedKeyword, selectedMatchType])

  const handlePause = () => {
    let keywordsChanged = []
    keywords.filter(record => (
      selectedKeywords.indexOf(record.keyword_id) !== -1
      && record.keyword !== '(_targeting_auto_)'
    )).forEach((record) => {
      keywordsChanged.push({
        campaignId: record.campaign_id,
        campaignType: record.campaignType,
        adGroupId: record.adgroup_id,
        keywordId: record.keyword_id,
        // Below information are used for logging in backend.
        campaignName: record.campaignName,
        adgroupName: record.adgroup_name,
        keyword: record.keyword,
        matchType: capitalizeFirstLetter(record.match_type || ''),
      })
    })

    // Remove duplicate entries.
    keywordsChanged =  [...new Map(keywordsChanged.map(item => [item.keywordId, item])).values()]

    if (keywordsChanged.length) {
      dispatch(updateKeywordStates(keywordsChanged, 'paused')).then((keywordIdsUpdated) => {
        setKeywords(duplicatedKeyword.children.map((record) => {
          if (keywordIdsUpdated.indexOf(record.keyword_id) !== -1) {
            return {
              ...record,
              state: 'paused',
            }
          }
          return record
        }))
      })
    }
  }

  const handleAdjustBid = () => {
    if (selectedAdjustBidOption.value !== ADJUST_BID_CPC
      && (bidValue === '' || isNaN(bidValue))) {
      toast.show({
        title: 'Warning',
        description: 'Please enter the valid bid value.',
      })
      return
    }

    let keywordsChanged = []
    keywords.filter(record => (
      selectedKeywords.indexOf(record.keyword_id) !== -1
      && record.keyword !== '(_targeting_auto_)'
    )).forEach((record) => {
      let newBid = parseFloat(bidValue)
      if (selectedAdjustBidOption.value === ADJUST_BID_RAISE) {
        newBid = parseFloat(record.bid || 0) * (1 + (newBid / 100))
      } else if (selectedAdjustBidOption.value === ADJUST_BID_LOWER) {
        newBid = parseFloat(record.bid || 0) * (1 - (newBid / 100))
      } else if (selectedAdjustBidOption.value === ADJUST_BID_CPC) {
        newBid = parseFloat(record.cpc || 0)
      }

      if (newBid >= 0.15) {
        keywordsChanged.push({
          campaignId: record.campaign_id,
          campaignType: record.campaignType,
          adGroupId: record.adgroup_id,
          keywordId: record.keyword_id,
          bid: parseFloat(newBid.toFixed(2)),
          // Below information are used for logging in backend.
          campaignName: record.campaignName,
          adgroupName: record.adgroup_name,
          keyword: record.keyword,
          originalBid: record.bid,
          matchType: capitalizeFirstLetter(record.match_type || ''),
        })
      }
    })

    // Remove duplicate entries.
    keywordsChanged =  [...new Map(keywordsChanged.map(item => [item.keywordId, item])).values()]

    if (!keywordsChanged.length) {
      toast.show({
        title: 'Warning',
        description: 'The minimum bid allowed is $0.15. Please check your keywords.',
      })
      return
    }

    dispatch(adjustKeywordBids(keywordsChanged)).then((keywordIdsUpdated) => {
      setKeywords(duplicatedKeyword.children.map((record) => {
        if (keywordIdsUpdated.indexOf(parseInt(record.keyword_id, 10)) !== -1) {
          const payload = keywordsChanged.find(p => (
            parseInt(p.keywordId, 10) === parseInt(record.keyword_id, 10))
          )
          if (payload) {
            return {
              ...record,
              bid: payload.bid,
            }
          }
        }
        return record
      }))
    })
  }

  const renderAction = () => {
    if (!selectedKeywords.length) {
      return null
    }

    if (!isShowAdjustBid) {
      const isPauseDisabled = typeof keywords.find(record => (
        selectedKeywords.indexOf(record.keyword_id) !== -1
        && record.state !== 'paused'
      )) === 'undefined'

      return (
        <>
          <button
            type="button"
            className="btn btn-red"
            disabled={isUpdatingKeywordStates || isPauseDisabled}
            onClick={handlePause}
          >
            Pause
          </button>
          <button
            type="button"
            className="btn btn-light-blue"
            onClick={() => { setIsShowAdjustBid(true) }}
          >
            Adjust Bid
          </button>
        </>
      )
    }

    return (
      <BidAdjustComponent
        adjustBidOption={selectedAdjustBidOption}
        bidValue={bidValue}
        isAdjusting={isAdjustingKeywordBids}
        onChangeAdjustBidOption={setSelectedAdjustBidOption}
        onChangeBidValue={setBidValue}
        onApply={handleAdjustBid}
        onCancel={() => { setIsShowAdjustBid(false) }}
      />
    )
  }

  const renderKeyword = record => (
    <>
      <div className="table-col col-campaign" title={record.campaignName}>
        <div className="contents">
          { record.campaignName }
        </div>
        <div className="campaign-detail">
          {
            record.campaignType === 'Sponsored Products' && (
              <span>
                { record.targetingType === 'auto' ? 'Auto' : 'Manual' }
              </span>
            )
          }
          <span>
            { campaignTypeMap[record.campaignType] }
          </span>
        </div>
      </div>
      <div className="table-col col-adgroup" title={record.adgroup_name}>
        <span className="contents">
          { record.adgroup_name }
        </span>
      </div>
      <div className="table-col col-state">
        { record.state }
      </div>
      <div className="table-col">
        { record.matchType }
      </div>
      <div className="table-col">
        { formatCurrency(record.bid, currencySign, currencyRate) }
      </div>
      {
        bulkBidColumnList.map(column => (
          <TableCell
            key={column.key}
            record={record}
            columnKey={column.key}
            columnSelection={campaignTableColumns}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  return (
    <Modal className="dup-keyword-modal" backdrop="static" full show={duplicatedKeyword !== null}>
      <Modal.Header onHide={() => { onClose() }}>
        <Modal.Title>
          Duplicated Keyword: { duplicatedKeyword ? duplicatedKeyword.keyword : '' }
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <div className="filter-container">
          <div className="select-wrapper">
            <span>Match Type</span>
            <Select
              classNamePrefix="match-type-selector"
              options={matchTypes}
              value={selectedMatchType}
              onChange={setSelectedMatchType}
            />
          </div>
        </div>
        <SortableTable
          columns={columns}
          defaultSort={['cost', 'desc']}
          sorter={tableSorter(['campaignName', 'adgroup_name', 'state', 'matchType'])}
          className="table-keywords"
          records={keywords || []}
          idField="keyword_id"
          searchFields={['campaignName', 'adgroup_name']}
          selectedRecords={selectedKeywords}
          paginationSelectPlacement="top"
          hasSticky
          columnEditorId="dupKeywordModal"
          columnList={bulkBidColumnList}
          columnSelection={campaignTableColumns}
          isLoading={isUpdatingKeywordStates || isAdjustingKeywordBids}
          renderRecord={renderKeyword}
          renderTopRight={renderAction}
          onChange={setSelectedKeywords}
        />
      </Modal.Body>
      <Modal.Footer>
        <button type="button" className="rs-btn rs-btn-subtle" onClick={() => onClose()}>
          Close
        </button>
      </Modal.Footer>
    </Modal>
  )
}

export default DupKeywordModal
