import React from 'react'

import SubSection from '../APMComponent/SubSection'
import OpNTA from './OpNTA'
import OpNPT from '../APMComponent/OpNPT'

const OpNegative = ({ settings, onChange, ...props }) => {
  return (
    <SubSection name="Negative Target Automation" {...props}>
      <OpNTA
        isOriginal
        settings={settings}
        onChange={onChange}
      />
      {
        settings.copy_nta_isactive && (
          <OpNTA
            settings={settings}
            onChange={onChange}
          />
        )
      }
      <OpNPT
        isOriginal
        settings={settings}
        onChange={onChange}
      />
      {
        settings.copy_npt_byclick_isactive && (
          <OpNPT
            settings={settings}
            onChange={onChange}
          />
        )
      }
    </SubSection>
  )
}

export default OpNegative
