import React from 'react'

import Section from '../APMComponent/Section'
import ExKeyword from '../APMComponent/ExKeyword'

const SUBSECTION_KEYWORD = 'keyword'

const ExSection = (props) => {
  return (
    <Section>
      <ExKeyword id={SUBSECTION_KEYWORD} {...props} />
    </Section>
  )
}

export default ExSection
