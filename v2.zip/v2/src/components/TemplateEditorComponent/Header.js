// Smart pilot template manager pane header.
import React from 'react'
import { Tooltip, Whisper } from 'rsuite'
import * as Icon from 'react-icons/fi'

import { ReactComponent as InfoSvg } from '../../assets/svg/info.svg'
import { ReactComponent as CloseSvg } from '../../assets/svg/close.svg'

import TabSelector from '../APMComponent/TabSelector'

const Header = ({ name, tabList, activeTab, onChangeName, onSetActiveTab, onClose }) => {
  return (
    <div className="top-container">
      <div className="pane-header">
        <div className="left-column">
          <span className="pane-title">
            Edit Smart Pilot Template
            <Whisper placement="bottomEnd" trigger="hover" speaker={(
              <Tooltip>
                <p>
                  Here you can update the template name and settings.
                  Please note the all changes will impact the campaigns
                  that are currently using this template.
                </p>
                <p>
                  You can also create new templates by making adjustments
                  and clicking on “Save as New Template”.
                  Once saved, your template will be available to apply
                  to one or more campaigns.
                </p>
              </Tooltip>
            )}>
              <InfoSvg />
            </Whisper>
          </span>
          <span className="input-wrapper">
            <input
              type="text"
              placeholder="Template name"
              value={name}
              onChange={(event) => { onChangeName(event.target.value) }}
            />
            <Icon.FiEdit3 />
          </span>
        </div>
        <div className="right-column">
          <CloseSvg className="close-button" onClick={onClose} />
        </div>
      </div>
      <TabSelector
        tabList={tabList}
        activeTab={activeTab}
        onSetActiveTab={onSetActiveTab}
      />
    </div>
  )
}

export default Header
