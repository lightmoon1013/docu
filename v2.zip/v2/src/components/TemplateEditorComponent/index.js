// Smart pilot template editor.
import React, { useState, useEffect } from 'react'
import { useDispatch, useStore } from 'react-redux'
import OutsideClickHandler from 'react-outside-click-handler'
import moment from 'moment'

import { hideTemplateEditor } from '../../redux/actions/pageGlobal'
import { saveTemplate } from '../../redux/actions/ap'
import { updateTemplate, deleteTemplate } from '../../redux/actions/templateEditor'
import { getDefaultAPSettings, apSettings as apSettingsTemplate } from '../../services/helper'

import LoaderComponent from '../CommonComponents/LoaderComponent'
import Header from './Header'
import Footer from './Footer'
import OpSection from './OpSection'
import ExSection from './ExSection'

const TAB_OP = 'op'
const TAB_EX = 'ex'

const tabList = [
  { value: TAB_OP, label: 'Optimization' },
  { value: TAB_EX, label: 'Expansion' },
]

const TemplateEditorComponent = () => {
  const dispatch = useDispatch()
  const store = useStore()

  const {
    templateEditor: { templateId, details, isLoading, isSaving },
  } = store.getState()

  // Current template settings.
  const [name, setName] = useState('')
  const [settings, setSettings] = useState(getDefaultAPSettings())

  // Switch between Optimization and Expansion tabs.
  const [activeTab, setActiveTab] = useState(TAB_OP)

  const [saveError, setSaveError] = useState(null)

  // Update local state with loaded settings.
  useEffect(() => {
    if (details) {
      setName(details.name)
      setSettings(details)
    }
  }, [details]) // eslint-disable-line

  // Change a setting value.
  const onChange = (name, value) => {
    setSettings(prev => ({
      ...prev,
      [name]: value,
    }))
  }

  // Hide template editor.
  const onClose = () => {
    dispatch(hideTemplateEditor())
  }

  const onOutsideClick = (event) => {
    // Date range picker renders itself as a popup outside APM pane,
    // causing clicking on it to close APM pane. Below fixes this behavior.
    if (document.getElementsByClassName('rs-picker-daterange-menu').length) {
      if (document.getElementsByClassName('rs-picker-daterange-menu')[0].contains(event.target)) {
        return
      }
    }
    // Modal dialog renders itself as a popup outside APM pane,
    // causing clicking on it to close APM pane. Below fixes this behavior.
    if (document.getElementsByClassName('rs-modal-dialog').length) {
      if (document.getElementsByClassName('rs-modal-dialog')[0].contains(event.target)) {
        return
      }
    }
    if (document.getElementsByClassName('rs-modal-backdrop').length) {
      if (document.getElementsByClassName('rs-modal-backdrop')[0].contains(event.target)) {
        return
      }
    }
    // Toast renders itself as a popup outside APM pane,
    // causing clicking on it to close APM pane. Below fixes this behavior.
    if (document.getElementsByClassName('notification').length) {
      if (document.getElementsByClassName('notification')[0].contains(event.target)) {
        return
      }
    }
    onClose()
  }

  // Sanitize settings before saving.
  const _sanitizeSettings = () => {
    setSaveError(null)

    if (parseFloat(settings['increase_adv_percentacos_threshold'])
      > parseFloat(settings['increase_adv_percentbid_byacos_threshold'])) {
      setSaveError('Please enter a valid ACoS range for Unprofitable Targets.')
      return null
    }

    if (parseFloat(settings['copy_increase_adv_percentacos_threshold'])
      > parseFloat(settings['copy_increase_adv_percentbid_byacos_threshold'])) {
      setSaveError('Please enter a valid ACoS range for Unprofitable Targets.')
      return null
    }

    const payload = Object.assign({}, settings, {
      template_id: templateId,
      name,
    })

    Object.keys(apSettingsTemplate).forEach((setting) => {
      if (typeof settings[setting] === 'undefined') {
        return
      }

      if (apSettingsTemplate[setting].type === 'json_array') {
        // TODO: Do we need to escape values to be query-safe?
        // `filter` method here removes NULL values.
        payload[setting] = JSON.stringify(settings[setting].filter(s => s))
      } else if (apSettingsTemplate[setting].type === 'concat') {
        payload[setting] = settings[setting].join(',')
      } else if (apSettingsTemplate[setting].type === 'date') {
        payload[setting] = settings[setting]
          ? moment(settings[setting]).format() : settings[setting]
      }
    })

    return payload
  }

  // Save smart pilot template settings.
  const onSave = () => {
    const payload = _sanitizeSettings()
    if (payload) {
      dispatch(updateTemplate(payload))
    }
  }

  const onSaveAsAnother = () => {
    if (details && details.name === name) {
      setSaveError('Please enter a name different than the original one.')
      return
    }

    const payload = _sanitizeSettings()
    if (payload) {
      dispatch(saveTemplate(name, false, payload))
    }
  }

  const onDelete = () => {
    dispatch(deleteTemplate(templateId)).then(() => {
      onClose()
    })
  }

  return (
    <OutsideClickHandler onOutsideClick={onOutsideClick}>
      <div className="template-editor-component">
        { (isLoading || isSaving) && <LoaderComponent /> }
        <Header
          name={name}
          tabList={tabList}
          activeTab={activeTab}
          onChangeName={setName}
          onSetActiveTab={setActiveTab}
          onClose={onClose}
        />
        <div className="pane-body">
          {
            activeTab === TAB_OP &&
            <OpSection
              settings={settings}
              onChange={onChange}
            />
          }
          {
            activeTab === TAB_EX &&
            <ExSection
              settings={settings}
              onChange={onChange}
            />
          }
        </div>
        <Footer
          isLoading={isLoading}
          isSaving={isSaving}
          saveError={saveError}
          onSave={onSave}
          onSaveAsAnother={onSaveAsAnother}
          onDelete={onDelete}
          onClose={onClose}
        />
      </div>
    </OutsideClickHandler>
  )
}

export default TemplateEditorComponent
