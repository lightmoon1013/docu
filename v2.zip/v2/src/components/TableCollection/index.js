import React, { useState } from 'react'
import { useDispatch, useStore } from 'react-redux'

import MyCampaignTable from '../MyCampaignTable'
import ProductTableComponent from '../ProductTableComponent'
import PortfolioTableComponent from '../PortfolioTableComponent'

import { ReactComponent as MaxSvg } from '../../assets/svg/maximize.svg'
import { ReactComponent as MinSvg } from '../../assets/svg/minimize.svg'

import { toggleDashboardTable } from '../../redux/actions/dashboard'

const TAB_CAMPAIGN = 'campaign'
const TAB_PRODUCT = 'product'
const TAB_PORTFOLIO = 'portfolio'

const tabList = [
  { tab: TAB_CAMPAIGN, name: 'My Campaigns' },
  { tab: TAB_PRODUCT, name: 'My Products' },
  { tab: TAB_PORTFOLIO, name: 'Portfolios' },
]

const TableCollection = () => {
  const dispatch = useDispatch()
  const store = useStore().getState()
  const { dashboard: { maxTable } } = store

  const [activeTab, setActiveTab] = useState(TAB_CAMPAIGN)

  const renderMaxMin = () => {
    if (!maxTable) {
      return <MaxSvg onClick={() => { dispatch(toggleDashboardTable()) }} />
    }
    return <MinSvg onClick={() => { dispatch(toggleDashboardTable()) }} />
  }

  const renderContents = () => {
    if (activeTab === TAB_CAMPAIGN) {
      return <MyCampaignTable />
    }
    if (activeTab === TAB_PRODUCT) {
      return <ProductTableComponent />
    }
    if (activeTab === TAB_PORTFOLIO) {
      return <PortfolioTableComponent />
    }
    return null
  }

  return (
    <div className="table-collection">
      <div className="table-tabs">
        <div className="table-tab-left">
          {
            tabList.map(tab => (
              <button
                key={tab.tab}
                type="button"
                className={`table-tab${activeTab === tab.tab ? ' selected' : ''}`}
                onClick={() => { setActiveTab(tab.tab) }}
              >
                { tab.name }
              </button>
            ))
          }
        </div>
        <div className="table-tab-right">
          { renderMaxMin() }
        </div>
      </div>
      { renderContents() }
    </div>
  )
}

export default TableCollection
