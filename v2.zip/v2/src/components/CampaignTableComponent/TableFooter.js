import React, { useMemo } from 'react'

import TableCell from '../CommonComponents/TableCell'

import { calcDerivedMetrics } from '../../services/helper'
import { campaignColumnList } from '../../utils/defaultValues'

const TableFooter = ({ campaigns, selectedColumns, currencySign, currencyRate,
  refTotal, hideDailyBudget }) => {
  let total = useMemo(() => {
    const summary = {
      revenue: 0,
      cost: 0,
      impressions: 0,
      clicks: 0,
      orders: 0,
      ntb_orders: 0,
      ntb_sales: 0,
      viewable_impressions: 0,
    }

    campaigns.forEach((record) => {
      summary.revenue += record.revenue
      summary.cost += record.cost
      summary.impressions += record.impressions
      summary.clicks += record.clicks
      summary.orders += record.orders
      summary.ntb_orders += record.ntb_orders
      summary.ntb_sales += record.ntb_sales
      summary.viewable_impressions += (record.viewable_impressions || 0)
    })

    return summary
  }, [campaigns])

  total = calcDerivedMetrics(total)

  return (
    <div className="table-row content-footer" ref={refTotal}>
      <div className="table-col"></div>
      <div className="table-col">Totals:</div>
      {
        campaignColumnList.map((column) => {
          if (column.fixed || (hideDailyBudget && column.key === 'daily_budget')) {
            return null
          }

          return (
            <TableCell
              key={column.key}
              record={total}
              columnKey={column.key}
              columnSelection={selectedColumns}
              currencySign={currencySign}
              currencyRate={currencyRate}
            />
          )
        })
      }
      <div className="table-col"></div>
    </div>
  )
}

export default TableFooter
