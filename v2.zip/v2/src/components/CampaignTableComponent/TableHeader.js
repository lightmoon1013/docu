import React from 'react'

import { ReactComponent as MaxSvg } from '../../assets/svg/maximize.svg'
import { ReactComponent as MinSvg } from '../../assets/svg/minimize.svg'

import CheckboxComponent from '../CommonComponents/CheckboxComponent'

import { campaignColumnList } from '../../utils/defaultValues'

const TableHeader = ({ campaigns, selectedCampaigns, selectedColumns,
  onSelect, onSort, refHeader,
  tableHeight, resizing, campaignColRef, hideDailyBudget,
  onCollapseCampaignCol, onExpandCampaignCol, onStartResizing,
}) => (
  <div className="table-row content-header" ref={refHeader}>
    <div className="table-col">
      <CheckboxComponent
        checked={selectedCampaigns.length > 0 && selectedCampaigns.length === campaigns.length}
        onChange={(checked) => { onSelect(checked ? campaigns : []) }}
      />
    </div>
    <div
      className="table-col campaign-status"
      onClick={() => { onSort('campaign') }}
      ref={campaignColRef}
    >
      Campaign
      <MinSvg className="min-svg" onClick={onCollapseCampaignCol} />
      <MaxSvg className="max-svg" onClick={onExpandCampaignCol} />
      <div
        style={{ height: tableHeight }}
        onMouseDown={onStartResizing}
        className={`resize-handle ${resizing ? 'active' : 'idle'}`}
      />
    </div>
    {
      campaignColumnList.map((column) => {
        if (column.fixed || !selectedColumns.includes(column.key)) {
          return null
        }

        if (hideDailyBudget && column.key === 'daily_budget') {
          return null
        }

        return (
          <div key={column.key} className="table-col" onClick={() => { onSort(column.key) }}>
            { column.name || column.label }
          </div>
        )
      })
    }
    <div className="table-col"></div>
  </div>
)

export default TableHeader
