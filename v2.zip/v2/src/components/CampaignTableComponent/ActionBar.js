import React, { useState, useEffect } from 'react'
import { useStore, useDispatch } from 'react-redux'
import Select from 'react-select'

import { ReactComponent as HistorySvg } from '../../assets/svg/history.svg'
import { ReactComponent as FilterSvg } from '../../assets/svg/filter.svg'
import { ReactComponent as ColumnSvg } from '../../assets/svg/columns.svg'
import { ReactComponent as SearchSvg } from '../../assets/svg/search.svg'

import DateRangeComponent from '../CommonComponents/DateRangeComponent'
import TableFilterShower from '../CommonComponents/TableFilterShower'

import {
  showFilter,
  showColumnEditorAction,
} from '../../redux/actions/pageGlobal'
import { setDateRange } from '../../redux/actions/header'
import { getPortfolios } from '../../redux/actions/bulkEngine'
import { campaignTypes } from '../../utils/filterDef'

export const FILTER_NAME = 'campaignTable'

const ActionBar = ({ searchKey, selectedCampaigns, dateRange,
  customActionBar, onChangeSearch, onAdTypeSelect, onPortfolioSelect,
  onDeselect, onShowHistory }) => {
  const dispatch = useDispatch()
  const store = useStore().getState()

  const {
    bulkEngine: {
      isGettingPortfolios,
      portfolioList,
    },
  } = store

  const [portfolioOptions, setPortfolioOptions] = useState([])
  const [selectedPortfolios, setSelectedPortfolios] = useState([])
  const [selectedAdType, setSelectedAdType] = useState(campaignTypes[0])

  useEffect(() => {
    dispatch(getPortfolios())
  }, []) // eslint-disable-line

  useEffect(() => {
    const options = portfolioList.map(portfolio => ({
      label: portfolio.name,
      value: portfolio.portfolio_id,
    })).sort((opt1, opt2) => opt1.label.localeCompare(opt2.label))
    setPortfolioOptions(options)
  }, [portfolioList])

  const handleDateRangeChange = ([ startDate, endDate ]) => {
    dispatch(setDateRange({
      startDate,
      endDate,
    }))
  }

  const handleAdTypeSelect = (option) => {
    onAdTypeSelect(option.value)
    setSelectedAdType(option)
  }

  const handlePortfolioSelect = (options) => {
    onPortfolioSelect(options.map(opt => parseInt(opt.value, 10)))
    setSelectedPortfolios(options)
  }

  const handleFilterShow = () => {
    dispatch(showFilter(FILTER_NAME))
  }

  const handleColumnEditorShow = () => {
    dispatch(showColumnEditorAction())
  }

  const CustomActionBar = customActionBar

  return (
    <div className="table-header">
      <div className="table-header-left">
        <SearchSvg />
        <input
          type="text"
          className="table-header-search"
          placeholder="Type to search..."
          value={searchKey}
          onChange={(event) => { onChangeSearch(event.target.value) }}
        />
        <DateRangeComponent
          value={dateRange}
          onChange={handleDateRangeChange}
        />
        <Select
          className="ad-type-select"
          classNamePrefix="ad-type-select"
          options={campaignTypes}
          value={selectedAdType}
          placeholder="Filter by Ad Type"
          onChange={handleAdTypeSelect}
        />
        <Select
          className="portfolio-select"
          classNamePrefix="portfolio-select"
          isMulti
          options={portfolioOptions}
          value={selectedPortfolios}
          placeholder="Filter by Portfolios"
          isLoading={isGettingPortfolios}
          onChange={handlePortfolioSelect}
        />
        {
          selectedCampaigns.length > 0 && (
            <button type="button" className="btn btn-white" onClick={() => { onDeselect() }}>
              Deselect
            </button>
          )
        }
        {
          CustomActionBar && (
            <CustomActionBar
              selectedCampaigns={selectedCampaigns}
            />
          )
        }
      </div>
      <div className="table-header-right">
        <TableFilterShower
          filterName={FILTER_NAME}
          noTitle
        />
        <FilterSvg title="Filter" onClick={handleFilterShow} />
        <HistorySvg title="History" onClick={onShowHistory}/>
        <ColumnSvg title="Column Customizer" onClick={handleColumnEditorShow} />
      </div>
    </div>
  )
}

export default ActionBar
