import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react'
import { useDispatch, useStore } from 'react-redux'
import moment from 'moment'

import PaginationComponent from '../CommonComponents/PaginationComponent'
import LoaderComponent from '../CommonComponents/LoaderComponent'
import { toast } from '../CommonComponents/ToastComponent/toast'
import ColumnEditor from '../CommonComponents/ColumnEditor'
import TableFilter from '../CommonComponents/TableFilter'

import APMComponent from '../APMComponent'
import ThumbHistory from './ThumbHistory'
import ActionBar, { FILTER_NAME } from './ActionBar'
import TableHeader from './TableHeader'
import TableRow from './TableRow'
import TableFooter from './TableFooter'

import {
  updateCampaignAcos,
  getCampaignsWithHistory,
  updateCampaignsDailyBudget,
} from '../../redux/actions/campaign'

import { selectColumns, applyFilter } from '../../redux/actions/pageGlobal'
import { campaignColumnList } from '../../utils/defaultValues'
import filterDef, { STATE_OPTION_ENABLED } from '../../utils/filterDef'
import { matchFilter, tableSorter } from '../../services/helper'

const CampaignTableComponent = ({ className = '', hideSb, hideSd, fromBulkEngine, customActionBar, customCallbacks }) => {
  const dispatch = useDispatch()
  const store = useStore().getState()
  const acosRef = useRef()
  const dailyBudgetRef = useRef()
  const refBody = useRef(null)
  const refHeader = useRef(null)
  const refTotal = useRef(null)

  const { campaign, pageGlobal, header, ap } = store

  const {
    currencyRate,
    currencySign,
    currentStartDate,
    currentEndDate,
    currentUserId,
    selectedUserInfo,
  } = header

  const {
    campaignsWithHistory,
    isUpdateCampaignAcos,
    isUpdateCampaignDailyBudget,
    isLoading,
    isUpdatingCampaignState,
    isUpdatingCampaignNames,
    isUpdatingBidStrategy,
  } = campaign

  const {
    showColumnEditor,
    visibleFilterName,
    showAPM,
    campaignTableColumns,
    filterValues,
    visibleColumnEditorId,
  } = pageGlobal

  const { isTurningBulk } = ap

  const [isShowHistory, setIsShowHistory] = useState(false)
  const [acosCampaignId, setAcosCampaignId] = useState('')
  const [dailyBudgetCampaignId, setDailyBudgetCampaignId] = useState('')
  const [selectedCampaigns, setSelectedCampaigns] = useState([])
  const [selectedPortfolioIds, setSelectedPortfolioIds] = useState([])
  const [selectedAdType, setSelectedAdType] = useState('')

  const [pageStartNum, setPageStartNum] = useState(0)
  const [pageEndNum, setPageEndNum] = useState(10)
  const [searchKey, setSearchKey] = useState('')
  const [sortColumnName, setSortColumnName] = useState('cost')
  const [sortDirection, setSortDirection] = useState('desc')

  const [historyPayload, setHistoryPayload] = useState({})

  const [stickyOffset, setStickyOffset] = useState(null)

  const [tableHeight, setTableHeight] = useState('auto')
  const [resizing, setResizing] = useState(false)

  const campaignColIndex = 0
  const campaignColRef = useRef()
  const campaignColMinWidth = 205

  useEffect(() => {
    setTableHeight(refBody.current.offsetHeight)

    // To show active campaigns only for the bulk engine,
    // we manually adjust filter values here.
    setTimeout(() => {
      // Because `GET_ALL_ACCOUNT_START` action resets `filterValues`,
      // we wait for a while until that action is proceeded.
      const currentFilter = { ...((filterValues || {})[FILTER_NAME] || {}) }
      currentFilter.state = fromBulkEngine ? STATE_OPTION_ENABLED : ''
      dispatch(applyFilter(FILTER_NAME, currentFilter))
    })
  }, []) // eslint-disable-line

  // Listener for mouse move event. Used to resize the campaign name column.
  const handleMouseMove = useCallback(
    (e) => {
      const leftPos = campaignColRef.current.getBoundingClientRect().left
      const width = e.clientX - leftPos >= campaignColMinWidth
        ? e.clientX - leftPos
        : campaignColRef.current.offsetWidth
      campaignColRef.current.style.minWidth = `${width}px`
      let rowElement = campaignColRef.current.parentNode
      while (rowElement) {
        rowElement.childNodes[campaignColIndex + 1].style.minWidth = `${width}px`
        rowElement = rowElement.nextSibling
      }
    },
    []
  )

  // Listener for mouse up event. Used to resize the campaign name column.
  const handleMouseUp = useCallback(() => {
    setResizing(false)
    window.removeEventListener('mousemove', handleMouseMove)
    window.removeEventListener('mouseup', handleMouseUp)
  }, [setResizing]) // eslint-disable-line

  const handleStartResizing = () => {
    setResizing(true)

    window.addEventListener('mousemove', handleMouseMove)
    window.addEventListener('mouseup', handleMouseUp)
  }

  useEffect(() => {
    if (!currentUserId) {
      return
    }
    setSelectedCampaigns([])
    setSelectedPortfolioIds([])
    dispatch(getCampaignsWithHistory({
      startDate: moment(currentStartDate).format('YYYY-MM-DD'),
      endDate: moment(currentEndDate).format('YYYY-MM-DD'),
    }))
  }, [currentStartDate, currentEndDate, currentUserId]) // eslint-disable-line

  useEffect(() => {
    // When changing to a differnt portfolio, de-select campaigns.
    selectCampaigns([])
  }, [selectedPortfolioIds]) // eslint-disable-line

  useEffect(() => {
    document.addEventListener('click', handleClick)

    return () => {
      document.removeEventListener('click', handleClick)
    }

    function handleClick(e) {
      if (acosRef && acosRef.current && !acosRef.current.contains(e.target)) {
        setAcosCampaignId('')
      }
      if (dailyBudgetRef && dailyBudgetRef.current && !dailyBudgetRef.current.contains(e.target)) {
        setDailyBudgetCampaignId('')
      }
    }
  }, [])

  useEffect(() => {
    const mainContent = document.querySelector('.main-content')
    mainContent.addEventListener('scroll', handleScroll)

    return () => {
      mainContent.removeEventListener('scroll', () => handleScroll)
    }
  })

  useEffect(() => {
    if (stickyOffset === null) {
      return
    }
    refHeader.current.style.top = `${stickyOffset}px`
    refTotal.current.style.top = `${stickyOffset + refHeader.current.clientHeight}px`
  }, [stickyOffset])

  const setCampaignColWidth = (width = campaignColMinWidth) => {
    campaignColRef.current.style.minWidth = `${width}px`
    let rowElement = campaignColRef.current.parentNode
    while (rowElement) {
      rowElement.childNodes[campaignColIndex + 1].style.minWidth = `${width}px`
      rowElement = rowElement.nextSibling
    }
  }

  const handleExpandCampaignCol = () => {
    let width = campaignColMinWidth
    const rows = document.getElementsByClassName('table-row')
    for (let index = 0; index < rows.length; index++) {
      const campaignCol = rows[index].childNodes[campaignColIndex + 1].getElementsByClassName('campaign-name')[0]
      if (campaignCol) {
        width = Math.max(width, campaignCol.scrollWidth)
      }
    }

    setCampaignColWidth(width)
  }

  const handleCollapseCampaignCol = () => {
    setCampaignColWidth()
  }

  const handleScroll = () => {
    if (refBody.current) {
      const { top } = refBody.current.getBoundingClientRect()
      if (top < 0) {
        setStickyOffset(-top)
        return
      }
    }
    setStickyOffset(null)
  }

  const loadPageCampaigns = (pageNum, pageRows) => {
    if (pageRows !== 'all') {
      setPageStartNum((pageNum - 1) * pageRows)
      setPageEndNum(pageNum * pageRows)
    } else {
      setPageStartNum(0)
      setPageEndNum(filteredCampaigns.length)
    }
  }

  const selectCampaigns = (campaigns) => {
    setSelectedCampaigns(campaigns)

    if (customCallbacks && customCallbacks.onSelectCampaigns) {
      customCallbacks.onSelectCampaigns(campaigns)
    }
  }

  const handleSaveAcos = (campaign) => {
    const acosValue = parseFloat(acosRef.current.value, 10)
    if (!acosValue || isNaN(acosValue)) {
      toast.show({
        title: 'Warning',
        description: 'Please enter Target ACoS.',
      })
      return
    }

    if (acosValue <= 0) {
      toast.show({
        title: 'Warning',
        description: 'Target ACoS should be greater than 0.',
      })
      return
    }
    dispatch(updateCampaignAcos(campaign.campaign_id, campaign.campaignType, acosValue))
  }

  const handleSaveDailyBudget = (campaign) => {
    const newDailyBudget = parseFloat(dailyBudgetRef.current.value, 10)
    if (!newDailyBudget) {
      return
    }
    const newBudget = newDailyBudget
    if (isNaN(newBudget) || newBudget < 1) {
      toast.show({
        title: 'Warning',
        description: 'Minimum value is $1. Please enter a higher number.',
      })
      return
    }
    dispatch(updateCampaignsDailyBudget(campaign.campaign_id, campaign.campaignType, newBudget))
  }

  const handleSelect = (checked, data) => {
    if (checked) {
      selectCampaigns(prevState => [...prevState, data])
    } else {
      selectCampaigns(selectedCampaigns.filter(item => item.campaign_id !== data.campaign_id))
    }
  }

  const handleClickHistory = (chartData, columnKey, campaign, metric) => {
    if (!isShowHistory) {
      return
    }

    setHistoryPayload({
      metric,
      campaign,
      direct: columnKey === 'cpc' || columnKey === 'acos',
      data: (chartData || []).map(item => ({
        date: item.report_date,
        value: item[columnKey] ? item[columnKey] : 0,
      })),
    })
  }

  const sortColumn = (field) => {
    setSortDirection(sortColumnName === field && sortDirection === 'asc' ? 'desc' : 'asc')
    setSortColumnName(field)
  }

  let filteredCampaigns = useMemo(() => {
    return (campaignsWithHistory || []).filter((record) => {
      if (hideSb
        && (record.campaignType === 'Sponsored Brands' || record.campaignType === 'Sponsored Brands Video')) {
        return false
      }

      if (hideSd && record.campaignType === 'Sponsored Displays') {
        return false
      }

      if (!record.campaign.toLowerCase().includes(searchKey.toLowerCase())) {
        return false
      }

      if (selectedAdType !== '' && record.campaignType.toLowerCase() !== selectedAdType) {
        return false
      }

      if (selectedPortfolioIds.length > 0
        && !selectedPortfolioIds.includes(parseInt(record.portfolio_id, 10))) {
        return false
      }

      if (!matchFilter(record, filterDef[FILTER_NAME], (filterValues || {})[FILTER_NAME] || {})) {
        return false
      }

      return true
    })
  }, [campaignsWithHistory, selectedAdType, selectedPortfolioIds, // eslint-disable-line
    searchKey, filterValues, hideSb, hideSd]) // eslint-disable-line

  filteredCampaigns = useMemo(() => (
    tableSorter(['campaign'])
    (filteredCampaigns, [sortColumnName, sortDirection])
  ), [filteredCampaigns, sortColumnName, sortDirection])

  let pageStart = pageStartNum
  let pageEnd = pageEndNum
  if (pageEndNum > filteredCampaigns.length) {
    const numberPerPage = pageEndNum - pageStartNum
    const totalPage =  Math.ceil(filteredCampaigns.length / numberPerPage)
    pageStart = (totalPage - 1) * numberPerPage
    pageEnd = filteredCampaigns.length
  }

  const campaignElements = filteredCampaigns.slice(pageStart, pageEnd).map(record => (
    <TableRow
      key={record.campaign_id}
      campaign={record}
      selectedCampaigns={selectedCampaigns}
      selectedColumns={campaignTableColumns}
      acosCampaignId={acosCampaignId}
      acosRef={acosRef}
      dailyBudgetCampaignId={dailyBudgetCampaignId}
      dailyBudgetRef={dailyBudgetRef}
      isShowHistory={isShowHistory}
      currencySign={currencySign}
      currencyRate={currencyRate}
      startDate={currentStartDate}
      endDate={currentEndDate}
      accountAcos={selectedUserInfo.average_acos || 30}
      hideDailyBudget={fromBulkEngine}
      onSelect={handleSelect}
      onOpenAcosPopup={setAcosCampaignId}
      onSaveAcos={handleSaveAcos}
      onCancelAcos={() => { setAcosCampaignId('') }}
      onOpenDailyBudgetPopup={setDailyBudgetCampaignId}
      onSaveDailyBudget={handleSaveDailyBudget}
      onCancelDailyBudget={() => { setDailyBudgetCampaignId('') }}
      onClickHistory={handleClickHistory}
    />
  ))

  let tableBodyClass = 'table-body'
  if (stickyOffset !== null) {
    tableBodyClass = `${tableBodyClass} sticky`
  }

  const isDataLoading = isLoading
    || isUpdateCampaignAcos
    || isUpdateCampaignDailyBudget
    || isUpdatingCampaignState
    || isTurningBulk
    || isUpdatingCampaignNames
    || isUpdatingBidStrategy

  return (
    <div className={`campaign-table-component ${className}${isDataLoading ? ' loading' : ''}`}>
      { isDataLoading && <LoaderComponent /> }
      {
        showColumnEditor && visibleColumnEditorId === '' &&
        <ColumnEditor
          columnList={campaignColumnList}
          currentSelection={campaignTableColumns}
          onApply={selectColumns}
        />
      }
      {
        visibleFilterName === FILTER_NAME &&
        <TableFilter
          title="Campaign Table Filters"
          filterName={FILTER_NAME}
        />
      }
      { showAPM && <APMComponent /> }
      <ActionBar
        searchKey={searchKey}
        selectedCampaigns={selectedCampaigns}
        dateRange={[currentStartDate, currentEndDate]}
        customActionBar={customActionBar}
        onChangeSearch={setSearchKey}
        onAdTypeSelect={setSelectedAdType}
        onPortfolioSelect={setSelectedPortfolioIds}
        onDeselect={() => { selectCampaigns([]) }}
        onShowHistory={() => { setIsShowHistory(!isShowHistory) }}
      />
      <div className={tableBodyClass} ref={refBody}>
        <TableHeader
          campaigns={filteredCampaigns}
          selectedCampaigns={selectedCampaigns}
          selectedColumns={campaignTableColumns}
          refHeader={refHeader}
          tableHeight={tableHeight}
          resizing={resizing}
          campaignColRef={campaignColRef}
          hideDailyBudget={fromBulkEngine}
          onSelect={selectCampaigns}
          onSort={sortColumn}
          onCollapseCampaignCol={handleCollapseCampaignCol}
          onExpandCampaignCol={handleExpandCampaignCol}
          onStartResizing={handleStartResizing}
        />
        <TableFooter
          campaigns={filteredCampaigns}
          selectedColumns={campaignTableColumns}
          currencySign={currencySign}
          currencyRate={currencyRate}
          refTotal={refTotal}
          hideDailyBudget={fromBulkEngine}
        />
        { campaignElements }
      </div>
      <PaginationComponent
        total={filteredCampaigns.length}
        pageRows={fromBulkEngine ? 5 : 10 }
        loadData={loadPageCampaigns}
      />
      <ThumbHistory
        title={`Campaign: ${historyPayload.campaign}`}
        areaData={historyPayload.data || []}
        metric={historyPayload.metric}
        direct={historyPayload.direct}
        startDate={currentStartDate}
        endDate={currentEndDate}
        onClose={() => { setHistoryPayload({}) }}
      />
    </div>
  )
}

export default CampaignTableComponent
