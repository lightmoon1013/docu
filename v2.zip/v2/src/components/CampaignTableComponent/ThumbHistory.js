import React from 'react'
import { Modal } from 'rsuite'

import AreaRechartComponent from '../CommonComponents/AreaChart'

const ThumbHistory = ({ title, metric, areaData, direct, onClose, startDate, endDate }) => {
  return (
    <Modal
      backdrop
      className="thumb-history-modal"
      show={typeof metric !== 'undefined'}
      size="lg"
      onClick={onClose}
      onHide={onClose}
    >
      <Modal.Header>
        <Modal.Title>
          { title }
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <div className="metric">
          Metric: { metric }
        </div>
        <AreaRechartComponent
          showXAxis
          showYAxis
          showToolTip
          areaData={areaData}
          direct={direct}
          margin={{
            top: 10,
            right: 50,
          }}
          startDate={startDate}
          endDate={endDate}
        />
      </Modal.Body>
    </Modal>
  )
}

export default ThumbHistory
