import React from 'react'
import { useDispatch } from 'react-redux'
import { Link } from 'react-router-dom'
import { Dropdown } from 'rsuite'

import { ReactComponent as MoreApmSvg } from '../../assets/svg/more-apm.svg'
import { ReactComponent as MoreDotsSvg } from '../../assets/svg/more-dots.svg'

import CheckboxComponent from '../CommonComponents/CheckboxComponent'
import TableCell from '../CommonComponents/TableCell'

import {
  showAPMAction,
} from '../../redux/actions/pageGlobal'

import {
  campaignColumnList,
  campaignTypeMap,
} from '../../utils/defaultValues'

const stateLabels = {
  enabled: 'Active',
  paused: 'Paused',
  archived: 'Archived',
}

const TableRow = ({ campaign, selectedCampaigns, selectedColumns,
  acosCampaignId, acosRef, dailyBudgetCampaignId, dailyBudgetRef,
  isShowHistory, currencySign, currencyRate, startDate, endDate, accountAcos,
  hideDailyBudget,
  onSelect, onOpenAcosPopup, onSaveAcos, onCancelAcos,
  onOpenDailyBudgetPopup, onSaveDailyBudget, onCancelDailyBudget, onClickHistory }) => {
  const dispatch = useDispatch()

  const isSelected = typeof selectedCampaigns.find(selected => (
    selected.campaign_id === campaign.campaign_id
  )) !== 'undefined'

  let targetingType
  if (campaign.campaignType === 'Sponsored Products') {
    if (campaign.targeting_type === 'auto') {
      targetingType = 'Auto'
    } else {
      targetingType = 'Manual'
    }
  }

  const handleAPMShow = () => {
    dispatch(showAPMAction(campaign.campaign_id))
  }

  return (
    <div className="table-row">
      <div className="table-col">
        <CheckboxComponent
          checked={isSelected}
          onChange={(checked) => { onSelect(checked, campaign) } }
        />
      </div>
      <div className="table-col">
        <div className="campaign-status">
          <div className={`status ${campaign.state === 'enabled' ? 'on' : 'off'}`}>
            <div className="bullet"></div>
            <span>{ stateLabels[campaign.state] }</span>
          </div>
          <div className={`status ${campaign.is_ap_active ? 'on' : 'off'}`}>
            <div className="bullet"></div>
            <span>Smart Pilot { campaign.is_ap_active ? 'On' : 'Off' }</span>
          </div>
          <MoreApmSvg title="Open Smart Pilot" onClick={handleAPMShow} />
        </div>
        <Link
          to={`/campaign/${campaign.campaign_id}/${campaign.campaignType}`}
          className="campaign-name"
          title={campaign.campaign}
        >
          { campaign.campaign }
        </Link>
        <div className="campaign-detail">
          {
            targetingType && <span>{ targetingType }</span>
          }
          <span>
            { campaignTypeMap[campaign.campaignType] }
          </span>
        </div>
      </div>
      {
        selectedColumns.includes('target_acos') && (
          <div className="table-col">
            {
              acosCampaignId === campaign.campaign_id
              ? (
                <>
                  <input type="number" ref={acosRef} className="edit-input"/>
                  <div className="action-button-container">
                    <button type="button" className="btn btn-blue" onClick={() => { onSaveAcos(campaign) }}>
                      Save
                    </button>
                    <button type="button" className="btn btn-white" onClick={() => { onCancelAcos() }}>
                      Cancel
                    </button>
                  </div>
                </>
              ) : (
                <input
                  type="number"
                  className="edit-input"
                  defaultValue={parseFloat(campaign.target_acos || accountAcos)}
                  onChange={() => { onOpenAcosPopup(campaign.campaign_id) } }
                />
              )
            }
          </div>
        )
      }
      {
        !hideDailyBudget && selectedColumns.includes('daily_budget') && (
          <div className="table-col">
            {
              dailyBudgetCampaignId === campaign.campaign_id
              ? (
                <>
                  <input type="number" ref={dailyBudgetRef} className="edit-input"/>
                  {
                    campaign.budgetrule_status === 'on' ? (
                      <div className="campaign-status">
                        <div className={`status ${campaign.budgetrule_status === 'on' ? 'on' : 'off'}`}>
                          <div className="bullet"></div>
                          <span>Rule On</span>
                        </div>
                      </div>
                    ) : ('')
                  }
                  <div className="action-button-container">
                    <button type="button" className="btn btn-blue" onClick={() => { onSaveDailyBudget(campaign) }}>
                      Save
                    </button>
                    <button type="button" className="btn btn-white" onClick={() => { onCancelDailyBudget() }}>
                      Cancel
                    </button>
                  </div>
                </>
              ) : (
                <>
                  <input
                    type="number"
                    className="edit-input"
                    defaultValue={campaign.daily_budget}
                    onChange={() => { onOpenDailyBudgetPopup(campaign.campaign_id) }}
                  />
                  {
                    campaign.budgetrule_status === 'on' ? (
                      <div className="campaign-status">
                        <div className={`status ${campaign.budgetrule_status === 'on' ? 'on' : 'off'}`}>
                          <div className="bullet"></div>
                          <span>Rule On</span>
                        </div>
                      </div>
                    ) : ('')
                  }
                </>
              )
            }
          </div>
        )
      }
      {
        campaignColumnList.map(column => {
          if (column.key !== 'target_acos'
            && column.key !== 'daily_budget'
            && column.key !== 'campaign') {
            return (
              <TableCell
                key={campaign.campaign_id + column.key}
                record={campaign}
                columnKey={column.key}
                columnSelection={selectedColumns}
                currencySign={currencySign}
                currencyRate={currencyRate}
                showHistory={isShowHistory}
                historyData={campaign.chartData || []}
                startDate={startDate}
                endDate={endDate}
                onClick={() => onClickHistory(campaign.chartData || [], column.key, campaign.campaign, column.label)}
              />
            )
          }
          return null
        })
      }
      <div className="table-col action-column">
        <Dropdown
          title={(<MoreDotsSvg />)}
          noCaret
          placement="topEnd"
        >
          <Dropdown.Item
            renderItem={() => (
              <Link
                to={`/campaign/${campaign.campaign_id}/${campaign.campaignType}`}
                className="rs-dropdown-item-content"
              >
                View Campaign Dashboard
              </Link>
            )}
          >
          </Dropdown.Item>
          <Dropdown.Item onClick={handleAPMShow}>Open Smart Pilot</Dropdown.Item>
        </Dropdown>
      </div>
    </div>
  )
}

export default TableRow
