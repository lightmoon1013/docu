import React, { useEffect, useState } from 'react'
import { useStore } from 'react-redux'
import { Link } from 'react-router-dom'
import { Dropdown, Toggle } from 'rsuite'
import * as Icon from 'react-icons/fi'

import SortableTable from '../CommonComponents/SortableTableComponent'
import GroupTable from '../CommonComponents/GroupTableComponent'
import CheckboxComponent from '../CommonComponents/CheckboxComponent'
import { toast } from '../CommonComponents/ToastComponent/toast'
import TableCampaignCell from '../CommonComponents/TableCampaignCell'
import TableCell from '../CommonComponents/TableCell'
import TableFilterModal from '../CommonComponents/TableFilterModal'

import BulkResultContainer from '../BulkResultContainer'
import { MODULE_NAME_PT_EX } from './PtExSection'
import TargetAddModal from './TargetAddModal'

import {
  tableSorter,
  copyToClipboard,
  calcDerivedMetrics,
  getAmazonLink,
  getExportValueForColumn,
  groupRecords,
} from '../../services/helper'

import { bulkNTBColumnList } from '../../utils/defaultValues'

const columns = [
  { key: 'title', name: 'Product', className: 'col-product' },
  { key: 'asin', name: 'ASIN', className: 'col-asin' },
  { key: 'campaignName', name: 'Campaign', className: 'col-campaign' },
  ...bulkNTBColumnList,
]

const columnsGroup = [
  { key: 'campaignName', name: 'Campaign', className: 'col-campaign', parentOnly: true },
  { key: 'checkPlaceholder', name: '', className: 'col-check', exportable: false, parentOnly: true },
  { key: 'title', name: 'Product', className: 'col-product' },
  { key: 'asin', name: 'ASIN', className: 'col-asin' },
  ...bulkNTBColumnList,
]

export const MODULE_NAME_PT_EX_ASIN = 'ASIN Expansion'
export const FILTER_NAME_PT_EX_ASIN = 'ptExAsin'

const PtExAsinResult = ({ newAsinOnly, onChangeNewAsinOnly, onChangeDate, onApplyFilter }) => {
  const store = useStore()

  const {
    header: {
      currencyRate,
      currencySign,
      selectedUserInfo,
    },
    pageGlobal: {
      campaignTableColumns,
      filterValues,
    },
    campaign: {
      campaignsWithHistory,
    },
    bulkEngine: {
      findPtsData,
    },
  } = store.getState()

  const [groupMode, setGroupMode] = useState(false)
  const [asins, setAsins] = useState([])
  const [groupedAsins, setGroupedAsins] = useState([])
  const [selectedAsins, setSelectedAsins] = useState([])
  const [isAddModalVisible, setIsAddModalVisible] = useState(false)
  const [targetsPayload, setTargetsPayload] = useState([])
  const [currentFilterName, setCurrentFilterName] = useState('')
  const [origFilters, setOrigFilters] = useState({})

  // Filter found search terms.
  useEffect(() => {
    if (!findPtsData || !findPtsData.length) {
      return
    }

    const campaignNamesById = {}
    const campaignTypesById = {}
    const campaignTargetingTypesById = {}
    campaignsWithHistory.forEach((campaign) => {
      campaignNamesById[campaign.campaign_id] = campaign.campaign
      campaignTypesById[campaign.campaign_id] = campaign.campaignType
      campaignTargetingTypesById[campaign.campaign_id] = campaign.targeting_type
    })

    const filteredPTs = findPtsData.map(record => ({
      ...calcDerivedMetrics(record),
      campaignName: campaignNamesById[record.campaign_id] || '',
      campaignType: campaignTypesById[record.campaign_id] || '',
      targetingType: campaignTargetingTypesById[record.campaign_id] || '',
    }))

    setAsins(filteredPTs)
    setGroupedAsins(
      groupRecords(
        filteredPTs,
        'campaign_id',
        ['campaignName', 'campaignType', 'targetingType']
      )
    )
  }, [findPtsData, campaignsWithHistory])

  const handleCopy = () => {
    const asinList = asins.filter(record => (
      selectedAsins.indexOf(record.target_id) !== -1
    )).map(record => record.asin)

    copyToClipboard([...new Set(asinList)].join('\n'))

    toast.show({
      title: 'Success',
      description: `Successfully copied ${asinList.length} ASIN${asinList.length > 1 ? 's' : ''}.`
    })
  }

  const handleAddToExisting = () => {
    setTargetsPayload(asins.filter(record => (
      selectedAsins.indexOf(record.target_id) !== -1
    )).map(record => ({
      target: record.asin,
      cpc: record.cpc,
    })))
    setIsAddModalVisible(true)
  }

  const handleFilterRefine = () => {
    setCurrentFilterName(FILTER_NAME_PT_EX_ASIN)
    setOrigFilters((filterValues || {})[FILTER_NAME_PT_EX_ASIN] || {})
  }

  const handleFilterApply = (values) => {
    // When acos values are changed, call API again.
    if (parseFloat(values.acosMin || 0) !== parseFloat(origFilters.acosMin || 0)
      || parseFloat(values.acosMax || 0) !== parseFloat(origFilters.acosMax || 0)) {
      onApplyFilter(values)
    }
    setCurrentFilterName('')
  }

  const handleFilterValidate = (values) => {
    const { acosMin, acosMax } = values

    if (acosMin === '' || isNaN(acosMin) || parseFloat(acosMin) < 0
      || acosMax === '' || isNaN(acosMax) || parseFloat(acosMax) < 0) {
      return 'Please enter ACoS greater than or equal to 0.'
    }

    if (parseFloat(acosMin) > parseFloat(acosMax)) {
      return 'The start range of ACoS cannot be greater than the end range.'
    }

    return null
  }

  const renderFilter = () => {
    return (
      <div className="filter-container">
        <div className="toggle-wrapper">
          <Toggle
            checked={groupMode}
            checkedChildren="Organize by campaigns"
            unCheckedChildren="By ASINs"
            onChange={setGroupMode}
          />
        </div>
        <div className="checkbox-wrapper">
          <CheckboxComponent
            label="New ASINs Only"
            checked={newAsinOnly}
            onChange={onChangeNewAsinOnly}
          />
        </div>
        <div className="button-wrapper">
          <button
            type="button"
            className="btn btn-blue"
            onClick={handleFilterRefine}
          >
            Refine Filter
          </button>
        </div>
      </div>
    )
  }

  const renderAction = () => {
    if (!selectedAsins.length) {
      return null
    }

    const targets = asins.filter(record => (
      selectedAsins.indexOf(record.target_id) !== -1
    )).map(record => record.asin)

    return (
      <>
        <button type="button" className="btn btn-green" onClick={handleCopy}>
          Copy
        </button>
        <button type="button" className="btn btn-blue" onClick={handleAddToExisting}>
          Add to Existing Campaigns
        </button>
        <Dropdown
          title="Add to New Campaign"
          placement="bottomEnd"
          toggleClassName="btn-new"
        >
          <Dropdown.Item componentClass={Link} to={{
            pathname: '/campaigns/new/sp',
            state: {
              targets,
              productTargeting: true,
            },
          }}>
            Sponsored Product Campaign
          </Dropdown.Item>
          <Dropdown.Item componentClass={Link} to={{
            pathname: '/campaigns/new/sb',
            state: {
              targets,
              productTargeting: true,
            },
          }}>
            Sponsored Brand Campaign
          </Dropdown.Item>
          <Dropdown.Item componentClass={Link} to={{
            pathname: '/campaigns/new/sd',
            state: {
              targets,
            },
          }}>
            Sponsored Display Campaign
          </Dropdown.Item>
        </Dropdown>
      </>
    )
  }

  const renderAsin = record => (
    <>
      <div className="table-col col-product" title={record.title || ''}>
        {
          typeof record.image !== 'undefined' && (
            <img
              src={record.image}
              alt={record.title || ''}
            />
          )
        }
        <span className="contents">
          { record.title || '' }
        </span>
      </div>
      <div className="table-col col-asin">
        <span className="contents">
          { record.asin }
        </span>
        <a
          href={`https://${getAmazonLink(selectedUserInfo)}/gp/product/${record.asin}`}
          target="_blank"
          rel="noopener noreferrer"
        >
          <Icon.FiExternalLink size={16} />
        </a>
      </div>
      <TableCampaignCell record={record} />
      {
        bulkNTBColumnList.map(column => (
          <TableCell
            key={column.key}
            record={record}
            columnKey={column.key}
            columnSelection={campaignTableColumns}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  // Render aggregation row.
  const renderTotal = summary => (
    <>
      <div className="table-col col-product">Totals:</div>
      <div className="table-col col-asin" />
      <div className="table-col col-campaign" />
      {
        bulkNTBColumnList.map(column => (
          <TableCell
            key={column.key}
            record={summary}
            columnKey={column.key}
            columnSelection={campaignTableColumns}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  const getExportData = (exportableColumns, record) => (
    exportableColumns.map((column) => {
      if (column.key === 'title') {
        return record.title || ''
      }
      if (column.key === 'asin') {
        return record.asin
      }
      return getExportValueForColumn(record, column.key, currencySign, currencyRate)
    })
  )

  // For grouped table.
  const renderParent = record => (
    <>
      <TableCampaignCell record={record} />
      <div className="table-col col-check" />
      <div className="table-col col-product" />
      <div className="table-col col-asin">
        { record.children.length } ASINs
      </div>
      {
        bulkNTBColumnList.map(column => (
          <TableCell
            key={column.key}
            record={record}
            columnKey={column.key}
            columnSelection={campaignTableColumns}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  const renderChild = record => (
    <>
      <div className="table-col col-product" title={record.title || ''}>
        {
          typeof record.image !== 'undefined' && (
            <img
              src={record.image}
              alt={record.title || ''}
            />
          )
        }
        <span className="contents">
          { record.title || '' }
        </span>
      </div>
      <div className="table-col col-asin">
        <span className="contents">
          { record.asin }
        </span>
        <a
          href={`https://${getAmazonLink(selectedUserInfo)}/gp/product/${record.asin}`}
          target="_blank"
          rel="noopener noreferrer"
        >
          <Icon.FiExternalLink size={16} />
        </a>
      </div>
      {
        bulkNTBColumnList.map(column => (
          <TableCell
            key={column.key}
            record={record}
            columnKey={column.key}
            columnSelection={campaignTableColumns}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  const renderTotalGroup = summary => (
    <>
      <div className="table-col col-campaign">Totals:</div>
      <div className="table-col col-check" />
      <div className="table-col col-product" />
      <div className="table-col col-asin" />
      {
        bulkNTBColumnList.map(column => (
          <TableCell
            key={column.key}
            record={summary}
            columnKey={column.key}
            columnSelection={campaignTableColumns}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  return (
    <BulkResultContainer>
      <div className="section-label">
        Select ASIN and take appropriate action
      </div>
      { renderFilter() }
      {
        groupMode ? (
          <SortableTable
            tableComponent={GroupTable}
            columns={columnsGroup}
            defaultSort={['title', 'asc']}
            sorter={tableSorter(['campaignName'])}
            className="table-grouped-asins"
            records={groupedAsins}
            idField="campaign_id"
            searchFields={['title', 'asin']}
            selectedRecords={selectedAsins}
            paginationSelectPlacement="top"
            hasSticky
            hasDateRange
            filterName={FILTER_NAME_PT_EX_ASIN}
            useFilterModal
            columnEditorId="ptExAsinResult"
            columnList={bulkNTBColumnList}
            columnSelection={campaignTableColumns}
            exportFileName={MODULE_NAME_PT_EX_ASIN}
            getExportData={getExportData}
            renderRecord={renderParent}
            renderTotal={renderTotalGroup}
            renderTopRight={renderAction}
            onChange={setSelectedAsins}
            onChangeDate={onChangeDate}
            onFilterValidate={handleFilterValidate}
            sorterChild={tableSorter(['title', 'asin'])}
            idFieldChild="target_id"
            renderChild={renderChild}
          />
        ) : (
          <SortableTable
            columns={columns}
            defaultSort={['title', 'asc']}
            sorter={tableSorter(['title', 'asin', 'campaignName'])}
            className="table-asins"
            records={asins || []}
            idField="target_id"
            searchFields={['title', 'asin']}
            selectedRecords={selectedAsins}
            paginationSelectPlacement="top"
            hasSticky
            hasDateRange
            filterName={FILTER_NAME_PT_EX_ASIN}
            useFilterModal
            columnEditorId="ptExAsinResult"
            columnList={bulkNTBColumnList}
            columnSelection={campaignTableColumns}
            exportFileName={MODULE_NAME_PT_EX_ASIN}
            getExportData={getExportData}
            renderRecord={renderAsin}
            renderTotal={renderTotal}
            renderTopRight={renderAction}
            onChange={setSelectedAsins}
            onChangeDate={onChangeDate}
            onFilterValidate={handleFilterValidate}
          />
        )
      }
      <TargetAddModal
        show={isAddModalVisible}
        targets={targetsPayload}
        forPtEx
        onClose={() => { setIsAddModalVisible(false) }}
      />
      {
        currentFilterName !== '' && (
          <TableFilterModal
            filterName={currentFilterName}
            currentModuleName={MODULE_NAME_PT_EX}
            onApply={handleFilterApply}
            onClose={() => { setCurrentFilterName('') }}
            onValidate={handleFilterValidate}
          />
        )
      }
    </BulkResultContainer>
  )
}

export default PtExAsinResult
