import React, { useState } from 'react'
import { Dropdown, Tooltip, Whisper } from 'rsuite'

import { ReactComponent as InfoSvg } from '../../assets/svg/info.svg'

import { MODULE_NAME_PT_EX_ASIN } from './PtExAsinResult'
import { MODULE_NAME_PT_EX_CATEGORY } from './PtExCategoryResult'

export const MODULE_NAME_PT_EX = 'Product Expansion'

export const SUB_MODULE_ASIN = 'asin'
const SUB_MODULE_CATEGORY = 'category'

const subModuleList = [
  {
    key: SUB_MODULE_ASIN,
    name: MODULE_NAME_PT_EX_ASIN,
    description: (
      <>
        <p>
          Our system will find related products that have generated
          the most sales for you and allow you to target them
          in a Product Targeting campaign/ad group.
        </p>
      </>
    ),
  },
  {
    key: SUB_MODULE_CATEGORY,
    name: MODULE_NAME_PT_EX_CATEGORY,
    description: (
      <>
        <p>
          Our system will find the categories related to products that have generated
          the most sales for you and allow you to target these categories
          in a Product Targeting campaign/ad group.
        </p>
      </>
    ),
  },
]

const PtExSection = ({ selectedCampaigns, onFind }) => {
  const [activeSubModule, setActiveSubModule] = useState(SUB_MODULE_ASIN)

  const handleSubModuleSelect = (module) => {
    if (activeSubModule !== module.key) {
      setActiveSubModule(module.key)
    }
  }

  const renderAction = () => {
    if (!activeSubModule) {
      return null
    }

    const label = activeSubModule === SUB_MODULE_ASIN ? 'Find ASINs' : 'Find Categories'

    return (
      <>
        <button
          type="button"
          className="btn btn-blue"
          disabled={!selectedCampaigns.length}
          onClick={() => { onFind(activeSubModule) }}
        >
          { !selectedCampaigns.length ? 'Select Campaigns to Continue' : label }
        </button>
      </>
    )
  }

  const renderTooltip = () => {
    if (!activeSubModule) {
      return null
    }

    if (activeSubModule === SUB_MODULE_ASIN) {
      return (
        <Whisper placement="right" trigger="hover" speaker={(
          <Tooltip>
            <ul>
              <li>First, determine your target ACoS %.</li>
              <li>Select the campaigns that you wish to pull ASINs from. Click "Find ASINs".</li>
              <li>
                The results will show you all products that have generated sales for you within your target ACoS.
                You may then add them to a new or existing Product Targeting campaign or ad group.
              </li>
            </ul>
          </Tooltip>
        )}>
          <InfoSvg />
        </Whisper>
      )
    }

    if (activeSubModule === SUB_MODULE_CATEGORY) {
      return (
        <Whisper placement="right" trigger="hover" speaker={(
          <Tooltip>
            <ul>
              <li>First, determine your target ACoS %.</li>
              <li>Select the campaigns that you wish to pull category information from. Click "Find Categories".</li>
              <li>
                The results will show you all categories related to products that have
                generated sales for you within your target ACoS. You may then add them
                to a new or existing Product Targeting campaign or ad group.
              </li>
            </ul>
          </Tooltip>
        )}>
          <InfoSvg />
        </Whisper>
      )
    }

    return null
  }

  let dropdownLabel = 'Select Sub Module'
  if (activeSubModule) {
    const active = subModuleList.find(module => module.key === activeSubModule)
    if (active) {
      dropdownLabel = active.name
    }
  }

  return (
    <>
      <Dropdown title={dropdownLabel}>
        {
          subModuleList.map(module => (
            <Dropdown.Item
              key={module.key}
              active={module.key === activeSubModule}
              onSelect={() => { handleSubModuleSelect(module) }}
            >
              { module.name }
              <Whisper placement="right" trigger="hover" speaker={(
                <Tooltip>
                  { module.description }
                </Tooltip>
              )}>
                <InfoSvg />
              </Whisper>
            </Dropdown.Item>
          ))
        }
      </Dropdown>
      { renderAction() }
      { renderTooltip() }
    </>
  )
}

export default PtExSection
