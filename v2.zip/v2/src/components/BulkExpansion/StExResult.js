import React, { useEffect, useState, useMemo } from 'react'
import { useStore } from 'react-redux'
import { Link } from 'react-router-dom'
import { Dropdown } from 'rsuite'
import { Tooltip, Whisper, Toggle } from 'rsuite'
import * as Icon from 'react-icons/fi'
import Select from 'react-select'

import SortableTable from '../CommonComponents/SortableTableComponent'
import GroupTable from '../CommonComponents/GroupTableComponent'
import CheckboxComponent from '../CommonComponents/CheckboxComponent'
import TableCell from '../CommonComponents/TableCell'
import TableCampaignCell from '../CommonComponents/TableCampaignCell'
import TableFilterModal from '../CommonComponents/TableFilterModal'

import { ReactComponent as InfoSvg } from '../../assets/svg/info.svg'

import BulkResultContainer from '../BulkResultContainer'
import StExSelection from './StExSelection'
import TargetAddModal from './TargetAddModal'

import {
  tableSorter,
  capitalizeFirstLetter,
  calcDerivedMetrics,
  getAmazonLink,
  getExportValueForColumn,
  groupRecords,
} from '../../services/helper'

import { bulkSTColumnList } from '../../utils/defaultValues'
import { matchTypes } from '../../utils/filterDef'

const columns = [
  { key: 'search', name: 'Search Term', className: 'col-search-term' },
  { key: 'matchType', name: 'Match Type' },
  { key: 'keywordText', name: 'Associated Target', className: 'col-keyword' },
  ...bulkSTColumnList,
]

const columnsGroup = [
  { key: 'campaignName', name: 'Campaign', className: 'col-campaign', parentOnly: true },
  { key: 'checkPlaceholder', name: '', className: 'col-check', exportable: false, parentOnly: true },
  { key: 'search', name: 'Search Term', className: 'col-search-term' },
  { key: 'matchType', name: 'Match Type' },
  { key: 'keywordText', name: 'Associated Target', className: 'col-keyword' },
  ...bulkSTColumnList,
]

const wordOptions = [
  { value: '', label: 'All' },
  { value: '1', label: '1' },
  { value: '2', label: '2' },
  { value: '3', label: '3' },
  { value: '4', label: '4' },
  { value: '5', label: '5+' },
]

export const MODULE_NAME_ST_EX = 'Search Term Expansion'
export const FILTER_NAME_ST_EX = 'stEx'

const StExResult = ({ hideKeywords, hideAsins, onChangeHideKeywords, onChangeHideAsins, onChangeDate, onApplyFilter }) => {
  const store = useStore()

  const {
    header: {
      currencyRate,
      currencySign,
      selectedUserInfo,
    },
    pageGlobal: {
      campaignTableColumns,
      stTableColumns,
      filterValues,
    },
    campaign: {
      campaignsWithHistory,
    },
    bulkEngine: {
      findStsData,
    },
  } = store.getState()

  const [groupMode, setGroupMode] = useState(false)
  const [searchTerms, setSearchTerms] = useState([])
  const [groupedSearchTerms, setGroupedSearchTerms] = useState([])
  const [selectedSearchTerms, setSelectedSearchTerms] = useState([])
  const [stSelection, setStSelection] = useState([])
  const [isAddModalVisible, setIsAddModalVisible] = useState(false)
  const [targetsPayload, setTargetsPayload] = useState([])
  const [selectedWord, setSelectedWord] = useState(wordOptions[0])
  const [selectedMatchType, setSelectedMatchType] = useState(matchTypes[0])
  const [currentFilterName, setCurrentFilterName] = useState('')
  const [origFilters, setOrigFilters] = useState({})

  // Filter found search terms.
  useEffect(() => {
    if (!findStsData || !findStsData.length) {
      return
    }

    const campaignNamesById = {}
    const campaignTypesById = {}
    const targetingTypesById = {}
    campaignsWithHistory.forEach((campaign) => {
      campaignNamesById[campaign.campaign_id] = campaign.campaign
      campaignTypesById[campaign.campaign_id] = campaign.campaignType
      targetingTypesById[campaign.campaign_id] = campaign.targeting_type
    })

    const filteredSTs = []

    findStsData.forEach((record) => {
      // Remove ASINs.
      if (hideAsins && (/^[0-9a-z]{10}$/ig.test(record.search))) {
        return
      }

      if (selectedWord.value !== '') {
        const wordCount = parseInt(selectedWord.value, 10)
        if (wordCount !== 5) {
          if (record.search.split(/\s+/).length !== wordCount) {
            return
          }
        } else if (record.search.split(/\s+/).length < wordCount) {
          return
        }
      }

      if (selectedMatchType.value !== ''
        && (record.match_type || '').toLowerCase() !== selectedMatchType.value) {
        return
      }

      filteredSTs.push({
        ...calcDerivedMetrics(record),
        matchType: capitalizeFirstLetter(record.match_type),
        campaignName: campaignNamesById[record.campaign_id] || '',
        campaignType: campaignTypesById[record.campaign_id] || '',
        targetingType: targetingTypesById[record.campaign_id] || '',
        keywordText: (record.keyword === '(_targeting_auto_)'
          || record.keyword === '(_targeting_auto_, 1)') ? '*' : record.keyword,
      })
    })

    setSearchTerms(filteredSTs)
    setGroupedSearchTerms(
      groupRecords(
        filteredSTs,
        'campaign_id',
        ['campaignName', 'campaignType', 'targetingType']
      )
    )
  }, [findStsData, campaignsWithHistory, hideAsins, selectedWord, selectedMatchType])

  const columnSelection = useMemo(() => {
    const selection = [...campaignTableColumns]
    if ((stTableColumns || []).includes('st_impr_rank')) {
      selection.push('st_impr_rank')
    }
    if ((stTableColumns || []).includes('st_impr_share')) {
      selection.push('st_impr_share')
    }
    return selection
  }, [campaignTableColumns, stTableColumns])

  const handleCopy = () => {
    const existingSts = stSelection.map(record => record.search)

    const newSts = searchTerms.filter(record => (
      selectedSearchTerms.indexOf(record.id) !== -1
      && existingSts.indexOf(record.search) === -1
    )).map(record => ({
      search: record.search,
    }))

    setStSelection([
      ...stSelection,
      ...newSts,
    ])
  }

  const handleAddToExisting = (sts) => {
    if (typeof sts === 'undefined') {
      setTargetsPayload(searchTerms.filter(record => (
        selectedSearchTerms.indexOf(record.id) !== -1
      )).map(record => ({
        target: record.search.trim(),
        cpc: record.cpc,
      })))
    } else {
      // From copied search terms section.
      setTargetsPayload(sts.map(record => ({
        target: record,
      })))
    }
    setIsAddModalVisible(true)
  }

  const handleFilterRefine = () => {
    setCurrentFilterName(FILTER_NAME_ST_EX)
    setOrigFilters((filterValues || {})[FILTER_NAME_ST_EX] || {})
  }

  const handleFilterApply = (values) => {
    // When acos values are changed, call API again.
    if (parseFloat(values.acosMin || 0) !== parseFloat(origFilters.acosMin || 0)
      || parseFloat(values.acosMax || 0) !== parseFloat(origFilters.acosMax || 0)) {
      onApplyFilter(values)
    }
    setCurrentFilterName('')
  }

  const handleFilterValidate = (values) => {
    const { acosMin, acosMax } = values

    if (acosMin === '' || isNaN(acosMin) || parseFloat(acosMin) < 0
      || acosMax === '' || isNaN(acosMax) || parseFloat(acosMax) < 0) {
      return 'Please enter ACoS greater than or equal to 0.'
    }

    if (parseFloat(acosMin) > parseFloat(acosMax)) {
      return 'The start range of ACoS cannot be greater than the end range.'
    }

    return null
  }

  const renderFilter = () => {
    return (
      <div className="filter-container">
        <div className="toggle-wrapper">
          <Toggle
            checked={groupMode}
            checkedChildren="Organize by campaigns"
            unCheckedChildren="By search terms"
            onChange={setGroupMode}
          />
        </div>
        <div className="checkbox-wrapper">
          <CheckboxComponent
            label="Remove Keywords"
            checked={hideKeywords}
            onChange={onChangeHideKeywords}
          />
          <Whisper placement="right" trigger="hover" speaker={(
            <Tooltip>
              <p>Sometimes a keyword and search term are the same
              (ex: Exact match types), many times they are not.</p>
              <p>Checking this box means that only search terms that are not yet keywords will be revealed.
              You can turn these new-found search terms into keywords by adding them to campaigns.</p>
            </Tooltip>
          )}>
            <InfoSvg />
          </Whisper>
        </div>
        <div className="checkbox-wrapper">
          <CheckboxComponent
            label="Remove ASINS"
            checked={hideAsins}
            onChange={onChangeHideAsins}
          />
        </div>
        <div className="select-wrapper">
          <span>Word Count</span>
          <Select
            classNamePrefix="word-count-selector"
            options={wordOptions}
            value={selectedWord}
            onChange={setSelectedWord}
          />
        </div>
        <div className="select-wrapper">
          <span>Match Type</span>
          <Select
            classNamePrefix="match-type-selector"
            options={matchTypes}
            value={selectedMatchType}
            onChange={setSelectedMatchType}
          />
        </div>
        <div className="button-wrapper">
          <button
            type="button"
            className="btn btn-blue"
            onClick={handleFilterRefine}
          >
            Refine Filter
          </button>
        </div>
      </div>
    )
  }

  const renderAction = () => {
    if (!selectedSearchTerms.length) {
      return null
    }

    const targets = searchTerms.filter(record => (
      selectedSearchTerms.indexOf(record.id) !== -1
    )).map(record => record.search.trim())

    return (
      <>
        <button type="button" className="btn btn-light-blue" onClick={handleCopy}>
          Copy to List Below
        </button>
        <button type="button" className="btn btn-blue" onClick={() => { handleAddToExisting() }}>
          Add to Existing Campaigns
        </button>
        <Dropdown
          title="Add to New Campaign"
          placement="bottomEnd"
          toggleClassName="btn-new"
        >
          <Dropdown.Item componentClass={Link} to={{
            pathname: '/campaigns/new/sp',
            state: {
              targets,
            },
          }}>
            Sponsored Product Campaign
          </Dropdown.Item>
          <Dropdown.Item componentClass={Link} to={{
            pathname: '/campaigns/new/sb',
            state: {
              targets,
            },
          }}>
            Sponsored Brand Campaign
          </Dropdown.Item>
        </Dropdown>
      </>
    )
  }

  const renderST = record => (
    <>
      <div className="table-col col-search-term" title={record.search}>
        <strong>{ record.search }</strong>
        <a
          href={`https://${getAmazonLink(selectedUserInfo)}/s/ref=nb_sb_noss?url=search-alias%3Daps&field-keywords=${record.search}`}
          target="_blank"
          rel="noopener noreferrer"
        >
          <Icon.FiExternalLink size={16} />
        </a>
      </div>
      <div className="table-col">
        { record.matchType }
      </div>
      <div className="table-col col-keyword" title={record.keywordText}>
        <span className="contents">
          { record.keywordText }
        </span>
      </div>
      {
        bulkSTColumnList.map(column => (
          <TableCell
            key={column.key}
            record={record}
            columnKey={column.key}
            columnSelection={columnSelection}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  // Render aggregation row.
  const renderTotal = summary => (
    <>
      <div className="table-col col-search-term">Totals:</div>
      <div className="table-col" />
      <div className="table-col col-keyword" />
      {
        bulkSTColumnList.map(column => (
          <TableCell
            key={column.key}
            record={summary}
            columnKey={column.key}
            columnSelection={columnSelection}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  const getExportData = (exportableColumns, record) => (
    exportableColumns.map((column) => {
      if (column.key === 'search') {
        return record.search
      }
      if (column.key === 'matchType') {
        return record.matchType
      }
      if (column.key === 'keywordText') {
        return record.keywordText
      }
      return getExportValueForColumn(record, column.key, currencySign, currencyRate)
    })
  )

  // For grouped table.
  const renderParent = record => (
    <>
      <TableCampaignCell record={record} />
      <div className="table-col col-check" />
      <div className="table-col col-search-term">
        { record.children.length } search terms
      </div>
      <div className="table-col" />
      <div className="table-col col-keyword" />
      {
        bulkSTColumnList.map(column => (
          <TableCell
            key={column.key}
            record={record}
            columnKey={column.key}
            columnSelection={columnSelection}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  const renderChild = record => (
    <>
      <div className="table-col col-search-term" title={record.search}>
        <strong>{ record.search }</strong>
        <a
          href={`https://${getAmazonLink(selectedUserInfo)}/s/ref=nb_sb_noss?url=search-alias%3Daps&field-keywords=${record.search}`}
          target="_blank"
          rel="noopener noreferrer"
        >
          <Icon.FiExternalLink size={16} />
        </a>
      </div>
      <div className="table-col">
        { record.matchType }
      </div>
      <div className="table-col col-keyword" title={record.keywordText}>
        <span className="contents">
          { record.keywordText }
        </span>
      </div>
      {
        bulkSTColumnList.map(column => (
          <TableCell
            key={column.key}
            record={record}
            columnKey={column.key}
            columnSelection={columnSelection}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  const renderTotalGroup = summary => (
    <>
      <div className="table-col col-campaign">Totals:</div>
      <div className="table-col col-check" />
      <div className="table-col col-search-term" />
      <div className="table-col" />
      <div className="table-col col-keyword" />
      {
        bulkSTColumnList.map(column => (
          <TableCell
            key={column.key}
            record={summary}
            columnKey={column.key}
            columnSelection={columnSelection}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  return (
    <BulkResultContainer>
      <div className="section-label">
        Select search term and take appropriate action
      </div>
      { renderFilter() }
      {
        groupMode ? (
          <SortableTable
            tableComponent={GroupTable}
            columns={columnsGroup}
            defaultSort={['cost', 'desc']}
            sorter={tableSorter(['campaignName'])}
            className="table-grouped-search-terms"
            records={groupedSearchTerms}
            idField="campaign_id"
            searchFields={['search']}
            selectedRecords={selectedSearchTerms}
            paginationSelectPlacement="top"
            hasSticky
            hasDateRange
            filterName={FILTER_NAME_ST_EX}
            useFilterModal
            columnEditorId="stExResult"
            columnList={bulkSTColumnList}
            columnSelection={columnSelection}
            exportFileName={MODULE_NAME_ST_EX}
            getExportData={getExportData}
            renderRecord={renderParent}
            renderTotal={renderTotalGroup}
            renderTopRight={renderAction}
            onChange={setSelectedSearchTerms}
            onChangeDate={onChangeDate}
            onFilterValidate={handleFilterValidate}
            sorterChild={tableSorter(['search', 'matchType', 'keywordText'])}
            idFieldChild="id"
            renderChild={renderChild}
          />
        ) : (
          <SortableTable
            columns={columns}
            defaultSort={['cost', 'desc']}
            sorter={tableSorter(['search', 'matchType', 'keywordText'])}
            className="table-search-terms"
            records={searchTerms || []}
            idField="id"
            searchFields={['search']}
            selectedRecords={selectedSearchTerms}
            paginationSelectPlacement="top"
            hasSticky
            hasDateRange
            filterName={FILTER_NAME_ST_EX}
            useFilterModal
            columnEditorId="stExResult"
            columnList={bulkSTColumnList}
            columnSelection={columnSelection}
            exportFileName={MODULE_NAME_ST_EX}
            getExportData={getExportData}
            renderRecord={renderST}
            renderTotal={renderTotal}
            renderTopRight={renderAction}
            onChange={setSelectedSearchTerms}
            onChangeDate={onChangeDate}
            onFilterValidate={handleFilterValidate}
          />
        )
      }
      <StExSelection
        searchTerms={stSelection}
        onChange={setStSelection}
        onAddToExisting={handleAddToExisting}
      />
      <TargetAddModal
        show={isAddModalVisible}
        targets={targetsPayload}
        forStEx
        onClose={() => { setIsAddModalVisible(false) }}
      />
      {
        currentFilterName !== '' && (
          <TableFilterModal
            filterName={currentFilterName}
            currentModuleName={MODULE_NAME_ST_EX}
            onApply={handleFilterApply}
            onClose={() => { setCurrentFilterName('') }}
            onValidate={handleFilterValidate}
          />
        )
      }
    </BulkResultContainer>
  )
}

export default StExResult
