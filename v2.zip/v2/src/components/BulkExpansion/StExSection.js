import React from 'react'
import { Tooltip, Whisper } from 'rsuite'

import { ReactComponent as InfoSvg } from '../../assets/svg/info.svg'

const StExSection = ({ selectedCampaigns, onFind }) => {
  return (
    <>
      <button
        type="button"
        className="btn btn-blue"
        disabled={!selectedCampaigns.length}
        onClick={() => { onFind() }}
      >
        { !selectedCampaigns.length ? 'Select Campaigns to Continue' : 'Find Search Terms' }
      </button>
      <Whisper placement="right" trigger="hover" speaker={(
        <Tooltip>
          <ul>
            <li>Home of The ACoS SCRAPING TECHNIQUE</li>
            <li>First, enter your target ACoS %.</li>
            <li>Select the campaigns that you wish to pull Search Terms from. Click "Find Search Terms".</li>
            <li>
              The results will appear below, showing you the search terms within
              your target ACoS that connected to your keywords/targets
              in the campaigns selected.
              You can sort these in a variety of ways.
            </li>
            <li>
              By default, only search terms that do not yet exist as keywords/targets
              in the campaigns selected will be displayed. To show all search terms
              instead of only new search terms, uncheck the "New Keywords/Targets Only" box.
            </li>
            <li>Consider adding these to a new campaign or ACoS Scraping ad group to get more exposure to your listing!</li>
            <li>Check weekly to find new opportunities.</li>
          </ul>
        </Tooltip>
      )}>
        <InfoSvg />
      </Whisper>
    </>
  )
}

export default StExSection
