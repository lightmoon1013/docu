/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useState, useEffect } from 'react'
import { useDispatch, useStore } from 'react-redux'
import { Dropdown, Tooltip, Whisper } from 'rsuite'

import LoaderComponent from '../CommonComponents/LoaderComponent'
import TableFilterModal from '../CommonComponents/TableFilterModal'
import VideoLink from '../CommonComponents/VideoLink'
import CampaignTableComponent from '../CampaignTableComponent'

import { ReactComponent as InfoSvg } from '../../assets/svg/info.svg'

import TargetExSection from './TargetExSection'
import TargetExResult, { MODULE_NAME_TARGET_EX } from './TargetExResult'
import StExSection from './StExSection'
import StExResult, { MODULE_NAME_ST_EX, FILTER_NAME_ST_EX } from './StExResult'
import PtExSection, { SUB_MODULE_ASIN, MODULE_NAME_PT_EX } from './PtExSection'
import PtExAsinResult, { FILTER_NAME_PT_EX_ASIN } from './PtExAsinResult'
import PtExCategoryResult, { FILTER_NAME_PT_EX_CATEGORY } from './PtExCategoryResult'

import {
  findNewTargets,
  findSts,
  findPts,
} from '../../redux/actions/bulkEngine'

import { applyFilter } from '../../redux/actions/pageGlobal'

const MODULE_TARGET_EX = 'target_ex'
const MODULE_ST_EX = 'st_ex'
const MODULE_PT_EX = 'pt_ex'

const moduleList = [
  {
    key: MODULE_TARGET_EX,
    name: MODULE_NAME_TARGET_EX,
    description: (
      <>
        <p>Enter in a list of targets to see if you are already targeting them in any campaigns.</p>
      </>
    ),
  },
  {
    key: MODULE_ST_EX,
    name: MODULE_NAME_ST_EX,
    description: (
      <>
        <p>Our system will quickly find your best search terms and convert them into new keywords/targets.</p>
      </>
    ),
  },
  {
    key: MODULE_PT_EX,
    name: MODULE_NAME_PT_EX,
    description: (
      <>
        <p>Finds ASINS and Categories that have converted so you can expand.</p>
      </>
    ),
  },
]

export const tutorialList = {
  '': {
    title: 'Bulk Engine Overview',
    videoList: [
      { title: 'Bulk Engine Overview', url: 'https://www.loom.com/embed/8aade68f957449d5ab685182612c39ad' },
    ],
  },
  [MODULE_TARGET_EX]: {
    title: MODULE_NAME_TARGET_EX,
    videoList: [
      { title: MODULE_NAME_TARGET_EX, url: 'https://www.loom.com/embed/276758843ca34bec9392af01d8485e75' },
    ],
  },
  [MODULE_ST_EX]: {
    title: MODULE_NAME_ST_EX,
    videoList: [
      { title: MODULE_NAME_ST_EX, url: 'https://www.loom.com/embed/fed58c4c440d4b82869250e4761ac044' },
    ],
  },
  [MODULE_PT_EX]: {
    title: MODULE_NAME_PT_EX,
    videoList: [
      { title: MODULE_NAME_PT_EX, url: 'https://www.loom.com/embed/fed58c4c440d4b82869250e4761ac044' },
    ],
  },
}

const DEFAULT_ACOS_MIN = 0.1
const DEFAULT_ACOS_MAX = 40

const BulkExpansion = () => {
  const dispatch = useDispatch()
  const store = useStore().getState()

  const {
    pageGlobal: {
      filterValues,
    },
    header: {
      currentUserId,
      currentStartDate,
      currentEndDate,
    },
    bulkEngine: {
      isFindingNewTargets,
      isFindingSts,
      isFindingPts,
    },
  } = store

  const [activeModule, setActiveModule] = useState('')
  const [activeTypeTarget, setActiveTypeTarget] = useState(SUB_MODULE_ASIN)
  const [selectedCampaigns, setSelectedCampaigns] = useState([])
  // For ST ex.
  const [hideKeywords, setHideKeywords] = useState(true)
  const [hideAsins, setHideAsins] = useState(true)
  // For PT ex.
  const [newAsinOnly, setNewAsinOnly] = useState(true)
  const [currentFilterName, setCurrentFilterName] = useState('')
  const [hasResults, setHasResults] = useState(false)
  const [isCampaignsExpanded, setIsCampaignsExpanded] = useState(false)

  useEffect(() => {
    setSelectedCampaigns([])
    setCurrentFilterName('')
    setHasResults(false)
    setIsCampaignsExpanded(false)
  }, [currentUserId])

  const handleModuleSelect = (module) => {
    if (activeModule !== module.key) {
      setHasResults(false)
      setActiveModule(module.key)
    }
  }

  const handleFindTargets = (targets) => {
    setHasResults(false)
    dispatch(findNewTargets(
      selectedCampaigns.map(campaign => campaign.campaign_id),
      targets
    )).then(() => {
      setHasResults(true)
      setIsCampaignsExpanded(false)
    })
  }

  const doFindSts = (startDate, endDate, stOnly, filterValues) => {
    let values
    if (filterValues) {
      values = filterValues
    } else {
      values = (filterValues || {})[FILTER_NAME_ST_EX] || {}
    }
    return dispatch(findSts(
      selectedCampaigns.map(campaign => campaign.campaign_id),
      startDate,
      endDate,
      values['acosMin'],
      values['acosMax'],
      stOnly
    ))
  }

  const handleStDateChange = (startDate, endDate) => {
    doFindSts(startDate, endDate, hideKeywords)
  }

  const handleFindSts = () => {
    // Update filter values in results section.
    const values = { ...((filterValues || {})[FILTER_NAME_ST_EX] || {}) }
    values['acosMin'] = DEFAULT_ACOS_MIN
    values['acosMax'] = DEFAULT_ACOS_MAX
    dispatch(applyFilter(FILTER_NAME_ST_EX, values))

    setCurrentFilterName(FILTER_NAME_ST_EX)
  }

  // Handle toggling 'Remove Keywords' checkbox for ST Ex.
  const handleChangeHideKeywords = (checked) => {
    setHideKeywords(checked)
    setHasResults(false)
    doFindSts(currentStartDate, currentEndDate, checked).then(() => {
      setHasResults(true)
      setIsCampaignsExpanded(false)
    })
  }

  const doFindPts = (typeTarget, newAsinOnlyValue, startDate, endDate, filterValues) => {
    let values
    if (filterValues) {
      values = filterValues
    } else {
      if (typeTarget === SUB_MODULE_ASIN) {
        values = (filterValues || {})[FILTER_NAME_PT_EX_ASIN] || {}
      } else {
        values = (filterValues || {})[FILTER_NAME_PT_EX_CATEGORY] || {}
      }
    }

    return dispatch(findPts(
      selectedCampaigns.map(campaign => campaign.campaign_id),
      startDate,
      endDate,
      values['acosMin'],
      values['acosMax'],
      typeTarget,
      newAsinOnlyValue,
    ))
  }

  const handleFindPts = (typeTarget) => {
    setActiveTypeTarget(typeTarget)
    if (typeTarget === SUB_MODULE_ASIN) {
      // Update filter values in results section.
      const valuesAsin = { ...((filterValues || {})[FILTER_NAME_PT_EX_ASIN] || {}) }
      valuesAsin['acosMin'] = DEFAULT_ACOS_MIN
      valuesAsin['acosMax'] = DEFAULT_ACOS_MAX
      dispatch(applyFilter(FILTER_NAME_PT_EX_ASIN, valuesAsin))

      setCurrentFilterName(FILTER_NAME_PT_EX_ASIN)
    } else {
      // Update filter values in results section.
      const valuesCategory = { ...((filterValues || {})[FILTER_NAME_PT_EX_CATEGORY] || {}) }
      valuesCategory['acosMin'] = DEFAULT_ACOS_MIN
      valuesCategory['acosMax'] = DEFAULT_ACOS_MAX
      dispatch(applyFilter(FILTER_NAME_PT_EX_CATEGORY, valuesCategory))

      setCurrentFilterName(FILTER_NAME_PT_EX_CATEGORY)
    }
  }

  const handlePtDateChange = (startDate, endDate) => {
    doFindPts(activeTypeTarget, newAsinOnly, startDate, endDate)
  }

  // Handle toggling 'New ASIN only' checkbox for PT Ex.
  const handleChangeNewAsinOnly = (checked) => {
    setNewAsinOnly(checked)
    setActiveTypeTarget(SUB_MODULE_ASIN)
    setHasResults(false)
    doFindPts(SUB_MODULE_ASIN, checked, currentStartDate, currentEndDate).then(() => {
      setHasResults(true)
      setIsCampaignsExpanded(false)
    })
  }

  const handleFilterApply = (values) => {
    setCurrentFilterName('')
    setHasResults(false)
    if (activeModule === MODULE_ST_EX) {
      doFindSts(currentStartDate, currentEndDate, hideKeywords, values).then(() => {
        setHasResults(true)
        setIsCampaignsExpanded(false)
      })
    } else if (activeModule === MODULE_PT_EX) {
      doFindPts(activeTypeTarget, newAsinOnly, currentStartDate, currentEndDate, values).then(() => {
        setHasResults(true)
        setIsCampaignsExpanded(false)
      })
    }
  }

  const handleFilterValidate = (values) => {
    const { acosMin, acosMax } = values

    if (acosMin === '' || isNaN(acosMin) || parseFloat(acosMin) < 0
      || acosMax === '' || isNaN(acosMax) || parseFloat(acosMax) < 0) {
      return 'Please enter ACoS greater than or equal to 0.'
    }

    if (parseFloat(acosMin) > parseFloat(acosMax)) {
      return 'The start range of ACoS cannot be greater than the end range.'
    }

    return null
  }

  const renderTopSection = () => {
    if (hasResults && !isCampaignsExpanded) {
      return null
    }

    if (activeModule === MODULE_TARGET_EX) {
      return (
        <TargetExSection
          selectedCampaigns={selectedCampaigns}
          onFind={handleFindTargets}
        />
      )
    }

    if (activeModule === MODULE_ST_EX) {
      return (
        <StExSection
          selectedCampaigns={selectedCampaigns}
          onFind={handleFindSts}
        />
      )
    }

    if (activeModule === MODULE_PT_EX) {
      return (
        <PtExSection
          selectedCampaigns={selectedCampaigns}
          onFind={handleFindPts}
        />
      )
    }

    return null
  }

  const renderModuleSelector = (dropdownLabel) => {
    return (
      <div className="module-selector-container">
        <div className="module-selector-left">
          <Dropdown title={dropdownLabel}>
            {
              moduleList.map(module => (
                <Dropdown.Item
                  key={module.key}
                  active={module.key === activeModule}
                  onSelect={() => { handleModuleSelect(module) }}
                >
                  { module.name }
                  {
                    typeof module.description !== 'undefined' && (
                      <Whisper placement="right" trigger="hover" speaker={(
                        <Tooltip>
                          { module.description }
                        </Tooltip>
                      )}>
                        <InfoSvg />
                      </Whisper>
                    )
                  }
                </Dropdown.Item>
              ))
            }
          </Dropdown>
          { renderTopSection() }
        </div>
        <VideoLink
          modalTitle={tutorialList[activeModule].title}
          videoList={tutorialList[activeModule].videoList}
        />
      </div>
    )
  }

  const renderCampaignSelection = () => {
    if (hasResults && !isCampaignsExpanded) {
     return (
       <div className="campaign-seletion-state">
         <strong>{ selectedCampaigns.length }</strong> campaigns selected.
         <a
           href="#"
           onClick={(event) => { event.preventDefault(); setIsCampaignsExpanded(true) }}
         >
           Change
         </a>
       </div>
     )
   }
   return null
  }

  const renderResults = () => {
    if (!hasResults) {
      return null
    }

    if (activeModule === MODULE_TARGET_EX) {
      return <TargetExResult />
    }
    if (activeModule === MODULE_ST_EX) {
      return (
        <StExResult
          hideKeywords={hideKeywords}
          hideAsins={hideAsins}
          onChangeHideKeywords={handleChangeHideKeywords}
          onChangeHideAsins={setHideAsins}
          onChangeDate={handleStDateChange}
          onApplyFilter={(values) => { doFindSts(currentStartDate, currentEndDate, hideKeywords, values) }}
        />
      )
    }
    if (activeModule === MODULE_PT_EX) {
      if (activeTypeTarget === SUB_MODULE_ASIN) {
        return (
          <PtExAsinResult
            newAsinOnly={newAsinOnly}
            onChangeNewAsinOnly={handleChangeNewAsinOnly}
            onChangeDate={handlePtDateChange}
            onApplyFilter={(values) => { doFindPts(activeTypeTarget, newAsinOnly, currentStartDate, currentEndDate, values) }}
          />
        )
      }
      return (
        <PtExCategoryResult
          onChangeDate={handlePtDateChange}
          onApplyFilter={(values) => { doFindPts(activeTypeTarget, newAsinOnly, currentStartDate, currentEndDate, values) }}
        />
      )
    }
    return null
  }

  let dropdownLabel = 'Choose Module'
  if (activeModule) {
    const active = moduleList.find(module => module.key === activeModule)
    if (active) {
      dropdownLabel = active.name
    }
  }

  const isLoading = isFindingNewTargets || isFindingSts || isFindingPts

  return (
    <div className={`bulk-engine-container bulk-expansion-container${isLoading ? ' loading' : ''}`}>
      { isLoading && <LoaderComponent /> }
      <div className="module-description">
        Choose Module, Select Campaigns, Refine Filters and Go!
      </div>
      { renderModuleSelector(dropdownLabel) }
      { renderCampaignSelection() }
      <CampaignTableComponent
        className={hasResults && !isCampaignsExpanded ? 'hidden' : ''}
        fromBulkEngine
        customCallbacks={{
          onSelectCampaigns: setSelectedCampaigns,
        }}
      />
      { renderResults() }
      {
        currentFilterName !== '' && (
          <TableFilterModal
            filterName={currentFilterName}
            currentModuleName={dropdownLabel}
            onApply={handleFilterApply}
            onClose={() => { setCurrentFilterName('') }}
            onValidate={handleFilterValidate}
          />
        )
      }
    </div>
  )
}

export default BulkExpansion
