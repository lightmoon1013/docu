import React, { useEffect, useState } from 'react'
import { useStore } from 'react-redux'
import { Link } from 'react-router-dom'
import { Dropdown } from 'rsuite'
import { Tooltip, Whisper } from 'rsuite'
import * as Icon from 'react-icons/fi'

import SortableTable from '../CommonComponents/SortableTableComponent'
import { toast } from '../CommonComponents/ToastComponent/toast'
import TableCell from '../CommonComponents/TableCell'
import TableFilterModal from '../CommonComponents/TableFilterModal'

import { ReactComponent as InfoSvg } from '../../assets/svg/info.svg'

import BulkResultContainer from '../BulkResultContainer'
import { MODULE_NAME_PT_EX } from './PtExSection'
import TargetAddModal from './TargetAddModal'

import {
  tableSorter,
  copyToClipboard,
  calcDerivedMetrics,
  getAmazonLink,
  getExportValueForColumn,
} from '../../services/helper'

import { bulkNTBColumnList } from '../../utils/defaultValues'

const columns = [
  { key: 'name', name: 'Category', className: 'col-category' },
  { key: 'associated', name: 'Associated ASINs', className: 'col-asin' },
  ...bulkNTBColumnList,
]

export const MODULE_NAME_PT_EX_CATEGORY = 'Category Expansion'
export const FILTER_NAME_PT_EX_CATEGORY = 'ptExCategory'

const PtExCategoryResult = ({ onChangeDate, onApplyFilter }) => {
  const store = useStore()

  const {
    header: {
      currencyRate,
      currencySign,
      selectedUserInfo,
    },
    pageGlobal: {
      campaignTableColumns,
      filterValues,
    },
    bulkEngine: {
      findPtsData,
    },
  } = store.getState()

  const [categories, setCategories] = useState([])
  const [selectedCategories, setSelectedCategories] = useState([])
  const [isAddModalVisible, setIsAddModalVisible] = useState(false)
  const [targetsPayload, setTargetsPayload] = useState([])
  const [currentFilterName, setCurrentFilterName] = useState('')
  const [origFilters, setOrigFilters] = useState({})

  // Filter found search terms.
  useEffect(() => {
    if (!findPtsData || !findPtsData.length) {
      return
    }

    setCategories(findPtsData.map(record => ({
      ...calcDerivedMetrics(record),
      associated: record.asins ? record.asins.length : 0,
    })))
  }, [findPtsData]) // eslint-disable-line

  const handleCopy = () => {
    const categoryList = categories.filter(record => (
      selectedCategories.indexOf(record.id) !== -1
    )).map(record => record.name)

    copyToClipboard([...new Set(categoryList)].join('\n'))

    toast.show({
      title: 'Success',
      description: `Successfully copied ${categoryList.length} ${categoryList.length > 1 ? 'categories' : 'category'}.`
    })
  }

  const handleAddToExisting = () => {
    setTargetsPayload(categories.filter(record => (
      selectedCategories.indexOf(record.id) !== -1
    )).map(record => ({
      id: record.id,
      target: record.name,
      cpc: record.cpc,
    })))
    setIsAddModalVisible(true)
  }

  const handleFilterRefine = () => {
    setCurrentFilterName(FILTER_NAME_PT_EX_CATEGORY)
    setOrigFilters((filterValues || {})[FILTER_NAME_PT_EX_CATEGORY] || {})
  }

  const handleFilterApply = (values) => {
    // When acos values are changed, call API again.
    if (parseFloat(values.acosMin || 0) !== parseFloat(origFilters.acosMin || 0)
      || parseFloat(values.acosMax || 0) !== parseFloat(origFilters.acosMax || 0)) {
      onApplyFilter(values)
    }
    setCurrentFilterName('')
  }

  const handleFilterValidate = (values) => {
    const { acosMin, acosMax } = values

    if (acosMin === '' || isNaN(acosMin) || parseFloat(acosMin) < 0
      || acosMax === '' || isNaN(acosMax) || parseFloat(acosMax) < 0) {
      return 'Please enter ACoS greater than or equal to 0.'
    }

    if (parseFloat(acosMin) > parseFloat(acosMax)) {
      return 'The start range of ACoS cannot be greater than the end range.'
    }

    return null
  }

  const renderFilter = () => {
    return (
      <div className="filter-container">
        <div className="button-wrapper">
          <button
            type="button"
            className="btn btn-blue"
            onClick={handleFilterRefine}
          >
            Refine Filter
          </button>
        </div>
      </div>
    )
  }

  const renderAction = () => {
    if (!selectedCategories.length) {
      return null
    }

    const selection = categories.filter(record => (
      selectedCategories.indexOf(record.id) !== -1
    )).map(record => ({
      id: record.id,
      name: record.name,
      path: record.path,
      parent: record.parent,
    }))

    return (
      <>
        <button type="button" className="btn btn-green" onClick={handleCopy}>
          Copy
        </button>
        <button type="button" className="btn btn-blue" onClick={handleAddToExisting}>
          Add to Existing Campaigns
        </button>
        <Dropdown
          title="Add to New Campaign"
          placement="bottomEnd"
          toggleClassName="btn-new"
        >
          <Dropdown.Item componentClass={Link} to={{
            pathname: '/campaigns/new/sp',
            state: {
              categories: selection,
              productTargeting: true,
            },
          }}>
            Sponsored Product Campaign
          </Dropdown.Item>
          <Dropdown.Item componentClass={Link} to={{
            pathname: '/campaigns/new/sb',
            state: {
              categories: selection,
              productTargeting: true,
            },
          }}>
            Sponsored Brand Campaign
          </Dropdown.Item>
          <Dropdown.Item componentClass={Link} to={{
            pathname: '/campaigns/new/sd',
            state: {
              categories: selection,
            },
          }}>
            Sponsored Display Campaign
          </Dropdown.Item>
        </Dropdown>
      </>
    )
  }

  const renderCategory = record => (
    <>
      <div className="table-col col-category" title={record.name || ''}>
        { record.name || '' }
        <a
          href={`https://${getAmazonLink(selectedUserInfo)}/b?node=${record.id}`}
          target="_blank"
          rel="noopener noreferrer"
        >
          <Icon.FiExternalLink size={16} />
        </a>
      </div>
      <div className="table-col col-asin">
        { record.associated }
        {
          record.associated > 0 && (
            <Whisper placement="right" trigger="hover" speaker={(
              <Tooltip>
                <ul>
                  {
                    record.asins.map(asin => (
                      <li key={asin}>{asin}</li>
                    ))
                  }
                </ul>
              </Tooltip>
            )}>
              <InfoSvg />
            </Whisper>
          )
        }
      </div>
      {
        bulkNTBColumnList.map(column => (
          <TableCell
            key={column.key}
            record={record}
            columnKey={column.key}
            columnSelection={campaignTableColumns}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  // Render aggregation row.
  const renderTotal = summary => (
    <>
      <div className="table-col col-category">Totals:</div>
      <div className="table-col col-asin" />
      {
        bulkNTBColumnList.map(column => (
          <TableCell
            key={column.key}
            record={summary}
            columnKey={column.key}
            columnSelection={campaignTableColumns}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  const getExportData = (exportableColumns, record) => (
    exportableColumns.map((column) => {
      if (column.key === 'name') {
        return record.name || ''
      }
      if (column.key === 'associated') {
        return record.associated
      }
      return getExportValueForColumn(record, column.key, currencySign, currencyRate)
    })
  )

  return (
    <BulkResultContainer>
      <div className="section-label">
        Select category and take appropriate action
      </div>
      { renderFilter() }
      <SortableTable
        columns={columns}
        defaultSort={['name', 'asc']}
        sorter={tableSorter(['name'])}
        className="table-categories"
        records={categories}
        idField="id"
        searchFields={['name']}
        selectedRecords={selectedCategories}
        paginationSelectPlacement="top"
        hasSticky
        hasDateRange
        filterName={FILTER_NAME_PT_EX_CATEGORY}
        useFilterModal
        columnEditorId="ptExCategoryResult"
        columnList={bulkNTBColumnList}
        columnSelection={campaignTableColumns}
        exportFileName={MODULE_NAME_PT_EX_CATEGORY}
        getExportData={getExportData}
        renderRecord={renderCategory}
        renderTotal={renderTotal}
        renderTopRight={renderAction}
        onChange={setSelectedCategories}
        onChangeDate={onChangeDate}
        onFilterValidate={handleFilterValidate}
      />
      <TargetAddModal
        show={isAddModalVisible}
        targets={targetsPayload}
        forPtEx
        forCategory
        onClose={() => { setIsAddModalVisible(false) }}
      />
      {
        currentFilterName !== '' && (
          <TableFilterModal
            filterName={currentFilterName}
            currentModuleName={MODULE_NAME_PT_EX}
            onApply={handleFilterApply}
            onClose={() => { setCurrentFilterName('') }}
            onValidate={handleFilterValidate}
          />
        )
      }
    </BulkResultContainer>
  )
}

export default PtExCategoryResult
