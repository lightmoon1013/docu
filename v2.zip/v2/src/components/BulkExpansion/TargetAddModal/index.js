import React, { useEffect, useState } from 'react'
import { useDispatch, useStore } from 'react-redux'
import { Modal, Tooltip, Whisper } from 'rsuite'

import { toast } from '../../CommonComponents/ToastComponent/toast'

import { ReactComponent as InfoSvg } from '../../../assets/svg/info.svg'

import StepCampaign from './StepCampaign'
import StepAdgroup from './StepAdgroup'
import StepBid from './StepBid'

import { addTargets } from '../../../redux/actions/bulkEngine'

import { MIN_BID_PRICE } from '../../../utils/defaultValues'

const STEP_CAMPAIGN = 1
const STEP_ADGROUP = 2
const STEP_BID = 3

const stepList = [
  {
    value: STEP_CAMPAIGN,
    name: 'Choose campaigns',
    description: (
      <>
        <p>
          Sponsored Products automatic targeting campaigns
          are not eligible to target keywords/products manually.
        </p>
        <p>
          Sponsored Displays campaigns with legacy tactic types
          are not eligible to target products/categories.
        </p>
      </>
    ),
  },
  { value: STEP_ADGROUP, name: 'Choose ad groups' },
  { value: STEP_BID, name: 'Confirm match type and bids' },
]

const MAX_KEYWORDS_PER_ADGROUP = 1000
const MAX_TARGETS_PER_ADGROUP = 10000 // 10k

// forCategory - true if this is for Product Targeting/Category Targeting.
const TargetAddModal = ({ show, targets, forTargetEx, forStEx, forPtEx, forCategory, onClose }) => {
  const dispatch = useDispatch()
  const store = useStore().getState()

  const {
    bulkEngine: {
      adgroupsToAddTargetsData,
      isAddingTargets,
    },
  } = store

  const [step, setStep] = useState(STEP_CAMPAIGN)
  const [selectedCampaigns, setSelectedCampaigns] = useState([])
  const [selectedAdgroups, setSelectedAdgroups] = useState([])
  const [payload, setPayload] = useState([])
  const [audience, setAudience] = useState([])
  const [lookback, setLookback] = useState()

  useEffect(() => {
    if (show) {
      setStep(STEP_CAMPAIGN)
      setSelectedCampaigns([])
      setSelectedAdgroups([])
      setPayload([])
    }
  }, [show]) // eslint-disable-line

  const handleBack = () => {
    if (step === STEP_ADGROUP) {
      setSelectedAdgroups([])
    }
    setStep(step - 1)
  }

  const handleConfirm = () => {
    if (step !== STEP_BID) {
      // For the step to choose ad groups.
      if (step === STEP_ADGROUP) {
        // Check if there is an ad group with keywords/targets more than allowed.
        const invalid = adgroupsToAddTargetsData.find((adgroup) => {
          if (selectedAdgroups.indexOf(adgroup.adgroup_id) === -1) {
            return false
          }

          if (parseInt(adgroup.targets, 10) > 0
            && (parseInt(adgroup.targets, 10) + targets.length) > MAX_TARGETS_PER_ADGROUP) {
            toast.show({
              title: 'Warning',
              description: `You can add up to ${MAX_TARGETS_PER_ADGROUP} product targets per ad group.`,
            })
            return true
          } else if (parseInt(adgroup.keywords, 10) > 0
            && (parseInt(adgroup.keywords, 10) + targets.length) > MAX_KEYWORDS_PER_ADGROUP) {
            toast.show({
              title: 'Warning',
              description: `You can add up to ${MAX_KEYWORDS_PER_ADGROUP} keywords per ad group.`,
            })
            return true
          }
          return false
        })

        if (invalid) {
          return
        }
      }

      setStep(step + 1)
      return
    }

    // Add keywords/targets depending on ad group selected.
    // Check if there is a target with an invalid bid price.
    // FIXME: The minimum bid prices are different per ad type.
    const invalid = payload.find(target => (
      target.bid === ''
      || isNaN(target.bid)
      || parseFloat(target.bid) < MIN_BID_PRICE
    ))
    if (invalid) {
      toast.show({
        title: 'Warning',
        description: `Bid should be at least $${MIN_BID_PRICE}.`,
      })
      return
    }

    // Fill in match type values.
    const sanitizedPayload = payload.map(record => (
      Object.assign({}, record, {
        matchType: record.matchType ? record.matchType.value : '',
      })
    ))

    if (!sanitizedPayload.length) {
      toast.show({
        title: 'Warning',
        description: 'There is nothing to add.',
      })
      return
    }

    if (forPtEx) {
      const sdCampaign = sanitizedPayload.find(campaign => (
        campaign.campaignType === 'Sponsored Displays'
        && campaign.tactic === 'T00030'
      ))

      if (sdCampaign && !audience.length) {
        toast.show({
          title: 'Warning',
          description: 'Please choose an audience.',
        })
        return
      }
    }

    dispatch(addTargets(
      sanitizedPayload,
      forCategory ? true: false,
      audience,
      lookback
    )).then((response) => {
      toast.show({
        title: 'Success',
        description: `Added ${response.count} keyword/targets successfully.`,
      })

      onClose()
    }).catch((error) => {
      toast.show({
        title: 'Danger',
        description: typeof error === 'string' ? error : 'Failed to add keyword/targets',
      })
    })
  }

  const renderSteps = () => {
    return (
      <div className="step-container">
        {
          stepList.map(stepInfo => (
            <span
              key={stepInfo.value}
              className={`step-wrapper${step === stepInfo.value ? ' active' : ''}`}
            >
              { stepInfo.name }
              {
                typeof stepInfo.description !== 'undefined' && (
                  <Whisper placement="right" trigger="hover" speaker={(
                    <Tooltip>
                      { stepInfo.description }
                    </Tooltip>
                  )}>
                    <InfoSvg />
                  </Whisper>
                )
              }
            </span>
          ))
        }
      </div>
    )
  }

  const renderContents = () => {
    if (step === STEP_CAMPAIGN) {
      return (
        <StepCampaign
          selectedCampaigns={selectedCampaigns}
          forPtEx={forPtEx}
          forCategory={forCategory}
          onSelect={setSelectedCampaigns}
        />
      )
    }

    if (step === STEP_ADGROUP) {
      return (
        <StepAdgroup
          selectedCampaigns={selectedCampaigns}
          selectedAdgroups={selectedAdgroups}
          forPtEx={forPtEx}
          onSelect={setSelectedAdgroups}
        />
      )
    }

    if (step === STEP_BID) {
      return (
        <StepBid
          targets={targets}
          payload={payload}
          selectedAdgroups={selectedAdgroups}
          forTargetEx={forTargetEx}
          forPtEx={forPtEx}
          forCategory={forCategory}
          onChange={setPayload}
          onChangeAudience={setAudience}
          onChangeLookback={setLookback}
        />
      )
    }

    return null
  }

  let isConfirmDisabled = isAddingTargets
  if (step === STEP_CAMPAIGN && selectedCampaigns.length === 0) {
    isConfirmDisabled = true
  } else if (step === STEP_ADGROUP && selectedAdgroups.length === 0) {
    isConfirmDisabled = true
  }

  return (
    <Modal className="target-add-modal" backdrop="static" size="lg" show={show}>
      <Modal.Header onHide={() => { onClose() }}>
        <Modal.Title>
          Add { forStEx ? 'Search Terms' : 'Targets' } to Campaign
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        { renderSteps() }
        { renderContents() }
      </Modal.Body>
      <Modal.Footer>
        {
          step !== STEP_CAMPAIGN && (
            <button
              type="button"
              className="rs-btn rs-btn-default"
              onClick={handleBack}
            >
              Back
            </button>
          )
        }
        <button
          type="button"
          className="rs-btn rs-btn-primary"
          disabled={isConfirmDisabled}
          onClick={handleConfirm}
        >
          { step === STEP_BID ? 'Confirm' : 'Next' }
        </button>
        <button type="button" className="rs-btn rs-btn-subtle" onClick={() => onClose()}>
          Close
        </button>
      </Modal.Footer>
    </Modal>
  )
}

export default TargetAddModal
