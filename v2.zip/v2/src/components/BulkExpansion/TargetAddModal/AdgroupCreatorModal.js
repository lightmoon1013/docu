import React, { useEffect, useState } from 'react'
import { useDispatch, useStore } from 'react-redux'
import Select from 'react-select'
import { Modal } from 'rsuite'

import LoaderComponent from '../../CommonComponents/LoaderComponent'
import { toast } from '../../CommonComponents/ToastComponent/toast'
import ProductModal from '../../CampaignCreator/ProductModal'

import { ReactComponent as CloseSvg } from '../../../assets/svg/close.svg'

import { createAdgroup } from '../../../redux/actions/bulkEngine'
import { campaignTypeMap } from '../../../utils/defaultValues'

const MIN_DEFAULT_BID = 0.02

const bidOpOptions = [
  { value: 'clicks', label: 'Optimize for page visits' },
  { value: 'conversions', label: 'Optimize for conversion' },
  { value: 'reach', label: 'Optimize for viewable impressions' },
]

const CampaignOption = (props) => {
  const { innerRef, innerProps, getStyles, data } = props
  return (
    <div
      ref={innerRef}
      {...innerProps}
      style={getStyles('option', props)}
      className="campaign-option"
    >
      <div>
        { data.campaign }
      </div>
      <div className="campaign-detail">
        {
          data.campaignType === 'Sponsored Products' && (
            <span>
              { data.targeting_type === 'auto' ? 'Auto' : 'Manual' }
            </span>
          )
        }
        <span>
          { campaignTypeMap[data.campaignType] }
        </span>
      </div>
    </div>
  )
}

const AdgroupCreatorModal = ({ show, campaigns = [], campaignDetail = null, onCreate, onCancel }) => {
  const dispatch = useDispatch()
  const store = useStore().getState()

  const {
    bulkEngine: {
      isCreatingAdgroup,
    },
  } = store

  const [selectedCampaign, setSelectedCampaign] = useState(null)
  const [name, setName] = useState('')
  const [defaultBid, setDefaultBid] = useState(MIN_DEFAULT_BID)
  const [selectedBidOp, setSelectedBidOp] = useState(bidOpOptions[0])
  const [products, setProducts] = useState([])
  const [openProductModal, setOpenProductModal] = useState(false)

  useEffect(() => {
    if (campaignDetail) {
      setSelectedCampaign(campaignDetail)
    }
  }, [campaignDetail])

  const handleCreate = () => {
    if (!selectedCampaign) {
      toast.show({
        title: 'Warning',
        description: 'Please choose a campaign.',
      })
      return
    }

    if (name === '') {
      toast.show({
        title: 'Warning',
        description: 'Please enter a name for the ad group.',
      })
      return
    }

    if (!defaultBid
      || Number.isNaN(parseFloat(defaultBid))
      || parseFloat(defaultBid) < MIN_DEFAULT_BID) {
      toast.show({
        title: 'Warning',
        description: `Please enter a bid value for use when no bid is specified `
          + `for keywords. The minimum is $${MIN_DEFAULT_BID}`,
      })
      return
    }

    if (!products.length) {
      toast.show({
        title: 'Warning',
        description: 'Please add products that you want to promote in this ad group.',
      })
      return
    }

    dispatch(createAdgroup(
      selectedCampaign.campaign_id,
      selectedCampaign.campaignType,
      name,
      parseFloat(defaultBid),
      selectedBidOp.value,
      selectedCampaign.tactic,
      products.map(product => ({
        asin: product.asin,
        sku: product.sku,
      }))
    )).then((response) => {
      if (response && response.adgroup_id) {
        onCreate(response.adgroup_id.toString())
      }
    })
  }

  const handleProductSelect = (products) => {
    setOpenProductModal(false)
    setProducts(products)
  }

  const handleProductRemove = (id) => {
    setProducts(products.filter(product => product.id !== id))
  }

  const renderProductTable = () => {
    if (!products.length) {
      return (
        <div className="no-product-desc">
          No product added.
        </div>
      )
    }

    return (
      <div className="product-container">
        {
          products.map((product) =>
            <div key={product.id} className="product-box">
              <CloseSvg title="Remove" onClick={() => { handleProductRemove(product.id) }}/>
              <img src={product.image} alt={product.name} />
              <div className="product-info">
                <div className="product-name">{product.name}</div>
                <div className="product-detail">
                  <span>Price: {product.price}</span>
                  <span>ASIN: {product.asin}</span>
                  <span>SKU: {product.sku}</span>
                </div>
              </div>
            </div>
          )
        }
      </div>
    )
  }

  const renderProducts = () => {
    return (
      <>
        <div className="field-wrapper">
          <label>Products</label>
          <button
            type="button"
            className="btn btn-blue"
            onClick={() => { setOpenProductModal(true) }}
          >
            Add Products
          </button>
          <ProductModal
            show={openProductModal}
            productsSelected={products}
            onSelect={handleProductSelect}
            onClose={() => { setOpenProductModal(false) }}
          />
        </div>
        { renderProductTable() }
      </>
    )
  }

  return (
    <Modal className="adgroup-creator-modal" backdrop="static" size="sm" show={show}>
      <Modal.Header onHide={() => { onCancel() }}>
        <Modal.Title>
          Create New Ad Group
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        { isCreatingAdgroup && <LoaderComponent /> }
        {
          campaigns.length > 0 && (
            <div className="field-wrapper">
              <label>Campaign</label>
              <Select
                components={{ Option: CampaignOption }}
                value={selectedCampaign}
                options={campaigns}
                getOptionLabel={record => record.campaign}
                getOptionValue={record => record.campaign_id}
                placeholder="Choose campaign"
                onChange={setSelectedCampaign}
              />
            </div>
          )
        }
        <div className="field-wrapper">
          <label>Ad Group Name</label>
          <input
            type="text"
            placeholder="Enter ad group name"
            value={name}
            onChange={(event) => { setName(event.target.value) }}
          />
        </div>
        <div className="field-wrapper">
          <label>Default Bid</label>
          <input
            type="number"
            min={MIN_DEFAULT_BID}
            placeholder="Default bid price"
            value={defaultBid}
            onChange={(event) => { setDefaultBid(event.target.value) }}
          />
        </div>
        {
          selectedCampaign !== null
          && selectedCampaign.campaignType === 'Sponsored Displays'
          && (
            <div className="field-wrapper">
              <label>Bid Optimization</label>
              <Select
                value={selectedBidOp}
                options={bidOpOptions}
                placeholder="Choose bid optimization"
                onChange={setSelectedBidOp}
              />
            </div>
          )
        }
        { renderProducts() }
      </Modal.Body>
      <Modal.Footer>
        <button
          type="button"
          className="rs-btn rs-btn-primary"
          disabled={isCreatingAdgroup}
          onClick={handleCreate}
        >
          Create
        </button>
        <button type="button" className="rs-btn rs-btn-subtle" onClick={() => onCancel()}>
          Cancel
        </button>
      </Modal.Footer>
    </Modal>
  )
}

export default AdgroupCreatorModal
