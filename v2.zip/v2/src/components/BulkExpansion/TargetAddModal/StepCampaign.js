import React, { useEffect, useState } from 'react'
import { useStore } from 'react-redux'
import Select from 'react-select'

import SortableTable from '../../CommonComponents/SortableTableComponent'

import {
  tableSorter,
} from '../../../services/helper'

import { campaignTypeMap } from '../../../utils/defaultValues'
import { campaignTypes, statuses, STATE_OPTION_ENABLED } from '../../../utils/filterDef'

const stateLabels = {
  enabled: 'Active',
  paused: 'Paused',
  archived: 'Archived',
}

const columns = [
  { key: 'campaign', name: 'Campaign' },
]

const StepCampaign = ({ selectedCampaigns, forPtEx, forCategory, onSelect }) => {
  const store = useStore().getState()

  const {
    campaign: { campaignsWithHistory },
  } = store

  const [campaigns, setCampaigns] = useState([])
  const [selectedType, setSelectedType] = useState(campaignTypes[0])
  const [selectedState, setSelectedState] = useState(STATE_OPTION_ENABLED)

  // Fill up a list of campaigns to select.
  useEffect(() => {
    setCampaigns(campaignsWithHistory.filter((campaign) => {
      // Filter by ad type.
      if (selectedType.value !== ''
        && campaign.campaignType.toLowerCase() !== selectedType.value) {
        return false
      }

      // Filter by status.
      if (selectedState.value !== '') {
        let selectedValue = selectedState.value
        if (!Array.isArray(selectedValue)) {
          selectedValue = [selectedValue]
        }
        if (selectedValue.indexOf(campaign.state.toLowerCase()) === -1) {
          return false
        }
      }

      // We cannot add keywords/targets to auto campaigns.
      if (campaign.campaignType === 'Sponsored Products'
        && campaign.targeting_type === 'auto') {
        return false
      }
      if (campaign.campaignType === 'Sponsored Displays') {
        // We cannot target products/campaigns for SD campaigns
        // with T00010 or remarketing tactics.
        if (campaign.tactic !== 'T00020' && campaign.tactic !== 'T00030') {
          return false
        }
        // T00030 (audience targeting) SD campaigns cannot be use
        // for product targeting.
        if (!(forPtEx === true && forCategory === true)
          && campaign.tactic === 'T00030') {
          return false
        }
      }
      return true
    }))
  }, [campaignsWithHistory, selectedType, selectedState]) // eslint-disable-line

  const renderFilter = () => {
    return (
      <>
        <div className="filter-wrapper">
          <label>Ad Type</label>
          <Select
            className="select-wrapper"
            options={campaignTypes}
            value={selectedType}
            onChange={setSelectedType}
          />
        </div>
        <div className="filter-wrapper">
          <label>Campaign Status</label>
          <Select
            className="select-wrapper"
            options={statuses}
            value={selectedState}
            onChange={setSelectedState}
          />
        </div>
      </>
    )
  }

  const renderCampaign = (record) => {
    let targetingType
    if (record.campaignType === 'Sponsored Products') {
      targetingType = 'Manual'
    }

    return (
      <>
        <div className="table-col col-campaign">
          <div className="campaign-status">
            <div className={`status ${record.state === 'enabled' ? 'on' : 'off'}`}>
              <div className="bullet"></div>
              <span>{ stateLabels[record.state] }</span>
            </div>
          </div>
          <div className="campaign-name" title={record.campaign}>
            { record.campaign }
          </div>
          <div className="campaign-detail">
            {
              targetingType && <span>{ targetingType }</span>
            }
            <span>
              { campaignTypeMap[record.campaignType] }
            </span>
          </div>
        </div>
      </>
    )
  }

  return (
    <SortableTable
      columns={columns}
      defaultSort={['campaign', 'asc']}
      sorter={tableSorter(['campaign'])}
      className="table-campaigns"
      records={campaigns}
      idField="campaign_id"
      searchFields={['campaign']}
      selectedRecords={selectedCampaigns}
      paginationSelectPlacement="top"
      renderTopRight={renderFilter}
      renderRecord={renderCampaign}
      onChange={onSelect}
    />
  )
}

export default StepCampaign
