import React, { useEffect, useMemo, useState } from 'react'
import { useDispatch, useStore } from 'react-redux'

import SortableTable from '../../CommonComponents/SortableTableComponent'

import AdgroupCreatorModal from './AdgroupCreatorModal'

import { getAdgroupsToAddTargets } from '../../../redux/actions/bulkEngine'

import { tableSorter } from '../../../services/helper'

import { campaignTypeMap } from '../../../utils/defaultValues'

const columns = [
  { key: 'campaign_name', name: 'Campaign' },
  { key: 'name', name: 'Ad Group' },
  { key: 'count', name: 'Number of Keywords/Targets', sortable: false },
]

const StepAdgroup = ({ selectedCampaigns, selectedAdgroups, forPtEx, onSelect }) => {
  const dispatch = useDispatch()
  const store = useStore().getState()

  const {
    campaign: { campaignsWithHistory },
    bulkEngine: {
      isGettingAdgroupsToAddTargets,
      adgroupsToAddTargetsData,
    },
  } = store

  const [adgroupList, setAdgroupList] = useState([])
  const [adgroupCreatorVisible, setAdgroupCreatorVisible] = useState(false)

  useEffect(() => {
    const payload = {}
    campaignsWithHistory.filter(campaign =>
      selectedCampaigns.indexOf(campaign.campaign_id) !== -1
    ).forEach((campaign) => {
      if (!payload[campaign.campaignType]) {
        payload[campaign.campaignType] = []
      }
      payload[campaign.campaignType].push(campaign.campaign_id)
    })

    dispatch(getAdgroupsToAddTargets(
      payload,
      forPtEx ? true : false // This needs to be cast to boolean explicitly.
    ))
  }, []) // eslint-disable-line

  useEffect(() => {
    const campaignNamesById = {}
    const campaignTypesById = {}
    const targetingTypesById = {}
    campaignsWithHistory.forEach((campaign) => {
      campaignNamesById[campaign.campaign_id] = campaign.campaign
      campaignTypesById[campaign.campaign_id] = campaign.campaignType
      targetingTypesById[campaign.campaign_id] = campaign.targeting_type
    })

    setAdgroupList((adgroupsToAddTargetsData || []).map(adgroup => ({
      ...adgroup,
      campaign_name: campaignNamesById[adgroup.campaign_id] || '',
      campaign_type: campaignTypesById[adgroup.campaign_id] || '',
      targeting_type: targetingTypesById[adgroup.campaign_id] || '',
    })))
  }, [adgroupsToAddTargetsData]) // eslint-disable-line

  const handleAdgroupCreate = (adgroupId) => {
    setAdgroupCreatorVisible(false)
    onSelect([
      ...selectedAdgroups,
      adgroupId,
    ])
  }

  // For SB campaigns, we cannot create a new ad group to an existing campaign.
  const nonSBCampaigns = useMemo(() => (
    campaignsWithHistory.filter(campaign =>
      selectedCampaigns.indexOf(campaign.campaign_id) !== -1
      && campaign.campaignType !== 'Sponsored Brands'
      && campaign.campaignType !== 'Sponsored Brands Video'
    )
  ), [campaignsWithHistory, selectedCampaigns])

  const renderAction = () => {
    if (!nonSBCampaigns.length) {
      return null
    }

    return (
      <button
        type="button"
        className="btn btn-green"
        onClick={() => { setAdgroupCreatorVisible(true) }}
      >
        Create New Ad Group
      </button>
    )
  }

  const renderAdgroup = (adgroup) => (
    <>
      <div className="table-col col-campaign">
        <div className="campaign-name">
          { adgroup.campaign_name }
        </div>
        <div className="campaign-detail">
          {
            adgroup.campaign_type === 'Sponsored Products' && (
              <span>
                { adgroup.targeting_type === 'auto' ? 'Auto' : 'Manual' }
              </span>
            )
          }
          <span>
            { campaignTypeMap[adgroup.campaign_type] }
          </span>
        </div>
      </div>
      <div className="table-col col-adgroup">
        { adgroup.name }
      </div>
      <div className="table-col">
        { parseInt(adgroup.keywords, 10) + parseInt(adgroup.targets, 10) }
      </div>
    </>
  )

  return (
    <>
      <SortableTable
        columns={columns}
        defaultSort={['campaign_name', 'asc']}
        sorter={tableSorter(['campaign_name', 'name'])}
        className="table-adgroups"
        records={adgroupList}
        idField="adgroup_id"
        searchFields={['campaign_name', 'name']}
        selectedRecords={selectedAdgroups}
        paginationSelectPlacement="top"
        noRecordText={ forPtEx ? 'No ad groups for product targeting found.' : 'No records found.'}
        isLoading={isGettingAdgroupsToAddTargets}
        renderTopRight={renderAction}
        renderRecord={renderAdgroup}
        onChange={onSelect}
      />
      <AdgroupCreatorModal
        show={adgroupCreatorVisible}
        campaigns={nonSBCampaigns}
        onCreate={handleAdgroupCreate}
        onCancel={() => { setAdgroupCreatorVisible(false) }}
      />
    </>
  )
}

export default StepAdgroup
