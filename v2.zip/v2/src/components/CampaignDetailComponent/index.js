import React, { useState, useEffect } from 'react'
import { useDispatch, useStore } from 'react-redux'
import { useHistory, useParams } from 'react-router-dom'
import moment from 'moment'

import MainLayout from '../../layout/MainLayout'
import APMComponent from '../APMComponent'
import TemplateEditorComponent from '../TemplateEditorComponent'
import CampaignSelector from './campaignSelector'
import DashboardTab from './tabs/dashboard'
import SKUOPTab from './tabs/sku'
import BidOPTab from './tabs/bid'
import KeywordCleanerTab from './tabs/keywordCleaner'
import STOPTab from './tabs/searchTerm'
import NegativeOPTab from './tabs/negative'
import PlacementOPTab from './tabs/placement'

import { getDetails } from '../../redux/actions/campaignDetail'
import { setUserChanged } from '../../redux/actions/header'

const CampaignDetailComponent = () => {
  const store = useStore()
  const dispatch = useDispatch()
  const history = useHistory()

  const {
    campaignDetail: {
      currentDetail
    },
    header: {
      currentStartDate,
      currentEndDate,
      currentUserId,
      isUserChanged,
    },
    pageGlobal: { showAPM, showTemplateEditor },
  } = store.getState()

  const { id: campaignId, campaignType } = useParams()

  const [currentTab, setCurrentTab] = useState('dashboard')

  useEffect(() => {
    document.querySelector('.main-content').scrollTop = 0
  }, [])

  useEffect(() => {
    if (!currentStartDate || !currentStartDate) {
      return
    }

    dispatch(getDetails({
      campaignId,
      campaignType,
      startDate: moment(currentStartDate).format('YYYY-MM-DD'),
      endDate: moment(currentEndDate).format('YYYY-MM-DD'),
    }))
  }, [campaignId, currentUserId, currentStartDate, currentEndDate]) // eslint-disable-line

  useEffect(() => {
    if (!isUserChanged) {
      return
    }
    history.push('/dashboard')
    dispatch(
      setUserChanged({
        isChanged: false
      })
    )
  }, [isUserChanged, history, dispatch])

  const isSB = campaignType === 'Sponsored Brands' || campaignType === 'Sponsored Brands Video'
  const isSD = campaignType === 'Sponsored Displays'

  const tabList = [
    {
      value: 'dashboard',
      label: 'Dashboard',
      isShow: true,
    },
    {
      value: 'sku',
      label: 'SKU Op',
      isShow: !isSB,
    },
    {
      value: 'bid',
      label: 'Bid Op',
      isShow: true,
    },
    {
      value: 'keyword',
      label: 'Keyword Cleaner',
      isShow: !isSB
        && !isSD
        && !(currentDetail && currentDetail.targeting_type === 'auto')
    },
    {
      value: 'search',
      label: 'Search Term Op',
      isShow: !isSD,
    },
    {
      value: 'negative',
      label: 'Negative Word/ASIN Finder',
      isShow: !isSD,
    },
    {
      value: 'placement',
      label: 'Placement Op',
      isShow: !isSB && campaignType !== 'Sponsored Displays',
    }
  ]

  const handleTabClick = tab => () => {
    if (currentDetail) {
      setCurrentTab(tab.value)
    }
  }

  return (
    <MainLayout>
      <div className="campaign-detail-component">
        { showAPM && <APMComponent /> }
        { showTemplateEditor && <TemplateEditorComponent /> }
        <div className="flex-wrap page-header">
          <div className="page-title">
            <CampaignSelector
              campaignId={campaignId}
              onSelect={() => { setCurrentTab('dashboard') }}
            />
          </div>
        </div>
        <div className="page-tabs">
          {
            tabList.map((tab) => (
              tab.isShow && (
                <button
                  key={tab.value}
                  type="button"
                  className={`page-tab${currentTab === tab.value ? ' selected' : ''}`}
                  onClick={handleTabClick(tab)}
                >
                  { tab.label }
                </button>
              )
            ))
          }
        </div>
        {
          currentTab === 'dashboard' && (
            <DashboardTab
              campaignType={campaignType}
            />
          )
        }
        {
          currentTab === 'sku' && (
            <SKUOPTab
              campaignType={campaignType}
            />
          )
        }
        {
          currentTab === 'bid' && (
            <BidOPTab
              campaignType={campaignType}
            />
          )
        }
        {
          currentTab === 'keyword' && (
            <KeywordCleanerTab
            campaignType={campaignType}
            />
          )
        }
        {
          currentTab === 'search' && (
            <STOPTab
              campaignType={campaignType}
            />
          )
        }
        {
          currentTab === 'negative' && (
            <NegativeOPTab
            campaignType={campaignType}
            />
          )
        }
        {
          currentTab === 'placement' && (
            <PlacementOPTab
              campaignType={campaignType}
            />
          )
        }
      </div>
    </MainLayout>
  )
}

export default CampaignDetailComponent
