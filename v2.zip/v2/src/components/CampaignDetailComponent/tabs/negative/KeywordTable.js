import React, { useState, useEffect } from 'react'
import { useStore } from 'react-redux'

import SortableTable from '../../../CommonComponents/SortableTableComponent'
import { toast } from '../../../CommonComponents/ToastComponent/toast'

import ModalAddNegatives from '../../modals/ModalAddNegatives'

import {
  formatValue,
  formatCurrency,
  copyToClipboard,
  tableSorter,
} from '../../../../services/helper'

const regExpForSpecialChars = new RegExp('&#34;', 'g')

const columns = [
  { key: 'search', name: 'Search Words', className: 'col-word' },
  { key: 'clicks', name: 'Unprofitable Clicks' },
  { key: 'revenue', name: 'Sales' },
  { key: 'cost', name: 'Wasted AD Spend' },
  { key: 'yearlyCost', name: 'Approximate Yearly Savings' },
  { key: 'impressions', name: 'Imp.' },
  { key: 'ctr', name: 'CTR %' },
]

const KeywordTable = ({ campaignType, currentAdgroupId, dateDiff }) => {
  const store = useStore()

  const {
    header: {
      currencyRate,
      currencySign,
    },
    campaignDetail: {
      currentAcos,
      isNegativeWordDataLoading,
      negativeWordData,
      existingNegativeData,
    },
  } = store.getState()

  const [negatives, setNegatives] = useState([])
  const [selectedNegatives, setSelectedNegatives] = useState([])
  const [showAddNegativesModal, setShowAddNegativesModal] = useState(false)

  useEffect(() => {
    if (!negativeWordData || !negativeWordData.length) {
      return
    }

    let searchTermList = negativeWordData[0]
    if (currentAdgroupId) {
      searchTermList = negativeWordData[1].filter(searchTerm => searchTerm.adgroup_id === currentAdgroupId)
    }

    let positiveWordList = []
    const negativeList = []
    const targetAcos = parseFloat(currentAcos || 40)
    searchTermList.forEach((searchTerm) => {
      if (searchTerm.acos !== null && parseFloat(searchTerm.acos) <= targetAcos) {
        // Get a list of profitable words.
        const search = searchTerm.search.replace(regExpForSpecialChars, '').toLowerCase()
        positiveWordList = positiveWordList.concat(search.trim().split(/\s+/g))
      } else {
        negativeList.push(searchTerm)
      }
    })
    positiveWordList = [...new Set(positiveWordList)].map(keyword => keyword.trim())

    // Get a list of unprofitable words.
    let negativeWordList = []
    negativeList.forEach((searchTerm) => {
      const search = searchTerm.search.replace(regExpForSpecialChars, '')
      search.trim().split(/\s+/g).forEach((word) => {
        if (positiveWordList.indexOf(word.toLowerCase()) !== -1) {
          return
        }

        if (existingNegativeData.indexOf(word.toLowerCase()) !== -1) {
          return
        }

        const existingIndex = negativeWordList.findIndex(negative => (
          negative.search === word
        ))

        if (existingIndex === -1) {
          negativeWordList.push({
            id: searchTerm.id,
            search: word,
            revenue: parseFloat(searchTerm.revenue),
            cost: parseFloat(searchTerm.cost),
            impressions: parseInt(searchTerm.impressions, 10),
            clicks: parseInt(searchTerm.clicks, 10),
            orders: parseInt(searchTerm.orders, 10),
          })
        } else {
          negativeWordList[existingIndex].revenue += parseFloat(searchTerm.revenue)
          negativeWordList[existingIndex].cost += parseFloat(searchTerm.cost)
          negativeWordList[existingIndex].impressions += parseFloat(searchTerm.impressions)
          negativeWordList[existingIndex].clicks += parseFloat(searchTerm.clicks)
          negativeWordList[existingIndex].orders += parseFloat(searchTerm.orders)
        }
      })
    })
    negativeWordList = negativeWordList.map((word) => {
      let ctr = 0
      if (word.impressions) {
        ctr = word.clicks / word.impressions * 100
      }

      return {
        ...word,
        ctr,
        yearlyCost: word.cost / dateDiff * 365,
      }
    })

    setNegatives(negativeWordList)
  }, [currentAdgroupId, currentAcos, negativeWordData, existingNegativeData]) // eslint-disable-line

  const handleCopy = () => {
    copyToClipboard([...new Set(selectedNegatives)].join('\n'))

    toast.show({
      title: 'Success',
      description: `Successfully copied ${selectedNegatives.length} search word${selectedNegatives.length > 1 ? 's' : ''}.`
    })
  }

  const renderAction = () => {
    if (selectedNegatives.length > 0) {
      return (
        <>
          <button
            type="button"
            className="btn btn-blue"
            onClick={() => { setShowAddNegativesModal(true) }}
          >
            Add negative{selectedNegatives.length > 1 ? 's' : ''} to campaign
          </button>
          <button type="button" className="btn btn-green" onClick={() => { handleCopy() }}>
            Copy
          </button>
        </>
      )
    }
    return null
  }

  const renderNegative = record => (
    <>
      <div className="table-col col-word">
        { record.search }
      </div>
      <div className="table-col">
        { formatValue(record.clicks, 'removeZeroDecimal') }
      </div>
      <div className="table-col">
        { formatCurrency(record.revenue, currencySign, currencyRate) }
      </div>
      <div className="table-col">
        { formatCurrency(record.cost, currencySign, currencyRate) }
      </div>
      <div className="table-col">
        { formatCurrency(record.yearlyCost, currencySign, currencyRate) }
      </div>
      <div className="table-col">
        { formatValue(record.impressions, 'removeZeroDecimal') }
      </div>
      <div className="table-col">
        { formatValue(record.ctr, 'percent') }
      </div>
    </>
  )

  const selectedWords = negatives.filter(negative => (
    selectedNegatives.indexOf(negative.search) !== -1
  ))

  return (
    <>
      <SortableTable
        columns={columns}
        defaultSort={['cost', 'desc']}
        sorter={tableSorter('search')}
        className="table-search-words"
        records={negatives}
        idField="search"
        searchFields={['search']}
        selectedRecords={selectedNegatives}
        paginationSelectPlacement="top"
        hasSticky
        hasDateRange
        filterName="campaignDetailNegative"
        isLoading={isNegativeWordDataLoading}
        renderRecord={renderNegative}
        renderTopRight={renderAction}
        onChange={setSelectedNegatives}
      />
      <ModalAddNegatives
        terms={selectedWords}
        modalType="negative-finder"
        campaignType={campaignType}
        showModal={showAddNegativesModal}
        currentAdGroupId={currentAdgroupId}
        onClose={() => { setShowAddNegativesModal(false) }}
      />
    </>
  )
}

export default KeywordTable
