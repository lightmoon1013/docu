import React, { useState, useEffect } from 'react'
import { useDispatch, useStore } from 'react-redux'
import { useParams } from 'react-router-dom'
import moment from 'moment'
import { Tooltip, Whisper } from 'rsuite'

import { ReactComponent as InfoSvg } from '../../../../assets/svg/info.svg'

import VideoLink from '../../../CommonComponents/VideoLink'

import KeywordTable from './KeywordTable'
import TargetTable from './TargetTable'


import {
  getNegativeWordData,
  getNegativeTargetData,
} from '../../../../redux/actions/campaignDetail'

import {
  updateAcos,
} from '../../../../redux/actions/campaignDetail'

const videoList = [
  { title: 'Negative Optimization Video', url: 'https://www.loom.com/embed/d4ff75392a6347f390b9c4413a86d174' },
]

const NegativeOPTab = ({ campaignType }) => {
  const store = useStore()
  const dispatch = useDispatch()

  const {
    header: {
      currentStartDate,
      currentEndDate,
    },
    campaignDetail: {
      currentAcos,
      currentAdGroups,
    },
  } = store.getState()

  const { id: campaignId } = useParams()

  const [currentAdgroupId, setCurrentAdgroupId] = useState(null)
  const [targetType, setTargetType] = useState('keywords')
  const [acos, setAcos] = useState(0)

  const handleChangeAdGroup = (adGroup) => {
    if (adGroup) {
      setCurrentAdgroupId(adGroup.adgroupid)
      setTargetType(adGroup.targetType === 'products' ? 'products' : 'keywords')
    } else {
      setCurrentAdgroupId(null)
      setTargetType('keywords')
    }
  }

  useEffect(() => {
    if (!currentAcos) {
      return
    }
    setAcos(currentAcos)
  }, [currentAcos])

  useEffect(() => {
    if (!currentStartDate || !currentEndDate) {
      return
    }
    if (targetType === 'keywords') {
      let adgroupIds
      if (currentAdgroupId) {
        adgroupIds = [currentAdgroupId]
      } else {
        adgroupIds = currentAdGroups.map(adgroup => adgroup.adgroupid)
      }

      dispatch(getNegativeWordData({
        campaignId: campaignId,
        adgroupIds,
        campaignType,
        startDate: moment(currentStartDate).format('YYYY-MM-DD'),
        endDate: moment(currentEndDate).format('YYYY-MM-DD'),
      }))
    } else {
      dispatch(getNegativeTargetData({
        campaignId: campaignId,
        adgroupId: currentAdgroupId,
        startDate: moment(currentStartDate).format('YYYY-MM-DD'),
        endDate: moment(currentEndDate).format('YYYY-MM-DD'),
        targetAcos: currentAcos || 0,
      }))
    }
    // eslint-disable-next-line
  }, [
    campaignId,
    targetType,
    currentAdgroupId,
    currentAdGroups.map(adgroup => adgroup.adgroupid).join(), // eslint-disable-line
    currentStartDate,
    currentEndDate,
    currentAcos,
  ])

  const handleChangeAcos = e => {
    if (!e.target.value) {
      return
    }
    setAcos(e.target.value)
  }

  const handleSaveAcos = () => {
    dispatch(updateAcos({
      campaignId,
      campaignType,
      acos,
    }))
  }

  const isSameAcos = currentAcos === acos
  if (campaignType === 'Sponsored Displays') {
    return null
  }

  const dateDiff = moment(currentEndDate).diff(moment(currentStartDate), 'day') || 1

  return (
    <div className="campaign-detail-negative-op campaign-detail-tab">
      <div className="tab-info">
        <div className="tab-title">
          Negative Word/ASIN Finder
          <Whisper placement="right" trigger="hover" speaker={(
            <Tooltip>
              <p>Automatically finds individual words that are leading to lost sales.</p>
              <p>Read through this list carefully and decide which words you want to add as negative phrase match.</p>
            </Tooltip>
          )}>
            <InfoSvg />
          </Whisper>
        </div>
        <div className="tab-description">
          Finds Unique Words/ASINS That Have Not Been Profitable.
        </div>
        <VideoLink
          videoList={videoList}
          modalTitle='Negative Optimization'
        />
      </div>
      <div className="adgroup-selector">
        <div className="adgroup-content">
          Ad group:
          <button
            type="button"
            className={`btn ${!currentAdgroupId ? 'btn-blue' : 'btn-white'}`}
            onClick={() => { handleChangeAdGroup() }}
          >
            All ad groups
          </button>
          {
            (currentAdGroups || []).map(adGroup => (
              <button
                key={adGroup.adgroupid}
                type="button"
                className={`btn ${currentAdgroupId === adGroup.adgroupid ? 'btn-blue' : 'btn-white'}`}
                onClick={() => { handleChangeAdGroup(adGroup) }}
              >
                { adGroup.name }
              </button>
            ))
          }
        </div>
        <div className="acos-container">
          <span>ACoS Target (%)</span>
          <input value={acos} type="number" onChange={handleChangeAcos} />
          {
            !isSameAcos && (
              <button type="button" className="btn btn-red" onClick={handleSaveAcos}>
                Save
              </button>
            )
          }
        </div>
      </div>
      {
        targetType === 'keywords' && (
          <KeywordTable
            currentAdgroupId={currentAdgroupId}
            campaignType={campaignType}
            dateDiff={dateDiff}
          />
        )
      }
      {
        targetType === 'products' && (
          <TargetTable
            currentAdgroupId={currentAdgroupId}
            dateDiff={dateDiff}
          />
        )
      }
    </div>
  )
}

export default NegativeOPTab
