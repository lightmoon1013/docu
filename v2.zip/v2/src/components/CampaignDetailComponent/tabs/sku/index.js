import React, { useEffect, useState } from 'react'
import { useDispatch, useStore } from 'react-redux'
import moment from 'moment'
import { Tooltip, Whisper } from 'rsuite'

import { ReactComponent as InfoSvg } from '../../../../assets/svg/info.svg'

import SortableTable from '../../../CommonComponents/SortableTableComponent'
import VideoLink from '../../../CommonComponents/VideoLink'
import TableCell from '../../../CommonComponents/TableCell'

import {
  getSKUData,
  changeSkuState,
} from '../../../../redux/actions/campaignDetail'

import {
  updateAcos,
} from '../../../../redux/actions/campaignDetail'

import {
  tableSorter,
  calcDerivedMetrics,
} from '../../../../services/helper'

import { bulkSKUColumnList } from '../../../../utils/defaultValues'

const columns = [
  { key: 'state', name: 'State' },
  { key: 'image', name: 'Image', sortable: false },
  { key: 'sku', name: 'SKU', className: 'col-sku' },
  ...bulkSKUColumnList,
]

const videoList = [
  { title: 'Sku Optimization Video', url: 'https://www.loom.com/embed/04bd6686f0f344ac9ca78e240613ccad' },
]

const SKUOPTab = ({ campaignType }) => {
  const store = useStore()
  const dispatch = useDispatch()

  const {
    header: {
      currentStartDate,
      currentEndDate,
      currencyRate,
      currencySign,
    },
    campaignDetail: {
      currentAcos,
      currentDetail,
      currentAdGroups,
      isSKUDataLoading,
      isChangingSkuState,
      skuData,
    },
  } = store.getState()

  const [currentAdGroupId, setCurrentAdGroupId] = useState(null)
  const [acos, setAcos] = useState(0)
  const [skus, setSkus] = useState([])
  const [selectedSkus, setSelectedSkus] = useState([])

  // Retrieve SKUs.
  useEffect(() => {
    if (!currentDetail || !currentStartDate || !currentEndDate) {
      return
    }
    dispatch(getSKUData({
      campaignId: currentDetail.campaign_id,
      campaignType,
      startDate: moment(currentStartDate).format('YYYY-MM-DD'),
      endDate: moment(currentEndDate).format('YYYY-MM-DD'),
    }))
  }, [currentDetail ? currentDetail.campaign_id : null, currentStartDate, currentEndDate]) // eslint-disable-line

  // Filter found SKUs.
  useEffect(() => {
    if (!skuData || !skuData.length) {
      return
    }

    let filteredSKUs = []
    if (!currentAdGroupId) {
      filteredSKUs = skuData[0]
    } else {
      filteredSKUs = skuData[1].filter(sku => sku.adgroup_id === currentAdGroupId)
    }

    setSkus(filteredSKUs.map((record) => {
      const derived = calcDerivedMetrics(record)
      return {
        ...derived,
        className: (currentAcos && derived.acos > parseFloat(currentAcos))
          || (parseFloat(record.cost) && !derived.acos)
          ? 'bg-red'
          : '',
      }
    }))
  }, [currentAdGroups, currentAcos, currentAdGroupId, skuData, isSKUDataLoading]) // eslint-disable-line

  useEffect(() => {
    if (!currentAcos) {
      return
    }
    setAcos(currentAcos)
  }, [currentAcos])

  const handleChangeAdGroup = (adGroup) => {
    setCurrentAdGroupId(adGroup ? adGroup.adgroupid : null)
  }

  const handleChangeSkuState = (state) => {
    const selected = skus.filter(record => selectedSkus.indexOf(record.id) !== -1)
    const productAds = selected.map(sku => ({
      adId: parseInt(sku.adId, 10),
      state,
    }))

    dispatch(changeSkuState({
      campaignType,
      productAds,
      state,
      adGroupId: parseInt(selectedSkus[0].adgroupid, 10),
      adId: parseInt(selectedSkus[0].adId, 10),
    }))
  }

  const handleChangeAcos = e => {
    if (!e.target.value) {
      return
    }
    setAcos(e.target.value)
  }

  const handleSaveAcos = () => {
    dispatch(
      updateAcos({
        campaignId: currentDetail.campaign_id,
        campaignType: campaignType,
        acos,
      })
    )
  }

  const renderAction = () => {
    if (!selectedSkus.length) {
      return null
    }

    const isEnableDisabled = typeof skus.find(record => (
      selectedSkus.indexOf(record.id) !== -1
      && record.state !== 'enabled'
    )) === 'undefined'

    const isPauseDisabled = typeof skus.find(record => (
      selectedSkus.indexOf(record.id) !== -1
      && record.state !== 'paused'
    )) === 'undefined'

    return (
      <>
        <button
          type="button"
          className="btn btn-green"
          disabled={isChangingSkuState || isEnableDisabled}
          onClick={() => { handleChangeSkuState('enabled') }}
        >
          Enable
        </button>
        <button
          type="button"
          className="btn btn-red"
          disabled={isChangingSkuState || isPauseDisabled}
          onClick={() => { handleChangeSkuState('paused') }}
        >
          Pause
        </button>
      </>
    )
  }

  const renderSKU = record => (
    <>
      <div className="table-col col-state">
        { record.state }
      </div>
      <div className="table-col">
        <a href={record.url} target="_blank" rel="noopener noreferrer">
          <img src={record.image} alt={record.sku} />
        </a>
      </div>
      <div className="table-col col-sku">
        { record.sku }
      </div>
      {
        bulkSKUColumnList.map(column => (
          <TableCell
            key={column.key}
            record={record}
            columnKey={column.key}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  if (campaignType === 'Sponsored Brands' || campaignType === 'Sponsored Brands Video') {
    return null
  }

  const isLoading = isSKUDataLoading || isChangingSkuState
  const isSameAcos = currentAcos === acos

  return (
    <div className="campaign-detail-sku-op campaign-detail-tab">
      <div className="tab-info">
        <div className="tab-title">
          SKU Optimization
          <Whisper placement="right" trigger="hover" speaker={(
            <Tooltip>
              <p>If a SKU is highlighted in red, its ACoS is above
              your set ACoS Target Zone.</p>
              <p>Consider pausing that SKU.</p>
            </Tooltip>
          )}>
            <InfoSvg />
          </Whisper>
        </div>
        <div className="tab-description">
          Find the skus that are above your ACoS target.
        </div>
        <VideoLink
          videoList={videoList}
          modalTitle='Sku Optimization'
        />
      </div>
      <div className="adgroup-selector">
        <div className="adgroup-content">
          Ad group:
          <button
            type="button"
            className={`btn ${!currentAdGroupId ? 'btn-blue' : 'btn-white'}`}
            onClick={() => { handleChangeAdGroup() }}
          >
            All ad groups
          </button>
          {
            currentAdGroups.map(adGroup => (
              <button
                key={adGroup.adgroupid}
                type="button"
                className={`btn ${currentAdGroupId === adGroup.adgroupid ? 'btn-blue' : 'btn-white'}`}
                onClick={() => { handleChangeAdGroup(adGroup) }}
              >
                { adGroup.name }
              </button>
            ))
          }
        </div>
        <div className="acos-container">
          <span>ACoS Target (%)</span>
          <input value={acos} type="number" onChange={handleChangeAcos} />
          {
            !isSameAcos && (
              <button type="button" className="btn btn-red" onClick={handleSaveAcos}>
                Save
              </button>
            )
          }
        </div>
      </div>
      <SortableTable
        isLoading={isLoading}
        columns={columns}
        defaultSort={['cost', 'desc']}
        sorter={tableSorter(['state', 'sku'])}
        className="table-skus"
        records={skus || []}
        idField="id"
        searchFields={['sku']}
        selectedRecords={selectedSkus}
        paginationSelectPlacement="top"
        hasSticky
        hasDateRange
        filterName="campaignDetailSku"
        renderRecord={renderSKU}
        renderTopRight={renderAction}
        onChange={setSelectedSkus}
      />
    </div>
  )
}

export default SKUOPTab
