import React, { useEffect, useState } from 'react'
import { useDispatch, useStore } from 'react-redux'
import Select from 'react-select'

import SortableTable from '../../../CommonComponents/SortableTableComponent'
import { toast } from '../../../CommonComponents/ToastComponent/toast'
import BidAdjustComponent from '../../../CommonComponents/BidAdjustComponent'
import TableCell from '../../../CommonComponents/TableCell'

import {
  changeKeywordBid,
  changeKeywordState,
} from '../../../../redux/actions/campaignDetail'

import {
  formatCurrency,
  capitalizeFirstLetter,
  copyToClipboard,
  tableSorter,
  calcDerivedMetrics,
} from '../../../../services/helper'

import {
  bulkBidColumnList,
  adjustBidOptions,
  ADJUST_BID_RAISE,
  ADJUST_BID_LOWER,
  ADJUST_BID_CPC,
} from '../../../../utils/defaultValues'

import { matchTypes } from '../../../../utils/filterDef'

const columns = [
  { key: 'keyword', name: 'Keyword/Target', className: 'col-keyword' },
  { key: 'bid', name: 'Current Bid' },
  { key: 'maxCpc', name: 'Genius Bid', className: 'col-genius-bid' },
  ...bulkBidColumnList,
]

const KeywordTable = ({ campaignType }) => {
  const dispatch = useDispatch()
  const store = useStore()
  const {
    header: {
      currencySign,
      currencyRate,
    },
    campaignDetail: {
      currentDetail,
      currentAcos,
      isBidDataLoading,
      isChangingKeywordBid,
      isChangingKeywordState,
      bidData,
    },
  } = store.getState()

  const [keywords, setKeywords] = useState([])
  const [selectedKeywords, setSelectedKeywords] = useState([])
  const [isShowAdjustBid, setIsShowAdjustBid] = useState(false)
  const [selectedAdjustBidOption, setSelectedAdjustBidOption] = useState(adjustBidOptions[0])
  const [bidValue, setBidValue] = useState(0)
  const [selectedMatchType, setSelectedMatchType] = useState(matchTypes[0])

  useEffect(() => {
    const extendedKeywords = [];
    (bidData || []).forEach((record) => {
      if (selectedMatchType.value !== '') {
        if ((record.match_type || '').toLowerCase() !== selectedMatchType.value) {
          return
        }
      }

      const derived = calcDerivedMetrics(record)
      let maxCpc
      if (parseInt(derived.clicks, 10) >= 3) {
        if (parseInt(derived.units, 10) && derived.clickOrder) {
          maxCpc = (parseFloat(derived.revenue) / parseInt(derived.units, 10))
            * (currentAcos / 100)
            / derived.clickOrder
        } else if (typeof derived.units === 'undefined' && parseInt(derived.clicks, 10)) {
          // For SB/SBV campaigns, the number of units is not available.
          maxCpc = parseFloat(derived.revenue) * (currentAcos / 100)  / parseInt(derived.clicks, 10)
        }

        if (maxCpc < 0.15) {
          maxCpc = 0.15
        }
      }

      extendedKeywords.push({
        ...derived,
        matchType: capitalizeFirstLetter(record.match_type),
        maxCpc,
      })
    })

    setKeywords(extendedKeywords)
  }, [currentAcos, bidData, selectedMatchType])

  const handleCopy = () => {
    const keywordTexts = keywords.filter(keyword => (
      selectedKeywords.indexOf(keyword.keyword_id) !== -1
    )).map(keyword => keyword.keyword.trim())

    copyToClipboard([...new Set(keywordTexts)].join('\n'))

    toast.show({
      title: 'Success',
      description: `Successfully copied ${selectedKeywords.length} keyword${selectedKeywords.length > 1 ? 's' : ''}.`
    })
  }

  const handleChangeState = (state) => {
    if (currentDetail && currentDetail.targeting_type === 'auto') {
      toast.show({
        title: 'Warning',
        description: 'Auto campaign cannot change keyword bid.',
      })
      return
    }

    const keywordsToChange = keywords.filter(keyword => (
      selectedKeywords.indexOf(keyword.keyword_id) !== -1
      && keyword.state !== 'archived'
      && keyword.keyword !== '(_targeting_auto_)'
    )).map(keyword => ({
      campaignId: keyword.campaign_id,
      adGroupId: keyword.adgroup_id,
      keywordId: keyword.keyword_id,
      targetId: keyword.targetId ? keyword.targetId : null,
      state,
    }))

    if (!keywordsToChange.length) {
      toast.show({
        title: 'Warning',
        description: 'Archived keywords cannot be changed.',
      })
      return
    }

    dispatch(changeKeywordState({
      campaignType,
      keywordsArr: keywordsToChange,
      state,
    }))
  }

  const handleAdjustBid = () => {
    if (selectedAdjustBidOption.value !== ADJUST_BID_CPC
      && (bidValue === '' || isNaN(bidValue))) {
      toast.show({
        title: 'Warning',
        description: 'Please enter the valid bid value.',
      })
      return
    }

    let keywordsChanged = []
    keywords.filter(record => (
      selectedKeywords.indexOf(record.keyword_id) !== -1
      && record.keyword !== '(_targeting_auto_)'
    )).forEach((record) => {
      let newBid = parseFloat(bidValue)
      if (selectedAdjustBidOption.value === ADJUST_BID_RAISE) {
        newBid = parseFloat(record.bid || 0) * (1 + (newBid / 100))
      } else if (selectedAdjustBidOption.value === ADJUST_BID_LOWER) {
        newBid = parseFloat(record.bid || 0) * (1 - (newBid / 100))
      } else if (selectedAdjustBidOption.value === ADJUST_BID_CPC) {
        newBid = parseFloat(record.cpc || 0)
      }

      if (newBid >= 0.15) {
        keywordsChanged.push({
          campaignId: record.campaign_id,
          adGroupId: record.adgroup_id,
          keywordId: record.keyword_id,
          keyword: record.keyword,
          oldBid: parseFloat(record.bid || 0),
          bid: parseFloat(newBid.toFixed(2)),
        })
      }
    })

    // Remove duplicate entries.
    keywordsChanged =  [...new Map(keywordsChanged.map(item => [item.keywordId, item])).values()]

    if (!keywordsChanged.length) {
      toast.show({
        title: 'Warning',
        description: 'The minimum bid allowed is $0.15. Please check your keywords',
      })
      return
    }

    dispatch(changeKeywordBid({
      changeToNewBid: false,
      campaignType,
      keywords: keywordsChanged,
      adjustType: selectedAdjustBidOption.value,
      newAdjustBid: bidValue,
    }))
  }

  const handleChangeToMaxBid = () => {
    if (currentDetail && currentDetail.targeting_type === 'auto') {
      toast.show({
        title: 'Warning',
        description: 'Auto campaign cannot change keyword bid.',
      })
      return
    }

    let keywordsToChange = []

    keywords.filter(record => (
      selectedKeywords.indexOf(record.keyword_id) !== -1
    )).forEach((record) => {
      if (record.maxCpc
        && parseFloat(record.maxCpc) >= 0.15
        && record.keyword !== '(_targeting_auto_)') {
        keywordsToChange.push({
          keywordId: record.keyword_id,
          campaignId: record.campaign_id,
          adGroupId: record.adgroup_id,
          bid: parseFloat(parseFloat(record.maxCpc).toFixed(2)),
          changeToNewBid: true,
          campaignType,
        })
      }
    })

    if (!keywordsToChange.length) {
      toast.show({
        title: 'Warning',
        description: 'Selected keyword(s) has invalid suggested bid. '
          + 'The minimum bid allowed is $0.15 and '
          + 'auto campaign cannot change keyword bid. Please check your keywords.',
      })
      return
    }

    // Remove duplicate records.
    keywordsToChange = [...new Map(keywordsToChange.map(item => [item.keywordId, item])).values()]

    dispatch(changeKeywordBid({
      changeToNewBid: true,
      campaignType,
      keywords: keywordsToChange,
    }))
  }

  const renderAction = () => {
    if (!selectedKeywords.length) {
      return null
    }

    if (!isShowAdjustBid) {
      const isEnableDisabled = typeof keywords.find(record => (
        selectedKeywords.indexOf(record.keyword_id) !== -1
        && record.state !== 'enabled'
      )) === 'undefined'

      const isPauseDisabled = typeof keywords.find(record => (
        selectedKeywords.indexOf(record.keyword_id) !== -1
        && record.state !== 'paused'
      )) === 'undefined'

      return (
        <>
          <button
            type="button"
            className="btn btn-green"
            disabled={isChangingKeywordState || isEnableDisabled}
            onClick={() => { handleChangeState('enabled') }}
          >
            Enable
          </button>
          <button
            type="button"
            className="btn btn-red"
            disabled={isChangingKeywordState || isPauseDisabled}
            onClick={() => { handleChangeState('paused') }}
          >
            Pause
          </button>
          <button type="button" className="btn btn-light-blue" onClick={() => { setIsShowAdjustBid(true) }}>
            Adjust Bid
          </button>
          <button type="button" className="btn btn-blue" onClick={handleChangeToMaxBid}>
            Change to Genius Bid
          </button>
          <button type="button" className="btn btn-green" onClick={() => { handleCopy() }}>
            Copy
          </button>
        </>
      )
    }

    return (
      <BidAdjustComponent
        adjustBidOption={selectedAdjustBidOption}
        bidValue={bidValue}
        isAdjusting={isChangingKeywordBid}
        onChangeAdjustBidOption={setSelectedAdjustBidOption}
        onChangeBidValue={setBidValue}
        onApply={handleAdjustBid}
        onCancel={() => { setIsShowAdjustBid(false) }}
      />
    )
  }

  const renderKeyword = record => (
    <>
      <div className="table-col col-keyword" title={record.keyword}>
        <strong>
          { record.keyword }
        </strong>
        <div className="meta-data">
          { record.matchType } | { capitalizeFirstLetter(record.state) }
        </div>
      </div>
      <div className="table-col">
        { formatCurrency(record.bid, currencySign, currencyRate) }
      </div>
      <div className="table-col col-genius-bid">
        {
          typeof record.maxCpc !== 'undefined'
          ? formatCurrency(record.maxCpc, currencySign, currencyRate)
          : 'N/A'
        }
      </div>
      {
        bulkBidColumnList.map(column => (
          <TableCell
            key={column.key}
            record={record}
            columnKey={column.key}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  const isLoading = isChangingKeywordBid
    || isChangingKeywordState
    || isBidDataLoading

  return (
    <>
      <div className="filter-container">
        <div className="select-wrapper">
          <span>Match Type</span>
          <Select
            classNamePrefix="match-type-selector"
            options={matchTypes}
            value={selectedMatchType}
            onChange={setSelectedMatchType}
          />
        </div>
      </div>
      <SortableTable
        columns={columns}
        defaultSort={['cost', 'desc']}
        sorter={tableSorter(['state', 'keyword', 'matchType'])}
        className="table-keywords"
        records={keywords || []}
        idField="keyword_id"
        searchFields={['keyword']}
        selectedRecords={selectedKeywords}
        paginationSelectPlacement="top"
        hasSticky
        hasDateRange
        filterName="campaignDetailBidKeyword"
        isLoading={isLoading}
        renderRecord={renderKeyword}
        renderTopRight={renderAction}
        onChange={setSelectedKeywords}
      />
    </>
  )
}

export default KeywordTable
