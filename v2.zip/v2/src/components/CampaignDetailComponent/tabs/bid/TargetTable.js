import React, { useEffect, useState } from 'react'
import { useDispatch, useStore } from 'react-redux'
import * as Icon from 'react-icons/fi'

import SortableTable from '../../../CommonComponents/SortableTableComponent'
import { toast } from '../../../CommonComponents/ToastComponent/toast'
import BidAdjustComponent from '../../../CommonComponents/BidAdjustComponent'
import TableCell from '../../../CommonComponents/TableCell'

import {
  changeTarget,
} from '../../../../redux/actions/campaignDetail'

import {
  formatCurrency,
  copyToClipboard,
  tableSorter,
  parseTargetExp,
  calcDerivedMetrics,
  capitalizeFirstLetter,
  getAmazonLink,
} from '../../../../services/helper'

import {
  bulkBidColumnList,
  adjustBidOptions,
  ADJUST_BID_RAISE,
  ADJUST_BID_LOWER,
  ADJUST_BID_CPC,
} from '../../../../utils/defaultValues'

const columns = [
  { key: 'target_text', name: 'Automatic Targeting Defaults', className: 'col-target' },
  { key: 'bid', name: 'Current Bid' },
  { key: 'maxCpc', name: 'Genius Bid', className: 'col-genius-bid' },
  ...bulkBidColumnList,
]

const TargetTable = ({ campaignType, campaignId, adgroupId }) => {
  const dispatch = useDispatch()
  const store = useStore()

  const {
    header: {
      currencySign,
      currencyRate,
      selectedUserInfo,
    },
    campaignDetail: {
      currentAcos,
      isBidTargetDataLoading,
      isChangingTarget,
      bidTargetData,
    },
  } = store.getState()

  const [targets, setTargets] = useState([])
  const [selectedTargets, setSelectedTargets] = useState([])
  const [isShowAdjustBid, setIsShowAdjustBid] = useState(false)
  const [selectedAdjustBidOption, setSelectedAdjustBidOption] = useState(adjustBidOptions[0])
  const [bidValue, setBidValue] = useState(0)

  useEffect(() => {
    const extendedTargets = (bidTargetData || []).filter(record => (
      record.state !== 'archived'
    )).map((record) => {
      const derived = calcDerivedMetrics(record)
      let maxCpc
      if (parseInt(derived.clicks, 10) >= 3) {
        if (parseInt(derived.units, 10) && derived.clickOrder) {
          maxCpc = (parseFloat(derived.revenue) / parseInt(derived.units, 10))
            * (currentAcos / 100)
            / derived.clickOrder
        } else if (typeof derived.units === 'undefined' && parseInt(derived.clicks, 10)) {
          // For SB/SBV campaigns, the number of units is not available.
          maxCpc = parseFloat(derived.revenue) * (currentAcos / 100)  / parseInt(derived.clicks, 10)
        }

        if (maxCpc < 0.15) {
          maxCpc = 0.15
        }
      }

      return {
        ...derived,
        maxCpc,
      }
    })

    setTargets(extendedTargets)
  }, [currentAcos, bidTargetData])

  const callChangeTarget = (targets) => {
    const payload = {}
    if (campaignType === 'Sponsored Brands'
      || campaignType === 'Sponsored Brands Video') {
        payload.campaignId = Number(campaignId)
        payload.adGroupId = Number(adgroupId)
    }

    dispatch(changeTarget(targets.map(target => ({
      ...target,
      ...payload,
    })), campaignType))
  }

  const handleCopy = () => {
    const targetTexts = targets.filter(target => (
      selectedTargets.indexOf(target.target_id) !== -1
    )).map(keyword => keyword.target_text.trim())

    copyToClipboard([...new Set(targetTexts)].join('\n'))

    toast.show({
      title: 'Success',
      description: `Successfully copied ${selectedTargets.length} target${selectedTargets.length > 1 ? 's' : ''}.`
    })
  }

  const handleChangeState = (state) => {
    const targetsToChange = targets.filter(target => selectedTargets.indexOf(target.target_id) !== -1)
    callChangeTarget(targetsToChange.map(target => ({
      targetId: parseInt(target.target_id, 10),
      state,
    })))
  }

  const handleAdjustBid = () => {
    if (selectedAdjustBidOption.value !== ADJUST_BID_CPC
      && (bidValue === '' || isNaN(bidValue))) {
      toast.show({
        title: 'Warning',
        description: 'Please enter the valid bid value.',
      })
      return
    }

    let targetsToChange = []
    targets.filter(record => (
      selectedTargets.indexOf(record.target_id) !== -1
    )).forEach((record) => {
      let newBid = parseFloat(bidValue)
      if (selectedAdjustBidOption.value === ADJUST_BID_RAISE) {
        newBid = parseFloat(record.bid || 0) * (1 + (newBid / 100))
      } else if (selectedAdjustBidOption.value === ADJUST_BID_LOWER) {
        newBid = parseFloat(record.bid || 0) * (1 - (newBid / 100))
      } else if (selectedAdjustBidOption.value === ADJUST_BID_CPC) {
        newBid = parseFloat(record.cpc || 0)
      }

      if (newBid >= 0.15) {
        targetsToChange.push({
          targetId: parseInt(record.target_id, 10),
          bid: parseFloat(newBid.toFixed(2)),
        })
      }
    })

    if (!targetsToChange.length){
      toast.show({
        title: 'Warning',
        description: 'The minimum bid allowed is $0.15. Please check your targets',
      })
      return
    }

    callChangeTarget(targetsToChange)
  }

  const handleChangeToMaxBid = () => {
    const targetsToChange = []
    targets.filter(record => (
      selectedTargets.indexOf(record.target_id) !== -1
    )).forEach((record) => {
      if (record.maxCpc
        && parseFloat(record.maxCpc) >= 0.15) {
        targetsToChange.push({
          targetId: parseInt(record.target_id, 10),
          bid: parseFloat(parseFloat(record.maxCpc).toFixed(2)),
        })
      }
    })

    if (!targetsToChange.length) {
      toast.show({
        title: 'Warning',
        description: 'The minimum bid allowed is $0.15. Please check your targets.',
      })
      return
    }

    callChangeTarget(targetsToChange, campaignType)
  }

  const renderAction = () => {
    if (!selectedTargets.length) {
      return null
    }

    if (!isShowAdjustBid) {
      const isEnableDisabled = typeof targets.find(record => (
        selectedTargets.indexOf(record.target_id) !== -1
        && record.state !== 'enabled'
      )) === 'undefined'

      const isPauseDisabled = typeof targets.find(record => (
        selectedTargets.indexOf(record.target_id) !== -1
        && record.state !== 'paused'
      )) === 'undefined'

      return (
        <>
          <button
            type="button"
            className="btn btn-green"
            disabled={isChangingTarget || isEnableDisabled}
            onClick={() => { handleChangeState('enabled') }}
          >
            Enable
          </button>
          <button
            type="button"
            className="btn btn-red"
            disabled={isChangingTarget || isPauseDisabled}
            onClick={() => { handleChangeState('paused') }}
          >
            Pause
          </button>
          <button type="button" className="btn btn-light-blue" onClick={() => { setIsShowAdjustBid(true) }}>
            Adjust Bid
          </button>
          <button type="button" className="btn btn-blue" onClick={handleChangeToMaxBid}>
            Change to Genius Bid
          </button>
          <button type="button" className="btn btn-green" onClick={() => { handleCopy() }}>
            Copy
          </button>
        </>
      )
    }

    return (
      <BidAdjustComponent
        adjustBidOption={selectedAdjustBidOption}
        bidValue={bidValue}
        isAdjusting={isChangingTarget}
        onChangeAdjustBidOption={setSelectedAdjustBidOption}
        onChangeBidValue={setBidValue}
        onApply={handleAdjustBid}
        onCancel={() => { setIsShowAdjustBid(false) }}
      />
    )
  }

  const renderTargetCell = (record) => {
    const target = parseTargetExp(record.target_text)
    let link
    if (target.indexOf('asin=') === 0) {
      try {
        const parsed = JSON.parse(record.target_text)
        link = (
          <a
            href={`https://${getAmazonLink(selectedUserInfo)}/gp/product/${parsed[0].value}`}
            target="_blank"
            rel="noopener noreferrer"
          >
            <Icon.FiExternalLink size={16} />
          </a>
        )
      } catch (e) {
        //
      }
    } else if (target.indexOf('category=') === 0) {
      try {
        const parsed = JSON.parse(record.target_exp)
        link = (
          <a
            href={`https://${getAmazonLink(selectedUserInfo)}/b?node=${parsed[0].value}`}
            target="_blank"
            rel="noopener noreferrer"
          >
            <Icon.FiExternalLink size={16} />
          </a>
        )
      } catch (e) {
        //
      }
    }

    return (
      <div className="table-col col-target" title={target}>
        <div className="target-text-wrapper">
          <strong>
            { target }
          </strong>
          { link }
        </div>
        <div className="meta-data">
          { capitalizeFirstLetter(record.state) }
        </div>
      </div>
    )
  }

  const renderTarget = record => (
    <>
      { renderTargetCell(record) }
      <div className="table-col">
        { formatCurrency(record.bid, currencySign, currencyRate) }
      </div>
      <div className="table-col col-genius-bid">
        {
          typeof record.maxCpc !== 'undefined'
          ? formatCurrency(record.maxCpc, currencySign, currencyRate)
          : 'N/A'
        }
      </div>
      {
        bulkBidColumnList.map(column => (
          <TableCell
            key={column.key}
            record={record}
            columnKey={column.key}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  const isLoading = isBidTargetDataLoading || isChangingTarget

  return (
    <SortableTable
      columns={columns}
      defaultSort={['cost', 'desc']}
      sorter={tableSorter(['state', 'target_text'])}
      className="table-targets"
      records={targets || []}
      idField="target_id"
      searchFields={['target_text']}
      selectedRecords={selectedTargets}
      paginationSelectPlacement="top"
      hasSticky
      hasDateRange
      filterName="campaignDetailBidTarget"
      isLoading={isLoading}
      renderRecord={renderTarget}
      renderTopRight={renderAction}
      onChange={setSelectedTargets}
    />
  )
}

export default TargetTable
