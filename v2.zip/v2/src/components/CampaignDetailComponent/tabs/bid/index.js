import React, { useState, useEffect } from 'react'
import { useStore, useDispatch } from 'react-redux'
import { Tooltip, Whisper } from 'rsuite'

import BidTab from './BidTab'

import { ReactComponent as InfoSvg } from '../../../../assets/svg/info.svg'

import VideoLink from '../../../CommonComponents/VideoLink'

import {
  updateAcos,
} from '../../../../redux/actions/campaignDetail'

const tabList = [
  {
    value: 'all',
    label: 'All Keywords/Targets',
  },
  {
    value: 'below',
    label: 'Below Target ACOS',
  },
  {
    value: 'above',
    label: 'Above Target ACOS',
  },
]

const videoList = [
  { title: 'Bid Optimization Video', url: 'https://www.loom.com/embed/50b32cce01964b1cae9f4c78a5ed49d0' },
]

const BidOPTab = ({ campaignType }) => {
  const store = useStore()
  const dispatch = useDispatch()
  const {
    campaignDetail: {
      currentAdGroups,
      currentAcos,
      currentDetail,
    },
  } = store.getState()

  const [currentTab, setCurrentTab] = useState('above')
  const [currentAdGroup, setCurrentAdGroup] = useState(null)
  const [acos, setAcos] = useState(0)

  useEffect(() => {
    if (!currentAcos) {
      return
    }
    setAcos(currentAcos)
  }, [currentAcos])

  useEffect(() => {
    if (!currentAdGroups || !currentAdGroups.length || currentAdGroup) {
      return
    }
    setCurrentAdGroup(currentAdGroups[0])
  }, [currentAdGroups]) // eslint-disable-line

  const handleChangeAdGroup = (adGroup) => {
    setCurrentAdGroup(adGroup || null)
  }

  const handleChangeAcos = e => {
    if (!e.target.value) {
      return
    }
    setAcos(e.target.value)
  }

  const handleSaveAcos = () => {
    dispatch(
      updateAcos({
        campaignId: currentDetail.campaign_id,
        campaignType: campaignType,
        acos,
      })
    )
  }
  const isSameAcos = currentAcos === acos

  return (
    <div className="campaign-detail-bid-op campaign-detail-tab">
      <div className="tab-info">
        <div className="tab-title">
          Bid Optimizer
          <Whisper placement="right" trigger="hover" speaker={(
            <Tooltip>
              <p>Bid Optimizer is a tool that suggests a new bid “Genius Bid” based
              on performance and the ACoS Target that you have set.</p>
              <p>A minimum of 3 clicks is required before we suggest a “Genius Bid”.</p>
              <p>
                Note for Sponsored Product Ads: To match ACoS Targets
                by placement performance, use placement op recommendations instead.
              </p>
            </Tooltip>
          )}>
            <InfoSvg />
          </Whisper>
        </div>
        <div className="tab-description">
          Review target performance and change bid prices below.
        </div>
        <VideoLink
          videoList={videoList}
          modalTitle='Bid Optimizer'
        />
      </div>
      <div className="tab-list">
        {
          tabList.map((tab) => (
            <button
              key={tab.value}
              type="button"
              className={currentTab === tab.value ? "tab selected" : "tab"}
              onClick={() => { setCurrentTab(tab.value)}}
            >
              { tab.label }
            </button>
          ))
        }
      </div>
      <div className="adgroup-selector">
        <div className="adgroup-content">
          Ad group:
          {
            currentAdGroups.map(adGroup => (
              <button
                key={adGroup.adgroupid}
                type="button"
                className={`btn ${currentAdGroup && currentAdGroup.adgroupid === adGroup.adgroupid ? 'btn-blue' : 'btn-white'}`}
                onClick={() => { handleChangeAdGroup(adGroup) }}
              >
                { adGroup.name }
              </button>
            ))
          }
        </div>
        <div className="acos-container">
          <span>ACoS Target (%)</span>
          <input value={acos} type="number" onChange={handleChangeAcos} />
          {
            !isSameAcos && (
              <button type="button" className="btn btn-red" onClick={handleSaveAcos}>
                Save
              </button>
            )
          }
        </div>
      </div>
      {
        currentTab === 'above' && (
          <BidTab
            campaignType={campaignType}
            currentAdGroup={currentAdGroup}
            isProfitable={false}
          />
        )
      }
      {
        currentTab === 'below' && (
          <BidTab
            campaignType={campaignType}
            currentAdGroup={currentAdGroup}
            isProfitable
          />
        )
      }
      {
        currentTab === 'all' && (
          <BidTab
            campaignType={campaignType}
            currentAdGroup={currentAdGroup}
            isProfitable={''}
          />
        )
      }
    </div>
  )
}

export default BidOPTab
