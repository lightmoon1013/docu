import React, { useState, useMemo } from 'react'
import { useDispatch, useStore } from 'react-redux'
import Select from 'react-select'
import moment from 'moment'

import CustomTable from '../../../../CommonComponents/CustomTableComponent'

import {
  revertLog,
} from '../../../../../redux/actions/campaignLog'

import {
  getLogDescription,
  filterLogs,
} from '../../../../../services/helper'

import {
  logTypeOptions,
  REVERTABLE_LOG_TYPES,
} from '../../../../../utils/defaultValues'

const CATEGORY_AP = 'ap'

const categoryList = [
  { value: '', label: 'All Logs' },
  { value: CATEGORY_AP, label: 'Smart Pilot Logs' },
]

const LogSection = () => {
  const store = useStore()
  const dispatch = useDispatch()

  const {
    campaignDetail: {
      isLoading,
      currentLogs,
    },
    campaignLog: {
      isRevertingLog,
    },
  } = store.getState()

  const [currentCategory, setCurrentCategory] = useState(categoryList[0])
  const [currentType, setCurrentType] = useState(logTypeOptions[0])

  const handleRevert = log => () => {
    dispatch(revertLog(log.id, log.campaign_id))
  }

  const renderAction = () => {
    return (
      <>
        <Select
          className="category-selector"
          value={currentCategory}
          options={categoryList}
          onChange={setCurrentCategory}
        />
        <Select
          className="type-selector"
          value={currentType}
          options={logTypeOptions}
          onChange={setCurrentType}
        />
      </>
    )
  }

  const renderLogAction = (log) => {
    if (REVERTABLE_LOG_TYPES.indexOf(log.log_type) === -1) {
      return null
    }

    if (log.reverted) {
      return (
        <button
          type="button"
          className="btn btn-red"
          disabled
        >
          Reverted
        </button>
      )
    }

    return (
      <button
        type="button"
        className="btn btn-red"
        disabled={isRevertingLog}
        onClick={handleRevert(log)}
      >
        Revert
      </button>
    )
  }

  const renderLog = log => (
    <>
      <div className="table-col col-type">
        { log.type }
      </div>
      <div className="table-col col-created-at">
        { moment(log.created_at).local().format('M/D') }
      </div>
      <div
        className="table-col col-description"
        dangerouslySetInnerHTML={{
          __html: getLogDescription(log.log_type, log.description),
        }}
      />
      <div className="table-col col-contents">
        <div
          dangerouslySetInnerHTML={{
            __html: log.contents,
          }}
        />
      </div>
      <div className="table-col col-action">
        { renderLogAction(log) }
      </div>
    </>
  )

  let filteredLogs = useMemo(() => {
    return filterLogs(currentLogs || [], currentType)
  }, [currentLogs, currentType])

  if (currentCategory.value === CATEGORY_AP) {
    filteredLogs = filteredLogs.filter(log => (
      (log.log_type || '').indexOf('ap_') === 0
    ))
  }

  return (
    <div className="section">
      <div className="section-header">
        <h4>Logs</h4>
      </div>
      <CustomTable
        isLoading={isLoading || isRevertingLog}
        className="table-logs"
        records={filteredLogs}
        idField="id"
        searchFields={['contents']}
        noCheckBox
        paginationSelectPlacement="top"
        renderRecord={renderLog}
        renderTopRight={renderAction}
      >
        <div className="table-col col-type">Log Type</div>
        <div className="table-col col-created-at">Date</div>
        <div className="table-col col-description">Description</div>
        <div className="table-col col-contents">Detail</div>
        <div className="table-col col-action"></div>
      </CustomTable>
    </div>
  )
}

export default LogSection