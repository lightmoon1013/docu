import React, { useState, useEffect } from 'react'
import { useStore, useDispatch } from 'react-redux'
import { Tooltip, Whisper } from 'rsuite'
import Select from 'react-select'

import CheckboxComponent from '../../../CommonComponents/CheckboxComponent'
import LoaderComponent from '../../../CommonComponents/LoaderComponent'
import VideoLink from '../../../CommonComponents/VideoLink'

import { ReactComponent as InfoSvg } from '../../../../assets/svg/info.svg'

import STTab from './subTabs/STTab'
import TimeSavingFilterTab from './subTabs/TimeSavingFilterTab'

import {
  updateAcos,
} from '../../../../redux/actions/campaignDetail'

import { matchTypes } from '../../../../utils/filterDef'

const TAB_BELOW = 'below'
const TAB_ABOVE = 'above'
const TAB_TIME = 'time'

const tabs = [
  {
    value: TAB_BELOW,
    label: 'Below Target ACOS',
  },
  {
    value: TAB_ABOVE,
    label: 'Above Target ACOS',
  },
  {
    value: TAB_TIME,
    label: 'Time Saving Filters',
  },
]

const videoList = [
  { title: 'Search Term Optimization Video', url: 'https://www.loom.com/embed/3af123e23f35452b8e725a8016d2b938' },
]

const STOPTab = ({ campaignType }) => {
  const store = useStore()
  const dispatch = useDispatch()
  const {
    campaignDetail: {
      currentAcos,
      currentDetail,
      currentAdGroups,
      isSTDataLoading,
      isNegativeKWLoading,
    },
  } = store.getState()

  const [currentTab, setCurrentTab] = useState(TAB_ABOVE)
  const [currentAdGroupId, setCurrentAdGroupId] = useState(null)
  const [hideKeywords, setHideKeywords] = useState(true)
  const [hideAsins, setHideAsins] = useState(false)
  const [hideNegatedTerms, setHideNegatedTerms] = useState(true)
  const [acos, setAcos] = useState(0)
  const [selectedMatchType, setSelectedMatchType] = useState(matchTypes[0])

  const handleChangeAdGroup = (adGroup) => {
    setCurrentAdGroupId(adGroup ? adGroup.adgroupid : null)
  }

  useEffect(() => {
    if (!currentAcos) {
      return
    }
    setAcos(currentAcos)
  }, [currentAcos])

  const handleChangeAcos = e => {
    if (!e.target.value) {
      return
    }
    setAcos(e.target.value)
  }

  const handleSaveAcos = () => {
    dispatch(
      updateAcos({
        campaignId: currentDetail.campaign_id,
        campaignType: campaignType,
        acos,
      })
    )
  }

  const isSameAcos = currentAcos === acos
  if (campaignType === 'Sponsored Displays') {
    return null
  }

  const isLoading = isNegativeKWLoading || isSTDataLoading

  return (
    <div className="campaign-detail-st-op campaign-detail-tab">
      <div className="tab-info">
        <h4 className="tab-title">
          Search Term Optimization
          <Whisper placement="right" trigger="hover" speaker={(
            <Tooltip style={{ lineHeight: '30px' }}>
              <p style={{ fontSize: '14px' }}>Research and optimize your campaigns at the search term level
              without ever touching a spreadsheet.</p>
              <p style={{ fontSize: '14px' }}>Use the table on Non-Profitable Search Terms to do a deeper dive
              into search terms causing wasteful ad spend.</p>
              <p style={{ fontSize: '14px' }}>By default, ASINs and search terms already added as negatives
              to your campaign will be hidden.</p>
              <p style={{ fontSize: '14px' }}>Uncheck the Remove ASIN and/or New Terms Only boxes respectively to reveal them.</p>
            </Tooltip>
          )}>
            <InfoSvg />
          </Whisper>
        </h4>
        <VideoLink
          videoList={videoList}
          modalTitle='Search Term Optimization'
        />
      </div>
      <div className="tab-list">
        {
          tabs.map((tab) => (
            <button
              key={tab.value}
              type="button"
              className={currentTab === tab.value ? "tab selected" : "tab"}
              onClick={() => { setCurrentTab(tab.value)}}
            >
              { tab.label }
            </button>
          ))
        }
      </div>
      <div className="adgroup-selector">
        <div className="adgroup-content">
          Ad group:
          <button
            type="button"
            className={`btn ${!currentAdGroupId ? 'btn-blue' : 'btn-white'}`}
            onClick={() => { handleChangeAdGroup() }}
          >
            All ad groups
          </button>
          {
            (currentAdGroups || []).map(adGroup => (
              <button
                key={adGroup.adgroupid}
                type="button"
                className={`btn ${currentAdGroupId === adGroup.adgroupid ? 'btn-blue' : 'btn-white'}`}
                onClick={() => { handleChangeAdGroup(adGroup) }}
              >
                { adGroup.name }
              </button>
            ))
          }
        </div>
        <div className="acos-container">
          <span>ACoS Target (%)</span>
          <input value={acos} type="number" onChange={handleChangeAcos} />
          {
            !isSameAcos && (
              <button type="button" className="btn btn-red" onClick={handleSaveAcos}>
                Save
              </button>
            )
          }
        </div>
      </div>
      <div className="filter-container">
        <div className="checkbox-wrapper">
          <CheckboxComponent
            label="Remove Keywords"
            onChange={setHideKeywords}
            checked={hideKeywords}
          />
          <Whisper placement="right" trigger="hover" speaker={(
            <Tooltip>
              <p>Sometimes a keyword and search term are the same
              (ex: Exact match types), many times they are not.</p>
              <p>Checking this box means ONLY actual customer search
              terms will be revealed, not keywords.</p>
              <p>Using this will help you find customer search terms that are
              resulting in wasted ad spend.</p>
              <p>This way you can consider using them as NEGATIVE EXACT for your campaigns.</p>
            </Tooltip>
          )}>
            <InfoSvg />
          </Whisper>
        </div>
        <div className="checkbox-wrapper">
          <CheckboxComponent
            label="Remove already negated terms from results below"
            onChange={setHideNegatedTerms}
            checked={hideNegatedTerms}
          />
          <Whisper placement="right" trigger="hover" speaker={(
            <Tooltip>
              <p>Remove words already added as negative to this campaign and ad group.</p>
            </Tooltip>
          )}>
            <InfoSvg />
          </Whisper>
        </div>
        {
          currentTab !== TAB_TIME && (
            <div className="checkbox-wrapper">
              <CheckboxComponent
                label="Remove ASINS"
                checked={hideAsins}
                onChange={setHideAsins}
              />
            </div>
          )
        }
        {
          currentTab !== TAB_TIME && (
            <div className="select-wrapper">
              <span>Match Type</span>
              <Select
                classNamePrefix="match-type-selector"
                options={matchTypes}
                value={selectedMatchType}
                onChange={setSelectedMatchType}
              />
            </div>
          )
        }
      </div>
      <div className={`tab-content${isLoading ? ' loading' : ''}`}>
        { isLoading && <LoaderComponent /> }
        {
          currentTab === TAB_BELOW && (
            <STTab
              isProfitable
              campaignType={campaignType}
              currentAdGroupId={currentAdGroupId}
              hideKeywords={hideKeywords}
              hideNegatedTerms={hideNegatedTerms}
              hideAsins={hideAsins}
              selectedMatchType={selectedMatchType}
            />
          )
        }
        {
          currentTab === TAB_ABOVE && (
            <STTab
              campaignType={campaignType}
              currentAdGroupId={currentAdGroupId}
              hideKeywords={hideKeywords}
              hideNegatedTerms={hideNegatedTerms}
              hideAsins={hideAsins}
              selectedMatchType={selectedMatchType}
            />
          )
        }
        {
          currentTab === TAB_TIME && (
            <TimeSavingFilterTab
              campaignType={campaignType}
              currentAdGroupId={currentAdGroupId}
              hideKeywords={hideKeywords}
              hideNegatedTerms={hideNegatedTerms}
            />
          )
        }
      </div>
    </div>
  )
}

export default STOPTab
