import React, { useState, useEffect } from 'react'
import { useStore } from 'react-redux'

import SortableTable from '../../../CommonComponents/SortableTableComponent'
import ModalAddNegatives from '../../modals/ModalAddNegatives'

import {
  formatValue,
  tableSorter,
} from '../../../../services/helper'

const columns = [
  { key: 'term', name: 'Search Term', className: 'col-search-term' },
  { key: 'clicks', name: 'Clicks' },
  { key: 'impressions', name: 'Imp.' },
  { key: 'ctr', name: 'CTR %' },
]

const CtrTable = ({ campaignType, currentAdGroupId }) => {
  const store = useStore()

  const {
    campaignDetail: {
      isNegativeKWLoading,
      isKeywordRelatedDataLoading,
      negativeKWData,
      keywordRelatedData,
    },
  } = store.getState()

  const [terms, setTerms] = useState([])
  const [selectedSearchTerms, setSelectedSearchTerms] = useState([])
  const [showAddToCampaignModal, setShowAddToCampaignModal] = useState(false)

  useEffect(() => {
    if (!keywordRelatedData
        || !keywordRelatedData.termsWithLowCTR
        || !keywordRelatedData.termsWithLowCTR.length) {
      setTerms([])
      return
    }

    let filteredTerms = [...keywordRelatedData.termsWithLowCTR]

    if (negativeKWData && negativeKWData.length) {
      filteredTerms = filteredTerms.filter(term => (
        !negativeKWData.find(keyword => keyword.keywordText === term.term)
      ))
    }

    setTerms(filteredTerms)
  }, [keywordRelatedData, negativeKWData])

  const renderAction = () => {
    return (
      <>
        {
          selectedSearchTerms.length > 0 && (
            <button
              type="button"
              className="btn btn-green"
              onClick={() => { setShowAddToCampaignModal(true) }}
            >
              Add Negatives to Campaign
            </button>
          )
        }
      </>
    )
  }

  const renderSearchTerm = record => (
    <>
      <div className="table-col col-search-term" title={record.term}>
        { record.term }
      </div>
      <div className="table-col">
        { formatValue(record.clicks, 'removeZeroDecimal') }
      </div>
      <div className="table-col">
        { formatValue(record.impressions, 'removeZeroDecimal') }
      </div>
      <div className="table-col">
        { formatValue(record.ctr * 100, 'percent') }
      </div>
    </>
  )

  const selectedSTs = terms
    .filter(term => selectedSearchTerms.indexOf(term.id) !== -1)
    .map(st => ({
      ...st,
      search: st.term,
    }))

  const isLoading = isKeywordRelatedDataLoading || isNegativeKWLoading

  return (
    <div className="table-content">
      <h6>Search terms more than 1000 impress and less than .4 ctr</h6>
      <SortableTable
        isLoading={isLoading}
        columns={columns}
        defaultSort={['cost', 'desc']}
        sorter={tableSorter(['term'])}
        className="table-search-terms"
        records={terms}
        idField="id"
        searchFields={['term']}
        paginationSelectPlacement="top"
        hasSticky
        selectedRecords={selectedSearchTerms}
        renderRecord={renderSearchTerm}
        renderTopRight={renderAction}
        onChange={setSelectedSearchTerms}
      />
      <ModalAddNegatives
        terms={selectedSTs}
        modalType="keyword-cleaner"
        campaignType={campaignType}
        currentAdGroupId={currentAdGroupId}
        showModal={showAddToCampaignModal}
        onClose={() => { setShowAddToCampaignModal(false) }}
      />
    </div>
  )
}
export default CtrTable
