import React, { useState, useEffect } from 'react'
import { useDispatch, useStore } from 'react-redux'
import { Tooltip, Whisper } from 'rsuite'
import moment from 'moment'

import KeywordTable from './keywords-table'
import SalesTable from './sales-table'
import AcosTable from './nonprofitable-table'
import CtrTable from './low-ctr-table'

import { ReactComponent as InfoSvg } from '../../../../assets/svg/info.svg'

import VideoLink from '../../../CommonComponents/VideoLink'

import {
  updateAcos,
  getKeywordData,
} from '../../../../redux/actions/campaignDetail'

const videoList = [
  { title: 'Keyword Optimization Video', url: 'https://www.loom.com/embed/b0c3af42a05741ea99b905c66a564ba9' },
]

const KeywordCleanerTab = ({ campaignType }) => {
  const store = useStore()
  const dispatch = useDispatch()

  const {
    header: {
      currentStartDate,
      currentEndDate,
    },
    campaignDetail: { currentAdGroups, currentAcos, currentDetail },
  } = store.getState()

  const [currentAdGroupId, setCurrentAdGroupId] = useState('')
  const [acos, setAcos] = useState(0)

  useEffect(() => {
    if (!currentAcos) {
      return
    }
    setAcos(currentAcos)
  }, [currentAcos])


  useEffect(() => {
    if (!currentAdGroups || !currentAdGroups.length) {
      return
    }
    setCurrentAdGroupId(currentAdGroups[0].adgroupid)
  }, [currentAdGroups])

  useEffect(() => {
    if (!currentDetail) {
      return
    }

    dispatch(getKeywordData({
      campaignId: currentDetail.campaign_id,
      startDate: moment(currentStartDate).format('YYYY-MM-DD'),
      endDate: moment(currentEndDate).format('YYYY-MM-DD'),
    }))
  }, [currentDetail ? currentDetail.campaign_id : null, currentStartDate, currentEndDate]) // eslint-disable-line

  const handleChangeAdGroup = (adGroup) => {
    if (adGroup) {
      setCurrentAdGroupId(adGroup.adgroupid)
    } else {
      setCurrentAdGroupId(null)
    }
  }

  const handleChangeAcos = (event) => {
    if (!event.target.value) {
      return
    }
    setAcos(event.target.value)
  }

  const handleSaveAcos = () => {
    dispatch(updateAcos({
      campaignId: currentDetail.campaign_id,
      campaignType,
      acos,
    }))
  }

  if (campaignType === 'Sponsored Displays'
    || campaignType === 'Sponsored Brands'
    || campaignType === 'Sponsored Brands Video') {
    return null
  }

  const isSameAcos = currentAcos === acos
  return (
    <div className="campaign-detail-keyword-cleaner campaign-detail-tab">
      <div className="tab-info">
        <div className="tab-title">
          Keyword Cleaner
          <Whisper placement="right" trigger="hover" speaker={(
            <Tooltip>
              <p>Keyword Cleaner allows you to research problematic search terms
              on a keyword level - click a keyword below to reveal the search terms
              they’ve connected with.</p>
              <p>You’ll then be able to optimize out any search terms that have clicks without sales,
              high ACoS, or CTR issues.</p>
              <p>This is a great way to reduce the ACoS of a keyword without
              lowering the bid.</p>
              <p>Keyword Cleaner does not work with Exact Match Keywords.</p>
            </Tooltip>
          )}>
            <InfoSvg />
          </Whisper>
        </div>
        <div className="tab-description">
          Click on a Keyword to See Unprofitable Search Terms Below.
        </div>
        <VideoLink
          videoList={videoList}
          modalTitle='Keyword Cleaner Optimization'
        />
      </div>
      <div className="adgroup-selector">
        <div className="adgroup-content">
          Ad group:
          <button
            type="button"
            className={`btn ${!currentAdGroupId ? 'btn-blue' : 'btn-white'}`}
            onClick={() => { handleChangeAdGroup() }}
          >
            All ad groups
          </button>
          {
            (currentAdGroups || []).map(adGroup => (
              <button
                key={adGroup.adgroupid}
                type="button"
                className={`btn ${currentAdGroupId === adGroup.adgroupid ? 'btn-blue' : 'btn-white'}`}
                onClick={() => { handleChangeAdGroup(adGroup) }}
              >
                { adGroup.name }
              </button>
            ))
          }
        </div>
        <div className="acos-container">
          <span>ACoS Target (%)</span>
          <input value={acos} type="number" onChange={handleChangeAcos} />
          {
            !isSameAcos && (
              <button type="button" className="btn btn-red" onClick={handleSaveAcos}>
                Save
              </button>
            )
          }
        </div>
      </div>
      <KeywordTable
        currentAdGroupId={currentAdGroupId}
      />
      <div className="results-container">
        <h5>Keyword Cleaner Results</h5>
        <div className="results-tables">
          <SalesTable
            currentAdGroupId={currentAdGroupId}
            campaignType={campaignType}
          />
          <AcosTable
            currentAdGroupId={currentAdGroupId}
            campaignType={campaignType}
          />
          <CtrTable
            currentAdGroupId={currentAdGroupId}
            campaignType={campaignType}
          />
        </div>
      </div>
    </div>
  )
}

export default KeywordCleanerTab
