import React, { useState, useEffect } from 'react'
import { useDispatch, useStore } from 'react-redux'
import Select from 'react-select'
import moment from 'moment'

import SortableTable from '../../../CommonComponents/SortableTableComponent'

import {
  getNegativeKWData,
  getKeywordRelatedData,
} from '../../../../redux/actions/campaignDetail'

import {
  formatValue,
  formatCurrency,
  capitalizeFirstLetter,
  tableSorter,
  calcDerivedMetrics,
} from "../../../../services/helper"

import { matchTypes } from '../../../../utils/filterDef'

const columns = [
  { key: 'keyword', name: 'Keyword', className: 'col-keyword' },
  { key: 'matchType', name: 'Match Type' },
  { key: 'orders', name: 'Orders' },
  { key: 'acos', name: 'ACoS %' },
  { key: 'revenue', name: 'Sales' },
  { key: 'cost', name: 'Spend' },
  { key: 'impressions', name: 'Imp.' },
  { key: 'clicks', name: 'Clicks' },
  { key: 'cpc', name: 'Ave CPC' },
]

const KeywordTable = ({ currentAdGroupId }) => {
  const store = useStore()
  const dispatch = useDispatch()

  const {
    header: {
      currentStartDate,
      currentEndDate,
      currencySign,
      currencyRate,
    },
    campaignDetail: {
      currentDetail,
      currentAcos,
      currentAdGroups,
      isKeywordDataLoading,
      keywordData,
    },
  } = store.getState()

  const [keywords, setKeywords] = useState([])
  const [selectedMatchType, setSelectedMatchType] = useState(matchTypes[0])

  useEffect(() => {
    if (!keywordData || !keywordData.length) {
      return
    }

    let filtereKeywords = []
    if (!currentAdGroupId) {
      filtereKeywords = keywordData[0]
    } else {
      filtereKeywords = keywordData[1].filter(keyword => keyword.adgroup_id === currentAdGroupId)
    }

    if (selectedMatchType.value !== '') {
      filtereKeywords = filtereKeywords.filter(record => (
        (record.match_type || '').toLowerCase() === selectedMatchType.value
      ))
    }

    filtereKeywords = filtereKeywords.map(keyword => ({
      ...calcDerivedMetrics(keyword),
      matchType: capitalizeFirstLetter(keyword.match_type),
    }))

    setKeywords(filtereKeywords)
  }, [keywordData, currentAdGroupId, selectedMatchType])

  const handleKeywordClick = (keyword) => {
    dispatch(getKeywordRelatedData({
      campaignId: currentDetail.campaign_id,
      startDate: moment(currentStartDate).format('YYYY-MM-DD'),
      endDate: moment(currentEndDate).format('YYYY-MM-DD'),
      keyword: keyword.keyword,
      matchType: keyword.match_type,
      acosProfitZone: currentAcos,
    }))

    let adGroupIds
    if (currentAdGroupId) {
      adGroupIds = currentAdGroupId
    } else {
      if (currentAdGroups && currentAdGroups.length > 0) {
        adGroupIds = currentAdGroups.map(adGroup => adGroup.adgroupid).join()
      }
    }
    dispatch(getNegativeKWData({
      campaignId: currentDetail.campaign_id,
      adGroupIds,
    }))

    document.querySelector('.main-content').scrollTop
      = document.querySelector('.results-container').getBoundingClientRect().top
  }

  const renderKeyword = record => (
    <>
      <div className="table-col col-keyword" title={record.keyword}>
        { record.keyword }
      </div>
      <div className="table-col">
        { record.matchType }
      </div>
      <div className="table-col">
        { formatValue(record.orders, 'removeZeroDecimal') }
      </div>
      <div className="table-col">
        { formatValue(record.acos, 'percent') }
      </div>
      <div className="table-col">
        { formatCurrency(record.revenue, currencySign, currencyRate) }
      </div>
      <div className="table-col">
        { formatCurrency(record.cost, currencySign, currencyRate) }
      </div>
      <div className="table-col">
        { formatValue(record.impressions, 'removeZeroDecimal') }
      </div>
      <div className="table-col">
        { formatValue(record.clicks, 'removeZeroDecimal') }
      </div>
      <div className="table-col">
        { formatCurrency(record.cpc, currencySign, currencyRate) }
      </div>
    </>
  )

  return (
    <>
      <div className="filter-container">
        <div className="select-wrapper">
          <span>Match Type</span>
          <Select
            classNamePrefix="match-type-selector"
            options={matchTypes}
            value={selectedMatchType}
            onChange={setSelectedMatchType}
          />
        </div>
      </div>
      <SortableTable
        columns={columns}
        defaultSort={['cost', 'desc']}
        sorter={tableSorter(['keyword', 'matchType'])}
        className="table-keywords"
        records={keywords}
        idField="id"
        searchFields={['keyword']}
        noCheckBox
        hasDateRange
        filterName="campaignDetailKeywordCleaner"
        paginationSelectPlacement="top"
        hasSticky
        isLoading={isKeywordDataLoading}
        renderRecord={renderKeyword}
        onClickRecord={handleKeywordClick}
      />
    </>
  )
}

export default KeywordTable
