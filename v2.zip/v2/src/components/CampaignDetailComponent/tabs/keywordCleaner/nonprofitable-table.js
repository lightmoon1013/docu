import React, { useState, useEffect } from 'react'
import { useStore } from 'react-redux'

import SortableTable from '../../../CommonComponents/SortableTableComponent'
import ModalAddNegatives from '../../modals/ModalAddNegatives'

import {
  formatValue,
  formatCurrency,
  tableSorter,
} from '../../../../services/helper'

const columns = [
  { key: 'term', name: 'Search Term', className: 'col-search-term' },
  { key: 'clicks', name: 'Clicks' },
  { key: 'acos', name: 'ACoS %' },
  { key: 'cost', name: 'Spend' },
  { key: 'sales', name: 'Sales' },
]

const AcosTable = ({ campaignType, currentAdGroupId }) => {
  const store = useStore()

  const {
    header: {
      currencySign,
      currencyRate,
    },
    campaignDetail: {
      isNegativeKWLoading,
      isKeywordRelatedDataLoading,
      negativeKWData,
      keywordRelatedData,
    },
  } = store.getState()

  const [terms, setTerms] = useState([])
  const [selectedSearchTerms, setSelectedSearchTerms] = useState([])
  const [showAddToCampaignModal, setShowAddToCampaignModal] = useState(false)

  useEffect(() => {
    if (!keywordRelatedData
        || !keywordRelatedData.unprofitableTerms
        || !keywordRelatedData.unprofitableTerms.length) {
      setTerms([])
      return
    }

    let filteredTerms = [...keywordRelatedData.unprofitableTerms]

    if (negativeKWData && negativeKWData.length) {
      filteredTerms = filteredTerms.filter(term => (
        !negativeKWData.find(keyword => keyword.keywordText === term.term)
      ))
    }

    filteredTerms = filteredTerms.map((term) => {
      let acos = 0
      if (parseFloat(term.sales)) {
        acos = parseFloat(term.cost) / parseFloat(term.sales) * 100
      }

      return {
        ...term,
        acos,
      }
    })

    setTerms(filteredTerms)
  }, [keywordRelatedData, negativeKWData])

  const renderAction = () => {
    return (
      <>
        {
          selectedSearchTerms.length > 0 && (
            <button
              type="button"
              className="btn btn-green"
              onClick={() => { setShowAddToCampaignModal(true) }}
            >
              Add Negatives to Campaign
            </button>
          )
        }
      </>
    )
  }

  const renderSearchTerm = record => (
    <>
      <div className="table-col col-search-term" title={record.term}>
        { record.term }
      </div>
      <div className="table-col">
        { formatValue(record.clicks, 'removeZeroDecimal') }
      </div>
      <div className="table-col">
        { formatValue(record.acos, 'percent') }
      </div>
      <div className="table-col">
        { formatCurrency(record.cost, currencySign, currencyRate) }
      </div>
      <div className="table-col">
        { formatCurrency(record.sales, currencySign, currencyRate) }
      </div>
    </>
  )

  const selectedSTs = terms
    .filter(term => selectedSearchTerms.indexOf(term.id) !== -1)
    .map(st => ({
      ...st,
      search: st.term,
    }))

  const isLoading = isKeywordRelatedDataLoading || isNegativeKWLoading

  return (
    <div className="table-content">
      <h6>Unprofitable search terms (based on acos)</h6>
      <SortableTable
        isLoading={isLoading}
        columns={columns}
        defaultSort={['cost', 'desc']}
        sorter={tableSorter(['term'])}
        className="table-search-terms"
        records={terms}
        idField="id"
        searchFields={['term']}
        paginationSelectPlacement="top"
        hasSticky
        selectedRecords={selectedSearchTerms}
        renderRecord={renderSearchTerm}
        renderTopRight={renderAction}
        onChange={setSelectedSearchTerms}
      />
      <ModalAddNegatives
        terms={selectedSTs}
        modalType="keyword-cleaner"
        campaignType={campaignType}
        showModal={showAddToCampaignModal}
        currentAdGroupId={currentAdGroupId}
        onClose={() => { setShowAddToCampaignModal(false) }}
      />
    </div>
  )
}

export default AcosTable
