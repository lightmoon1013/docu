import React, { useState, useEffect } from 'react'
import { useDispatch, useStore } from 'react-redux'
import { useParams } from 'react-router-dom'
import moment from 'moment'
import { Tooltip, Whisper } from 'rsuite'

import { ReactComponent as InfoSvg } from '../../../../assets/svg/info.svg'

import SortableTable from '../../../CommonComponents/SortableTableComponent'
import { toast } from '../../../CommonComponents/ToastComponent/toast'
import VideoLink from '../../../CommonComponents/VideoLink'
import CheckboxComponent from '../../../CommonComponents/CheckboxComponent'

import {
  getPlacementData,
  updatePlacementBidding,
  applyPlacementBidding,
} from '../../../../redux/actions/campaignDetail'

import {
  updateAcos,
} from '../../../../redux/actions/campaignDetail'

import {
  formatValue,
  formatCurrency,
  tableSorter,
  calcDerivedMetrics,
} from '../../../../services/helper'

const columns = [
  { key: 'check', name: '', className: 'col-check' },
  { key: 'placementText', name: 'Placement', className: 'col-placement' },
  { key: 'strategy', name: 'Bidding Strategy', className: 'col-strategy' },
  { key: 'currentBidAdjustment', name: 'Current Modifier' },
  { key: 'newBidAdjustment', name: 'Recomm Modifier' },
  { key: 'baseBid', name: 'Recomm Base Bid' },
  { key: 'revenue', name: 'Sales' },
  { key: 'cost', name: 'Spend' },
  { key: 'impressions', name: 'Imp.' },
  { key: 'clicks', name: 'Clicks' },
  { key: 'ctr', name: 'CTR %' },
  { key: 'cpc', name: 'Ave CPC' },
  { key: 'orders', name: 'Orders' },
  { key: 'acos', name: 'ACoS %' },
]

const videoList = [
  { title: 'Placement Optimization Video', url: 'https://www.loom.com/embed/fbb097c69f4e4bb0b8b5480c6d2cda74' },
]

const PLACEMENT_REST_OF_SEARCH = 'placementRestOfSearch'

const placementList = {
  placementTop: 'Top of search (first page)',
  placementProductPage: 'Product pages',
  [PLACEMENT_REST_OF_SEARCH]: 'Rest of search',
}

const MAX_BID_CHANGE = 900

const PlacementOPTab = ({ campaignType }) => {
  const store = useStore()
  const dispatch = useDispatch()

  const {
    header: {
      currentStartDate,
      currentEndDate,
      currencyRate,
      currencySign,
    },
    campaignDetail: {
      currentAcos,
      currentDetail,
      isPlacementDataLoading,
      placementData,
      isUpdatingPlacementBid,
    },
  } = store.getState()

  const { id: campaignId } = useParams()

  const [placements, setPlacements] = useState([])
  const [selectedPlacement, setSelectedPlacement] = useState(null)
  const [newBidVal, setNewBidVal] = useState(0)
  const [acos, setAcos] = useState(0)

  useEffect(() => {
    if (!currentAcos) {
      return
    }
    setAcos(currentAcos)
  }, [currentAcos])

  useEffect(() => {
    if (!campaignId || !currentStartDate || !currentEndDate) {
      return
    }
    dispatch(getPlacementData({
      campaignId,
      startDate: moment(currentStartDate).format('YYYY-MM-DD'),
      endDate: moment(currentEndDate).format('YYYY-MM-DD'),
    }))
  }, [campaignId, currentStartDate, currentEndDate]) // eslint-disable-line

  useEffect(() => {
    let strategy = 'Fixed bid'
    const adjustmentsByPlacement = {}
    if (currentDetail.bidding) {
      if (currentDetail.bidding.strategy) {
        if (currentDetail.bidding.strategy === 'legacyForSales') {
          strategy = 'Dynamic bids - down only'
        } else if (currentDetail.bidding.strategy === 'autoForSales') {
          strategy = 'Dynamic bids - up and down'
        } else {
          strategy = 'Fixed bid'
        }
      }

      if (currentDetail.bidding.adjustments) {
        currentDetail.bidding.adjustments.forEach((adjustment) => {
          adjustmentsByPlacement[adjustment.predicate] = adjustment.percentage
        })
      }
    }

    let worstAcos = 0
    const records = Object.keys(placementList).map((placement) => {
      const currentBidAdjustment = adjustmentsByPlacement[placement] || 0

      const derived = calcDerivedMetrics({
        placement,
        placementText: placementList[placement],
        strategy,
        currentBidAdjustment,
        revenue: placementData[placement] ? placementData[placement].revenue : 0,
        cost: placementData[placement] ? placementData[placement].cost : 0,
        clicks: placementData[placement] ? placementData[placement].clicks : 0,
        impressions: placementData[placement] ? placementData[placement].impressions : 0,
        orders: placementData[placement] ? placementData[placement].orders : 0,
      })

      let newBidAdjustment = 0
      if (derived.acos) {
        newBidAdjustment = Math.min(
          Math.ceil(currentBidAdjustment * (acos / derived.acos)),
          MAX_BID_CHANGE
        )

        if (!worstAcos || worstAcos < derived.acos) {
          worstAcos = derived.acos
        }
      }

      return Object.assign(derived, {
        newBidAdjustment,
      })
    })

    let baseBid = 0
    if (worstAcos) {
      baseBid = Math.ceil(acos / worstAcos * 100) - 100
    }

    setPlacements(records.map(record => Object.assign(record, {
      baseBid,
    })))
  }, [currentDetail, placementData, acos])

  const handleChangeAcos = (event) => {
    if (!event.target.value) {
      return
    }
    setAcos(event.target.value)
  }

  const handleSaveAcos = () => {
    dispatch(updateAcos({
      campaignId,
      campaignType,
      acos,
    }))
  }

  const handleAdjustBid = () => {
    const bidChange = parseInt(newBidVal, 10)
    if (newBidVal === '' || isNaN(bidChange)) {
      toast.show({
        title: 'Warning',
        description: 'Please enter a valid bid value.',
      })
      return
    }

    if (bidChange < 0 || bidChange > MAX_BID_CHANGE) {
      toast.show({
        title: 'Warning',
        description: `A new bid value must be between 0 and ${MAX_BID_CHANGE}.`,
      })
      return
    }

    const bidding = Object.assign({}, currentDetail.bidding || {})
    const adjustments = [...bidding.adjustments || []]
    const index = adjustments.findIndex(adjustment => adjustment.predicate === selectedPlacement)
    if (index !== -1) {
      adjustments[index] = Object.assign({}, adjustments[index], {
        percentage: bidChange,
      })
    } else {
      adjustments.push({
        predicate: selectedPlacement,
        percentage: bidChange,
      })
    }
    bidding.adjustments = adjustments

    dispatch(updatePlacementBidding({
      campaignId,
      bidding,
      oldBidding: currentDetail.bidding || {},
    }))
  }

  const handleApplyRecommendation = () => {
    const bidding = Object.assign({}, currentDetail.bidding || {})
    bidding.adjustments = []
    placements.forEach((placement) => {
      if (placement.placement === PLACEMENT_REST_OF_SEARCH) {
        return
      }
      bidding.adjustments.push({
        predicate: placement.placement,
        percentage: placement.newBidAdjustment,
      })
    })

    dispatch(applyPlacementBidding({
      campaignId,
      bidding,
      oldBidding: (currentDetail || {}).bidding || {},
      baseBid: placements[0].baseBid,
    }))
  }

  const renderAcos = () => {
    const isSameAcos = currentAcos === acos

    return (
      <div className="acos-container">
        <span>ACoS Target (%)</span>
        <input
          type="number"
          value={acos}
          onChange={handleChangeAcos}
        />
        {
          !isSameAcos && (
            <button type="button" className="btn btn-red" onClick={handleSaveAcos}>
              Save
            </button>
          )
        }
      </div>
    )
  }

  const renderAction = () => {
    if (selectedPlacement && selectedPlacement !== PLACEMENT_REST_OF_SEARCH) {
      return (
        <>
          <input
            type="number"
            placeholder="Enter Bid Value"
            value={newBidVal}
            onChange={(event) => { setNewBidVal(parseInt(event.target.value, 10)) }}
          />
          <button
            type="button"
            className="btn btn-white"
            disabled={isUpdatingPlacementBid}
            onClick={handleAdjustBid}
          >
            Update
          </button>
        </>
      )
    }

    return (
      <button
        type="button"
        className="btn btn-blue"
        disabled={isUpdatingPlacementBid}
        onClick={handleApplyRecommendation}
      >
        Apply Recommendations
      </button>
    )
  }

  const renderPlacement = record => (
    <>
      <div className="table-col col-check">
        {
          record.placement !== PLACEMENT_REST_OF_SEARCH && (
            <CheckboxComponent
              checked={selectedPlacement === record.placement}
              onChange={(checked) => { setSelectedPlacement(checked ? record.placement : null) }}
            />
          )
        }
      </div>
      <div className="table-col col-placement">
        { record.placementText }
      </div>
      <div className="table-col col-strategy">
        { record.strategy }
      </div>
      <div className="table-col">
        {
          record.placement !== PLACEMENT_REST_OF_SEARCH
          ? formatValue(record.currentBidAdjustment, 'percent', 0)
          : ''
        }
      </div>
      <div className="table-col">
        {
          record.placement !== PLACEMENT_REST_OF_SEARCH
          ? formatValue(record.newBidAdjustment, 'percent', 0)
          : ''
        }
      </div>
      <div className="table-col">
        {
          record.placement !== PLACEMENT_REST_OF_SEARCH
          ? formatValue(record.baseBid, 'percent', 0)
          : ''
        }
      </div>
      <div className="table-col">
        { formatCurrency(record.revenue, currencySign, currencyRate) }
      </div>
      <div className="table-col">
        { formatCurrency(record.cost, currencySign, currencyRate) }
      </div>
      <div className="table-col">
        { formatValue(record.impressions, 'removeZeroDecimal') }
      </div>
      <div className="table-col">
        { formatValue(record.clicks, 'removeZeroDecimal') }
      </div>
      <div className="table-col">
        { formatValue(record.ctr, 'percent') }
      </div>
      <div className="table-col">
        { formatCurrency(record.cpc, currencySign, currencyRate) }
      </div>
      <div className="table-col">
        { formatValue(record.orders, 'removeZeroDecimal') }
      </div>
      <div className="table-col">
        { formatValue(record.acos, 'percent') }
      </div>
    </>
  )

  if (campaignType === 'Sponsored Displays' || campaignType === 'Sponsored Brands') {
    return null
  }

  return (
    <div className="campaign-detail-placement-op campaign-detail-tab">
      <div className="tab-info">
        <div className="tab-title">
          Placement Optimization
          <Whisper placement="right" trigger="hover" speaker={(
            <Tooltip>
              <p>
                By applying the recommendations, you’ll be adjusting
                the base bid of each target while adjusting the placements
                for both top of search and product pages
                to help match your overall ACoS target for the campaign.
              </p>
              <p>
                You can also adjust each placement separately by selecting them first.
              </p>
            </Tooltip>
          )}>
            <InfoSvg />
          </Whisper>
        </div>
        <VideoLink
          videoList={videoList}
          modalTitle='Placement Optimization'
        />
        { renderAcos() }
      </div>
      <SortableTable
        isLoading={isPlacementDataLoading || isUpdatingPlacementBid}
        columns={columns}
        defaultSort={['cost', 'desc']}
        sorter={tableSorter(['placementText', 'strategy'])}
        className="table-placements"
        records={placements}
        idField="placement"
        searchFields={['placement']}
        paginationSelectPlacement="top"
        noCheckBox
        hasSticky
        hasDateRange
        filterName="campaignDetailPlacement"
        renderRecord={renderPlacement}
        renderTopRight={renderAction}
      />
    </div>
  )
}

export default PlacementOPTab
