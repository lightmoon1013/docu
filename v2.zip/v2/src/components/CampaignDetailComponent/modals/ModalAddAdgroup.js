import React, { useEffect, useState } from 'react'
import { useDispatch, useStore } from 'react-redux'
import { useLocation } from 'react-router-dom'
import Select from 'react-select'
import { Modal } from 'rsuite'

import LoaderComponent from '../../CommonComponents/LoaderComponent'
import { toast } from '../../CommonComponents/ToastComponent/toast'
import ProductModal from '../../CampaignCreator/ProductModal'
import ManualTargetingSelector from '../../CampaignCreator/ManualTargetingSelector'
import KeywordSection from '../../AdgroupCreator/KeywordSection'
import NegativeKeywordSection from '../../CampaignCreator/NegativeKeywordSection'
import TargetingSection from '../../AdgroupCreator/TargetingSection'
import NegativeTargetingSection from '../../AdgroupCreator/NegativeTargetingSection'

import SDTargetingSection from '../../AdgroupCreator/SDTargetingSection'
import AudienceSection from '../../AdgroupCreator/AudienceSection'
// import SDCreativeSection from '../../CampaignCreator/SDCreativeSection'

import { ReactComponent as CloseSvg } from '../../../assets/svg/close.svg'

import { campaignTypeMap } from '../../../utils/defaultValues'

import { createSPAdgroup, getSPSuggestions, getSuggestedKeywordBids, getSDSuggestions, createSDAdgroup } from '../../../redux/actions/campaignCreator'
import { getAllCategories, getProductsBySearchText } from '../../../redux/actions/targeting'

const MIN_DEFAULT_BID = 0.02

const bidOpOptions = [
  { value: 'clicks', label: 'Optimize for page visits' },
  { value: 'conversions', label: 'Optimize for conversion' },
]

const CampaignOption = (props) => {
  const { innerRef, innerProps, getStyles, data } = props
  return (
    <div
      ref={innerRef}
      {...innerProps}
      style={getStyles('option', props)}
      className="campaign-option"
    >
      <div>
        { data.campaign }
      </div>
      <div className="campaign-detail">
        {
          data.campaignType === 'Sponsored Products' && (
            <span>
              { data.targeting_type === 'auto' ? 'Auto' : 'Manual' }
            </span>
          )
        }
        <span>
          { campaignTypeMap[data.campaignType] }
        </span>
      </div>
    </div>
  )
}

const ModalAddAdgroup = ({ show, campaigns = [], campaignDetail = null, onCreate, onCancel }) => {
  const dispatch = useDispatch()
  const store = useStore().getState()
  const location = useLocation()

  const {
    campaignCreator,
  } = store
  const { isSuggestedBidsLoading, suggestedBids, isAllCategoriesLoading, isCreatingAdgroup } = campaignCreator

  const [selectedCampaign, setSelectedCampaign] = useState(null)
  const [name, setName] = useState('')
  const [defaultBid, setDefaultBid] = useState(MIN_DEFAULT_BID)
  const [selectedBidOp, setSelectedBidOp] = useState(bidOpOptions[0])
  const [products, setProducts] = useState([])
  const [openProductModal, setOpenProductModal] = useState(false)

  const [target, setTarget] = useState('manual')
  const [manualTarget, setManualTarget] = useState('keyword')

  const [keywords, setKeywords] = useState([])
  const [negativeKeywords, setNegativeKeywords] = useState([])
  const [targetings, setTargetings] = useState([])
  const [negativeTargetings, setNegativeTargetings] = useState([])
  

  useEffect(() => {
    dispatch(getAllCategories())
  }, []) // eslint-disable-line

  useEffect(() => {
    if(show) {
      setTargetings([])
      setName('')
      setProducts([])
      setKeywords([])
      setNegativeKeywords([])
      setTargetings([])
      setNegativeTargetings([])
    }

  }, [show])
  useEffect(() => {
    if (campaignDetail) {
      setSelectedCampaign(campaignDetail)
      setTarget(campaignDetail.targetingType)
    }
  }, [campaignDetail])
  useEffect(() => {
    if (isSuggestedBidsLoading || !suggestedBids || suggestedBids.length === 0) {
      return
    }

    setKeywords(keywords.map((keyword) => {
      const suggestedBid = suggestedBids.filter(bid => (
        bid.keywordText === keyword.keywordText && bid.matchType === keyword.matchType
      ))
      if (suggestedBid.length) {
        return {
          ...keyword,
          suggestedBid: suggestedBid[0].suggestedBid,
        }
      }
      return keyword
    }))
  }, [suggestedBids, isSuggestedBidsLoading]) // eslint-disable-line

  useEffect(() => {
    if (location.state) {
      if (location.state.targets && location.state.targets.length) {
        setKeywords(location.state.targets.map((target, index) => ({
          id: index,
          keywordText: target,
          matchType: 'broad',
          keywordBid: 0,
        })))

        const asinTargets = location.state.targets
          .filter(target => /^[0-9a-z]{10}$/ig.test(target))

        if (asinTargets.length) {
          dispatch(getProductsBySearchText({
            asins: asinTargets.join(),
          }, true)).then((response) => {
            setTargetings(response.Item.map(product => ({
              ...product,
              name: product.name || product.ItemAttributes.Title,
              isTargeted: true,
              type: 'product',
              bid: 0,
            })))
          })
        }
      }

      if (location.state.categories && location.state.categories.length) {
        setTargetings(location.state.categories.map(category => ({
          ...category,
          type: 'category',
          bid: 0,
        })))
      }

      if (location.state.productTargeting) {
        setManualTarget('product')
      }
    }
  }, [location.state]) // eslint-disable-line

  const getProductTargets = () => {
    const targets = []
    targetings.forEach((targeting) => {
      const payload = {
        expressionType: 'manual',
        state: 'enabled',
        bid: targeting.bid,
        expression: [],
        expressionResolve: [],
      }
      switch (targeting.type) {
        case 'category':
          payload.expression.push({
            type: 'asinCategorySameAs',
            value: targeting.id,
          })
          payload.expressionResolve.push({
            type: 'asinCategorySameAs',
            value: targeting.name,
          })
          break
        case 'product':
          payload.expression.push({
            type: 'asinSameAs',
            value: targeting.ASIN,
          })
          payload.expressionResolve.push({
            type: 'asinSameAs',
            value: targeting.ASIN,
          })
          break
        case 'refine':
          payload.expression.push({
            type: 'asinCategorySameAs',
            value: targeting.id,
          })
          payload.expressionResolve.push({
            type: 'asinCategorySameAs',
            value: targeting.name,
          })

          if (targeting.brandId) {
            payload.expression.push({
              type: 'asinBrandSameAs',
              value: targeting.brandId,
            })
            payload.expressionResolve.push({
              type: 'asinBrandSameAs',
              value: targeting.brandName,
            })
          }

          if (targeting.ratingValue) {
            payload.expression.push({
              type: 'asinReviewRatingBetween',
              value: targeting.ratingValue,
            })
            payload.expressionResolve.push({
              type: 'asinReviewRatingBetween',
              value: targeting.ratingValue,
            })
          }

          if (targeting.priceFrom && targeting.priceTo) {
            payload.expression.push({
              type: 'asinPriceBetween',
              value: `${targeting.priceFrom}-${targeting.priceTo}`,
            })
            payload.expressionResolve.push({
              type: 'asinPriceBetween',
              value: `${targeting.priceFrom}-${targeting.priceTo}`,
            })
          } else if (targeting.priceFrom && !targeting.priceTo) {
            payload.expression.push({
              type: 'asinPriceGreaterThan',
              value: targeting.priceFrom,
            })
            payload.expressionResolve.push({
              type: 'asinPriceGreaterThan',
              value: targeting.priceFrom,
            })
          } else if (!targeting.priceFrom && targeting.priceTo) {
            payload.expression.push({
              type: 'asinPriceLessThan',
              value: targeting.priceTo,
            })
            payload.expressionResolve.push({
              type: 'asinPriceLessThan',
              value: targeting.priceTo,
            })
          }
          break
        default:
          break
      }
      targets.push(payload)
    })
    return targets
  }

  const getNegativeProductTargets = () => {
    const negatives = []
    negativeTargetings.forEach(product => {
      const negativeProduct = {
        expressionType: 'manual',
        state: 'enabled',
        expression: [],
      }
      if (product.type === 'brand') {
        negativeProduct.expression.push({
          type: 'asinBrandSameAs',
          value: product.id,
        })
      } else if (product.type === 'product') {
        negativeProduct.expression.push({
          type: 'asinSameAs',
          value: product.ASIN,
        })
      }
      negatives.push(negativeProduct)
    })
    return negatives
  }

  const parseTargetings = () => {
    const targets = []
    targetings.forEach((targeting) => {
      const payload = {
        bid: targeting.bid,
        expression: [],
      }
      switch (targeting.type) {
        case 'category':
          payload.expression.push({
            type: 'asinCategorySameAs',
            value: targeting.id.toString(),
          })
          break
        case 'product':
          payload.expression.push({
            type: 'asinSameAs',
            value: targeting.ASIN,
          })
          break
        case 'refine':
          payload.expression.push({
            type: 'asinCategorySameAs',
            value: targeting.id.toString(),
          })

          if (targeting.brandId) {
            payload.expression.push({
              type: 'asinBrandSameAs',
              value: targeting.brandId.toString(),
            })
          }

          if (targeting.ratingValue) {
            payload.expression.push({
              type: 'asinReviewRatingBetween',
              value: targeting.ratingValue,
            })
          }

          if (targeting.priceFrom && targeting.priceTo) {
            payload.expression.push({
              type: 'asinPriceBetween',
              value: `${targeting.priceFrom}-${targeting.priceTo}`,
            })
          } else if (targeting.priceFrom && !targeting.priceTo) {
            payload.expression.push({
              type: 'asinPriceGreaterThan',
              value: targeting.priceFrom,
            })
          } else if (!targeting.priceFrom && targeting.priceTo) {
            payload.expression.push({
              type: 'asinPriceLessThan',
              value: targeting.priceTo,
            })
          }
          break
        case 'audience_category':
          payload.expression.push({
            type: targeting.audienceType ? targeting.audienceType : 'views',
            value: [
              {
                type: 'asinCategorySameAs',
                value: targeting.id.toString().replace(targeting.audienceType, ''),
              },
              {
                type: 'lookback',
                value: targeting.lookback ? targeting.lookback.value : '30',
              },
            ],

          })
          break
        case 'audience_product':
          payload.expression.push({
            type: targeting.audienceType ? targeting.audienceType : 'views',
            value: [
              {
                type: targeting.id.replace(targeting.audienceType, ''),
              },
              {
                type: 'lookback',
                value: targeting.lookback ? targeting.lookback.value : '30',
              },
            ],
          })
          break
        case 'audience_refine':
          const values = []
          values.push({
            type: 'asinCategorySameAs',
            value: targeting.id.toString().replace(targeting.audienceType, ''),
          })

          if (targeting.brandId) {
            values.push({
              type: 'asinBrandSameAs',
              value: targeting.brandId.toString(),
            })
          }

          if (targeting.ratingValue) {
            values.push({
              type: 'asinReviewRatingBetween',
              value: targeting.ratingValue,
            })
          }

          if (targeting.priceFrom && targeting.priceTo) {
            values.push({
              type: 'asinPriceBetween',
              value: `${targeting.priceFrom}-${targeting.priceTo}`,
            })
          } else if (targeting.priceFrom && !targeting.priceTo) {
            values.push({
              type: 'asinPriceGreaterThan',
              value: targeting.priceFrom,
            })
          } else if (!targeting.priceFrom && targeting.priceTo) {
            values.push({
              type: 'asinPriceLessThan',
              value: targeting.priceTo,
            })
          }
          values.push({
            type: 'lookback',
            value: targeting.lookback ? targeting.lookback.value : '30',
          })
          payload.expression.push({
            type: targeting.audienceType ? targeting.audienceType : 'views',
            value: values,
          })
          break
        case 'audience':
          payload.expression.push({
            type: 'audience',
            value: [
              {
                type: 'audienceSameAs',
                value: targeting.id.toString(),
              },
            ],
          })
          break
        default:
          break
      }
      if ((selectedCampaign.tactic === 'T00020' && ['category', 'refine', 'product'].indexOf(targeting.type) !== -1)
        || (selectedCampaign.tactic === 'T00030'
          && ['audience_category', 'audience_refine', 'audience_product', 'audience'].indexOf(targeting.type) !== -1)) {
        targets.push(payload)
      }
    })
    return targets
  }

  const handleCreate = () => {
    if (!selectedCampaign) {
      toast.show({
        title: 'Warning',
        description: 'Please choose a campaign.',
      })
      return
    }

    if (name === '') {
      toast.show({
        title: 'Warning',
        description: 'Please enter a name for the ad group.',
      })
      return
    }

    if (!defaultBid
      || Number.isNaN(parseFloat(defaultBid))
      || parseFloat(defaultBid) < MIN_DEFAULT_BID) {
      toast.show({
        title: 'Warning',
        description: `Please enter a bid value for use when no bid is specified `
          + `for keywords. The minimum is $${MIN_DEFAULT_BID}`,
      })
      return
    }

    if (!products.length) {
      toast.show({
        title: 'Warning',
        description: 'Please add products that you want to promote in this ad group.',
      })
      return
    }

    if (selectedCampaign.campaignType === 'Sponsored Products') {
      let targetParams = {}


      if (manualTarget === 'product') {
        targetParams.targets = getProductTargets()
        targetParams.negatives = getNegativeProductTargets()
      } else {
        targetParams.keywords = keywords.map(kw => ({
          keywordText: kw.keywordText !== '(_targeting_auto_)' && kw.keywordText !== '' ? kw.keywordText : kw.search,
          matchType: kw.matchType.toLowerCase(),
          bid: kw.keywordBid,
          state: 'enabled',
        }))
        targetParams.negativeKws = negativeKeywords.map(kw => ({
          keywordText: kw.keywordText !== '(_targeting_auto_)' && kw.keywordText !== '' ? kw.keywordText : kw.search,
          matchType: kw.matchType.toLowerCase(),
          state: 'enabled',
        }))
      }

      dispatch(createSPAdgroup(
        selectedCampaign.campaign_id,
        selectedCampaign.campaignType,
        name,
        parseFloat(defaultBid),
        selectedBidOp.value,
        selectedCampaign.tactic,
        targetParams.keywords,
        targetParams.negativeKws,
        targetParams.targets,
        targetParams.negatives,
        products.map(product => ({
          asin: product.asin,
          sku: product.sku,
        })),
      )).then((response) => {
        onCancel()
      })
    } else {
      let adGroups = [{
        name,
        defaultBid,
        bidOptimization: selectedCampaign.costType === 'cpc' ? selectedBidOp.value : 'reach',
        tactic: selectedCampaign.tactic
      }]
      let productAds = products.map(product => ({
        sku: product.sku,
        asin: product.asin,
      }))
      let targetParams = parseTargetings()
      let creative = [{}]
      dispatch(createSDAdgroup(
        selectedCampaign.campaign_id,
        selectedCampaign.campaignType,
        name,
        adGroups,
        productAds,
        targetParams,
        creative
      )).then((response) => {
        onCancel()
      })
    }
  }

  const handleProductSelect = (products) => {
    setOpenProductModal(false)
    setProducts(products)

    if (products.length) {
      if (selectedCampaign.tactic === null) {
        dispatch(getSPSuggestions(products.map(product => product.asin)))
      } else {
        dispatch(getSDSuggestions(selectedCampaign.tactic, products.map(product => product.asin)))
      }
    }
  }

  const handleKeywordsSelect = (keywords, reload = false, newKeywords = []) => {
    setKeywords(keywords)

    if (reload && newKeywords.length) {
      dispatch(getSuggestedKeywordBids(newKeywords))
    }
  }

  const handleProductRemove = (id) => {
    setProducts(products.filter(product => product.id !== id))
  }

  const renderProductTable = () => {
    if (!products.length) {
      return (
        <div className="no-product-desc">
          No product added.
        </div>
      )
    }

    return (
      <div className="product-container">
        {
          products.map((product) =>
            <div key={product.id} className="product-box">
              <CloseSvg title="Remove" onClick={() => { handleProductRemove(product.id) }}/>
              <img src={product.image} alt={product.name} />
              <div className="product-info">
                <div className="product-name">{product.name}</div>
                <div className="product-detail">
                  <span>Price: {product.price}</span>
                  <span>ASIN: {product.asin}</span>
                  <span>SKU: {product.sku}</span>
                </div>
              </div>
            </div>
          )
        }
      </div>
    )
  }

  const renderProducts = () => {
    return (
      <>
        <div className="field-wrapper">
          <label>Products</label>
          <button
            type="button"
            className="btn btn-blue"
            onClick={() => { setOpenProductModal(true) }}
          >
            Add Products
          </button>
          <ProductModal
            show={openProductModal}
            productsSelected={products}
            onSelect={handleProductSelect}
            onClose={() => { setOpenProductModal(false) }}
          />
        </div>
        { renderProductTable() }
      </>
    )
  }

  const renderManualSections = () => {
    if (target !== 'manual') {
      return null
    }

    return (
      <>
        <ManualTargetingSelector
          manualTarget={manualTarget}
          onChange={setManualTarget}
        />
        {
          manualTarget === 'keyword' && (
            <>
              <KeywordSection
                keywords={keywords}
                onChange={handleKeywordsSelect}
              />
              <NegativeKeywordSection
                negativeKeywords={negativeKeywords}
                bidInfo={{defaultBid: defaultBid}}
                onChange={setNegativeKeywords}
              />
            </>
          )
        }
        {
          manualTarget === 'product' && (
            <>
              <TargetingSection
                targetings={targetings}
                dailyBudget={selectedCampaign.dailyBudget}
                onChange={setTargetings}
              />
              <NegativeTargetingSection
                negativeTargetings={negativeTargetings}
                onChange={setNegativeTargetings}
              />
            </>
          )
        }
      </>
    )
  }

  const isLoading = isSuggestedBidsLoading || isCreatingAdgroup || isAllCategoriesLoading 

  return (
    <Modal className={`adgroup-creator-modal${isLoading ? ' loading' : ''}`} backdrop="static" size="sm" show={show}>
      <Modal.Header onHide={() => { onCancel() }}>
        <Modal.Title>
          Create New Ad Group
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        { isLoading && <LoaderComponent /> }
        {
          campaigns.length > 0 && (
            <div className="field-wrapper">
              <label>Campaign</label>
              <Select
                components={{ Option: CampaignOption }}
                value={selectedCampaign}
                options={campaigns}
                getOptionLabel={record => record.campaign}
                getOptionValue={record => record.campaign_id}
                placeholder="Choose campaign"
                onChange={setSelectedCampaign}
              />
            </div>
          )
        }
        <div className="field-wrapper">
          <label>Ad Group Name</label>
          <input
            type="text"
            placeholder="Enter ad group name"
            value={name}
            onChange={(event) => { setName(event.target.value) }}
          />
        </div>
        <div className="field-wrapper">
          <label>Default Bid</label>
          <input
            type="number"
            min={MIN_DEFAULT_BID}
            placeholder="Default bid price"
            value={defaultBid}
            onChange={(event) => { setDefaultBid(event.target.value) }}
          />
        </div>
        {
          selectedCampaign !== null
          && selectedCampaign.campaignType === 'Sponsored Displays'
          && selectedCampaign.costType === 'cpc'
          && (
            <div className="field-wrapper">
              <label>Bid Optimization</label>
              <Select
                value={selectedBidOp}
                options={bidOpOptions}
                placeholder="Choose bid optimization"
                onChange={setSelectedBidOp}
              />
            </div>
          )
        }
        { renderProducts() }
        {
          selectedCampaign !== null
          && selectedCampaign.campaignType === 'Sponsored Products'
          && selectedCampaign.targetingType === 'manual'
          && renderManualSections()
        }
        {
          selectedCampaign !== null
          && selectedCampaign.campaignType === 'Sponsored Displays'
          && selectedCampaign.tactic === 'T00020'
          && (
            <SDTargetingSection
              targetings={targetings}
              dailyBudget={selectedCampaign.dailyBudget}
              isForSD
              bidInfo={{bidOp: selectedBidOp}}
              products={products}
              onChange={setTargetings}
            />
          )
        }
        {
          selectedCampaign !== null
          && selectedCampaign.campaignType === 'Sponsored Displays'
          && selectedCampaign.tactic === 'T00030'
          && (
            <AudienceSection
              targetings={targetings}
              dailyBudget={selectedCampaign.dailyBudget}
              defaultBid={selectedCampaign.defaultBid}
              bidInfo={{bidOp: selectedBidOp}}
              products={products}
              onChange={setTargetings}
            />
          )
        }
      </Modal.Body>
      <Modal.Footer>
        <button
          type="button"
          className="rs-btn rs-btn-primary"
          disabled={isCreatingAdgroup}
          onClick={handleCreate}
        >
          Create
        </button>
        <button type="button" className="rs-btn rs-btn-subtle" onClick={() => onCancel()}>
          Cancel
        </button>
      </Modal.Footer>
    </Modal>
  )
}

export default ModalAddAdgroup
