import React, { useEffect, useState } from 'react'
import { useStore } from 'react-redux'
import { Modal } from 'rsuite'

import SortableTable from '../CommonComponents/SortableTableComponent'

import {
  tableSorter,
} from '../../services/helper'

const columns = [
  { key: 'name', name: 'Ad Group', className: 'col-adgroup' },
  { key: 'campaignName', name: 'Campaign', className: 'col-campaign' },
  { key: 'numTargets', name: 'Targets', className: 'col-target' },
]

const AdgroupSelectorModal = ({ show, currentModuleName, onConfirm, onClose }) => {
  const store = useStore().getState()

  const {
    campaign: {
      campaignsWithHistory,
    },
    bulkEngine: {
      isGettingAdgroupsForCampaigns,
      adgroupsForCampaignsData,
    },
  } = store

  const [adgroups, setAdgroups] = useState([])
  const [selectedAdgroups, setSelectedAdgroups] = useState([])

  useEffect(() => {
    const campaignNamesById = {}
    campaignsWithHistory.forEach((campaign) => {
      campaignNamesById[campaign.campaign_id] = campaign.campaign
    })

    const extendedAdgroups = (adgroupsForCampaignsData || []).map(record => ({
      ...record,
      numTargets: parseInt(record.keywords, 10) + parseInt(record.targets, 10),
      campaignName: campaignNamesById[record.campaign_id] || '',
    }))

    setAdgroups(extendedAdgroups)
    // By default, select all adgroups.
    setSelectedAdgroups(extendedAdgroups.map(record => record.adgroup_id))
  }, [adgroupsForCampaignsData, campaignsWithHistory])

  const renderAdgroup = record => (
    <>
      <div className="table-col col-adgroup" title={record.name}>
        <span className="contents">
          { record.name }
        </span>
      </div>
      <div className="table-col col-campaign" title={record.campaignName}>
        <span className="contents">
          { record.campaignName }
        </span>
      </div>
      <div className="table-col col-target">
        { record.numTargets }
      </div>
    </>
  )

  return (
    <Modal className="adgroup-selector-modal" backdrop="static" size="md" show={show}>
      <Modal.Header onHide={() => { onClose() }}>
        <Modal.Title>
          { currentModuleName }: Select Ad Groups
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <SortableTable
          isLoading={isGettingAdgroupsForCampaigns}
          columns={columns}
          defaultSort={['name', 'asc']}
          sorter={tableSorter(['name', 'campaignName'])}
          className="table-adgroups"
          records={adgroups}
          idField="adgroup_id"
          searchFields={['name', 'campaignName']}
          selectedRecords={selectedAdgroups}
          paginationSelectPlacement="top"
          renderRecord={renderAdgroup}
          onChange={setSelectedAdgroups}
        />
      </Modal.Body>
      <Modal.Footer>
        <button
          type="button"
          className="rs-btn rs-btn-primary"
          disabled={!selectedAdgroups.length || isGettingAdgroupsForCampaigns}
          onClick={() => { onConfirm(selectedAdgroups) }}
        >
          Continue
        </button>
        <button type="button" className="rs-btn rs-btn-subtle" onClick={() => onClose()}>
          Close
        </button>
      </Modal.Footer>
    </Modal>
  )
}

export default AdgroupSelectorModal
