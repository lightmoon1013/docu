import React, { useState } from 'react'
import { useDispatch, useStore } from 'react-redux'
import { Modal, Radio, RadioGroup, Tooltip, Whisper } from 'rsuite'

import LoaderComponent from '../CommonComponents/LoaderComponent'
import CheckboxComponent from '../CommonComponents/CheckboxComponent'
import { toast } from '../CommonComponents/ToastComponent/toast'

import {
  addNegatives,
} from '../../redux/actions/bulkEngine'

import {
  checkSpecialCharater,
} from '../../services/helper'

const MAX_CHARS_PER_NK = 80
const MAX_WORDS_PER_NE = 10
const MAX_WORDS_PER_NP = 4

const NegativeCreatorModal = ({ show, searchTerms, defaultMatchType = 'negativeExact', onClose }) => {
  const store = useStore().getState()
  const dispatch = useDispatch()

  const {
    bulkEngine: { isAddingNegatives }
  } = store

  const [targetLevel, setTargetLevel] = useState('campaign')
  const [matchType, setMatchType] = useState(defaultMatchType)

  const handleAdd = () => {
    const negativesToAdd = []
    const negativesForAuto = []
    searchTerms.forEach((record) => {
      if (record.campaignType === 'Sponsored Products' && record.targetingType === 'auto') {
        // For auto campaigns, ASINs are added as negative targeting.
        if (/^[0-9a-z]{10}$/ig.test(record.search)) {
          negativesForAuto.push(record)
          return
        }
      }
      negativesToAdd.push(record)
    })

    const negativeKeywords = []
    let validationError = null
    negativesToAdd.forEach((record) => {
      if (checkSpecialCharater(record.search)) {
        validationError = 'One or some keywords contain invalid characters.'
        return
      }

      if (record.search.length > MAX_CHARS_PER_NK) {
        validationError = 'Character limit exceeded. Negative keywords have '
          + `a maximum of ${MAX_CHARS_PER_NK} characters.`
        return
      }

      const wordCount = record.search.split(/\s+/).length
      if (matchType === 'negativeExact' && wordCount > MAX_WORDS_PER_NE) {
        validationError = `Word limit exceeded. Negative exact has maximum ${MAX_WORDS_PER_NE} words.`
        return
      }
      if (matchType === 'negativePhrase' && wordCount > MAX_WORDS_PER_NP) {
        validationError = `Word limit exceeded. Negative phrase has maximum ${MAX_WORDS_PER_NP} words.`
        return
      }

      negativeKeywords.push({
        campaignId: record.campaign_id,
        adgroupId: record.adgroup_id,
        campaignType: record.campaignType,
        search: record.search,
        // Below information are used for logging in backend.
        campaignName: record.campaignName,
        adgroupName: record.adgroupName,
      })
    })

    if (validationError) {
      toast.show({
        title: 'Warning',
        description: validationError,
      })
      return
    }

    const negativeTargets = []
    negativesForAuto.forEach((record) => {
      negativeTargets.push({
        campaignId: record.campaign_id,
        adgroupId: record.adgroup_id,
        campaignType: record.campaignType,
        search: record.search,
        // Below information are used for logging in backend.
        campaignName: record.campaignName,
        adgroupName: record.adgroupName,
      })
    })

    if (!negativeKeywords.length && !negativeTargets.length) {
      toast.show({
        title: 'Warning',
        description: 'Nothing to addd.',
      })
      return
    }

    dispatch(addNegatives(negativeKeywords, negativeTargets, targetLevel, matchType)).then((response) => {
      toast.show({
        title: 'Success',
        description: `Added ${response.count} negative${response.count > 1 ? 's' : ''} successfully.`,
      })

      onClose()
    }).catch((error) => {
      toast.show({
        title: 'Danger',
        description: error,
      })
    })
  }

  const hasAsin = searchTerms.find(term => /^[0-9a-z]{10}$/ig.test(term.search))

  // If only search terms for SB/SBV campaigns are selected,
  // disable adding to ad group level.
  const hasSPSDCampaigns = typeof searchTerms.find(record => (
    record.campaignType === 'Sponsored Products'
  )) !== 'undefined'

  return (
    <Modal backdrop="static" className="negative-creator-modal" show={show} size="md">
      <Modal.Header onHide={() => { onClose() }}>
        <Modal.Title>
          Add { searchTerms.length } Search Term{ searchTerms.length > 1 ? 's' : '' } As Negatives
          <Whisper placement="right" trigger="hover" speaker={(
            <Tooltip>
              <ul>
                {
                  searchTerms.map(record => (
                    <li key={record.search}>{record.search}</li>
                  ))
                }
              </ul>
            </Tooltip>
          )}>
            <span className="view-link">View search terms</span>
          </Whisper>
        </Modal.Title>
      </Modal.Header>
      <Modal.Body>
        { isAddingNegatives && <LoaderComponent /> }
        <div className="description">
          We’ll automatically add negatives to the correct ad groups/campaigns.
        </div>
        <div className="section-wrapper">
          <div className="section-container">
            <div className="section-title">
              1) Choose Ad Group or Campaign Level
            </div>
            <RadioGroup
              value={targetLevel}
              onChange={setTargetLevel}
            >
              <Radio value="adgroup" disabled={!hasSPSDCampaigns}>Ad Group Level</Radio>
              <Radio value="campaign">Campaign Level</Radio>
            </RadioGroup>
          </div>
          <div className="section-container">
            <div className="section-title">
              2) Confirm Negative Match Type and Add Negatives
            </div>
            {
              hasAsin && (
                <CheckboxComponent
                  label="Add ASINs as Negative Product Targeting"
                  checked
                  disabled
                />
              )
            }
            <RadioGroup
              value={matchType}
              onChange={setMatchType}
            >
              <Radio value="negativeExact">
                Add All Negatives As Negative Exact
                <small>Recommended</small>
              </Radio>
              <Radio value="negativePhrase">
                Add All Negatives As Negative Phrase
                <small className="warning">
                  Negative Phrase match is a high risk optimization</small>
              </Radio>
            </RadioGroup>
          </div>
        </div>
      </Modal.Body>
      <Modal.Footer>
        <button
          type="button"
          className="rs-btn rs-btn-primary"
          disabled={isAddingNegatives}
          onClick={() => { handleAdd() }}
        >
          Add Negatives
        </button>
        <button type="button" className="rs-btn rs-btn-subtle" onClick={() => { onClose() }}>
          Cancel
        </button>
      </Modal.Footer>
    </Modal>
  )
}

export default NegativeCreatorModal
