import React, { useEffect, useState } from 'react'
import { useDispatch, useStore } from 'react-redux'
import Select from 'react-select'
import { Tooltip, Whisper, Toggle } from 'rsuite'

import SortableTable from '../CommonComponents/SortableTableComponent'
import GroupTable from '../CommonComponents/GroupTableComponent'
import CheckboxComponent from '../CommonComponents/CheckboxComponent'
import { toast } from '../CommonComponents/ToastComponent/toast'
import TableCell from '../CommonComponents/TableCell'
import TableCampaignCell from '../CommonComponents/TableCampaignCell'
import TableFilterModal from '../CommonComponents/TableFilterModal'
import BidAdjustComponent from '../CommonComponents/BidAdjustComponent'

import {
  MODULE_NAME_TARGET_OP,
  FILTER_NAME_TARGET_OP,
  FILTER_NAME_ADVANCED_OP,
} from './TargetOpResult'

import { ReactComponent as InfoSvg } from '../../assets/svg/info.svg'

import {
  updateKeywordStates,
  adjustKeywordBids,
} from '../../redux/actions/bulkEngine'

import {
  formatCurrency,
  formatValue,
  capitalizeFirstLetter,
  tableSorter,
  calcDerivedMetrics,
  calcMaxCpc,
  getExportValueForColumn,
  groupRecords,
  copyToClipboard,
} from '../../services/helper'

import {
  bulkBidColumnList,
  adjustBidOptions,
  ADJUST_BID_RAISE,
  ADJUST_BID_LOWER,
  ADJUST_BID_CPC,
} from '../../utils/defaultValues'

import {
  matchTypes,
  keywordStatuses,
} from '../../utils/filterDef'

const TargetOpKeywordTable = ({ sortBy, keyMetric, forAdvanced, onChangeDate }) => {
  const dispatch = useDispatch()
  const store = useStore()
  const {
    header: {
      currencySign,
      currencyRate,
    },
    pageGlobal: {
      campaignTableColumns,
    },
    campaign: {
      campaignsWithHistory,
    },
    bulkEngine: {
      adgroupsForCampaignsData,
      targetOpData,
      isAdjustingKeywordBids,
      isUpdatingKeywordStates,
    },
  } = store.getState()

  const [groupMode, setGroupMode] = useState(false)
  const [keywords, setKeywords] = useState([])
  const [groupedKeywords, setGroupedKeywords] = useState([])
  const [selectedKeywords, setSelectedKeywords] = useState([])
  const [removeTargetAuto, setRemoveTargetAuto] = useState(true)
  const [isShowAdjustBid, setIsShowAdjustBid] = useState(false)
  const [selectedAdjustBidOption, setSelectedAdjustBidOption] = useState(adjustBidOptions[0])
  const [bidValue, setBidValue] = useState(0)
  const [selectedMatchType, setSelectedMatchType] = useState(matchTypes[0])
  const [selectedStatus, setSelectedStatus] = useState(keywordStatuses[0])
  const [currentFilterName, setCurrentFilterName] = useState('')

  useEffect(() => {
    const campaignNamesById = {}
    const campaignTypesById = {}
    const campaignTargetingTypesById = {}
    campaignsWithHistory.forEach((campaign) => {
      campaignNamesById[campaign.campaign_id] = campaign.campaign
      campaignTypesById[campaign.campaign_id] = campaign.campaignType
      campaignTargetingTypesById[campaign.campaign_id] = campaign.targeting_type
    })

    const adgroupNamesById = {}
    adgroupsForCampaignsData.forEach((adgroup) => {
      adgroupNamesById[adgroup.adgroup_id] = adgroup.name
    })

    const extendedKeywords = []; // semi-colon is required here.
    ((targetOpData || {}).keywords || []).forEach((record) => {
      if (removeTargetAuto && record.keyword === '(_targeting_auto_)') {
        return
      }

      if (selectedMatchType.value !== '') {
        if ((record.match_type || '').toLowerCase() !== selectedMatchType.value) {
          return
        }
      }

      if (selectedStatus.value !== '') {
        if ((record.state || '').toLowerCase() !== selectedStatus.value) {
          return
        }
      }

      const derived = calcDerivedMetrics(record)

      extendedKeywords.push({
        ...derived,
        campaignName: campaignNamesById[record.campaign_id] || '',
        campaignType: campaignTypesById[record.campaign_id] || '',
        adgroupName: adgroupNamesById[record.adgroup_id] || '',
        targetingType: campaignTargetingTypesById[record.campaign_id] || '',
        matchType: capitalizeFirstLetter(record.match_type),
        maxCpc: calcMaxCpc(derived),
      })
    })

    setKeywords(extendedKeywords)
    setGroupedKeywords(
      groupRecords(
        extendedKeywords,
        'campaign_id',
        ['campaignName', 'campaignType', 'targetingType']
      )
    )
  }, [targetOpData, removeTargetAuto, campaignsWithHistory,
    adgroupsForCampaignsData, forAdvanced, selectedMatchType, selectedStatus])

  let columns = [
    { key: 'keyword', name: 'Keyword', className: 'col-keyword' },
    { key: 'campaignName', name: 'Campaign', className: 'col-campaign' },
    { key: 'adgroupName', name: 'Ad Group', className: 'col-adgroup' },
  ]

  let columnsGroup = [
    { key: 'campaignName', name: 'Campaign', className: 'col-campaign', parentOnly: true },
    { key: 'checkPlaceholder', name: '', className: 'col-check', exportable: false, parentOnly: true },
    { key: 'keyword', name: 'Keyword', className: 'col-keyword' },
    { key: 'adgroupName', name: 'Ad Group', className: 'col-adgroup' },
  ]

  if (!keyMetric) {
    const metricColumns = [
      { key: 'bid', name: 'Current Bid' },
      {
        key: 'maxCpc',
        name: (
          <span>
            Genius Bid
            <Whisper placement="right" trigger="hover" speaker={(
              <Tooltip>
                <p>A minimum of 3 clicks is required before we suggest a “Genius Bid”.</p>
              </Tooltip>
            )}>
              <InfoSvg />
            </Whisper>
          </span>
        ),
        plainName: 'Genius Bid',
        className: 'col-genius-bid',
      },
      ...bulkBidColumnList,
    ]

    columns = columns.concat(metricColumns)
    columnsGroup = columnsGroup.concat(metricColumns)
  } else {
    const keyColumn = bulkBidColumnList.find(c => c.key === keyMetric)

    const metricColumns = [
      keyColumn,
      { key: 'bid', name: 'Current Bid' },
      {
        key: 'maxCpc',
        name: (
          <span>
            Genius Bid
            <Whisper placement="right" trigger="hover" speaker={(
              <Tooltip>
                <p>A minimum of 3 clicks is required before we suggest a “Genius Bid”.</p>
              </Tooltip>
            )}>
              <InfoSvg />
            </Whisper>
          </span>
        ),
        plainName: 'Genius Bid',
        className: 'col-genius-bid',
      },
      ...bulkBidColumnList.filter(c => c.key !== keyMetric),
    ]

    columns = columns.concat(metricColumns)
    columnsGroup = columnsGroup.concat(metricColumns)
  }

  const handleChangeState = (state) => {
    const nonAuto = keywords.filter(record => (
      selectedKeywords.indexOf(record.keyword_id) !== -1
      && record.keyword !== '(_targeting_auto_)'
    ))

    if (!nonAuto.length) {
      toast.show({
        title: 'Warning',
        description: 'You cannot change states of Target Auto.',
      })
      return
    }

    const keywordsChanged = nonAuto.map(record => ({
      campaignId: record.campaign_id,
      campaignType: record.campaignType,
      adGroupId: record.adgroup_id,
      keywordId: record.keyword_id,
      // Below information are used for logging in backend.
      campaignName: record.campaignName,
      adgroupName: record.adgroupName,
      keyword: record.keyword,
      matchType: record.matchType,
    }))

    dispatch(updateKeywordStates(keywordsChanged, state))
  }

  const handleChangeToMaxBid = () => {
    const nonAuto = keywords.filter(record => (
      selectedKeywords.indexOf(record.keyword_id) !== -1
      && record.keyword !== '(_targeting_auto_)'
    ))

    if (!nonAuto.length) {
      toast.show({
        title: 'Warning',
        description: 'You cannot change bid prices of Target Auto.',
      })
      return
    }

    let keywordsToChange = []

    nonAuto.forEach((record) => {
      if (record.maxCpc && record.maxCpc >= 0.15) {
        keywordsToChange.push({
          campaignId: record.campaign_id,
          campaignType: record.campaignType,
          adGroupId: record.adgroup_id,
          keywordId: record.keyword_id,
          bid: parseFloat(record.maxCpc.toFixed(2)),
          // Below information are used for logging in backend.
          campaignName: record.campaignName,
          adgroupName: record.adgroupName,
          keyword: record.keyword,
          originalBid: record.bid,
          matchType: record.matchType,
        })
      }
    })

    if (!keywordsToChange.length) {
      toast.show({
        title: 'Warning',
        description: 'Selected keyword(s) has invalid genius bid. '
          + 'The minimum bid allowed is $0.15 and '
          + 'auto campaign cannot change keyword bid. Please check your keywords.',
      })
      return
    }

    dispatch(adjustKeywordBids(keywordsToChange))
  }

  const handleAdjustBid = () => {
    if (selectedAdjustBidOption.value !== ADJUST_BID_CPC
      && (bidValue === '' || isNaN(bidValue))) {
      toast.show({
        title: 'Warning',
        description: 'Please enter the valid bid value.',
      })
      return
    }

    const nonAuto = keywords.filter(record => (
      selectedKeywords.indexOf(record.keyword_id) !== -1
      && record.keyword !== '(_targeting_auto_)'
    ))

    if (!nonAuto.length) {
      toast.show({
        title: 'Warning',
        description: 'You cannot change bid prices of Target Auto.',
      })
      return
    }

    let keywordsChanged = []
    nonAuto.forEach((record) => {
      let newBid = parseFloat(bidValue)
      if (selectedAdjustBidOption.value === ADJUST_BID_RAISE) {
        newBid = parseFloat(record.bid || 0) * (1 + (newBid / 100))
      } else if (selectedAdjustBidOption.value === ADJUST_BID_LOWER) {
        newBid = parseFloat(record.bid || 0) * (1 - (newBid / 100))
      } else if (selectedAdjustBidOption.value === ADJUST_BID_CPC) {
        newBid = parseFloat(record.cpc || 0)
      }

      if (newBid >= 0.15) {
        keywordsChanged.push({
          campaignId: record.campaign_id,
          campaignType: record.campaignType,
          adGroupId: record.adgroup_id,
          keywordId: record.keyword_id,
          bid: parseFloat(newBid.toFixed(2)),
          // Below information are used for logging in backend.
          campaignName: record.campaignName,
          adgroupName: record.adgroupName,
          keyword: record.keyword,
          originalBid: record.bid,
          matchType: record.matchType,
        })
      }
    })

    if (!keywordsChanged.length) {
      toast.show({
        title: 'Warning',
        description: 'The minimum bid allowed is $0.15. Please check your keywords.',
      })
      return
    }

    dispatch(adjustKeywordBids(keywordsChanged)).then(() => {
      setIsShowAdjustBid(false)
    })
  }

  const handleRefineFilter = () => {
    setCurrentFilterName(forAdvanced ? FILTER_NAME_ADVANCED_OP : FILTER_NAME_TARGET_OP)
  }

  const handleCopy = () => {
    const dataToCopy = keywords.filter(record => (
      selectedKeywords.indexOf(record.keyword_id) !== -1
    )).map(record => record.keyword.trim())

    copyToClipboard(dataToCopy.join('\n'))

    toast.show({
      title: 'Success',
      description: `Successfully copied ${dataToCopy.length} keyword${dataToCopy.length > 1 ? 's' : ''}.`
    })
  }

  const renderFilter = () => {
    return (
      <div className="filter-container">
        <div className="toggle-wrapper">
          <Toggle
            checked={groupMode}
            checkedChildren="Organize by campaigns"
            unCheckedChildren="By keywords"
            onChange={setGroupMode}
          />
        </div>
        <div className="checkbox-wrapper">
          <CheckboxComponent
            label="Remove Target Auto"
            checked={removeTargetAuto}
            onChange={setRemoveTargetAuto}
          />
          <Whisper placement="right" trigger="hover" speaker={(
            <Tooltip>
              <p>
                Results that show "Target Auto" represent legacy Automatic Campaigns.
              </p>
              <p>
                These campaigns do not contain Automatic Targeting types (Close Match, Loose Match, etc.)
                and therefore can't be adjusted from this section.
              </p>
              <p>
                Keeping this box checked will remove them from results.
              </p>
            </Tooltip>
          )}>
            <InfoSvg />
          </Whisper>
        </div>
        <div className="select-wrapper">
          <span>Match Type</span>
          <Select
            classNamePrefix="match-type-selector"
            options={matchTypes}
            value={selectedMatchType}
            onChange={setSelectedMatchType}
          />
        </div>
        <div className="select-wrapper">
          <span>Status</span>
          <Select
            classNamePrefix="status-selector"
            options={keywordStatuses}
            value={selectedStatus}
            onChange={setSelectedStatus}
          />
        </div>
        <div className="button-wrapper">
          <button
            type="button"
            className="btn btn-blue"
            onClick={handleRefineFilter}
          >
            Refine Filter
          </button>
        </div>
      </div>
    )
  }

  const renderAction = () => {
    if (!selectedKeywords.length) {
      return null
    }

    if (!isShowAdjustBid) {
      const isEnableDisabled = typeof keywords.find(record => (
        selectedKeywords.indexOf(record.keyword_id) !== -1
        && record.state !== 'enabled'
      )) === 'undefined'

      const isPauseDisabled = typeof keywords.find(record => (
        selectedKeywords.indexOf(record.keyword_id) !== -1
        && record.state !== 'paused'
      )) === 'undefined'

      return (
        <>
          <button
            type="button"
            className="btn btn-green"
            onClick={() => { handleCopy() }}
          >
            Copy
          </button>
          <button
            type="button"
            className="btn btn-green"
            disabled={isUpdatingKeywordStates || isEnableDisabled}
            onClick={() => { handleChangeState('enabled') }}
          >
            Enable
          </button>
          <button
            type="button"
            className="btn btn-red"
            disabled={isUpdatingKeywordStates || isPauseDisabled}
            onClick={() => { handleChangeState('paused') }}
          >
            Pause
          </button>
          <button
            type="button"
            className="btn btn-light-blue"
            onClick={() => { setIsShowAdjustBid(true) }}
          >
            Adjust Bid
          </button>
          <button
            type="button"
            className="btn btn-blue"
            disabled={isAdjustingKeywordBids}
            onClick={handleChangeToMaxBid}
          >
            Change to Genius Bid
          </button>
        </>
      )
    }

    return (
      <BidAdjustComponent
        adjustBidOption={selectedAdjustBidOption}
        bidValue={bidValue}
        isAdjusting={isAdjustingKeywordBids}
        onChangeAdjustBidOption={setSelectedAdjustBidOption}
        onChangeBidValue={setBidValue}
        onApply={handleAdjustBid}
        onCancel={() => { setIsShowAdjustBid(false) }}
      />
    )
  }

  const renderKeyword = record => (
    <>
      <div className="table-col col-keyword" title={record.keyword}>
        <strong>
          { record.keyword }
        </strong>
        <div className="meta-data">
          { record.matchType } | { capitalizeFirstLetter(record.state) }
        </div>
      </div>
      <TableCampaignCell record={record} />
      <div className="table-col col-adgroup" title={record.adgroupName}>
        <span className="contents">
          { record.adgroupName }
        </span>
      </div>
      {
        keyMetric === 'cpc' && campaignTableColumns.includes(keyMetric) && (
          <div className="table-col">
            { formatCurrency(record.cpc, currencySign, currencyRate) }
          </div>
        )
      }
      {
        keyMetric === 'conversion' && campaignTableColumns.includes(keyMetric) && (
          <div className="table-col">
            { formatValue(record.conversion, 'percent') }
          </div>
        )
      }
      {
        keyMetric === 'cost' && campaignTableColumns.includes(keyMetric) && (
          <div className="table-col">
            { formatCurrency(record.cost, currencySign, currencyRate) }
          </div>
        )
      }
      <div className="table-col">
        { formatCurrency(record.bid, currencySign, currencyRate) }
      </div>
      <div className="table-col col-genius-bid">
        {
          typeof record.maxCpc !== 'undefined'
          ? formatCurrency(record.maxCpc, currencySign, currencyRate)
          : 'N/A'
        }
      </div>
      {
        bulkBidColumnList.map((column) => {
          if (keyMetric && column.key === keyMetric) {
            return null
          }

          return (
            <TableCell
              key={column.key}
              record={record}
              columnKey={column.key}
              columnSelection={campaignTableColumns}
              currencySign={currencySign}
              currencyRate={currencyRate}
            />
          )
        })
      }
    </>
  )

  // Render aggregation row.
  const renderTotal = summary => (
    <>
      <div className="table-col col-keyword">Totals:</div>
      <div className="table-col col-campaign" />
      <div className="table-col col-adgroup" />
      {
        keyMetric === 'cpc' && campaignTableColumns.includes(keyMetric) && (
          <div className="table-col">
            { formatCurrency(summary.cpc, currencySign, currencyRate) }
          </div>
        )
      }
      {
        keyMetric === 'conversion' && campaignTableColumns.includes(keyMetric) && (
          <div className="table-col">
            { formatValue(summary.conversion, 'percent') }
          </div>
        )
      }
      {
        keyMetric === 'cost' && campaignTableColumns.includes(keyMetric) && (
          <div className="table-col">
            { formatCurrency(summary.cost, currencySign, currencyRate) }
          </div>
        )
      }
      <div className="table-col"></div>
      <div className="table-col col-genius-bid"></div>
      {
        bulkBidColumnList.map((column) => {
          if (keyMetric && column.key === keyMetric) {
            return null
          }

          return (
            <TableCell
              key={column.key}
              record={summary}
              columnKey={column.key}
              columnSelection={campaignTableColumns}
              currencySign={currencySign}
              currencyRate={currencyRate}
            />
          )
        })
      }
    </>
  )

  const getExportData = (exportableColumns, record) => (
    exportableColumns.map((column) => {
      if (column.key === 'keyword') {
        return `${record.keyword} (${record.matchType} | ${capitalizeFirstLetter(record.state)})`
      }
      if (column.key === 'bid') {
        return formatCurrency(record.bid, currencySign, currencyRate)
      }
      if (column.key === 'maxCpc') {
        return typeof record.maxCpc !== 'undefined'
          ? formatCurrency(record.maxCpc, currencySign, currencyRate)
          : 'N/A'
      }
      return getExportValueForColumn(record, column.key, currencySign, currencyRate)
    })
  )

  // For grouped table.
  const renderParent = record => (
    <>
      <TableCampaignCell record={record} />
      <div className="table-col col-check" />
      <div className="table-col col-keyword">
        { record.children.length } keywords
      </div>
      <div className="table-col col-adgroup" />
      {
        keyMetric === 'cpc' && campaignTableColumns.includes(keyMetric) && (
          <div className="table-col">
            { formatCurrency(record.cpc, currencySign, currencyRate) }
          </div>
        )
      }
      {
        keyMetric === 'conversion' && campaignTableColumns.includes(keyMetric) && (
          <div className="table-col">
            { formatValue(record.conversion, 'percent') }
          </div>
        )
      }
      {
        keyMetric === 'cost' && campaignTableColumns.includes(keyMetric) && (
          <div className="table-col">
            { formatCurrency(record.cost, currencySign, currencyRate) }
          </div>
        )
      }
      <div className="table-col" />
      <div className="table-col col-genius-bid" />
      {
        bulkBidColumnList.map((column) => {
          if (keyMetric && column.key === keyMetric) {
            return null
          }

          return (
            <TableCell
              key={column.key}
              record={record}
              columnKey={column.key}
              columnSelection={campaignTableColumns}
              currencySign={currencySign}
              currencyRate={currencyRate}
            />
          )
        })
      }
    </>
  )

  const renderChild = record => (
    <>
      <div className="table-col col-keyword" title={record.keyword}>
        <strong>
          { record.keyword }
        </strong>
        <div className="meta-data">
          { record.matchType } | { capitalizeFirstLetter(record.state) }
        </div>
      </div>
      <div className="table-col col-adgroup" title={record.adgroupName}>
        <span className="contents">
          { record.adgroupName }
        </span>
      </div>
      {
        keyMetric === 'cpc' && campaignTableColumns.includes(keyMetric) && (
          <div className="table-col">
            { formatCurrency(record.cpc, currencySign, currencyRate) }
          </div>
        )
      }
      {
        keyMetric === 'conversion' && campaignTableColumns.includes(keyMetric) && (
          <div className="table-col">
            { formatValue(record.conversion, 'percent') }
          </div>
        )
      }
      {
        keyMetric === 'cost' && campaignTableColumns.includes(keyMetric) && (
          <div className="table-col">
            { formatCurrency(record.cost, currencySign, currencyRate) }
          </div>
        )
      }
      <div className="table-col">
        { formatCurrency(record.bid, currencySign, currencyRate) }
      </div>
      <div className="table-col col-genius-bid">
        {
          typeof record.maxCpc !== 'undefined'
          ? formatCurrency(record.maxCpc, currencySign, currencyRate)
          : 'N/A'
        }
      </div>
      {
        bulkBidColumnList.map((column) => {
          if (keyMetric && column.key === keyMetric) {
            return null
          }

          return (
            <TableCell
              key={column.key}
              record={record}
              columnKey={column.key}
              columnSelection={campaignTableColumns}
              currencySign={currencySign}
              currencyRate={currencyRate}
            />
          )
        })
      }
    </>
  )

  const renderTotalGroup = summary => (
    <>
      <div className="table-col col-campaign">Totals:</div>
      <div className="table-col col-check" />
      <div className="table-col col-keyword" />
      <div className="table-col col-adgroup" />
      {
        keyMetric === 'cpc' && campaignTableColumns.includes(keyMetric) && (
          <div className="table-col">
            { formatCurrency(summary.cpc, currencySign, currencyRate) }
          </div>
        )
      }
      {
        keyMetric === 'conversion' && campaignTableColumns.includes(keyMetric) && (
          <div className="table-col">
            { formatValue(summary.conversion, 'percent') }
          </div>
        )
      }
      {
        keyMetric === 'cost' && campaignTableColumns.includes(keyMetric) && (
          <div className="table-col">
            { formatCurrency(summary.cost, currencySign, currencyRate) }
          </div>
        )
      }
      <div className="table-col" />
      <div className="table-col col-genius-bid" />
      {
        bulkBidColumnList.map((column) => {
          if (keyMetric && column.key === keyMetric) {
            return null
          }

          return (
            <TableCell
              key={column.key}
              record={summary}
              columnKey={column.key}
              columnSelection={campaignTableColumns}
              currencySign={currencySign}
              currencyRate={currencyRate}
            />
          )
        })
      }
    </>
  )

  const isLoading = isUpdatingKeywordStates || isAdjustingKeywordBids

  return (
    <>
      { renderFilter() }
      {
        groupMode ? (
          <SortableTable
            tableComponent={GroupTable}
            isLoading={isLoading}
            columns={columnsGroup}
            defaultSort={sortBy}
            sorter={tableSorter(['campaignName'])}
            className="table-grouped-keywords"
            records={groupedKeywords}
            idField="campaign_id"
            searchFields={['keyword']}
            selectedRecords={selectedKeywords}
            paginationSelectPlacement="top"
            hasSticky
            hasDateRange
            filterName={forAdvanced ? FILTER_NAME_ADVANCED_OP : FILTER_NAME_TARGET_OP}
            useFilterModal
            columnEditorId="targetOpKeywordResult"
            columnList={bulkBidColumnList}
            columnSelection={campaignTableColumns}
            exportFileName={MODULE_NAME_TARGET_OP}
            getExportData={getExportData}
            renderRecord={renderParent}
            renderTotal={renderTotalGroup}
            renderTopRight={renderAction}
            onChange={setSelectedKeywords}
            onChangeDate={onChangeDate}
            sorterChild={tableSorter(['adgroupName', 'state', 'keyword', 'matchType'])}
            idFieldChild="keyword_id"
            renderChild={renderChild}
          />
        ) : (
          <SortableTable
            isLoading={isLoading}
            columns={columns}
            defaultSort={sortBy}
            sorter={tableSorter(['campaignName', 'adgroupName', 'state', 'keyword', 'matchType'])}
            className="table-keywords"
            records={keywords || []}
            idField="keyword_id"
            searchFields={['keyword']}
            selectedRecords={selectedKeywords}
            paginationSelectPlacement="top"
            hasSticky
            hasDateRange
            filterName={forAdvanced ? FILTER_NAME_ADVANCED_OP : FILTER_NAME_TARGET_OP}
            useFilterModal
            columnEditorId="targetOpKeywordResult"
            columnList={bulkBidColumnList}
            columnSelection={campaignTableColumns}
            exportFileName={MODULE_NAME_TARGET_OP}
            getExportData={getExportData}
            renderRecord={renderKeyword}
            renderTotal={renderTotal}
            renderTopRight={renderAction}
            onChange={setSelectedKeywords}
            onChangeDate={onChangeDate}
          />
        )
      }
      {
        currentFilterName !== '' && (
          <TableFilterModal
            filterName={currentFilterName}
            currentModuleName={forAdvanced ? 'Advanced Optimization' : MODULE_NAME_TARGET_OP}
            onApply={() => { setCurrentFilterName('') }}
            onClose={() => { setCurrentFilterName('') }}
          />
        )
      }
    </>
  )
}

export default TargetOpKeywordTable
