import React, { useEffect, useState } from 'react'
import { useDispatch, useStore } from 'react-redux'
import { Toggle } from 'rsuite'

import SortableTable from '../CommonComponents/SortableTableComponent'
import GroupTable from '../CommonComponents/GroupTableComponent'
import TableCell from '../CommonComponents/TableCell'
import TableCampaignCell from '../CommonComponents/TableCampaignCell'
import TableFilterModal from '../CommonComponents/TableFilterModal'
import { toast } from '../CommonComponents/ToastComponent/toast'

import BulkResultContainer from '../BulkResultContainer'

import {
  updatePaStates,
} from '../../redux/actions/bulkEngine'

import {
  tableSorter,
  calcDerivedMetrics,
  capitalizeFirstLetter,
  getExportValueForColumn,
  groupRecords,
  copyToClipboard,
} from '../../services/helper'

import { bulkSKUColumnList } from '../../utils/defaultValues'

export const MODULE_NAME_SKU_OP = 'SKU Optimization'
export const FILTER_NAME_SKU_OP = 'bulkSkuOp'

const columns = [
  { key: 'image', name: 'Image', sortable: false, exportable: false },
  { key: 'sku', name: 'SKU' },
  { key: 'campaignName', name: 'Campaign', className: 'col-campaign' },
  { key: 'adgroupName', name: 'Ad Group', className: 'col-adgroup' },
  ...bulkSKUColumnList,
]

const columnsGroup = [
  { key: 'campaignName', name: 'Campaign', className: 'col-campaign', parentOnly: true },
  { key: 'checkPlaceholder', name: '', className: 'col-check', exportable: false, parentOnly: true },
  { key: 'image', name: 'Image', sortable: false, exportable: false },
  { key: 'sku', name: 'SKU' },
  { key: 'adgroupName', name: 'Ad Group', className: 'col-adgroup' },
  ...bulkSKUColumnList,
]

const SkuOpResult = ({ onChangeDate }) => {
  const store = useStore()
  const dispatch = useDispatch()

  const {
    header: {
      currencyRate,
      currencySign,
    },
    pageGlobal: {
      campaignTableColumns,
    },
    campaign: {
      campaignsWithHistory,
    },
    bulkEngine: {
      adgroupsForCampaignsData,
      skuOpData,
      isUpdatingPaStates,
    },
  } = store.getState()

  const [groupMode, setGroupMode] = useState(false)
  const [skus, setSkus] = useState([])
  const [groupedSkus, setGroupedSkus] = useState([])
  const [selectedSkus, setSelectedSkus] = useState([])
  const [currentFilterName, setCurrentFilterName] = useState('')

  useEffect(() => {
    const campaignNamesById = {}
    const campaignTypesById = {}
    const campaignTargetingTypesById = {}

    campaignsWithHistory.forEach((campaign) => {
      campaignNamesById[campaign.campaign_id] = campaign.campaign
      campaignTypesById[campaign.campaign_id] = campaign.campaignType
      campaignTargetingTypesById[campaign.campaign_id] = campaign.targeting_type
    })

    const adgroupNamesById = {}
    adgroupsForCampaignsData.forEach((adgroup) => {
      adgroupNamesById[adgroup.adgroup_id] = adgroup.name
    })

    const extendedSkus = [];
    (skuOpData || []).forEach((record) => {
      extendedSkus.push({
        ...calcDerivedMetrics(record),
        campaignName: campaignNamesById[record.campaign_id] || '',
        campaignType: campaignTypesById[record.campaign_id] || '',
        targetingType: campaignTargetingTypesById[record.campaign_id] || '',
        adgroupName: adgroupNamesById[record.adgroup_id] || '',
      })
    })

    setSkus(extendedSkus)
    setGroupedSkus(
      groupRecords(
        extendedSkus,
        'campaign_id',
        ['campaignName', 'campaignType', 'targetingType']
      )
    )
  }, [skuOpData, campaignsWithHistory, adgroupsForCampaignsData])

  const handleChangeState = (state) => {
    const productAds = skus
      .filter(sku => selectedSkus.indexOf(sku.ad_id) !== -1)
      .map(sku => ({
        campaignType: sku.campaignType,
        ad_id: sku.ad_id,
        // Below information are used for logging in backend.
        campaign_id: sku.campaign_id,
        campaignName: sku.campaignName,
        adgroup_id: sku.adgroup_id,
        adgroupName: sku.adgroupName,
        sku: sku.sku,
      }))

    dispatch(updatePaStates(productAds, state))
  }

  const handleCopyAsin = () => {
    const asins = skus.filter(record => (
      selectedSkus.indexOf(record.ad_id) !== -1
    )).map(record => record.asin.trim())

    copyToClipboard(asins.join('\n'))

    toast.show({
      title: 'Success',
      description: `Successfully copied ${asins.length} ASIN${asins.length > 1 ? 's' : ''}.`
    })
  }

  const handleCopySku = () => {
    const skusToCopy = skus.filter(record => (
      selectedSkus.indexOf(record.ad_id) !== -1
    )).map(record => record.sku.trim())

    copyToClipboard(skusToCopy.join('\n'))

    toast.show({
      title: 'Success',
      description: `Successfully copied ${skusToCopy.length} SKU${skusToCopy.length > 1 ? 's' : ''}.`
    })
  }

  const renderFilter = () => {
    return (
      <div className="filter-container">
        <div className="toggle-wrapper">
          <Toggle
            checked={groupMode}
            checkedChildren="Organize by campaigns"
            unCheckedChildren="By SKUs"
            onChange={setGroupMode}
          />
        </div>
        <div className="button-wrapper">
          <button
            type="button"
            className="btn btn-blue"
            onClick={() => { setCurrentFilterName(FILTER_NAME_SKU_OP) }}
          >
            Refine Filter
          </button>
        </div>
      </div>
    )
  }

  const renderAction = () => {
    if (!selectedSkus.length) {
      return null
    }

    const isEnableDisabled = typeof skus.find(record => (
      selectedSkus.indexOf(record.ad_id) !== -1
      && record.state !== 'enabled'
    )) === 'undefined'

    const isPauseDisabled = typeof skus.find(record => (
      selectedSkus.indexOf(record.ad_id) !== -1
      && record.state !== 'paused'
    )) === 'undefined'

    return (
      <>
        <button
          type="button"
          className="btn btn-green"
          onClick={() => { handleCopyAsin() }}
        >
          Copy ASINs
        </button>
        <button
          type="button"
          className="btn btn-green"
          onClick={() => { handleCopySku() }}
        >
          Copy SKUs
        </button>
        <button
          type="button"
          className="btn btn-green"
          disabled={isUpdatingPaStates || isEnableDisabled}
          onClick={() => { handleChangeState('enabled') }}
        >
          Enable
        </button>
        <button
          type="button"
          className="btn btn-red"
          disabled={isUpdatingPaStates || isPauseDisabled}
          onClick={() => { handleChangeState('paused') }}
        >
          Pause
        </button>
      </>
    )
  }

  const renderSku = record => (
    <>
      <div className="table-col">
        <a href={record.url} title={record.name} target="_blank" rel="noopener noreferrer">
          <img src={record.image} alt={record.name} />
        </a>
      </div>
      <div className="table-col col-sku">
        <strong>
          { record.sku }
        </strong>
        <div className="meta-data">
          { capitalizeFirstLetter(record.state) }
        </div>
      </div>
      <TableCampaignCell record={record} />
      <div className="table-col col-adgroup" title={record.adgroupName}>
        <span className="contents">
          { record.adgroupName }
        </span>
      </div>
      {
        bulkSKUColumnList.map(column => (
          <TableCell
            key={column.key}
            record={record}
            columnKey={column.key}
            columnSelection={campaignTableColumns}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  // Render aggregation row.
  const renderTotal = summary => (
    <>
      <div className="table-col">Totals:</div>
      <div className="table-col col-sku" />
      <div className="table-col col-campaign" />
      <div className="table-col col-adgroup" />
      {
        bulkSKUColumnList.map(column => (
          <TableCell
            key={column.key}
            record={summary}
            columnKey={column.key}
            columnSelection={campaignTableColumns}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  const getExportData = (exportableColumns, record) => (
    exportableColumns.map((column) => {
      if (column.key === 'sku') {
        return `${record.sku} (${capitalizeFirstLetter(record.state)})`
      }
      return getExportValueForColumn(record, column.key, currencySign, currencyRate)
    })
  )

  // For grouped table.
  const renderParent = record => (
    <>
      <TableCampaignCell record={record} />
      <div className="table-col col-check" />
      <div className="table-col" />
      <div className="table-col col-sku">
        { record.children.length } SKUs
      </div>
      <div className="table-col col-adgroup" />
      {
        bulkSKUColumnList.map(column => (
          <TableCell
            key={column.key}
            record={record}
            columnKey={column.key}
            columnSelection={campaignTableColumns}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  const renderChild = record => (
    <>
      <div className="table-col">
        <a href={record.url} title={record.name} target="_blank" rel="noopener noreferrer">
          <img src={record.image} alt={record.name} />
        </a>
      </div>
      <div className="table-col col-sku">
        <strong>
          { record.sku }
        </strong>
        <div className="meta-data">
          { capitalizeFirstLetter(record.state) }
        </div>
      </div>
      <div className="table-col col-adgroup" title={record.adgroupName}>
        <span className="contents">
          { record.adgroupName }
        </span>
      </div>
      {
        bulkSKUColumnList.map(column => (
          <TableCell
            key={column.key}
            record={record}
            columnKey={column.key}
            columnSelection={campaignTableColumns}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  const renderTotalGroup = summary => (
    <>
      <div className="table-col col-campaign">Totals:</div>
      <div className="table-col col-check" />
      <div className="table-col" />
      <div className="table-col col-sku" />
      <div className="table-col col-adgroup" />
      {
        bulkSKUColumnList.map(column => (
          <TableCell
            key={column.key}
            record={summary}
            columnKey={column.key}
            columnSelection={campaignTableColumns}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  const isLoading = isUpdatingPaStates

  return (
    <BulkResultContainer>
      { renderFilter() }
      {
        groupMode ? (
          <SortableTable
            tableComponent={GroupTable}
            isLoading={isLoading}
            columns={columnsGroup}
            defaultSort={['cost', 'desc']}
            sorter={tableSorter(['campaignName'])}
            className="table-grouped-skus"
            records={groupedSkus}
            idField="campaign_id"
            searchFields={['sku', 'asin', 'name']}
            selectedRecords={selectedSkus}
            paginationSelectPlacement="top"
            hasSticky
            hasDateRange
            filterName={FILTER_NAME_SKU_OP}
            useFilterModal
            columnEditorId="skuOpResult"
            columnList={bulkSKUColumnList}
            columnSelection={campaignTableColumns}
            exportFileName={MODULE_NAME_SKU_OP}
            getExportData={getExportData}
            renderRecord={renderParent}
            renderTotal={renderTotalGroup}
            renderTopRight={renderAction}
            onChange={setSelectedSkus}
            onChangeDate={onChangeDate}
            sorterChild={tableSorter(['state', 'sku', 'asin', 'adgroupName'])}
            idFieldChild="ad_id"
            renderChild={renderChild}
          />
        ) : (
          <SortableTable
            isLoading={isLoading}
            columns={columns}
            defaultSort={['cost', 'desc']}
            sorter={tableSorter(['state', 'sku', 'asin', 'campaignName', 'adgroupName'])}
            className="table-skus"
            records={skus}
            idField="ad_id"
            searchFields={['sku', 'asin', 'name']}
            selectedRecords={selectedSkus}
            paginationSelectPlacement="top"
            hasSticky
            hasDateRange
            filterName={FILTER_NAME_SKU_OP}
            useFilterModal
            columnEditorId="skuOpResult"
            columnList={bulkSKUColumnList}
            columnSelection={campaignTableColumns}
            exportFileName={MODULE_NAME_SKU_OP}
            getExportData={getExportData}
            renderRecord={renderSku}
            renderTotal={renderTotal}
            renderTopRight={renderAction}
            onChange={setSelectedSkus}
            onChangeDate={onChangeDate}
          />
        )
      }
      {
        currentFilterName !== '' && (
          <TableFilterModal
            filterName={currentFilterName}
            currentModuleName={MODULE_NAME_SKU_OP}
            onApply={() => { setCurrentFilterName('') }}
            onClose={() => { setCurrentFilterName('') }}
          />
        )
      }
    </BulkResultContainer>
  )
}

export default SkuOpResult
