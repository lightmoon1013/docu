import React, { useEffect, useState } from 'react'
import { useDispatch, useStore } from 'react-redux'
import { Toggle } from 'rsuite'
import Select from 'react-select'
import * as Icon from 'react-icons/fi'

import SortableTable from '../CommonComponents/SortableTableComponent'
import GroupTable from '../CommonComponents/GroupTableComponent'
import TableCampaignCell from '../CommonComponents/TableCampaignCell'

import { updateNtStates } from '../../redux/actions/bulkEngine'

import {
  tableSorter,
  capitalizeFirstLetter,
  parseTargetExp,
  getAmazonLink,
  groupRecords,
} from '../../services/helper'
import { campaignTypes, targetingTypes } from '../../utils/filterDef'

const columns = [
  { key: 'target', name: 'Target', className: 'col-target' },
  { key: 'targetingType', name: 'Type' },
  { key: 'level', name: 'Level' },
  { key: 'campaignName', name: 'Campaign', className: 'col-campaign' },
  { key: 'adgroupName', name: 'Ad Group', className: 'col-adgroup' },
]

const columnsGroup = [
  { key: 'campaignName', name: 'Campaign', className: 'col-campaign', parentOnly: true },
  { key: 'childCount', name: 'Number of Negatives', parentOnly: true },
  { key: 'target', name: 'Target', className: 'col-target' },
  { key: 'targetingType', name: 'Type' },
  { key: 'level', name: 'Level' },
  { key: 'adgroupName', name: 'Ad Group', className: 'col-adgroup' },
]

const AdvancedNegativeTargetTable = () => {
  const dispatch = useDispatch()
  const store = useStore()
  const {
    header: {
      selectedUserInfo,
    },
    campaign: {
      campaignsWithHistory,
    },
    bulkEngine: {
      adgroupsForCampaignsData,
      advancedNegativeData,
      isUpdatingNtStates,
    },
  } = store.getState()

  const [groupMode, setGroupMode] = useState(false)
  const [targets, setTargets] = useState([])
  const [groupedTargets, setGroupedTargets] = useState([])
  const [selectedTargets, setSelectedTargets] = useState([])
  const [selectedAdType, setSelectedAdType] = useState(campaignTypes[0])
  const [selectedTargetingType, setSelectedTargetingType] = useState(targetingTypes[0])

  useEffect(() => {
    const campaignNamesById = {}
    const campaignTypesById = {}
    const campaignTargetingTypesById = {}
    campaignsWithHistory.forEach((campaign) => {
      campaignNamesById[campaign.campaign_id] = campaign.campaign
      campaignTypesById[campaign.campaign_id] = campaign.campaignType
      campaignTargetingTypesById[campaign.campaign_id] = campaign.targeting_type
    })

    const adgroupNamesById = {}
    adgroupsForCampaignsData.forEach((adgroup) => {
      adgroupNamesById[adgroup.adgroup_id] = adgroup.name
    })

    // Remove duplicate entries.
    const records =  [...new Map(
      ((advancedNegativeData || {}).negativeTargets || [])
      .map(item => [item.target_id, item]))
      .values()
    ]

    const extended = [];
    records.forEach((record) => {
      const campaignType = campaignTypesById[record.campaign_id] || ''
      const negativeTargetingType = capitalizeFirstLetter(record.targeting_type || 'Manual')

      if (selectedAdType.value !== '') {
        if (campaignType.toLowerCase() !== selectedAdType.value) {
          return
        }
      }

      if (selectedTargetingType.value !== '') {
        if (negativeTargetingType.toLowerCase() !== selectedTargetingType.value) {
          return
        }
      }

      const target = parseTargetExp(record.expression)
      let asin = ''
      if (target.indexOf('asin=') === 0) {
        const parsed = JSON.parse(record.expression)
        asin = parsed[0].value
      }
      extended.push({
        ...record,
        campaignName: campaignNamesById[record.campaign_id] || '',
        campaignType,
        targetingType: campaignTargetingTypesById[record.campaign_id] || '',
        adgroupName: record.adgroup_id
          ? adgroupNamesById[record.adgroup_id] || '' : '',
        target,
        asin,
        negativeTargetingType,
        level: record.adgroup_id ? 'Ad group level' : 'Campaign level',
      })
    })

    setTargets(extended)
    setGroupedTargets(
      groupRecords(
        extended,
        'campaign_id',
        ['campaignName', 'campaignType', 'targetingType']
      )
    )
  }, [advancedNegativeData, campaignsWithHistory,
    adgroupsForCampaignsData, selectedAdType, selectedTargetingType])

  const handleArchive = () => {
    const negatives = targets.filter(record => (
      selectedTargets.indexOf(record.target_id) !== -1
    ))

    if (negatives.length) {
      dispatch(updateNtStates(negatives, 'archived'))
    }
  }

  const renderFilter = () => {
    return (
      <div className="filter-container">
        <div className="toggle-wrapper">
          <Toggle
            checked={groupMode}
            checkedChildren="Organize by campaigns"
            unCheckedChildren="By targets"
            onChange={setGroupMode}
          />
        </div>
        <div className="select-wrapper">
          <span>Ad Type</span>
          <Select
            classNamePrefix="ad-type-selector"
            options={campaignTypes}
            value={selectedAdType}
            onChange={setSelectedAdType}
          />
        </div>
        <div className="select-wrapper">
          <span>Targeting Type</span>
          <Select
            classNamePrefix="match-type-selector"
            options={targetingTypes}
            value={selectedTargetingType}
            onChange={setSelectedTargetingType}
          />
        </div>
      </div>
    )
  }

  const renderAction = () => {
    if (!selectedTargets.length) {
      return null
    }

    return (
      <>
        <button
          type="button"
          className="btn btn-red"
          disabled={isUpdatingNtStates}
          onClick={() => { handleArchive() }}
        >
          Remove Negative{selectedTargets.length > 1 ? 's' : ''}
        </button>
      </>
    )
  }

  const renderTarget = record => (
    <>
      <div className="table-col col-target" title={record.target}>
        <strong className="contents">
          { record.target }
        </strong>
        {
          record.asin !== '' && (
            <a
              href={`https://${getAmazonLink(selectedUserInfo)}/gp/product/${record.asin}`}
              target="_blank"
              rel="noopener noreferrer"
            >
              <Icon.FiExternalLink size={16} />
            </a>
          )
        }
      </div>
      <div className="table-col">
        { record.negativeTargetingType }
      </div>
      <div className="table-col">
        { record.level }
      </div>
      <TableCampaignCell record={record} />
      <div className="table-col col-adgroup" title={record.adgroupName}>
        <span className="contents">
          { record.adgroupName }
        </span>
      </div>
    </>
  )

  // For grouped table.
  const renderParent = record => (
    <>
      <TableCampaignCell record={record} />
      <div className="table-col">
        { record.children.length }
      </div>
    </>
  )

  const renderChild = record => (
    <>
      <div className="table-col col-target" title={record.target}>
        <strong className="contents">
          { record.target }
        </strong>
        {
          record.asin !== '' && (
            <a
              href={`https://${getAmazonLink(selectedUserInfo)}/gp/product/${record.asin}`}
              target="_blank"
              rel="noopener noreferrer"
            >
              <Icon.FiExternalLink size={16} />
            </a>
          )
        }
      </div>
      <div className="table-col">
        { record.negativeTargetingType }
      </div>
      <div className="table-col">
        { record.level }
      </div>
      <div className="table-col col-adgroup" title={record.adgroupName}>
        <span className="contents">
          { record.adgroupName }
        </span>
      </div>
    </>
  )

  const isLoading = isUpdatingNtStates

  return (
    <>
      { renderFilter() }
      {
        groupMode ? (
          <SortableTable
            tableComponent={GroupTable}
            isLoading={isLoading}
            columns={columnsGroup}
            defaultSort={['target', 'asc']}
            sorter={tableSorter(['campaignName'])}
            className="table-grouped-negative-targets"
            records={groupedTargets}
            idField="campaign_id"
            searchFields={['target']}
            selectedRecords={selectedTargets}
            paginationSelectPlacement="top"
            noSearch
            hasSticky
            renderRecord={renderParent}
            renderTopRight={renderAction}
            onChange={setSelectedTargets}
            showParentColumnsOnly
            hasSearchChild
            sorterChild={tableSorter(['adgroupName', 'level', 'target', 'targetingType'])}
            idFieldChild="target_id"
            renderChild={renderChild}
          />
        ) : (
          <SortableTable
            isLoading={isLoading}
            columns={columns}
            defaultSort={['target', 'asc']}
            sorter={tableSorter(['campaignName', 'adgroupName', 'level', 'target', 'targetingType'])}
            className="table-negative-targets"
            records={targets || []}
            idField="target_id"
            searchFields={['target']}
            selectedRecords={selectedTargets}
            paginationSelectPlacement="top"
            hasSticky
            renderRecord={renderTarget}
            renderTopRight={renderAction}
            onChange={setSelectedTargets}
          />
        )
      }
    </>
  )
}

export default AdvancedNegativeTargetTable
