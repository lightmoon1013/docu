import React, { useEffect, useState } from 'react'
import { useDispatch, useStore } from 'react-redux'
import { Toggle } from 'rsuite'
import Select from 'react-select'

import SortableTable from '../CommonComponents/SortableTableComponent'
import GroupTable from '../CommonComponents/GroupTableComponent'
import TableCampaignCell from '../CommonComponents/TableCampaignCell'

import { updateNkStates } from '../../redux/actions/bulkEngine'

import { tableSorter, groupRecords } from '../../services/helper'
import { campaignTypes, negativeMatchTypes } from '../../utils/filterDef'

const columns = [
  { key: 'keyword', name: 'Keyword', className: 'col-keyword' },
  { key: 'matchType', name: 'Match Type' },
  { key: 'level', name: 'Level' },
  { key: 'campaignName', name: 'Campaign', className: 'col-campaign' },
  { key: 'adgroupName', name: 'Ad Group', className: 'col-adgroup' },
]

const columnsGroup = [
  { key: 'campaignName', name: 'Campaign', className: 'col-campaign', parentOnly: true },
  { key: 'childCount', name: 'Number of Negatives', parentOnly: true },
  { key: 'keyword', name: 'Keyword', className: 'col-keyword' },
  { key: 'matchType', name: 'Match Type' },
  { key: 'level', name: 'Level' },
  { key: 'adgroupName', name: 'Ad Group', className: 'col-adgroup' },
]

const AdvancedNegativeKeywordTable = () => {
  const dispatch = useDispatch()
  const store = useStore()
  const {
    campaign: {
      campaignsWithHistory,
    },
    bulkEngine: {
      adgroupsForCampaignsData,
      advancedNegativeData,
      isUpdatingNkStates,
    },
  } = store.getState()

  const [groupMode, setGroupMode] = useState(false)
  const [keywords, setKeywords] = useState([])
  const [groupedKeywords, setGroupedKeywords] = useState([])
  const [selectedKeywords, setSelectedKeywords] = useState([])
  const [selectedAdType, setSelectedAdType] = useState(campaignTypes[0])
  const [selectedMatchType, setSelectedMatchType] = useState(negativeMatchTypes[0])

  useEffect(() => {
    const campaignNamesById = {}
    const campaignTypesById = {}
    const campaignTargetingTypesById = {}
    campaignsWithHistory.forEach((campaign) => {
      campaignNamesById[campaign.campaign_id] = campaign.campaign
      campaignTypesById[campaign.campaign_id] = campaign.campaignType
      campaignTargetingTypesById[campaign.campaign_id] = campaign.targeting_type
    })

    const adgroupNamesById = {}
    adgroupsForCampaignsData.forEach((adgroup) => {
      adgroupNamesById[adgroup.adgroup_id] = adgroup.name
    })

    // Remove duplicate entries.
    const records =  [...new Map(
      ((advancedNegativeData || {}).negativeKeywords || [])
      .map(item => [item.keyword_id, item]))
      .values()
    ]

    const extendedKeywords = [];
    records.forEach((record) => {
      const campaignType = campaignTypesById[record.campaign_id] || ''

      if (selectedAdType.value !== '') {
        if (campaignType.toLowerCase() !== selectedAdType.value) {
          return
        }
      }

      if (selectedMatchType.value !== '') {
        if ((record.match_type || '').toLowerCase() !== selectedMatchType.value) {
          return
        }
      }

      extendedKeywords.push({
        ...record,
        campaignName: campaignNamesById[record.campaign_id] || '',
        campaignType,
        targetingType: campaignTargetingTypesById[record.campaign_id] || '',
        adgroupName: record.adgroup_id
          ? adgroupNamesById[record.adgroup_id] || '' : '',
        matchType: record.match_type,
        level: record.adgroup_id ? 'Ad group level' : 'Campaign level',
      })
    })

    setKeywords(extendedKeywords)
    setGroupedKeywords(
      groupRecords(
        extendedKeywords,
        'campaign_id',
        ['campaignName', 'campaignType', 'targetingType']
      )
    )
  }, [advancedNegativeData, campaignsWithHistory,
    adgroupsForCampaignsData, selectedAdType, selectedMatchType])

  const handleArchive = () => {
    const negatives = keywords.filter(record => (
      selectedKeywords.indexOf(record.keyword_id) !== -1
    ))

    if (negatives.length) {
      dispatch(updateNkStates(negatives, 'archived'))
    }
  }

  const renderFilter = () => {
    return (
      <div className="filter-container">
        <div className="toggle-wrapper">
          <Toggle
            checked={groupMode}
            checkedChildren="Organize by campaigns"
            unCheckedChildren="By keywords"
            onChange={setGroupMode}
          />
        </div>
        <div className="select-wrapper">
          <span>Ad Type</span>
          <Select
            classNamePrefix="ad-type-selector"
            options={campaignTypes}
            value={selectedAdType}
            onChange={setSelectedAdType}
          />
        </div>
        <div className="select-wrapper">
          <span>Match Type</span>
          <Select
            classNamePrefix="match-type-selector"
            options={negativeMatchTypes}
            value={selectedMatchType}
            onChange={setSelectedMatchType}
          />
        </div>
      </div>
    )
  }

  const renderAction = () => {
    if (!selectedKeywords.length) {
      return null
    }

    return (
      <>
        <button
          type="button"
          className="btn btn-red"
          disabled={isUpdatingNkStates}
          onClick={() => { handleArchive() }}
        >
          Remove Negative{selectedKeywords.length > 1 ? 's' : ''}
        </button>
      </>
    )
  }

  const renderKeyword = record => (
    <>
      <div className="table-col col-keyword" title={record.keyword}>
        <strong className="contents">
          { record.keyword }
        </strong>
      </div>
      <div className="table-col">
        { record.matchType === 'negativePhrase' ? 'Negative Phrase' : 'Negative Exact' }
      </div>
      <div className="table-col">
        { record.level }
      </div>
      <TableCampaignCell record={record} />
      <div className="table-col col-adgroup" title={record.adgroupName}>
        <span className="contents">
          { record.adgroupName }
        </span>
      </div>
    </>
  )

  // For grouped table.
  const renderParent = record => (
    <>
      <TableCampaignCell record={record} />
      <div className="table-col">
        { record.children.length }
      </div>
    </>
  )

  const renderChild = record => (
    <>
      <div className="table-col col-keyword" title={record.keyword}>
        <strong className="contents">
          { record.keyword }
        </strong>
      </div>
      <div className="table-col">
        { record.matchType === 'negativePhrase' ? 'Negative Phrase' : 'Negative Exact' }
      </div>
      <div className="table-col">
        { record.level }
      </div>
      <div className="table-col col-adgroup" title={record.adgroupName}>
        <span className="contents">
          { record.adgroupName }
        </span>
      </div>
    </>
  )

  const isLoading = isUpdatingNkStates

  return (
    <>
      { renderFilter() }
      {
        groupMode ? (
          <SortableTable
            tableComponent={GroupTable}
            isLoading={isLoading}
            columns={columnsGroup}
            defaultSort={['keyword', 'asc']}
            sorter={tableSorter(['campaignName'])}
            className="table-grouped-negative-keywords"
            records={groupedKeywords}
            idField="campaign_id"
            searchFields={['keyword']}
            selectedRecords={selectedKeywords}
            paginationSelectPlacement="top"
            noSearch
            hasSticky
            renderRecord={renderParent}
            renderTopRight={renderAction}
            onChange={setSelectedKeywords}
            showParentColumnsOnly
            hasSearchChild
            sorterChild={tableSorter(['adgroupName', 'level', 'keyword', 'matchType'])}
            idFieldChild="keyword_id"
            renderChild={renderChild}
          />
        ) : (
          <SortableTable
            isLoading={isLoading}
            columns={columns}
            defaultSort={['keyword', 'asc']}
            sorter={tableSorter(['campaignName', 'adgroupName', 'level', 'keyword', 'matchType'])}
            className="table-negative-keywords"
            records={keywords || []}
            idField="keyword_id"
            searchFields={['keyword']}
            selectedRecords={selectedKeywords}
            paginationSelectPlacement="top"
            hasSticky
            renderRecord={renderKeyword}
            renderTopRight={renderAction}
            onChange={setSelectedKeywords}
          />
        )
      }
    </>
  )
}

export default AdvancedNegativeKeywordTable
