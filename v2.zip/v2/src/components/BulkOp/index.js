/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useEffect, useState } from 'react'
import { useDispatch, useStore } from 'react-redux'
import { Dropdown, Tooltip, Whisper } from 'rsuite'

import LoaderComponent from '../CommonComponents/LoaderComponent'
import TableFilterModal from '../CommonComponents/TableFilterModal'
import VideoLink from '../CommonComponents/VideoLink'
import CampaignTableComponent from '../CampaignTableComponent'

import { ReactComponent as InfoSvg } from '../../assets/svg/info.svg'

import AdgroupSelectorModal from './AdgroupSelectorModal'
import SkuOpResult, { MODULE_NAME_SKU_OP, FILTER_NAME_SKU_OP } from './SkuOpResult'
import TargetOpResult, { MODULE_NAME_TARGET_OP, FILTER_NAME_TARGET_OP } from './TargetOpResult'
import StOpResult, { MODULE_NAME_ST_OP, FILTER_NAME_ST_OP } from './StOpResult'
import NegativeResult, { MODULE_NAME_NEGATIVE } from './NegativeResult'
import AdvancedNegativeResult from './AdvancedNegativeResult'

import {
  getAdgroupsForCampaigns,
  getSKUOpData,
  getTargetOpData,
  getStOpData,
  getNegativeFinderData,
  getAdvancedNegativeData,
} from '../../redux/actions/bulkEngine'

const MODULE_SKU = 'sku'
const MODULE_TARGET = 'target'
const MODULE_ST = 'st'
const MODULE_NEGATIVE = 'negative'
const MODULE_ADVANCED = 'advanced'

const MODULE_NAME_ADVANCED = 'Advanced Optimization'

const moduleList = [
  {
    key: MODULE_SKU,
    name: MODULE_NAME_SKU_OP,
    description: (
      <>
        <p>
          Finds SKU’s (ads) that are hidden in campaigns and ad groups that are unprofitable.
        </p>
        <p>
          Compatible with Sponsored Product and Sponsored Display only.
        </p>
      </>
    ),
  },
  {
    key: MODULE_TARGET,
    name: MODULE_NAME_TARGET_OP,
    description: (
      <>
        <p>
          Easily find and optimize targets across all campaigns
          and ad groups at once.
        </p>
      </>
    ),
  },
  {
    key: MODULE_ST,
    name: MODULE_NAME_ST_OP,
    description: (
      <>
        <p>
          Searches multiple campaigns and ad groups to find search terms
          or ASINS that are losing you money.
        </p>
      </>
    ),
  },
  {
    key: MODULE_NEGATIVE,
    name: MODULE_NAME_NEGATIVE,
    description: (
      <>
        <p>
          Finds individual words hidden in search terms that are unprofitable
          so they can be negated (negative phrase match).
        </p>
      </>
    ),
  },
  {
    key: MODULE_ADVANCED,
    name: MODULE_NAME_ADVANCED,
    description: (
      <>
        <p>
          In-depth optimization performed in bulk.
        </p>
        <p>
          Select the type of Advanced Optimization action you’d like to take.
        </p>
        <p>
          Then, select a date range and the campaigns you’d like to optimize.
        </p>
        <p>
          Then click Search.
        </p>
      </>
    ),
  },
]

const ACTION_EXPENSIVE = 'expensive'
const ACTION_NO_IMPRESSION = 'no_impression'
const ACTION_LOW_CONVERSION = 'low_conversion'
const ACTION_NO_SALES = 'no_sales'
const ACTION_NEGATIVES = 'negatives'

const actionList = [
  {
    value: ACTION_EXPENSIVE,
    label: 'Find High CPC Targets',
    description: (
      <>
        <p>
          Displays targets in order of highest to lowest CPC
          and allows you to adjust bids or pause targets.
        </p>
      </>
    ),
  },
  {
    value: ACTION_NO_IMPRESSION,
    label: 'Find Zero Impression Targets',
    description: (
      <>
        <p>
          Finds all targets in selected campaigns with zero impressions
          and allows you to adjust bids or pause targets.
        </p>
      </>
    ),
  },
  {
    value: ACTION_LOW_CONVERSION,
    label: 'Find Low Converting Targets',
    description: (
      <>
        <p>
          Finds and displays targets with a Conversion Rate under 7%
          and allows you to adjust bids and statuses.
        </p>
      </>
    ),
  },
  {
    value: ACTION_NO_SALES,
    label: 'Find Targets with Spend and No Sales',
    description: (
      <>
        <p>
          Finds all targets with ad spend but no sales
          and allows you to adjust bids and statuses.
        </p>
      </>
    ),
  },
  {
    value: ACTION_NEGATIVES,
    label: 'Review All Negatives',
    description: (
      <>
        <p>
          Displays all Negative Keywords and Negative Targeting in selected campaigns
          and allows you to archive any or all of them.
        </p>
      </>
    ),
  },
]

export const tutorialList = {
  '': {
    title: 'Bulk Engine Overview',
    videoList: [
      { title: 'Bulk Engine Overview', url: 'https://www.loom.com/embed/8aade68f957449d5ab685182612c39ad' },
    ],
  },
  [MODULE_SKU]: {
    title: MODULE_NAME_SKU_OP,
    videoList: [
      { title: MODULE_NAME_SKU_OP, url: 'https://www.loom.com/embed/9616163435a94a7e8c14742a6d9b157b' },
    ],
  },
  [MODULE_TARGET]: {
    title: MODULE_NAME_TARGET_OP,
    videoList: [
      { title: MODULE_NAME_TARGET_OP, url: 'https://www.loom.com/embed/0b12967340884ceeade49532d1b5b0e9' },
    ],
  },
  [MODULE_ST]: {
    title: MODULE_NAME_ST_OP,
    videoList: [
      { title: MODULE_NAME_ST_OP, url: 'https://www.loom.com/embed/14bd02eb73d14ac984970771a4655b29' },
    ],
  },
  [MODULE_NEGATIVE]: {
    title: MODULE_NAME_NEGATIVE,
    videoList: [
      { title: MODULE_NAME_NEGATIVE, url: 'https://www.loom.com/embed/a516e13e6f164a2aa1d0fde6d4fc182b' },
    ],
  },
  [MODULE_ADVANCED]: {
    title: MODULE_NAME_ADVANCED,
    videoList: [
      { title: MODULE_NAME_ADVANCED, url: 'https://www.loom.com/embed/039500d677f640b89a7939886575173e' },
    ],
  },
}

const BulkOp = () => {
  const dispatch = useDispatch()
  const store = useStore().getState()

  const {
    header: {
      currentUserId,
      currentStartDate,
      currentEndDate,
    },
    bulkEngine: {
      isGettingSkuOp,
      isGettingTargetOp,
      isGettingStOp,
      isGettingNegativeFinderData,
      isGettingAdvancedNegativeData,
    },
  } = store

  const [activeModule, setActiveModule] = useState('')
  const [activeAction, setActiveAction] = useState('')
  const [selectedCampaigns, setSelectedCampaigns] = useState([])
  const [selectedAdgroupIds, setSelectedAdgroupIds] = useState([])
  const [isAdgroupSelectorVisible, setIsAdgroupSelectorVisible] = useState(false)
  const [newTermOnly, setNewTermOnly] = useState(true)
  const [hideAsins, setHideAsins] = useState(true)
  const [targetAcos, setTargetAcos] = useState(40)
  const [removeNumbers, setRemoveNumbers] = useState(true)
  const [removePreps, setRemovePreps] = useState(true)
  const [currentFilterName, setCurrentFilterName] = useState('')
  const [hasResults, setHasResults] = useState(false)
  const [isCampaignsExpanded, setIsCampaignsExpanded] = useState(false)

  useEffect(() => {
    setSelectedCampaigns([])
    setSelectedAdgroupIds([])
    setIsAdgroupSelectorVisible(false)
    setCurrentFilterName('')
    setHasResults(false)
    setIsCampaignsExpanded(false)
  }, [currentUserId])

  const handleModuleSelect = (module) => {
    if (activeModule !== module.key) {
      setHasResults(false)
      setActiveModule(module.key)
    }
  }

  const handleFind = () => {
    dispatch(getAdgroupsForCampaigns(
      selectedCampaigns.map(campaign => campaign.campaign_id)
    ))
    setIsAdgroupSelectorVisible(true)
  }

  const getResults = (adgroupIds, startDate, endDate, acos) => {
    if (activeModule === MODULE_SKU) {
      return dispatch(getSKUOpData(
        selectedCampaigns.map(campaign => campaign.campaign_id),
        adgroupIds,
        startDate,
        endDate
      ))
    } else if (activeModule === MODULE_TARGET) {
      return dispatch(getTargetOpData(
        selectedCampaigns.map(campaign => campaign.campaign_id),
        adgroupIds,
        startDate,
        endDate
      ))
    } else if (activeModule === MODULE_ST) {
      return dispatch(getStOpData(
        selectedCampaigns.map(campaign => campaign.campaign_id),
        adgroupIds,
        startDate,
        endDate,
        newTermOnly
      ))
    } else if (activeModule === MODULE_NEGATIVE) {
      return dispatch(getNegativeFinderData(
        selectedCampaigns.map(campaign => campaign.campaign_id),
        adgroupIds,
        startDate,
        endDate,
        acos || targetAcos
      ))
    } else if (activeModule === MODULE_ADVANCED) {
      if (activeAction === ACTION_EXPENSIVE
        || activeAction === ACTION_NO_IMPRESSION
        || activeAction === ACTION_LOW_CONVERSION
        || activeAction === ACTION_NO_SALES) {
        return dispatch(getTargetOpData(
          selectedCampaigns.map(campaign => campaign.campaign_id),
          adgroupIds,
          startDate,
          endDate,
          activeAction
        ))
      } else if (activeAction === ACTION_NEGATIVES) {
        return dispatch(getAdvancedNegativeData(
          selectedCampaigns.map(campaign => campaign.campaign_id),
          adgroupIds,
        ))
      }
    }
  }

  const handleAdgroupSelect = (adgroupIds) => {
    setIsAdgroupSelectorVisible(false)
    setSelectedAdgroupIds(adgroupIds)

    let filterName
    // No filter for negative finder & advanced op.
    if (activeModule === MODULE_SKU) {
      filterName = FILTER_NAME_SKU_OP
    } else if (activeModule === MODULE_TARGET) {
      filterName = FILTER_NAME_TARGET_OP
    } else if (activeModule === MODULE_ST) {
      filterName = FILTER_NAME_ST_OP
    }

    if (!filterName) {
      setHasResults(false)
      getResults(
        adgroupIds,
        currentStartDate,
        currentEndDate
      ).then(() => {
        setHasResults(true)
        setIsCampaignsExpanded(false)
      })
    } else {
      setCurrentFilterName(filterName)
    }
  }

  const handleFilterApply = () => {
    setCurrentFilterName('')
    setHasResults(false)

    getResults(
      selectedAdgroupIds,
      currentStartDate,
      currentEndDate
    ).then(() => {
      setHasResults(true)
      setIsCampaignsExpanded(false)
    })
  }

  const handleDateChange = (startDate, endDate) => {
    getResults(selectedAdgroupIds, startDate, endDate)
  }

  const handleChangeNewTermOnly = (checked) => {
    setNewTermOnly(checked)
    dispatch(getStOpData(
      selectedCampaigns.map(campaign => campaign.campaign_id),
      selectedAdgroupIds,
      currentStartDate,
      currentEndDate,
      checked
    ))
  }

  const handleTargetAcosChange = (acos) => {
    setTargetAcos(acos)
    getResults(selectedAdgroupIds, currentStartDate, currentEndDate, acos)
  }

  const renderTopSection = (currentModuleName) => {
    let searchDisabled = false
    let buttonLabel = 'Continue'
    if (!activeModule) {
      searchDisabled = true
      buttonLabel = 'Choose Module'
    } else if (!selectedCampaigns.length) {
      searchDisabled = true
      buttonLabel = 'Select Campaigns to Continue'
    } else if (activeModule === MODULE_ADVANCED && !activeAction) {
      searchDisabled = true
      buttonLabel = 'Choose Action'
    }

    let dropdownLabel = 'Actions'
    if (activeModule === MODULE_ADVANCED) {
      if (activeAction) {
        const active = actionList.find(module => module.value === activeAction)
        if (active) {
          dropdownLabel = active.label
        }
      }
    }
    return (
      <>
        {
          activeModule === MODULE_ADVANCED && (
            <Dropdown title={dropdownLabel}>
              {
                actionList.map(action => (
                  <Dropdown.Item
                    key={action.value}
                    active={action.value === activeAction}
                    onSelect={() => { setActiveAction(action.value); setHasResults(false) }}
                  >
                    { action.label }
                    <Whisper placement="right" trigger="hover" speaker={(
                      <Tooltip>
                        { action.description }
                      </Tooltip>
                    )}>
                      <InfoSvg />
                    </Whisper>
                  </Dropdown.Item>
                ))
              }
            </Dropdown>
          )
        }
        {
          (!hasResults || isCampaignsExpanded) && (
            <button
              type="button"
              className="btn btn-blue"
              disabled={searchDisabled}
              onClick={handleFind}
            >
              { buttonLabel }
            </button>
          )
        }
        <AdgroupSelectorModal
          show={isAdgroupSelectorVisible}
          currentModuleName={currentModuleName}
          onConfirm={handleAdgroupSelect}
          onClose={() => { setIsAdgroupSelectorVisible(false) }}
        />
      </>
    )
  }

  const renderModuleSelector = (dropdownLabel) => {
    return (
      <div className="module-selector-container">
        <div className="module-selector-left">
          <Dropdown title={dropdownLabel}>
            {
              moduleList.map(module => (
                <Dropdown.Item
                  key={module.key}
                  active={module.key === activeModule}
                  onSelect={() => { handleModuleSelect(module) }}
                >
                  { module.name }
                  <Whisper placement="right" trigger="hover" speaker={(
                    <Tooltip>
                      { module.description }
                    </Tooltip>
                  )}>
                    <InfoSvg />
                  </Whisper>
                </Dropdown.Item>
              ))
            }
          </Dropdown>
          { renderTopSection(dropdownLabel) }
        </div>
        <VideoLink
          modalTitle={tutorialList[activeModule].title}
          videoList={tutorialList[activeModule].videoList}
        />
      </div>
    )
  }

  const renderCampaignSelection = () => {
     if (hasResults && !isCampaignsExpanded) {
      return (
        <div className="campaign-seletion-state">
          <strong>{ selectedCampaigns.length }</strong> campaigns selected.
          <a
            href="#"
            onClick={(event) => { event.preventDefault(); setIsCampaignsExpanded(true) }}
          >
            Change
          </a>
        </div>
      )
    }
    return null
  }

  const renderResults = () => {
    if (!hasResults) {
      return null
    }

    if (activeModule === MODULE_SKU) {
      return (
        <SkuOpResult
          onChangeDate={handleDateChange}
        />
      )
    }
    if (activeModule === MODULE_TARGET) {
      return (
        <TargetOpResult
          onChangeDate={handleDateChange}
        />
      )
    }
    if (activeModule === MODULE_ST) {
      return (
        <StOpResult
          newTermOnly={newTermOnly}
          hideAsins={hideAsins}
          onChangeNewTermOnly={handleChangeNewTermOnly}
          onChangeHideAsins={setHideAsins}
          onChangeDate={handleDateChange}
        />
      )
    }
    if (activeModule === MODULE_NEGATIVE) {
      return (
        <NegativeResult
          hideAsins={hideAsins}
          removeNumbers={removeNumbers}
          removePreps={removePreps}
          currentTargetAcos={targetAcos}
          onChangeHideAsins={setHideAsins}
          onChangeRemoveNumbers={setRemoveNumbers}
          onChangeRemovePreps={setRemovePreps}
          onChangeDate={handleDateChange}
          onChangeTargetAcos={handleTargetAcosChange}
        />
      )
    }
    if (activeModule === MODULE_ADVANCED) {
      if (activeAction === ACTION_EXPENSIVE) {
        return (
          <TargetOpResult
            sortBy={['cpc', 'desc']}
            forAdvanced
            onChangeDate={handleDateChange}
          />
        )
      }
      if (activeAction === ACTION_NO_IMPRESSION) {
        return (
          <TargetOpResult
            forAdvanced
            onChangeDate={handleDateChange}
          />
        )
      }
      if (activeAction === ACTION_LOW_CONVERSION) {
        return (
          <TargetOpResult
            sortBy={['conversion', 'asc']}
            keyMetric="conversion"
            forAdvanced
            onChangeDate={handleDateChange}
          />
        )
      }
      if (activeAction === ACTION_NO_SALES) {
        return (
          <TargetOpResult
            sortBy={['cost', 'desc']}
            keyMetric="cost"
            forAdvanced
            onChangeDate={handleDateChange}
          />
        )
      }
      if (activeAction === ACTION_NEGATIVES) {
        return (
          <AdvancedNegativeResult />
        )
      }
    }
    return null
  }

  let dropdownLabel = 'Choose Module'
  if (activeModule) {
    const active = moduleList.find(module => module.key === activeModule)
    if (active) {
      dropdownLabel = active.name
    }
  }

  const isLoading = isGettingSkuOp || isGettingTargetOp
    || isGettingStOp || isGettingNegativeFinderData
    || isGettingAdvancedNegativeData

  return (
    <div className={`bulk-engine-container bulk-op-container${isLoading ? ' loading' : ''}`}>
      { isLoading && <LoaderComponent /> }
      <div className="module-description">
        Choose Module, Select Campaigns and Ad Groups, Refine Filters and Go!
      </div>
      { renderModuleSelector(dropdownLabel) }
      { renderCampaignSelection() }
      <CampaignTableComponent
        className={hasResults && !isCampaignsExpanded ? 'hidden' : ''}
        hideSb={activeModule === MODULE_SKU}
        hideSd={activeModule === MODULE_ST}
        fromBulkEngine
        customCallbacks={{
          onSelectCampaigns: setSelectedCampaigns,
        }}
      />
      { renderResults() }
      {
        currentFilterName !== '' && (
          <TableFilterModal
            filterName={currentFilterName}
            currentModuleName={dropdownLabel}
            onApply={handleFilterApply}
            onClose={() => { setCurrentFilterName('') }}
          />
        )
      }
    </div>
  )
}

export default BulkOp
