import React, { useEffect, useMemo, useState } from 'react'
import { useStore } from 'react-redux'
import { Tooltip, Whisper, Toggle } from 'rsuite'
import Select from 'react-select'

import SortableTable from '../CommonComponents/SortableTableComponent'
import GroupTable from '../CommonComponents/GroupTableComponent'
import CheckboxComponent from '../CommonComponents/CheckboxComponent'
import { toast } from '../CommonComponents/ToastComponent/toast'
import TableCell from '../CommonComponents/TableCell'
import TableCampaignCell from '../CommonComponents/TableCampaignCell'
import TableFilterModal from '../CommonComponents/TableFilterModal'

import BulkResultContainer from '../BulkResultContainer'
import NegativeCreatorModal from './NegativeCreatorModal'

import { ReactComponent as InfoSvg } from '../../assets/svg/info.svg'

import {
  tableSorter,
  calcDerivedMetrics,
  capitalizeFirstLetter,
  copyToClipboard,
  getExportValueForColumn,
  groupRecords,
} from '../../services/helper'

import { bulkSTColumnList } from '../../utils/defaultValues'

import { matchTypes } from '../../utils/filterDef'

export const MODULE_NAME_ST_OP = 'Search Term/ASIN Optimization'
export const FILTER_NAME_ST_OP = 'bulkStOp'

const columns = [
  { key: 'search', name: 'Search Term', className: 'col-search-term' },
  { key: 'matchType', name: 'Match Type' },
  { key: 'target', name: 'Associated Target', className: 'col-target' },
  { key: 'campaignName', name: 'Campaign', className: 'col-campaign' },
  { key: 'adgroupName', name: 'Ad Group', className: 'col-adgroup' },
  ...bulkSTColumnList,
]

const columnsGroup = [
  { key: 'campaignName', name: 'Campaign', className: 'col-campaign', parentOnly: true },
  { key: 'checkPlaceholder', name: '', className: 'col-check', exportable: false, parentOnly: true },
  { key: 'search', name: 'Search Term', className: 'col-search-term' },
  { key: 'matchType', name: 'Match Type' },
  { key: 'target', name: 'Associated Target', className: 'col-target' },
  { key: 'adgroupName', name: 'Ad Group', className: 'col-adgroup' },
  ...bulkSTColumnList,
]

const StOpResult = ({ newTermOnly, hideAsins, onChangeNewTermOnly, onChangeHideAsins, onChangeDate }) => {
  const store = useStore()

  const {
    header: {
      currencyRate,
      currencySign,
    },
    pageGlobal: {
      campaignTableColumns,
      stTableColumns,
    },
    campaign: {
      campaignsWithHistory,
    },
    bulkEngine: {
      adgroupsForCampaignsData,
      stOpData,
    },
  } = store.getState()

  const [groupMode, setGroupMode] = useState(false)
  const [searchTerms, setSearchTerms] = useState([])
  const [groupedSearchTerms, setGroupedSearchTerms] = useState([])
  const [selectedSearchTerms, setSelectedSearchTerms] = useState([])
  const [showNegativeCreatorModal, setShowNegativeCreatorModal] = useState(false)
  const [selectedMatchType, setSelectedMatchType] = useState(matchTypes[0])
  const [currentFilterName, setCurrentFilterName] = useState('')

  useEffect(() => {
    const campaignNamesById = {}
    const campaignTypesById = {}
    const targetingTypesById = {}
    campaignsWithHistory.forEach((campaign) => {
      campaignNamesById[campaign.campaign_id] = campaign.campaign
      campaignTypesById[campaign.campaign_id] = campaign.campaignType
      targetingTypesById[campaign.campaign_id] = campaign.targeting_type
    })

    const adgroupNamesById = {}
    adgroupsForCampaignsData.forEach((adgroup) => {
      adgroupNamesById[adgroup.adgroup_id] = adgroup.name
    })

    const extendedSearchTerms = []; // semi-colon is a must here.
    (stOpData || []).forEach((record) => {
      // Remove ASINs.
      if (hideAsins && /^[0-9a-z]{10}$/ig.test(record.search)) {
        return
      }

      if (selectedMatchType.value !== '') {
        if ((record.match_type || '').toLowerCase() !== selectedMatchType.value) {
          return
        }
      }

      extendedSearchTerms.push({
        ...calcDerivedMetrics(record),
        matchType: capitalizeFirstLetter(record.match_type),
        campaignName: campaignNamesById[record.campaign_id] || '',
        campaignType: campaignTypesById[record.campaign_id] || '',
        targetingType: targetingTypesById[record.campaign_id] || '',
        adgroupName: adgroupNamesById[record.adgroup_id] || '',
        search: record.search.trim().toLowerCase(),
        target: (record.target === '(_targeting_auto_)'
          || record.target === '(_targeting_auto_, 1)') ? '*' : record.target,
      })
    })

    setSearchTerms(extendedSearchTerms)
    setGroupedSearchTerms(
      groupRecords(
        extendedSearchTerms,
        'campaign_id',
        ['campaignName', 'campaignType', 'targetingType']
      )
    )
  }, [stOpData, campaignsWithHistory, adgroupsForCampaignsData, hideAsins, selectedMatchType])

  const columnSelection = useMemo(() => {
    const selection = [...campaignTableColumns]
    if ((stTableColumns || []).includes('st_impr_rank')) {
      selection.push('st_impr_rank')
    }
    if ((stTableColumns || []).includes('st_impr_share')) {
      selection.push('st_impr_share')
    }
    return selection
  }, [campaignTableColumns, stTableColumns])

  const handleCopy = () => {
    const sts = searchTerms.filter(st => (
      selectedSearchTerms.indexOf(st.id) !== -1
    )).map(st => st.search.trim())

    copyToClipboard([...new Set(sts)].join('\n'))

    toast.show({
      title: 'Success',
      description: `Successfully copied ${selectedSearchTerms.length} search term${selectedSearchTerms.length > 1 ? 's' : ''}.`
    })
  }

  const renderFilter = () => {
    return (
      <div className="filter-container">
        <div className="toggle-wrapper">
          <Toggle
            checked={groupMode}
            checkedChildren="Organize by campaigns"
            unCheckedChildren="By search terms"
            onChange={setGroupMode}
          />
        </div>
        <div className="checkbox-wrapper">
          <CheckboxComponent
            label="New Term Only"
            checked={newTermOnly}
            onChange={onChangeNewTermOnly}
          />
          <Whisper placement="right" trigger="hover" speaker={(
            <Tooltip>
              <p>Remove words already added as negative to selected campaigns and ad groups.</p>
            </Tooltip>
          )}>
            <InfoSvg />
          </Whisper>
        </div>
        <div className="checkbox-wrapper">
          <CheckboxComponent
            label="Remove ASINS"
            checked={hideAsins}
            onChange={onChangeHideAsins}
          />
        </div>
        <div className="select-wrapper">
          <span>Match Type</span>
          <Select
            classNamePrefix="match-type-selector"
            options={matchTypes}
            value={selectedMatchType}
            onChange={setSelectedMatchType}
          />
        </div>
        <div className="button-wrapper">
          <button
            type="button"
            className="btn btn-blue"
            onClick={() => { setCurrentFilterName(FILTER_NAME_ST_OP) }}
          >
            Refine Filter
          </button>
        </div>
      </div>
    )
  }

  const renderAction = () => {
    if (!selectedSearchTerms.length) {
      return null
    }
    return (
      <>
        <button
          type="button"
          className="btn btn-blue"
          onClick={() => { setShowNegativeCreatorModal(true) }}
        >
          Add Negative{selectedSearchTerms.length > 1 ? 's' : ''} to Campaign{selectedSearchTerms.length > 1 ? 's' : ''}
        </button>
        <button
          type="button"
          className="btn btn-green"
          onClick={() => { handleCopy() }}
        >
          Copy
        </button>
      </>
    )
  }

  const renderRecord = record => (
    <>
      <div className="table-col col-search-term" title={record.search}>
        <strong>{ record.search }</strong>
      </div>
      <div className="table-col">
        { record.matchType }
      </div>
      <div className="table-col col-target" title={record.target}>
        <span className="contents">
          { record.target }
        </span>
      </div>
      <TableCampaignCell record={record} />
      <div className="table-col col-adgroup" title={record.adgroupName}>
        <span className="contents">
          { record.adgroupName }
        </span>
      </div>
      {
        bulkSTColumnList.map(column => (
          <TableCell
            key={column.key}
            record={record}
            columnKey={column.key}
            columnSelection={columnSelection}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  // Render aggregation row.
  const renderTotal = summary => (
    <>
      <div className="table-col col-search-term">Totals:</div>
      <div className="table-col" />
      <div className="table-col col-target" />
      <div className="table-col col-campaign" />
      <div className="table-col col-adgroup" />
      {
        bulkSTColumnList.map(column => (
          <TableCell
            key={column.key}
            record={summary}
            columnKey={column.key}
            columnSelection={columnSelection}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  const getExportData = (exportableColumns, record) => (
    exportableColumns.map((column) => {
      if (column.key === 'search') {
        return record.search
      }
      if (column.key === 'matchType') {
        return record.matchType
      }
      if (column.key === 'target') {
        return record.target
      }
      return getExportValueForColumn(record, column.key, currencySign, currencyRate)
    })
  )

  // For grouped table.
  const renderParent = record => (
    <>
      <TableCampaignCell record={record} />
      <div className="table-col col-check" />
      <div className="table-col col-search-term">
        { record.children.length } search terms
      </div>
      <div className="table-col" />
      <div className="table-col col-target" />
      <div className="table-col col-adgroup" />
      {
        bulkSTColumnList.map(column => (
          <TableCell
            key={column.key}
            record={record}
            columnKey={column.key}
            columnSelection={columnSelection}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  const renderChild = record => (
    <>
      <div className="table-col col-search-term" title={record.search}>
        <strong>{ record.search }</strong>
      </div>
      <div className="table-col">
        { record.matchType }
      </div>
      <div className="table-col col-target" title={record.target}>
        <span className="contents">
          { record.target }
        </span>
      </div>
      <div className="table-col col-adgroup" title={record.adgroupName}>
        <span className="contents">
          { record.adgroupName }
        </span>
      </div>
      {
        bulkSTColumnList.map(column => (
          <TableCell
            key={column.key}
            record={record}
            columnKey={column.key}
            columnSelection={columnSelection}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  const renderTotalGroup = summary => (
    <>
      <div className="table-col col-campaign">Totals:</div>
      <div className="table-col col-check" />
      <div className="table-col col-search-term" />
      <div className="table-col" />
      <div className="table-col col-target" />
      <div className="table-col col-adgroup" />
      {
        bulkSTColumnList.map(column => (
          <TableCell
            key={column.key}
            record={summary}
            columnKey={column.key}
            columnSelection={columnSelection}
            currencySign={currencySign}
            currencyRate={currencyRate}
          />
        ))
      }
    </>
  )

  const sts = searchTerms.filter(st => (
    selectedSearchTerms.indexOf(st.id) !== -1
  ))

  return (
    <BulkResultContainer>
      { renderFilter() }
      {
        groupMode ? (
          <SortableTable
            tableComponent={GroupTable}
            columns={columnsGroup}
            defaultSort={['cost', 'desc']}
            sorter={tableSorter(['campaignName'])}
            className="table-grouped-search-terms"
            records={groupedSearchTerms}
            idField="campaign_id"
            searchFields={['search', 'target']}
            selectedRecords={selectedSearchTerms}
            paginationSelectPlacement="top"
            hasSticky
            hasDateRange
            filterName={FILTER_NAME_ST_OP}
            useFilterModal
            columnEditorId="bulkStOpResult"
            columnList={bulkSTColumnList}
            columnSelection={columnSelection}
            exportFileName={MODULE_NAME_ST_OP}
            getExportData={getExportData}
            renderRecord={renderParent}
            renderTotal={renderTotalGroup}
            renderTopRight={renderAction}
            onChange={setSelectedSearchTerms}
            onChangeDate={onChangeDate}
            sorterChild={tableSorter(['search', 'matchType', 'target', 'adgroupName'])}
            idFieldChild="id"
            renderChild={renderChild}
          />
        ) : (
          <SortableTable
            columns={columns}
            defaultSort={['cost', 'desc']}
            sorter={tableSorter(['search', 'matchType', 'target', 'campaignName', 'adgroupName'])}
            className="table-search-terms"
            records={searchTerms}
            idField="id"
            searchFields={['search', 'target']}
            selectedRecords={selectedSearchTerms}
            paginationSelectPlacement="top"
            hasSticky
            hasDateRange
            filterName={FILTER_NAME_ST_OP}
            useFilterModal
            columnEditorId="bulkStOpResult"
            columnList={bulkSTColumnList}
            columnSelection={columnSelection}
            exportFileName={MODULE_NAME_ST_OP}
            getExportData={getExportData}
            renderRecord={renderRecord}
            renderTotal={renderTotal}
            renderTopRight={renderAction}
            onChange={setSelectedSearchTerms}
            onChangeDate={onChangeDate}
          />
        )
      }
      <NegativeCreatorModal
        show={showNegativeCreatorModal}
        searchTerms={sts}
        onClose={() => { setShowNegativeCreatorModal(false) }}
      />
      {
        currentFilterName !== '' && (
          <TableFilterModal
            filterName={currentFilterName}
            currentModuleName={MODULE_NAME_ST_OP}
            onApply={() => { setCurrentFilterName('') }}
            onClose={() => { setCurrentFilterName('') }}
          />
        )
      }
    </BulkResultContainer>
  )
}

export default StOpResult
