import React, { useState } from 'react'

import BulkResultContainer from '../BulkResultContainer'
import TargetOpKeywordTable from './TargetOpKeywordTable'
import TargetOpTargetTable from './TargetOpTargetTable'

const TAB_KEYWORD = 'keyword'
const TAB_TARGET = 'target'

const tabList = [
  {
    value: TAB_KEYWORD,
    label: 'Keywords',
  },
  {
    value: TAB_TARGET,
    label: 'Targets',
  },
]

export const MODULE_NAME_TARGET_OP = 'Bid Optimization'
export const FILTER_NAME_TARGET_OP = 'bulkTargetOp'
export const FILTER_NAME_ADVANCED_OP = 'bulkAdvancedOp'

const TargetOpResult = ({ sortBy = ['cost', 'desc'], keyMetric = '',
forAdvanced = false, onChangeDate }) => {
  const [currentTab, setCurrentTab] = useState(TAB_KEYWORD)

  return (
    <BulkResultContainer>
      <div className="target-op-result-container">
        <div className="tab-list">
          {
            tabList.map((tab) => (
              <button
                key={tab.value}
                type="button"
                className={currentTab === tab.value ? "tab selected" : "tab"}
                onClick={() => { setCurrentTab(tab.value)}}
              >
                { tab.label }
              </button>
            ))
          }
        </div>
        {
          currentTab === TAB_KEYWORD && (
            <TargetOpKeywordTable
              sortBy={sortBy}
              keyMetric={keyMetric}
              forAdvanced={forAdvanced}
              onChangeDate={onChangeDate}
            />
          )
        }
        {
          currentTab === TAB_TARGET && (
            <TargetOpTargetTable
              sortBy={sortBy}
              keyMetric={keyMetric}
              forAdvanced={forAdvanced}
              onChangeDate={onChangeDate}
            />
          )
        }
      </div>
    </BulkResultContainer>
  )
}

export default TargetOpResult
