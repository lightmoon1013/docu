import React, { useEffect, useState } from 'react'
import { useStore } from 'react-redux'
import moment from 'moment'
import { Tooltip, Whisper, Toggle } from 'rsuite'

import SortableTable from '../CommonComponents/SortableTableComponent'
import GroupTable from '../CommonComponents/GroupTableComponent'
import CheckboxComponent from '../CommonComponents/CheckboxComponent'
import { toast } from '../CommonComponents/ToastComponent/toast'
import TableCampaignCell from '../CommonComponents/TableCampaignCell'

import { ReactComponent as InfoSvg } from '../../assets/svg/info.svg'

import BulkResultContainer from '../BulkResultContainer'
import NegativeCreatorModal from './NegativeCreatorModal'

import {
  formatValue,
  formatCurrency,
  tableSorter,
  calcDerivedMetrics,
  copyToClipboard,
  getExportValueForColumn,
  groupRecords,
} from '../../services/helper'

export const MODULE_NAME_NEGATIVE = 'Negative Word Finder'

const prepList = [
  'above', 'across', 'against', 'along', 'among', 'around', 'at',
  'before', 'behind', 'below', 'beneath', 'beside', 'between', 'by',
  'down', 'for', 'from', 'in', 'into', 'near', 'of', 'off', 'on', 'to',
  'toward', 'under', 'upon', 'with', 'within'
]

const columns = [
  { key: 'search', name: 'Words', className: 'col-word' },
  { key: 'campaignName', name: 'Campaign', className: 'col-campaign' },
  { key: 'adgroupName', name: 'Ad Group', className: 'col-adgroup' },
  { key: 'impressions', name: 'Imp.' },
  { key: 'clicks', name: 'Unprofitable Clicks' },
  { key: 'acos', name: 'Associated ACoS %' },
  { key: 'revenue', name: 'Associated Sales' },
  { key: 'cost', name: 'Wasted AD Spend' },
  { key: 'yearlyCost', name: 'Approx Yearly Savings' },
]

const columnsGroup = [
  { key: 'campaignName', name: 'Campaign', className: 'col-campaign', parentOnly: true },
  { key: 'checkPlaceholder', name: '', className: 'col-check', exportable: false, parentOnly: true },
  { key: 'search', name: 'Words', className: 'col-word' },
  { key: 'adgroupName', name: 'Ad Group', className: 'col-adgroup' },
  { key: 'impressions', name: 'Imp.' },
  { key: 'clicks', name: 'Unprofitable Clicks' },
  { key: 'acos', name: 'Associated ACoS %' },
  { key: 'revenue', name: 'Associated Sales' },
  { key: 'cost', name: 'Wasted AD Spend' },
  { key: 'yearlyCost', name: 'Approx Yearly Savings' },
]

const NegativeResult = ({ hideAsins, removeNumbers, removePreps, currentTargetAcos,
  onChangeHideAsins, onChangeRemoveNumbers, onChangeRemovePreps, onChangeDate, onChangeTargetAcos }) => {
  const store = useStore()

  const {
    header: {
      currencyRate,
      currencySign,
      currentStartDate,
      currentEndDate,
    },
    campaign: {
      campaignsWithHistory,
    },
    bulkEngine: {
      adgroupsForCampaignsData,
      negativeFinderData,
    },
  } = store.getState()

  const [groupMode, setGroupMode] = useState(false)
  const [negatives, setNegatives] = useState([])
  const [groupedNegatives, setGroupedNegatives] = useState([])
  const [selectedNegatives, setSelectedNegatives] = useState([])
  const [targetAcos, setTargetAcos] = useState(currentTargetAcos)
  const [showNegativeCreatorModal, setShowNegativeCreatorModal] = useState(false)

  useEffect(() => {
    const campaignNamesById = {}
    const campaignTypesById = {}
    const targetingTypesById = {}
    campaignsWithHistory.forEach((campaign) => {
      campaignNamesById[campaign.campaign_id] = campaign.campaign
      campaignTypesById[campaign.campaign_id] = campaign.campaignType
      targetingTypesById[campaign.campaign_id] = campaign.targeting_type
    })

    const adgroupNamesById = {}
    adgroupsForCampaignsData.forEach((adgroup) => {
      adgroupNamesById[adgroup.adgroup_id] = adgroup.name
    })

    const dateDiff = moment(currentEndDate).diff(moment(currentStartDate), 'day') || 1

    const extendedNegatives = []; // semi-colon is a must here.
    (negativeFinderData || []).forEach((record) => {
      // Remove ASINs.
      if (hideAsins && /^[0-9a-z]{10}$/ig.test(record.search)) {
        return
      }

      // Remove numbers.
      if (removeNumbers && !isNaN(record.search)) {
        return
      }

      // Remove Prepositions.
      if (removePreps && prepList.indexOf(record.search.toLowerCase()) !== -1) {
        return
      }

      extendedNegatives.push({
        ...calcDerivedMetrics(record),
        id: `${record.campaign_id}-${record.adgroup_id}-${record.search}`,
        campaignName: campaignNamesById[record.campaign_id] || '',
        campaignType: campaignTypesById[record.campaign_id] || '',
        targetingType: targetingTypesById[record.campaign_id] || '',
        adgroupName: adgroupNamesById[record.adgroup_id] || '',
        yearlyCost: parseFloat(record.cost) / dateDiff * 365,
      })
    })

    setNegatives(extendedNegatives)
    setGroupedNegatives(
      groupRecords(
        extendedNegatives,
        'campaign_id',
        ['campaignName', 'campaignType', 'targetingType']
      )
    )
  }, [negativeFinderData, hideAsins, removeNumbers, removePreps,
    campaignsWithHistory, adgroupsForCampaignsData, currentStartDate, currentEndDate])

  const handleCopy = () => {
    const sts = negatives.filter(st => (
      selectedNegatives.indexOf(st.id) !== -1
    )).map(st => st.search)

    copyToClipboard([...new Set(sts)].join('\n'))

    toast.show({
      title: 'Success',
      description: `Successfully copied ${selectedNegatives.length} word${selectedNegatives.length > 1 ? 's' : ''}.`
    })
  }

  const renderFilter = () => {
    return (
      <div className="filter-container">
        <div className="toggle-wrapper">
          <Toggle
            checked={groupMode}
            checkedChildren="Organize by campaigns"
            unCheckedChildren="By words"
            onChange={setGroupMode}
          />
        </div>
        <div className="checkbox-wrapper">
          <CheckboxComponent
            label="Remove ASINS"
            checked={hideAsins}
            onChange={onChangeHideAsins}
          />
        </div>
        <div className="checkbox-wrapper">
          <CheckboxComponent
            label="Remove Numbers"
            checked={removeNumbers}
            onChange={onChangeRemoveNumbers}
          />
        </div>
        <div className="checkbox-wrapper">
          <CheckboxComponent
            label="Remove Prepositions"
            checked={removePreps}
            onChange={onChangeRemovePreps}
          />
          <Whisper placement="right" trigger="hover" speaker={(
            <Tooltip>
              <p>{ prepList.join(', ') }</p>
            </Tooltip>
          )}>
            <InfoSvg />
          </Whisper>
        </div>
        <div className="search-wrapper">
          <label>
            ACoS % &gt;
          </label>
          <input
            type="number"
            min="0.1"
            value={targetAcos}
            onChange={(event) => { setTargetAcos(event.target.value) }}
          />
          &nbsp; <strong>or 0</strong>&nbsp;&nbsp;&nbsp;
          <button
            type="button"
            className="btn btn-blue"
            disabled={targetAcos === '' || isNaN(targetAcos)}
            onClick={() => { onChangeTargetAcos(targetAcos) }}
          >
            Search
          </button>
        </div>
      </div>
    )
  }

  const renderAction = () => {
    if (!selectedNegatives.length) {
      return null
    }
    return (
      <>
        <button
          type="button"
          className="btn btn-blue"
          onClick={() => { setShowNegativeCreatorModal(true) }}
        >
          Add Negative{selectedNegatives.length > 1 ? 's' : ''} to Campaign{selectedNegatives.length > 1 ? 's' : ''}
        </button>
        <button
          type="button"
          className="btn btn-green"
          onClick={() => { handleCopy() }}
        >
          Copy
        </button>
      </>
    )
  }

  const renderRecord = record => (
    <>
      <div className="table-col col-word" title={record.search}>
        <strong className="contents">
          { record.search }
        </strong>
      </div>
      <TableCampaignCell record={record} />
      <div className="table-col col-adgroup" title={record.adgroupName}>
        <span className="contents">
          { record.adgroupName }
        </span>
      </div>
      <div className="table-col">
        { formatValue(record.impressions, 'removeZeroDecimal') }
      </div>
      <div className="table-col">
        { formatValue(record.clicks, 'removeZeroDecimal') }
      </div>
      <div className="table-col">
        { formatValue(record.acos, 'percent') }
      </div>
      <div className="table-col">
        { formatCurrency(record.revenue, currencySign, currencyRate) }
      </div>
      <div className="table-col">
        { formatCurrency(record.cost, currencySign, currencyRate) }
      </div>
      <div className="table-col">
        { formatCurrency(record.yearlyCost, currencySign, currencyRate) }
      </div>
    </>
  )

  // Render aggregation row.
  const renderTotal = summary => (
    <>
      <div className="table-col col-word">Totals:</div>
      <div className="table-col col-campaign" />
      <div className="table-col col-adgroup" />
      <div className="table-col">
        { formatValue(summary.impressions, 'removeZeroDecimal') }
      </div>
      <div className="table-col">
        { formatValue(summary.clicks, 'removeZeroDecimal') }
      </div>
      <div className="table-col">
        { formatValue(summary.acos, 'percent') }
      </div>
      <div className="table-col">
        { formatCurrency(summary.revenue, currencySign, currencyRate) }
      </div>
      <div className="table-col">
        { formatCurrency(summary.cost, currencySign, currencyRate) }
      </div>
      <div className="table-col">
        { formatCurrency(summary.yearlyCost, currencySign, currencyRate) }
      </div>
    </>
  )

  const getExportData = (exportableColumns, record) => (
    exportableColumns.map((column) => {
      if (column.key === 'search') {
        return record.search
      }
      if (column.key === 'yearlyCost') {
        return formatCurrency(record.yearlyCost, currencySign, currencyRate)
      }
      return getExportValueForColumn(record, column.key, currencySign, currencyRate)
    })
  )

  // For grouped table.
  const renderParent = record => (
    <>
      <TableCampaignCell record={record} />
      <div className="table-col col-check" />
      <div className="table-col col-word">
        { record.children.length } words
      </div>
      <div className="table-col col-adgroup" />
      <div className="table-col">
        { formatValue(record.impressions, 'removeZeroDecimal') }
      </div>
      <div className="table-col">
        { formatValue(record.clicks, 'removeZeroDecimal') }
      </div>
      <div className="table-col">
        { formatValue(record.acos, 'percent') }
      </div>
      <div className="table-col">
        { formatCurrency(record.revenue, currencySign, currencyRate) }
      </div>
      <div className="table-col">
        { formatCurrency(record.cost, currencySign, currencyRate) }
      </div>
      <div className="table-col">
        { formatCurrency(record.yearlyCost, currencySign, currencyRate) }
      </div>
    </>
  )

  const renderChild = record => (
    <>
      <div className="table-col col-word" title={record.search}>
        <strong className="contents">
          { record.search }
        </strong>
      </div>
      <div className="table-col col-adgroup" title={record.adgroupName}>
        <span className="contents">
          { record.adgroupName }
        </span>
      </div>
      <div className="table-col">
        { formatValue(record.impressions, 'removeZeroDecimal') }
      </div>
      <div className="table-col">
        { formatValue(record.clicks, 'removeZeroDecimal') }
      </div>
      <div className="table-col">
        { formatValue(record.acos, 'percent') }
      </div>
      <div className="table-col">
        { formatCurrency(record.revenue, currencySign, currencyRate) }
      </div>
      <div className="table-col">
        { formatCurrency(record.cost, currencySign, currencyRate) }
      </div>
      <div className="table-col">
        { formatCurrency(record.yearlyCost, currencySign, currencyRate) }
      </div>
    </>
  )

  const renderTotalGroup = summary => (
    <>
      <div className="table-col col-campaign">Totals:</div>
      <div className="table-col col-check" />
      <div className="table-col col-word" />
      <div className="table-col col-adgroup" />
      <div className="table-col">
        { formatValue(summary.impressions, 'removeZeroDecimal') }
      </div>
      <div className="table-col">
        { formatValue(summary.clicks, 'removeZeroDecimal') }
      </div>
      <div className="table-col">
        { formatValue(summary.acos, 'percent') }
      </div>
      <div className="table-col">
        { formatCurrency(summary.revenue, currencySign, currencyRate) }
      </div>
      <div className="table-col">
        { formatCurrency(summary.cost, currencySign, currencyRate) }
      </div>
      <div className="table-col">
        { formatCurrency(summary.yearlyCost, currencySign, currencyRate) }
      </div>
    </>
  )

  const sts = negatives.filter(st => (
    selectedNegatives.indexOf(st.id) !== -1
  ))

  return (
    <BulkResultContainer>
      { renderFilter() }
      {
        groupMode ? (
          <SortableTable
            tableComponent={GroupTable}
            columns={columnsGroup}
            defaultSort={['clicks', 'desc']}
            sorter={tableSorter(['campaignName'])}
            className="table-grouped-negatives"
            records={groupedNegatives}
            idField="campaign_id"
            searchFields={['search']}
            selectedRecords={selectedNegatives}
            paginationSelectPlacement="top"
            hasSticky
            hasDateRange
            exportFileName="Negative Word Finder"
            getExportData={getExportData}
            renderRecord={renderParent}
            renderTotal={renderTotalGroup}
            renderTopRight={renderAction}
            onChange={setSelectedNegatives}
            onChangeDate={onChangeDate}
            sorterChild={tableSorter(['search', 'adgroupName'])}
            idFieldChild="id"
            renderChild={renderChild}
          />
        ) : (
          <SortableTable
            columns={columns}
            defaultSort={['clicks', 'desc']}
            sorter={tableSorter(['search', 'campaignName', 'adgroupName'])}
            className="table-negatives"
            records={negatives}
            idField="id"
            searchFields={['search']}
            selectedRecords={selectedNegatives}
            paginationSelectPlacement="top"
            hasSticky
            hasDateRange
            exportFileName="Negative Word Finder"
            getExportData={getExportData}
            renderRecord={renderRecord}
            renderTotal={renderTotal}
            renderTopRight={renderAction}
            onChange={setSelectedNegatives}
            onChangeDate={onChangeDate}
          />
        )
      }
      <NegativeCreatorModal
        show={showNegativeCreatorModal}
        searchTerms={sts}
        defaultMatchType="negativePhrase"
        onClose={() => { setShowNegativeCreatorModal(false) }}
      />
    </BulkResultContainer>
  )
}

export default NegativeResult
