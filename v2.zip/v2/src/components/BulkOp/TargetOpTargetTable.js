import React, { useEffect, useState } from 'react'
import { useDispatch, useStore } from 'react-redux'
import Select from 'react-select'
import { Tooltip, Whisper, Toggle } from 'rsuite'
import * as Icon from 'react-icons/fi'

import SortableTable from '../CommonComponents/SortableTableComponent'
import GroupTable from '../CommonComponents/GroupTableComponent'
import { toast } from '../CommonComponents/ToastComponent/toast'
import TableCell from '../CommonComponents/TableCell'
import TableCampaignCell from '../CommonComponents/TableCampaignCell'
import TableFilterModal from '../CommonComponents/TableFilterModal'
import BidAdjustComponent from '../CommonComponents/BidAdjustComponent'

import {
  MODULE_NAME_TARGET_OP,
  FILTER_NAME_TARGET_OP,
  FILTER_NAME_ADVANCED_OP,
} from './TargetOpResult'

import { ReactComponent as InfoSvg } from '../../assets/svg/info.svg'

import {
  updateTargetStates,
  adjustTargetBids,
} from '../../redux/actions/bulkEngine'

import {
  formatCurrency,
  formatValue,
  tableSorter,
  calcDerivedMetrics,
  calcMaxCpc,
  capitalizeFirstLetter,
  parseTargetExp,
  getExportValueForColumn,
  groupRecords,
  getAmazonLink,
  copyToClipboard,
} from '../../services/helper'

import {
  bulkBidColumnList,
  adjustBidOptions,
  ADJUST_BID_RAISE,
  ADJUST_BID_LOWER,
  ADJUST_BID_CPC,
} from '../../utils/defaultValues'

import { keywordStatuses } from '../../utils/filterDef'

const TargetOpTargetTable = ({ sortBy, keyMetric, forAdvanced, onChangeDate }) => {
  const dispatch = useDispatch()
  const store = useStore()
  const {
    header: {
      currencySign,
      currencyRate,
      selectedUserInfo,
    },
    pageGlobal: {
      campaignTableColumns,
    },
    campaign: {
      campaignsWithHistory,
    },
    bulkEngine: {
      adgroupsForCampaignsData,
      targetOpData,
      isAdjustingTargetBids,
      isUpdatingTargetStates,
    },
  } = store.getState()

  const [groupMode, setGroupMode] = useState(false)
  const [targets, setTargets] = useState([])
  const [groupedTargets, setGroupedTargets] = useState([])
  const [selectedTargets, setSelectedTargets] = useState([])
  const [isShowAdjustBid, setIsShowAdjustBid] = useState(false)
  const [selectedAdjustBidOption, setSelectedAdjustBidOption] = useState(adjustBidOptions[0])
  const [bidValue, setBidValue] = useState(0)
  const [selectedStatus, setSelectedStatus] = useState(keywordStatuses[0])
  const [currentFilterName, setCurrentFilterName] = useState('')

  useEffect(() => {
    const campaignNamesById = {}
    const campaignTypesById = {}
    const campaignTargetingTypesById = {}
    campaignsWithHistory.forEach((campaign) => {
      campaignNamesById[campaign.campaign_id] = campaign.campaign
      campaignTypesById[campaign.campaign_id] = campaign.campaignType
      campaignTargetingTypesById[campaign.campaign_id] = campaign.targeting_type
    })

    const adgroupNamesById = {}
    adgroupsForCampaignsData.forEach((adgroup) => {
      adgroupNamesById[adgroup.adgroup_id] = adgroup.name
    })

    const extendedTargets = []; // semi-colon is required here.
    ((targetOpData || {}).targets || []).forEach((record) => {
      if (selectedStatus.value !== '') {
        if ((record.state || '').toLowerCase() !== selectedStatus.value) {
          return
        }
      }

      const derived = calcDerivedMetrics(record)
      extendedTargets.push({
        ...derived,
        campaignName: campaignNamesById[record.campaign_id] || '',
        campaignType: campaignTypesById[record.campaign_id] || '',
        targetingType: campaignTargetingTypesById[record.campaign_id] || '',
        adgroupName: adgroupNamesById[record.adgroup_id] || '',
        maxCpc: calcMaxCpc(derived),
      })
    })

    setTargets(extendedTargets)
    setGroupedTargets(
      groupRecords(
        extendedTargets,
        'campaign_id',
        ['campaignName', 'campaignType', 'targetingType']
      )
    )
  }, [targetOpData, campaignsWithHistory, adgroupsForCampaignsData,
    forAdvanced, selectedStatus])

  let columns = [
    { key: 'target_text', name: 'Target', className: 'col-target' },
    { key: 'campaignName', name: 'Campaign', className: 'col-campaign' },
    { key: 'adgroupName', name: 'Ad Group', className: 'col-adgroup' },
  ]

  let columnsGroup = [
    { key: 'campaignName', name: 'Campaign', className: 'col-campaign', parentOnly: true },
    { key: 'checkPlaceholder', name: '', className: 'col-check', exportable: false, parentOnly: true },
    { key: 'target_text', name: 'Target', className: 'col-target' },
    { key: 'adgroupName', name: 'Ad Group', className: 'col-adgroup' },
  ]

  if (!keyMetric) {
    const metricColumns = [
      { key: 'bid', name: 'Current Bid' },
      {
        key: 'maxCpc',
        name: (
          <span>
            Genius Bid
            <Whisper placement="right" trigger="hover" speaker={(
              <Tooltip>
                <p>A minimum of 3 clicks is required before we suggest a “Genius Bid”.</p>
              </Tooltip>
            )}>
              <InfoSvg />
            </Whisper>
          </span>
        ),
        plainName: 'Genius Bid',
        className: 'col-genius-bid',
      },
      ...bulkBidColumnList,
    ]

    columns = columns.concat(metricColumns)
    columnsGroup = columnsGroup.concat(metricColumns)
  } else {
    const keyColumn = bulkBidColumnList.find(c => c.key === keyMetric)

    const metricColumns = [
      keyColumn,
      { key: 'bid', name: 'Current Bid' },
      {
        key: 'maxCpc',
        name: (
          <span>
            Genius Bid
            <Whisper placement="right" trigger="hover" speaker={(
              <Tooltip>
                <p>A minimum of 3 clicks is required before we suggest a “Genius Bid”.</p>
              </Tooltip>
            )}>
              <InfoSvg />
            </Whisper>
          </span>
        ),
        plainName: 'Genius Bid',
        className: 'col-genius-bid',
      },
      ...bulkBidColumnList.filter(c => c.key !== keyMetric),
    ]

    columns = columns.concat(metricColumns)
    columnsGroup = columnsGroup.concat(metricColumns)
  }

  const handleChangeState = (state) => {
    const targetsChanged = targets.filter(record => (
      selectedTargets.indexOf(record.target_id) !== -1
    )).map(record => ({
      campaignId: record.campaign_id,
      campaignType: record.campaignType,
      adGroupId: record.adgroup_id,
      targetId: record.target_id,
      // Below information are used for logging in backend.
      campaignName: record.campaignName,
      adgroupName: record.adgroupName,
      target_text: record.target_text,
    }))

    if (targetsChanged.length) {
      dispatch(updateTargetStates(targetsChanged, state))
    }
  }

  const handleChangeToMaxBid = () => {
    let targetsToChange = []

    targets.filter(record => (
      selectedTargets.indexOf(record.target_id) !== -1)
    ).forEach((record) => {
      if (record.maxCpc
        && record.maxCpc >= 0.15) {
        targetsToChange.push({
          campaignId: record.campaign_id,
          campaignType: record.campaignType,
          adGroupId: record.adgroup_id,
          targetId: record.target_id,
          bid: parseFloat(record.maxCpc.toFixed(2)),
          // Below information are used for logging in backend.
          campaignName: record.campaignName,
          adgroupName: record.adgroupName,
          target_text: record.target_text,
          originalBid: record.bid,
        })
      }
    })

    if (!targetsToChange.length) {
      toast.show({
        title: 'Warning',
        description: 'Selected target(s) has invalid genius bid. '
          + 'The minimum bid allowed is $0.15. Please check your targets.',
      })
      return
    }

    dispatch(adjustTargetBids(targetsToChange))
  }

  const handleAdjustBid = () => {
    if (selectedAdjustBidOption.value !== ADJUST_BID_CPC
      && (bidValue === '' || isNaN(bidValue))) {
      toast.show({
        title: 'Warning',
        description: 'Please enter the valid bid value.',
      })
      return
    }

    let targetsChanged = []
    targets.filter(record => (
      selectedTargets.indexOf(record.target_id) !== -1
    )).forEach((record) => {
      let newBid = parseFloat(bidValue)
      if (selectedAdjustBidOption.value === ADJUST_BID_RAISE) {
        newBid = parseFloat(record.bid || 0) * (1 + (newBid / 100))
      } else if (selectedAdjustBidOption.value === ADJUST_BID_LOWER) {
        newBid = parseFloat(record.bid || 0) * (1 - (newBid / 100))
      } else if (selectedAdjustBidOption.value === ADJUST_BID_CPC) {
        newBid = parseFloat(record.cpc || 0)
      }

      if (newBid >= 0.15) {
        targetsChanged.push({
          campaignId: record.campaign_id,
          campaignType: record.campaignType,
          adGroupId: record.adgroup_id,
          targetId: record.target_id,
          bid: parseFloat(newBid.toFixed(2)),
          // Below information are used for logging in backend.
          campaignName: record.campaignName,
          adgroupName: record.adgroupName,
          target_text: record.target_text,
          originalBid: record.bid,
        })
      }
    })

    if (!targetsChanged.length) {
      toast.show({
        title: 'Warning',
        description: 'The minimum bid allowed is $0.15. Please check your targets.',
      })
      return
    }

    dispatch(adjustTargetBids(targetsChanged)).then(() => {
      setIsShowAdjustBid(false)
    })
  }

  const handleRefineFilter = () => {
    setCurrentFilterName(forAdvanced ? FILTER_NAME_ADVANCED_OP : FILTER_NAME_TARGET_OP)
  }

  const handleCopy = () => {
    const dataToCopy = targets.filter(record => (
      selectedTargets.indexOf(record.target_id) !== -1
    )).map(record => parseTargetExp(record.target_text))

    copyToClipboard(dataToCopy.join('\n'))

    toast.show({
      title: 'Success',
      description: `Successfully copied ${dataToCopy.length} target${dataToCopy.length > 1 ? 's' : ''}.`
    })
  }

  const renderFilter = () => {
    return (
      <div className="filter-container">
        <div className="toggle-wrapper">
          <Toggle
            checked={groupMode}
            checkedChildren="Organize by campaigns"
            unCheckedChildren="By targets"
            onChange={setGroupMode}
          />
        </div>
        <div className="select-wrapper">
          <span>Status</span>
          <Select
            classNamePrefix="status-selector"
            options={keywordStatuses}
            value={selectedStatus}
            onChange={setSelectedStatus}
          />
        </div>
        <div className="button-wrapper">
          <button
            type="button"
            className="btn btn-blue"
            onClick={handleRefineFilter}
          >
            Refine Filter
          </button>
        </div>
      </div>
    )
  }

  const renderAction = () => {
    if (!selectedTargets.length) {
      return null
    }

    if (!isShowAdjustBid) {
      const isEnableDisabled = typeof targets.find(record => (
        selectedTargets.indexOf(record.target_id) !== -1
        && record.state !== 'enabled'
      )) === 'undefined'

      const isPauseDisabled = typeof targets.find(record => (
        selectedTargets.indexOf(record.target_id) !== -1
        && record.state !== 'paused'
      )) === 'undefined'

      return (
        <>
          <button
            type="button"
            className="btn btn-green"
            onClick={() => { handleCopy() }}
          >
            Copy
          </button>
          <button
            type="button"
            className="btn btn-green"
            disabled={isUpdatingTargetStates || isEnableDisabled}
            onClick={() => { handleChangeState('enabled') }}
          >
            Enable
          </button>
          <button
            type="button"
            className="btn btn-red"
            disabled={isUpdatingTargetStates || isPauseDisabled}
            onClick={() => { handleChangeState('paused') }}
          >
            Pause
          </button>
          <button
            type="button"
            className="btn btn-light-blue"
            onClick={() => { setIsShowAdjustBid(true) }}
          >
            Adjust Bid
          </button>
          <button
            type="button"
            className="btn btn-blue"
            disabled={isAdjustingTargetBids}
            onClick={handleChangeToMaxBid}
          >
            Change to Genius Bid
          </button>
        </>
      )
    }

    return (
      <BidAdjustComponent
        adjustBidOption={selectedAdjustBidOption}
        bidValue={bidValue}
        isAdjusting={isAdjustingTargetBids}
        onChangeAdjustBidOption={setSelectedAdjustBidOption}
        onChangeBidValue={setBidValue}
        onApply={handleAdjustBid}
        onCancel={() => { setIsShowAdjustBid(false) }}
      />
    )
  }

  const renderTargetCell = (record) => {
    const target = parseTargetExp(record.target_text)
    let link
    if (target.indexOf('asin=') === 0) {
      try {
        const parsed = JSON.parse(record.target_text)
        link = (
          <a
            href={`https://${getAmazonLink(selectedUserInfo)}/gp/product/${parsed[0].value}`}
            target="_blank"
            rel="noopener noreferrer"
          >
            <Icon.FiExternalLink size={16} />
          </a>
        )
      } catch (e) {
        //
      }
    } else if (target.indexOf('category=') === 0) {
      try {
        const parsed = JSON.parse(record.target_exp)
        link = (
          <a
            href={`https://${getAmazonLink(selectedUserInfo)}/b?node=${parsed[0].value}`}
            target="_blank"
            rel="noopener noreferrer"
          >
            <Icon.FiExternalLink size={16} />
          </a>
        )
      } catch (e) {
        //
      }
    }

    return (
      <div className="table-col col-target" title={target}>
        <div className="target-text-wrapper">
          <strong>
            { target }
          </strong>
          { link }
        </div>
        <div className="meta-data">
          { capitalizeFirstLetter(record.state) }
        </div>
      </div>
    )
  }

  const renderTarget = record => (
    <>
      { renderTargetCell(record) }
      <TableCampaignCell record={record} />
      <div className="table-col col-adgroup" title={record.adgroupName}>
        <span className="contents">
          { record.adgroupName }
        </span>
      </div>
      {
        keyMetric === 'cpc' && campaignTableColumns.includes(keyMetric) && (
          <div className="table-col">
            { formatCurrency(record.cpc, currencySign, currencyRate) }
          </div>
        )
      }
      {
        keyMetric === 'conversion' && campaignTableColumns.includes(keyMetric) && (
          <div className="table-col">
            { formatValue(record.conversion, 'percent') }
          </div>
        )
      }
      {
        keyMetric === 'cost' && campaignTableColumns.includes(keyMetric) && (
          <div className="table-col">
            { formatCurrency(record.cost, currencySign, currencyRate) }
          </div>
        )
      }
      <div className="table-col">
        { formatCurrency(record.bid, currencySign, currencyRate) }
      </div>
      <div className="table-col col-genius-bid">
        {
          typeof record.maxCpc !== 'undefined'
          ? formatCurrency(record.maxCpc, currencySign, currencyRate)
          : 'N/A'
        }
      </div>
      {
        bulkBidColumnList.map((column) => {
          if (keyMetric && column.key === keyMetric) {
            return null
          }

          return (
            <TableCell
              key={column.key}
              record={record}
              columnKey={column.key}
              columnSelection={campaignTableColumns}
              currencySign={currencySign}
              currencyRate={currencyRate}
            />
          )
        })
      }
    </>
  )

  // Render aggregation row.
  const renderTotal = summary => (
    <>
      <div className="table-col col-target">Totals:</div>
      <div className="table-col col-campaign" />
      <div className="table-col col-adgroup" />
      {
        keyMetric === 'cpc' && campaignTableColumns.includes(keyMetric) && (
          <div className="table-col">
            { formatCurrency(summary.cpc, currencySign, currencyRate) }
          </div>
        )
      }
      {
        keyMetric === 'conversion' && campaignTableColumns.includes(keyMetric) && (
          <div className="table-col">
            { formatValue(summary.conversion, 'percent') }
          </div>
        )
      }
      {
        keyMetric === 'cost' && campaignTableColumns.includes(keyMetric) && (
          <div className="table-col">
            { formatCurrency(summary.cost, currencySign, currencyRate) }
          </div>
        )
      }
      <div className="table-col"></div>
      <div className="table-col col-genius-bid"></div>
      {
        bulkBidColumnList.map((column) => {
          if (keyMetric && column.key === keyMetric) {
            return null
          }

          return (
            <TableCell
              key={column.key}
              record={summary}
              columnKey={column.key}
              columnSelection={campaignTableColumns}
              currencySign={currencySign}
              currencyRate={currencyRate}
            />
          )
        })
      }
    </>
  )

  const getExportData = (exportableColumns, record) => (
    exportableColumns.map((column) => {
      if (column.key === 'target_text') {
        return `${parseTargetExp(record.target_text)} (${capitalizeFirstLetter(record.state)})`
      }
      if (column.key === 'bid') {
        return formatCurrency(record.bid, currencySign, currencyRate)
      }
      if (column.key === 'maxCpc') {
        return typeof record.maxCpc !== 'undefined'
          ? formatCurrency(record.maxCpc, currencySign, currencyRate)
          : 'N/A'
      }
      return getExportValueForColumn(record, column.key, currencySign, currencyRate)
    })
  )

  // For grouped table.
  const renderParent = record => (
    <>
      <TableCampaignCell record={record} />
      <div className="table-col col-check" />
      <div className="table-col col-target">
        { record.children.length } targets
      </div>
      <div className="table-col col-adgroup" />
      <div className="table-col" />
      <div className="table-col col-genius-bid" />
      {
        keyMetric === 'cpc' && campaignTableColumns.includes(keyMetric) && (
          <div className="table-col">
            { formatCurrency(record.cpc, currencySign, currencyRate) }
          </div>
        )
      }
      {
        keyMetric === 'conversion' && campaignTableColumns.includes(keyMetric) && (
          <div className="table-col">
            { formatValue(record.conversion, 'percent') }
          </div>
        )
      }
      {
        keyMetric === 'cost' && campaignTableColumns.includes(keyMetric) && (
          <div className="table-col">
            { formatCurrency(record.cost, currencySign, currencyRate) }
          </div>
        )
      }
      {
        bulkBidColumnList.map((column) => {
          if (keyMetric && column.key === keyMetric) {
            return null
          }

          return (
            <TableCell
              key={column.key}
              record={record}
              columnKey={column.key}
              columnSelection={campaignTableColumns}
              currencySign={currencySign}
              currencyRate={currencyRate}
            />
          )
        })
      }
    </>
  )

  const renderChild = record => (
    <>
      { renderTargetCell(record) }
      <div className="table-col col-adgroup" title={record.adgroupName}>
        <span className="contents">
          { record.adgroupName }
        </span>
      </div>
      {
        keyMetric === 'cpc' && campaignTableColumns.includes(keyMetric) && (
          <div className="table-col">
            { formatCurrency(record.cpc, currencySign, currencyRate) }
          </div>
        )
      }
      {
        keyMetric === 'conversion' && campaignTableColumns.includes(keyMetric) && (
          <div className="table-col">
            { formatValue(record.conversion, 'percent') }
          </div>
        )
      }
      {
        keyMetric === 'cost' && campaignTableColumns.includes(keyMetric) && (
          <div className="table-col">
            { formatCurrency(record.cost, currencySign, currencyRate) }
          </div>
        )
      }
      <div className="table-col">
        { formatCurrency(record.bid, currencySign, currencyRate) }
      </div>
      <div className="table-col col-genius-bid">
        {
          typeof record.maxCpc !== 'undefined'
          ? formatCurrency(record.maxCpc, currencySign, currencyRate)
          : 'N/A'
        }
      </div>
      {
        bulkBidColumnList.map((column) => {
          if (keyMetric && column.key === keyMetric) {
            return null
          }

          return (
            <TableCell
              key={column.key}
              record={record}
              columnKey={column.key}
              columnSelection={campaignTableColumns}
              currencySign={currencySign}
              currencyRate={currencyRate}
            />
          )
        })
      }
    </>
  )

  const renderTotalGroup = summary => (
    <>
      <div className="table-col col-campaign">Totals:</div>
      <div className="table-col col-check" />
      <div className="table-col col-target" />
      <div className="table-col col-adgroup" />
      <div className="table-col" />
      <div className="table-col col-genius-bid" />
      {
        keyMetric === 'cpc' && campaignTableColumns.includes(keyMetric) && (
          <div className="table-col">
            { formatCurrency(summary.cpc, currencySign, currencyRate) }
          </div>
        )
      }
      {
        keyMetric === 'conversion' && campaignTableColumns.includes(keyMetric) && (
          <div className="table-col">
            { formatValue(summary.conversion, 'percent') }
          </div>
        )
      }
      {
        keyMetric === 'cost' && campaignTableColumns.includes(keyMetric) && (
          <div className="table-col">
            { formatCurrency(summary.cost, currencySign, currencyRate) }
          </div>
        )
      }
      {
        bulkBidColumnList.map((column) => {
          if (keyMetric && column.key === keyMetric) {
            return null
          }

          return (
            <TableCell
              key={column.key}
              record={summary}
              columnKey={column.key}
              columnSelection={campaignTableColumns}
              currencySign={currencySign}
              currencyRate={currencyRate}
            />
          )
        })
      }
    </>
  )

  const isLoading = isUpdatingTargetStates || isAdjustingTargetBids

  return (
    <>
      { renderFilter() }
      {
        groupMode ? (
          <SortableTable
            tableComponent={GroupTable}
            isLoading={isLoading}
            columns={columnsGroup}
            defaultSort={sortBy}
            sorter={tableSorter(['campaignName'])}
            className="table-grouped-targets"
            records={groupedTargets}
            idField="campaign_id"
            searchFields={['target_text']}
            selectedRecords={selectedTargets}
            paginationSelectPlacement="top"
            hasSticky
            hasDateRange
            filterName={forAdvanced ? FILTER_NAME_ADVANCED_OP :  FILTER_NAME_TARGET_OP}
            useFilterModal
            columnEditorId="targetOpTargetResult"
            columnList={bulkBidColumnList}
            columnSelection={campaignTableColumns}
            exportFileName={MODULE_NAME_TARGET_OP}
            getExportData={getExportData}
            renderRecord={renderParent}
            renderTotal={renderTotalGroup}
            renderTopRight={renderAction}
            onChange={setSelectedTargets}
            onChangeDate={onChangeDate}
            sorterChild={tableSorter(['adgroupName', 'state', 'target_text'])}
            idFieldChild="target_id"
            renderChild={renderChild}
          />
        ) : (
          <SortableTable
            isLoading={isLoading}
            columns={columns}
            defaultSort={sortBy}
            sorter={tableSorter(['campaignName', 'adgroupName', 'state', 'target_text'])}
            className="table-targets"
            records={targets || []}
            idField="target_id"
            searchFields={['target_text']}
            selectedRecords={selectedTargets}
            paginationSelectPlacement="top"
            hasSticky
            hasDateRange
            filterName={forAdvanced ? FILTER_NAME_ADVANCED_OP : FILTER_NAME_TARGET_OP}
            useFilterModal
            columnEditorId="targetOpTargetResult"
            columnList={bulkBidColumnList}
            columnSelection={campaignTableColumns}
            exportFileName={MODULE_NAME_TARGET_OP}
            getExportData={getExportData}
            renderRecord={renderTarget}
            renderTotal={renderTotal}
            renderTopRight={renderAction}
            onChange={setSelectedTargets}
            onChangeDate={onChangeDate}
          />
        )
      }
      {
        currentFilterName !== '' && (
          <TableFilterModal
            filterName={currentFilterName}
            currentModuleName={forAdvanced ? 'Advanced Optimization' : MODULE_NAME_TARGET_OP}
            onApply={() => { setCurrentFilterName('') }}
            onClose={() => { setCurrentFilterName('') }}
          />
        )
      }
    </>
  )
}

export default TargetOpTargetTable
