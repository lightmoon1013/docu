/*global chrome*/
import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react'
import { useDispatch, useStore } from 'react-redux'
import { Link } from 'react-router-dom'
import { Toggle, Radio, Tooltip, Whisper, Dropdown } from 'rsuite'
import moment from 'moment'

import { ReactComponent as SearchSvg } from '../../assets/svg/search.svg'
import { ReactComponent as FilterSvg } from '../../assets/svg/filter.svg'
import { ReactComponent as ColumnSvg } from '../../assets/svg/columns.svg'
import { ReactComponent as EyeSvg } from '../../assets/svg/eye.svg'
import { ReactComponent as MoreDotsSvg } from '../../assets/svg/more-dots.svg'
import ImgBlueArrowRight from '../../assets/img/blue-right.png'
import ImgBlueArrowDown from '../../assets/img/blue-down.png'
import ImgLock from '../../assets/img/lock.png'

import { toast } from '../CommonComponents/ToastComponent/toast'
import ImportFileContent from '../CommonComponents/ImportFileContent'
import PaginationComponent from '../CommonComponents/PaginationComponent'
import DateRangeComponent from '../CommonComponents/DateRangeComponent'
import ColumnEditor from '../CommonComponents/ColumnEditor'
import LoaderComponent from '../CommonComponents/LoaderComponent'
import TableFilter from '../CommonComponents/TableFilter'
import TableFilterShower from '../CommonComponents/TableFilterShower'

import TableHeader from './TableHeader'
import TableFooter from './TableFooter'

import {
  showColumnEditorAction,
  showFilter,
  applyProductColumnChanges,
} from '../../redux/actions/pageGlobal'

import {
  setDateRange,
} from '../../redux/actions/header'

import {
  updateBulkCogs,
  getProducts,
  updateProductCog,
  getProductKeywords,
} from '../../redux/actions/product'

import {
  formatCurrency,
  formatValue,
  tableSorter,
  matchFilter,
} from '../../services/helper'

import { EXTENSION_ID, productColumnList } from '../../utils/defaultValues'

import filterDef from '../../utils/filterDef'

const columns = [
  { key: 'cog', name: 'Cost of Goods' },
  { key: 'profit_margin', name: 'Profit Margin' },
  {
    key: 'break_even_cpa',
    name: (<span>Break Even<br/> CPA</span>),
    className: 'break-even',
    tooltip: (
      <p>
        Break Even Cost per Acquisition is the amount of money
        you can spend to get a sale while still breaking even.
      </p>
    )
  },
  {
    key: 'clicks_order_ratio',
    name: (<span>Clicks /<br/> Orders</span>),
    tooltip: (
      <p>
        This measures how many clicks it takes on average to get an order.
      </p>
    )
  },
  {
    key: 'max_cpc',
    name: (<span>Max<br/> CPC</span>),
    tooltip: (
      <>
        <p>The maximum one can spend per click to break even with PPC.</p>
        <p>
          Takes into account the products profit margins
          and the average amount of clicks to get an order.
        </p>
      </>
    )
  },
  {
    key: 'weeklyorders',
    name: (<span>7 Day<br/> Avg.</span>),
    tooltip: (
      <p>Advertising only 7 day average (does not include SB/SBV)</p>
    )
  },
  {
    key: 'monthlyorders',
    name: (<span>30 Day<br/> Avg.</span>),
    tooltip: (
      <p>Advertising only 30 day average (does not include SB/SBV)</p>
    )
  },
  {
    key: 'twomonthlyorders',
    name: (<span>60 Day<br/> Avg.</span>),
    tooltip: (
      <p>Advertising only 60 day average (does not include SB/SBV)</p>
    )
  },
  { key: 'active_campaigns', name: 'Active Campaigns' },
  { key: 'revenue', name: 'Sales' },
  {
    key: 'sales',
    name: (
      <>
        <span>Organic</span>
        <span>PPC Sales</span>
      </>
    ),
    className: 'organic-sales',
  },
  {
    key: 'sales_ratio',
    name: (
      <>
        <span>Sales Ratio %</span>
        <span>Organic/PPC</span>
      </>
    ),
    className: 'organic-sales-ratio',
  },
  {
    key: 'ad_spend_margin',
    name: (<span>Ad Spend<br/> Margin Impact</span>),
    className: 'ad-spend-margin',
    tooltip: (
      <>
        <p>Also known as TACOS.</p>
        <p>
          The amount of margin impact that your ad dollars are having
          on this products profitability (does not include SB/SBV ad spend)
        </p>
      </>
    )
  },
  { key: 'total_clicks', name: 'Clicks' },
  { key: 'ctr', name: 'CTR %' },
  { key: 'cost', name: 'Spend' },
  { key: 'orders', name: 'Orders' },
  { key: 'acos', name: 'ACoS %' },
]

const ProductTableComponent = () => {
  const dispatch = useDispatch()
  const store = useStore()

  const { product, header, pageGlobal } = store.getState()
  const {
    currencyRate,
    currencySign,
    currentStartDate,
    currentEndDate,
    selectedUserInfo,
  } = header
  const {
    productList,
    isLoading,
    isUpdateProductCog,
    isLoadingProductKeywords,
    isUpdateBulkCogs,
    productKeywords,
  } = product
  const {
    showColumnEditor,
    visibleColumnEditorId,
    visibleFilterName,
    productTableColumns,
    filterValues,
  } = pageGlobal

  const [searchKey, setSearchKey] = useState('')
  const [pageStartNum, setPageStartNum] = useState(0)
  const [pageEndNum, setPageEndNum] = useState(10)
  const [sortColumnName, setSortColumnName] = useState('cost')
  const [sortDirection, setSortDirection] = useState('desc')

  const [showFileUpload, setShowFileUpload] = useState(false)
  const [fileImportBtnName, setFileImportBtnName] = useState('Upload Bulk COGS')
  const [changedCogId, setChangedCogId] = useState(0)
  const [changedCogValue, setChangedCogValue] = useState('')
  const [productExpanded, setProductExpanded] = useState()
  const [isExtensionInstalled, setIsExtensionInstalled] = useState(false)
  const [exportCogCSV, setExportCogCSV] = useState('')
  const [isSticky, setIsSticky] = useState(false)
  const [topPos, setTopPos] = useState(0)

  const refHeader = useRef(null)
  const refFooter = useRef(null)
  const refProductCol = useRef()
  const refTable = useRef(null)

  const [tableHeight, setTableHeight] = useState('auto')
  const [resizing, setResizing] = useState(false)

  const productColIndex = 0
  const productColMinWidth = 240

  useEffect(() => {
    setTableHeight(refTable.current.offsetHeight)
  }, [])

  const handleMouseMove = useCallback(
    (e) => {
      const leftPos = refProductCol.current.getBoundingClientRect().left
      const width = e.clientX - leftPos >= productColMinWidth
        ? e.clientX - leftPos
        : refProductCol.current.offsetWidth
      refProductCol.current.style.minWidth = `${width}px`
      let rowElement = refProductCol.current.parentNode
      while (rowElement) {
        rowElement.childNodes[productColIndex].style.minWidth = `${width}px`
        rowElement = rowElement.nextSibling
      }
    },
    []
  )

  const removeListeners = useCallback(() => {
    window.removeEventListener('mousemove', handleMouseMove)
    window.removeEventListener('mouseup', removeListeners)
  }, [handleMouseMove])

  const handleMouseUp = useCallback(() => {
    setResizing(false)
    removeListeners()
  }, [setResizing, removeListeners])

  useEffect(() => {
    if (resizing) {
      window.addEventListener('mousemove', handleMouseMove)
      window.addEventListener('mouseup', handleMouseUp)
    }

    return () => {
      removeListeners()
    }
  }, [resizing, handleMouseMove, handleMouseUp, removeListeners])

  useEffect(() => {
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
      chrome.runtime.sendMessage(EXTENSION_ID, { type: 'checkIfExtensionInstalled' }, function (response) {
        if (chrome.runtime.lastError) {
          return
        }
        if (response && response.success === true) {
          setIsExtensionInstalled(true)
        }
      });
    }
    setCogDownloadContent()
  })

  useEffect(() => {
    const mainContent = document.querySelector('.main-content')
    mainContent.addEventListener('scroll', handleScroll)

    return () => {
      mainContent.removeEventListener('scroll', () => handleScroll)
    }
  }, [])

  useEffect(() => {
    if (!isSticky || !topPos) {
      return
    }
    refHeader.current.style.top = `${topPos}px`
    refFooter.current.style.top = `${topPos + refHeader.current.clientHeight}px`
  }, [isSticky, topPos])

  useEffect(() => {
    dispatch(
      getProducts({
        startDate: moment(currentStartDate).format('YYYY-MM-DD'),
        endDate: moment(currentEndDate).format('YYYY-MM-DD'),
      })
    )
  }, [currentStartDate, currentEndDate]) // eslint-disable-line

  const setProductColWidth = (width = productColMinWidth) => {
    refProductCol.current.style.minWidth = `${width}px`
    let rowElement = refProductCol.current.parentNode
    while (rowElement) {
      rowElement.childNodes[productColIndex].style.minWidth = `${width}px`
      rowElement = rowElement.nextSibling
    }
  }

  const handleExpandProductName = () => {
    let width = productColMinWidth
    const rows = document.getElementsByClassName('table-row')
    for (let index = 0; index < rows.length; index++) {
      const productCol = rows[index].childNodes[productColIndex].getElementsByTagName('button')[0]
      if (productCol) {
        width = Math.max(width, productCol.scrollWidth)
      }
    }

    setProductColWidth(width)
  }

  const handleCollapseProductName = () => {
    setProductColWidth()
  }

  const setCogDownloadContent = () => {
    let data = [
      ['SKU', 'COG'],
      ['Light-gray99', 10],
      ['4th-refil', 3],
    ]

    let csvContent = "data:text/csv;charset=utf-8,"
    data.forEach((row, index) => {
      const dataString = row.join(',')
      csvContent += index < data.length ? dataString + '\n' : dataString
    })
    setExportCogCSV(csvContent)
  }

  const handleScroll = () => {
    setIsSticky(false)
    if (refHeader.current) {
      const { top } = refHeader.current.getBoundingClientRect()
      if (top <= 0) {
        setIsSticky(true)
        setTopPos(-top)
      }
    }
  }

  const loadUploadedFileContent = (data, fileName) => {
    let results = []
    const products = data.split(/\n/)
    if (products.length > 300) {
      toast.show({
        title: 'Warning',
        description: 'Only 300 rows are allowed at once'
      })
      return
    }
    results = products.map(product => product.split(','))
    const header = results.shift()
    const skuIndex = header.findIndex(col => col.toLowerCase().trim() === 'sku')
    const cogIndex = header.findIndex(col => col.toLowerCase().trim() === 'cog')
    if (skuIndex === -1 || cogIndex === -1) {
      toast.show({
        title: 'Danger',
        description: 'Unable to detect the csv headers. Please make sure you have the '
          + 'both (\'sku\' and \'cog\') headers in your file.',
      })
      return
    }
    const invalidSkus = []
    let successfulSkus = {}
    const insertValues = []
    results.forEach(result => {
      const sku = result[skuIndex]
      const cog = parseFloat((result[cogIndex] || '').replace(/\$/g, ''))
      if (isNaN(cog)) {
        invalidSkus.push({
          sku,
          reason: 'Invalid value for COG.',
        })
      } else if (productList.findIndex(skuWithProfit => skuWithProfit.sku === sku) === -1) {
        invalidSkus.push({
          sku,
          reason: 'Skus was not found.',
        })
      } else if (successfulSkus[sku] && successfulSkus[sku] !== cog) {
        invalidSkus.push({
          sku,
          reason: 'SKU has duplicate entries and the last value by the order is saved as final one. '
            + 'Please fix it and upload again if you don\'t agree.',
        })
      } else {
        successfulSkus[sku] = cog
        insertValues.push({
          sku,
          cog,
        })
      }
    })
    if (insertValues.length === 0) {
      toast.show({
        title: 'Danger',
        description: 'There were no valid items in csv file',
      })
      return
    }
    dispatch(updateBulkCogs({
      skus: insertValues,
    }))
    setFileImportBtnName(fileName)
    setShowFileUpload(false)
  }

  const loadProducts = (pageNum, pageRows) => {
    if (pageRows !== 'all') {
      setPageStartNum((pageNum - 1) * pageRows)
      setPageEndNum(pageNum * pageRows - 1)
    } else {
      setPageStartNum(0)
      setPageEndNum(products.length)
    }
  }

  const handleChangeDateRange = ([startDate, endDate]) => {
    dispatch(setDateRange({
      startDate,
      endDate,
    }))
  }

  const onShowColumnEditor = () => {
    dispatch(showColumnEditorAction())
  }

  const onShowTableFilter = () => {
    dispatch(showFilter('productTable'))
  }

  const handleOpenAmazon = (url) => {
    window.open(url)
  }

  const sortColumn = (field) => {
    setSortDirection(sortColumnName === field && sortDirection === 'asc' ? 'desc' : 'asc')
    setSortColumnName(field)
  }

  const onChangeCog = (e, data) => {
    setChangedCogId(data['id'])
    setChangedCogValue(e.target.value)
  }

  const onSaveCogUpdate = (data) => {
    dispatch(updateProductCog({
      cog: changedCogValue,
      product: data
    })).then(() => {
      setChangedCogId(0)
      setChangedCogValue('')

      dispatch(getProducts({
        startDate: moment(currentStartDate).format('YYYY-MM-DD'),
        endDate: moment(currentStartDate).format('YYYY-MM-DD'),
      }))
    })
  }

  const onCancelCogUpdate = () => {
    setChangedCogId(0)
    setChangedCogValue('')
  }

  const onExpandProduct = (id, sku) => {
    setProductExpanded(id)
    dispatch(getProductKeywords({id, sku }))
  }

  let products = useMemo(() => {
    const euList = ['gb', 'fr', 'de', 'es', 'it', 'nl', 'in', 'ae', 'se', 'pl', 'tr', 'eg', 'sa']
    const isInEU = euList.includes(selectedUserInfo.country_id || 'us')

    return productList.filter((record) => {
      record.acos = record.revenue ? record.cost / record.revenue * 100 : 0
      record.sales_ratio = record.sales + record.ppcRevenue
        ? record.sales / (record.sales + record.ppcRevenue) * 100
        : 0
      record.ad_spend_margin = record.sales + record.ppcRevenue
        ? record.cost / (record.sales + record.ppcRevenue) * 100
        : 0
      record.ctr = parseInt(record.impressions, 10)
        ? parseInt(record.total_clicks, 10) / parseInt(record.impressions, 10) * 100
        : 0

      record.total_quantity = parseInt(record.total_quantity || 0, 10)
      record.profit_margin = 0
      if (record.total_quantity) {
        let sales = parseFloat(record.total_sale || 0)
        if (isInEU) {
          // In EU, sales do not contain VAT.
          sales += parseFloat(record.total_tax || 0)
        }
        record.profit_margin =
          (sales - parseFloat(record.total_fee || 0))
          / record.total_quantity - parseFloat(record.cog || 0)
      }

      if (!record['product-name'].toLowerCase().includes(searchKey.toLowerCase())) {
        return false
      }

      if (!matchFilter(record, filterDef.productTable, (filterValues || {}).productTable || {})) {
        return false
      }

      return true
    })
  }, [productList, searchKey, filterValues, selectedUserInfo])

  products = useMemo(() => (
    tableSorter(['campaign'])
    (products, [sortColumnName, sortDirection])
  ), [products, sortColumnName, sortDirection])

  const renderActions = () => (
    <div className="table-header">
      <div className="table-header-left">
        <SearchSvg />
        <input
          type="text"
          className="table-header-search"
          placeholder="Type to search..."
          value={searchKey}
          onChange={(event) => { setSearchKey(event.target.value) }}
        />
        <DateRangeComponent
          onChange={handleChangeDateRange}
          value={[currentStartDate, currentEndDate]}
        />
        <button
          type="button"
          className="btn btn-green btn-upload"
          disabled={isUpdateBulkCogs}
          onClick={() => { setShowFileUpload(true) }}
        >
          { fileImportBtnName }
        </button>
        <ImportFileContent
          showFileUpload={showFileUpload}
          loadData={loadUploadedFileContent}
          hideFileUpload={() => { setShowFileUpload(false) }}
        />
        <Whisper placement="right" trigger="hover" speaker={(
          <Tooltip>
            <p>Please click on this icon to download the template csv file of cogs.</p>
          </Tooltip>
        )}>
          <a
            href={encodeURI(exportCogCSV)}
            className="download-cog-csv"
            download="cog.csv"
          >
            <EyeSvg />
          </a>
        </Whisper>
      </div>
      <div className="table-header-right">
        <FilterSvg onClick={onShowTableFilter} />
        <ColumnSvg onClick={onShowColumnEditor} />
      </div>
    </div>
  )

  const productElements = products.slice(pageStartNum, pageEndNum + 1).map((data) => (
    <React.Fragment key={data.id}>
      <div className="table-row">
        <div className="table-col product-name">
          <img src={data.image_sm} alt={data.product} />
          <div>
            {
              data['abtest_status'] === 'running' ? (
                <span className="test-on">A/B Test On</span>
              ) : (
                <span className="test-off">A/B Test Off</span>
              )
            }
            <Link
              to={`/product/${data.id}/${data.sku}`}
              title={data['product-name']}
            >
              { data['product-name'] }
            </Link>
            <div className="row">
              <span title={data.asin}>{ data.asin }</span>
            </div>
            <div className="row">
              <span title={data.sku}>{ data.sku }</span>
              {
                productExpanded === data.id ? (
                  <img
                    src={ImgBlueArrowDown}
                    alt={data['product-name']}
                    onClick={()=> { setProductExpanded() }}
                  />
                ) : (
                  <img
                    src={ImgBlueArrowRight}
                    alt={data['product-name']}
                    onClick={()=> { onExpandProduct(data.id, data.sku) }}
                  />
                )
              }
            </div>
          </div>
        </div>
        {productTableColumns.includes('cog') && <div className="table-col">
          {changedCogId === data['id'] ?
            <>
              <input type="number" value={ changedCogValue } onChange={ (e)=>onChangeCog(e, data) }/>
              <div className="cog-btn-container">
                <button type="button" onClick={ ()=>onSaveCogUpdate(data) }>Save</button>
                <button type="button" onClick={ onCancelCogUpdate }>Cancel</button>
              </div>
            </>
            :
            <input type="number" value={ data.cog } onChange={ (e)=>onChangeCog(e, data) }/>
          }
        </div>}
        {productTableColumns.includes('profit_margin') && <div className="table-col">{ formatValue(data.profit_margin, 'number') }</div>}
        {productTableColumns.includes('break_even_cpa') && <div className="table-col break-even">{ formatValue(data.break_even_cpa, 'number') }</div>}
        {productTableColumns.includes('clicks_order_ratio') && <div className="table-col">{ formatValue(data.clicks_order_ratio, 'number', 0) }</div>}
        {productTableColumns.includes('max_cpc') && <div className="table-col">{ formatValue(data.max_cpc, 'number', 2) }</div>}
        {productTableColumns.includes('weeklyorders') && <div className="table-col">{ formatValue(data.weeklyorders, 'number', 0) }</div>}
        {productTableColumns.includes('monthlyorders') && <div className="table-col">{ formatValue(data.monthlyorders, 'number', 0) }</div>}
        {productTableColumns.includes('twomonthlyorders') && <div className="table-col">{ formatValue(data.twomonthlyorders, 'number', 0) }</div>}
        {productTableColumns.includes('active_campaigns') && <div className="table-col">{ formatValue(data.active_campaigns, 'number', 0) }</div>}
        {productTableColumns.includes('revenue') && <div className="table-col">{formatCurrency(data.revenue, currencySign, currencyRate)}</div>}
        {
          productTableColumns.includes('sales') && (
            <div className="table-col organic-sales">
              <span>
                { formatCurrency(data.sales, currencySign, currencyRate) }
              </span>
              <span>
                { formatCurrency(data.ppcRevenue, currencySign, currencyRate) }
              </span>
            </div>
          )
        }
        {
          productTableColumns.includes('sales_ratio') && (
            <div className="table-col organic-sales-ratio">
              <span>
                { formatValue(data.sales_ratio, 'percent') }
              </span>
              <span>
                { formatValue(data.sales + data.ppcRevenue ? data.ppcRevenue / (data.sales + data.ppcRevenue) * 100 : 0, 'percent') }
              </span>
            </div>
          )
        }
        {
          productTableColumns.includes('ad_spend_margin') && (
            <div className="table-col ad-spend-margin">
              {formatValue(data.ad_spend_margin, 'percent')}
            </div>
          )
        }
        {productTableColumns.includes('total_clicks') && <div className="table-col">{formatValue(data.total_clicks, 'number', 0)}</div>}
        {productTableColumns.includes('ctr') && <div className="table-col">{formatValue(data.ctr, 'percent')}</div>}
        {productTableColumns.includes('cost') && <div className="table-col">{formatCurrency(data.cost, currencySign, currencyRate)}</div>}
        {productTableColumns.includes('orders') && <div className="table-col">{formatValue(data.orders, 'number', 0)}</div>}
        {productTableColumns.includes('acos') && <div className="table-col">{formatValue(data.acos, 'number')}</div>}
        <div className="table-col">
          <Dropdown
            title={(<MoreDotsSvg />)}
            noCaret
            placement="leftEnd"
          >
            <Dropdown.Item
              componentClass={Link}
              to={`/product/${data.id}/${data.sku}`}
            >
              View Dashboard
            </Dropdown.Item>
            <Dropdown.Item onClick={()=>handleOpenAmazon(data['url'])}>Open in Amazon</Dropdown.Item>
          </Dropdown>
        </div>
      </div>
      {productExpanded === data.id && (
        <div className="product-detail">
          <div className="keyword-row keyword-header">
            <div className="keyword-col">Keyword</div>
            <div className="keyword-col">Organic Rank</div>
            <div className="keyword-col">Rank Change</div>
            <div className="keyword-col">Spend</div>
            <div className="keyword-col">Impressions</div>
            <div className="keyword-col">Number Of Orders</div>
            <div className="keyword-col">Max CPC</div>
            <div className="keyword-col">Started Tracking On</div>
          </div>
          {productKeywords.length ?
            productKeywords.map((keyword)=> (
              <div className="keyword-row" key={keyword.keyword}>
                <div className="keyword-col">{keyword['keyword']}</div>
                <div className="keyword-col">
                  {isExtensionInstalled ?
                    <Toggle checked={keyword['auto_organic_rank_checking'] ? true:false} />
                    :
                    <Whisper
                      trigger="hover"
                      placement="auto"
                      speaker={
                        <Tooltip>
                          <p>Install the 'PPC Entourage Chrome Extension' to enable product rank tracking
                          property</p>
                        </Tooltip>
                      }
                    >
                      <img alt={keyword['keyword']} src={ImgLock} />
                    </Whisper>
                  }
                </div>
                <div className="keyword-col">
                  {isExtensionInstalled ?
                    <Radio checked={keyword['indexing_last_check_date'] ? true:false} />
                    :
                    <Whisper
                      trigger="hover"
                      placement="auto"
                      speaker={
                        <Tooltip>
                          <p>Install the 'PPC Entourage Chrome Extension' to see and check the indexing statuses
                          property</p>
                        </Tooltip>
                      }
                    >
                      <img alt={keyword['keyword']} src={ImgLock} />
                    </Whisper>
                  }
                </div>
                <div className="keyword-col">{formatCurrency(keyword['cost'], currencySign, currencyRate)}</div>
                <div className="keyword-col">{formatValue(keyword['impressions'], 'number', 0)}</div>
                <div className="keyword-col">{formatValue(keyword['orders'], 'number', 0)}</div>
                <div className="keyword-col">{formatValue(keyword['max_cpc'], 'number')}</div>
                <div className="keyword-col">{keyword['started_tracking_on'] ? moment(keyword['started_tracking_on']).format('YYYY-MM-DD') : ''}</div>
              </div>
            ))
            :
            <div className="keyword-no-data">
              {isLoadingProductKeywords && <LoaderComponent />}
              No Data
            </div>
          }
        </div>
      )}
    </React.Fragment>
  ))

  return (
    <div className={`product-table-component${(isLoading || isUpdateProductCog) ? ' loading' : ''}`}>
      { (isLoading || isUpdateProductCog) && <LoaderComponent />}
      {
        showColumnEditor && visibleColumnEditorId === '' &&
        <ColumnEditor
          columnList={productColumnList}
          currentSelection={productTableColumns}
          onApply={applyProductColumnChanges}
        />
      }
      {
        visibleFilterName === 'productTable' &&
        <TableFilter filterName="productTable" />
      }
      <TableFilterShower filterName="productTable" />
      { renderActions() }
      <div className="table-body" ref={refTable}>
        <TableHeader
          columns={columns}
          tableColumns={productTableColumns}
          isSticky={isSticky}
          refHeader={refHeader}
          refProductCol={refProductCol}
          tableHeight={tableHeight}
          resizing={resizing}
          onSort={sortColumn}
          onExpandProductName={handleExpandProductName}
          onCollapseProductName={handleCollapseProductName}
          onResize={setResizing}
        />
        <TableFooter
          columns={columns}
          tableColumns={productTableColumns}
          products={products}
          isSticky={isSticky}
          refFooter={refFooter}
          currencyRate={currencyRate}
          currencySign={currencySign}
        />
        { productElements }
      </div>
      <PaginationComponent
        total={products.length}
        loadData={loadProducts}
      />
    </div>
  )
}

export default ProductTableComponent
