import React from 'react'
import { Tooltip, Whisper } from 'rsuite'

import { ReactComponent as MaxSvg } from '../../assets/svg/maximize.svg'
import { ReactComponent as MinSvg } from '../../assets/svg/minimize.svg'
import { ReactComponent as InfoSvg } from '../../assets/svg/info.svg'

const TableHeader = ({ columns, tableColumns, isSticky,
  refHeader, refProductCol, tableHeight, resizing,
  onSort, onExpandProductName, onCollapseProductName, onResize }) => (
  <div className={`table-row content-header${isSticky ? ' sticky' : ''}`} ref={refHeader}>
    <div className="table-col product-name" ref={refProductCol} onClick={() => { onSort('product-name') }}>
      Product
      <MinSvg className="min-svg" onClick={onCollapseProductName} />
      <MaxSvg className="max-svg" onClick={onExpandProductName} />
      <div
        className={`resize-handle ${resizing ? 'active' : 'idle'}`}
        style={{ height: tableHeight }}
        onMouseDown={() => { onResize(true) }}
      />
    </div>
    {
      columns.map(column => (
        tableColumns.includes(column.key) && (
          <div
            key={column.key}
            className={`table-col ${column.className || ''}`}
            onClick={() => { onSort(column.key) }}
          >
            { column.name }
            {
              typeof column.tooltip !== 'undefined' && (
                <Whisper placement="right" trigger="hover" speaker={(
                  <Tooltip>
                    { column.tooltip }
                  </Tooltip>
                )}>
                  <InfoSvg />
                </Whisper>
              )
            }
          </div>
        )
      ))
    }
    <div className="table-col"></div>
  </div>
)

export default TableHeader
