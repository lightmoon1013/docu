import React, { useMemo } from 'react'
import { useStore } from 'react-redux'
import { Slider } from 'rsuite'

import MatchTypePerformance from './MatchTypePerformance'

import {
  formatValue,
  parsePerformanceSummary,
} from '../../services/helper'

const PerformanceComponent = ({ adTypeFilter }) => {
  const store = useStore().getState()
  const {
    health: { summaryData: { placementSummary } },
  } = store

  const { bidTotal, placementTotal } = useMemo(() => {
    return parsePerformanceSummary(placementSummary)
  }, [placementSummary])

  const placementEligible = adTypeFilter === null
    || adTypeFilter.value === ''
    || adTypeFilter.value === 'sp'

  return (
    <div className="account-health-performance">
      <div className="performance-section">
        <div className="table-toolbar">
          <div className="toolbar-left">
            By Placement
          </div>
        </div>
        <div className="table-body">
          <div className="table-row">
            <div className="table-col">Top of search (first page)</div>
            <div className="table-col">
              <div className="col-title">CTR</div>
              <div className="col-value">
                { placementEligible ? formatValue(placementTotal['ctrTop'], 'percent') : 'N/A' }
              </div>
              {
                placementEligible && (
                  <div className="col-progress">
                    <div className="label">
                      <span>Clicks: {formatValue(placementTotal['clicksTop'], 'number', 0)}</span>
                      <span>Impressions: {formatValue(placementTotal['impressionsTop'], 'number', 0)}</span>
                    </div>
                    <div className="content">
                      <Slider
                        barClassName="performance-ctr"
                        progress
                        value={parseFloat(placementTotal['ctrTop'] || 0)}
                      />
                    </div>
                  </div>
                )
              }
            </div>
            <div className="table-col">
              <div className="col-title">Conversion</div>
              <div className="col-value">
                { placementEligible ? formatValue(placementTotal['convTop'], 'percent') : 'N/A' }
              </div>
              {
                placementEligible && (
                  <div className="col-progress">
                    <div className="label">
                      <span>Orders: {formatValue(placementTotal['ordersTop'], 'number', 0)}</span>
                      <span>Clicks: {formatValue(placementTotal['clicksTop'], 'number', 0)}</span>
                    </div>
                    <div className="content">
                      <Slider
                        barClassName="performance-conv"
                        progress
                        value={parseFloat(placementTotal['convTop'] || 0)}
                      />
                    </div>
                  </div>
                )
              }
            </div>
            <div className="table-col">
              <div className="col-title">Acos</div>
              <div className="col-value">
                { placementEligible ? formatValue(placementTotal['acosTop'], 'percent') : 'N/A' }
              </div>
              {
                placementEligible && (
                  <div className="col-progress">
                    <div className="label">
                      <span>Sales: {formatValue(placementTotal['revenueTop'], 'number', 0)}</span>
                      <span>CPC: {formatValue(placementTotal['cpcTop'], 'number', 0)}</span>
                    </div>
                    <div className="content">
                      <Slider
                        barClassName="performance-acos"
                        progress
                        value={parseFloat(placementTotal['acosTop'] || 0)}
                      />
                    </div>
                  </div>
                )
              }
            </div>
          </div>
          <div className="table-row">
            <div className="table-col">Product pages</div>
            <div className="table-col">
              <div className="col-title">CTR</div>
              <div className="col-value">
                { placementEligible ? formatValue(placementTotal['ctrDetail'], 'percent') : 'N/A' }
              </div>
              {
                placementEligible && (
                  <div className="col-progress">
                    <div className="label">
                      <span>Clicks: {formatValue(placementTotal['clicksDetail'], 'number', 0)}</span>
                      <span>Impressions: {formatValue(placementTotal['impressionsDetail'], 'number', 0)}</span>
                    </div>
                    <div className="content">
                      <Slider
                        barClassName="performance-ctr"
                        progress
                        value={parseFloat(placementTotal['ctrDetail'] || 0)}
                      />
                    </div>
                  </div>
                )
              }
            </div>
            <div className="table-col">
              <div className="col-title">Conversion</div>
              <div className="col-value">
                { placementEligible ? formatValue(placementTotal['convDetail'], 'percent') : 'N/A' }
              </div>
              {
                placementEligible && (
                  <div className="col-progress">
                    <div className="label">
                      <span>Orders: {formatValue(placementTotal['ordersDetail'], 'number', 0)}</span>
                      <span>Clicks: {formatValue(placementTotal['clicksDetail'], 'number', 0)}</span>
                    </div>
                    <div className="content">
                      <Slider
                        barClassName="performance-conv"
                        progress
                        value={parseFloat(placementTotal['convDetail'] || 0)}
                      />
                    </div>
                  </div>
                )
              }
            </div>
            <div className="table-col">
              <div className="col-title">Acos</div>
              <div className="col-value">
                { placementEligible ? formatValue(placementTotal['acosDetail'], 'percent') : 'N/A' }
              </div>
              {
                placementEligible && (
                  <div className="col-progress">
                    <div className="label">
                      <span>Sales: {formatValue(placementTotal['revenueDetail'], 'number', 0)}</span>
                      <span>CPC: {formatValue(placementTotal['cpcDetail'], 'number', 0)}</span>
                    </div>
                    <div className="content">
                      <Slider
                        barClassName="performance-acos"
                        progress
                        value={parseFloat(placementTotal['acosDetail'] || 0)}
                      />
                    </div>
                  </div>
                )
              }
            </div>
          </div>
          <div className="table-row">
            <div className="table-col">Rest of search</div>
            <div className="table-col">
              <div className="col-title">CTR</div>
              <div className="col-value">
                { placementEligible ? formatValue(placementTotal['ctrOther'], 'percent') : 'N/A' }
              </div>
              {
                placementEligible && (
                  <div className="col-progress">
                    <div className="label">
                      <span>Clicks: {formatValue(placementTotal['clicksOther'], 'number', 0)}</span>
                      <span>Impressions: {formatValue(placementTotal['impressionsOther'], 'number', 0)}</span>
                    </div>
                    <div className="content">
                      <Slider
                        barClassName="performance-ctr"
                        progress
                        value={parseFloat(placementTotal['ctrOther'] || 0)}
                      />
                    </div>
                  </div>
                )
              }
            </div>
            <div className="table-col">
              <div className="col-title">Conversion</div>
              <div className="col-value">
                { placementEligible ? formatValue(placementTotal['convOther'], 'percent') : 'N/A' }
              </div>
              {
                placementEligible && (
                  <div className="col-progress">
                    <div className="label">
                      <span>Orders: {formatValue(placementTotal['ordersOther'], 'number', 0)}</span>
                      <span>Clicks: {formatValue(placementTotal['clicksOther'], 'number', 0)}</span>
                    </div>
                    <div className="content">
                      <Slider
                        barClassName="performance-conv"
                        progress
                        value={parseFloat(placementTotal['convOther'] || 0)}
                      />
                    </div>
                  </div>
                )
              }
            </div>
            <div className="table-col">
              <div className="col-title">Acos</div>
              <div className="col-value">
                { placementEligible ? formatValue(placementTotal['acosOther'], 'percent') : 'N/A' }
              </div>
              {
                placementEligible && (
                  <div className="col-progress">
                    <div className="label">
                      <span>Sales: {formatValue(placementTotal['revenueOther'], 'number', 0)}</span>
                      <span>CPC: {formatValue(placementTotal['cpcOther'], 'number', 0)}</span>
                    </div>
                    <div className="content">
                      <Slider
                        barClassName="performance-acos"
                        progress
                        value={parseFloat(placementTotal['acosOther'] || 0)}
                      />
                    </div>
                  </div>
                )
              }
            </div>
          </div>
        </div>
      </div>
      <div className="performance-section">
        <div className="table-toolbar">
          <div className="toolbar-left">
            By Bid Type
          </div>
        </div>
        <div className="table-body">
          <div className="table-row">
            <div className="table-col">Dynamic bids - down only</div>
            <div className="table-col">
              <div className="col-title">CTR</div>
              <div className="col-value">
                { placementEligible ? formatValue(bidTotal['ctrLegacy'], 'percent') : 'N/A' }
              </div>
              {
                placementEligible && (
                  <div className="col-progress">
                    <div className="label">
                      <span>Clicks: {formatValue(bidTotal['clicksLegacy'], 'number', 0)}</span>
                      <span>Impressions: {formatValue(bidTotal['impressionsLegacy'], 'number', 0)}</span>
                    </div>
                    <div className="content">
                      <Slider
                        barClassName="performance-ctr"
                        progress
                        value={parseFloat(bidTotal['ctrLegacy'] || 0)}
                      />
                    </div>
                  </div>
                )
              }
            </div>
            <div className="table-col">
              <div className="col-title">Conversion</div>
              <div className="col-value">
                { placementEligible ? formatValue(bidTotal['convLegacy'], 'percent') : 'N/A' }
              </div>
              {
                placementEligible && (
                  <div className="col-progress">
                    <div className="label">
                      <span>Orders: {formatValue(bidTotal['ordersLegacy'], 'number', 0)}</span>
                      <span>Clicks: {formatValue(bidTotal['clicksLegacy'], 'number', 0)}</span>
                    </div>
                    <div className="content">
                      <Slider
                        barClassName="performance-conv"
                        progress
                        value={parseFloat(bidTotal['convLegacy'] || 0)}
                      />
                    </div>
                  </div>
                )
              }
            </div>
            <div className="table-col">
              <div className="col-title">Acos</div>
              <div className="col-value">
                { placementEligible ? formatValue(bidTotal['acosLegacy'], 'percent') : 'N/A' }
              </div>
              {
                placementEligible && (
                  <div className="col-progress">
                    <div className="label">
                      <span>Sales: {formatValue(bidTotal['revenueLegacy'], 'number', 0)}</span>
                      <span>CPC: {formatValue(bidTotal['cpcLegacy'], 'number', 0)}</span>
                    </div>
                    <div className="content">
                      <Slider
                        barClassName="performance-acos"
                        progress
                        value={parseFloat(bidTotal['acosLegacy'] || 0)}
                      />
                    </div>
                  </div>
                )
              }
            </div>
          </div>
          <div className="table-row">
            <div className="table-col">Dynamic bids - up and down</div>
            <div className="table-col">
              <div className="col-title">CTR</div>
              <div className="col-value">
                { placementEligible ? formatValue(bidTotal['ctrAuto'], 'percent') : 'N/A' }
              </div>
              {
                placementEligible && (
                  <div className="col-progress">
                    <div className="label">
                      <span>Clicks: {formatValue(bidTotal['clicksAuto'], 'number', 0)}</span>
                      <span>Impressions: {formatValue(bidTotal['impressionsAuto'], 'number', 0)}</span>
                    </div>
                    <div className="content">
                      <Slider
                        barClassName="performance-ctr"
                        progress
                        value={parseFloat(bidTotal['ctrAuto'] || 0)}
                      />
                    </div>
                  </div>
                )
              }
            </div>
            <div className="table-col">
              <div className="col-title">Conversion</div>
              <div className="col-value">
                { placementEligible ? formatValue(bidTotal['convAuto'], 'percent') : 'N/A' }
              </div>
              {
                placementEligible && (
                  <div className="col-progress">
                    <div className="label">
                      <span>Orders: {formatValue(bidTotal['ordersAuto'], 'number', 0)}</span>
                      <span>Clicks: {formatValue(bidTotal['clicksAuto'], 'number', 0)}</span>
                    </div>
                    <div className="content">
                      <Slider
                        barClassName="performance-conv"
                        progress
                        value={parseFloat(bidTotal['convAuto'] || 0)}
                      />
                    </div>
                  </div>
                )
              }
            </div>
            <div className="table-col">
              <div className="col-title">Acos</div>
              <div className="col-value">
                { placementEligible ? formatValue(bidTotal['acosAuto'], 'percent') : 'N/A' }
              </div>
              {
                placementEligible && (
                  <div className="col-progress">
                    <div className="label">
                      <span>Sales: {formatValue(bidTotal['revenueAuto'], 'number', 0)}</span>
                      <span>CPC: {formatValue(bidTotal['cpcAuto'], 'number', 0)}</span>
                    </div>
                    <div className="content">
                      <Slider
                        barClassName="performance-acos"
                        progress
                        value={parseFloat(bidTotal['acosAuto'] || 0)}
                      />
                    </div>
                  </div>
                )
              }
            </div>
          </div>
          <div className="table-row">
            <div className="table-col">Fixed Bid</div>
            <div className="table-col">
              <div className="col-title">CTR</div>
              <div className="col-value">
                { placementEligible ? formatValue(bidTotal['ctrManual'], 'percent') : 'N/A' }
              </div>
              {
                placementEligible && (
                  <div className="col-progress">
                    <div className="label">
                      <span>Clicks: {formatValue(bidTotal['clicksManual'], 'number', 0)}</span>
                      <span>Impressions: {formatValue(bidTotal['impressionsManual'], 'number', 0)}</span>
                    </div>
                    <div className="content">
                      <Slider
                        barClassName="performance-ctr"
                        progress
                        value={parseFloat(bidTotal['ctrManual'] || 0)}
                      />
                    </div>
                  </div>
                )
              }
            </div>
            <div className="table-col">
              <div className="col-title">Conversion</div>
              <div className="col-value">
                { placementEligible ? formatValue(bidTotal['convManual'], 'percent') : 'N/A' }
              </div>
              {
                placementEligible && (
                  <div className="col-progress">
                    <div className="label">
                      <span>Orders: {formatValue(bidTotal['ordersManual'], 'number', 0)}</span>
                      <span>Clicks: {formatValue(bidTotal['clicksManual'], 'number', 0)}</span>
                    </div>
                    <div className="content">
                      <Slider
                        barClassName="performance-conv"
                        progress
                        value={parseFloat(bidTotal['convManual'] || 0)}
                      />
                    </div>
                  </div>
                )
              }
            </div>
            <div className="table-col">
              <div className="col-title">Acos</div>
              <div className="col-value">
                { placementEligible ? formatValue(bidTotal['acosManual'], 'percent') : 'N/A'}
              </div>
              {
                placementEligible && (
                  <div className="col-progress">
                    <div className="label">
                      <span>Sales: {formatValue(bidTotal['revenueManual'], 'number', 0)}</span>
                      <span>CPC: {formatValue(bidTotal['cpcManual'], 'number', 0)}</span>
                    </div>
                    <div className="content">
                      <Slider
                        barClassName="performance-acos"
                        progress
                        value={parseFloat(bidTotal['acosManual'] || 0)}
                      />
                    </div>
                  </div>
                )
              }
            </div>
          </div>
        </div>
      </div>
      <MatchTypePerformance adTypeFilter={adTypeFilter} />
    </div>
  )
}

export default PerformanceComponent
