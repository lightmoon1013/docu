import React, { useState, useEffect, useRef } from 'react'
import { useStore, useDispatch } from 'react-redux'
import Select, { components } from 'react-select'
import { DatePicker, Dropdown } from 'rsuite'
import moment from 'moment'

import CheckboxComponent from '../CommonComponents/CheckboxComponent'
import LoaderComponent from '../CommonComponents/LoaderComponent'
import SelectAsyncPaginate from '../CommonComponents/SelectAsyncPaginate'

import MetricsComponent from './metrics'
import PerformanceComponent from './performance'
import ReportComponent from './report'

import { setDateRange } from '../../redux/actions/header'
import { getPortfolios } from '../../redux/actions/bulkEngine'
import { getApSkus } from '../../redux/actions/ap'
import {
  getHealthData,
  getSummaryChart,
  // getCampaignData,
  saveNotificationPlan,
} from '../../redux/actions/health'

const adTypeOptions = [
  { label: 'All Sponsored', value: '' },
  { label: 'Sponsored Product', value: 'sp' },
  { label: 'Sponsored Brand', value: 'sb' },
  { label: 'Sponsored Brand Video', value: 'sbv' },
  { label: 'Sponsored Display', value: 'sd' },
]

const Option = (props) => {
  const { innerRef, innerProps, getStyles, data } = props
  return (
    <div
      ref={innerRef}
      {...innerProps}
      style={getStyles('option', props)}
      className="sku-option"
    >
      {
        data.image !== '' ? (
          <img src={data.image} alt={data.name} />
        ) : (
          <span className="placeholder-image" />
        )
      }
      <div className="product-info">
        <span className="product-name" title={data.name}>{data.name}</span>
        <span className="product-sku">SKU: {data.sku}</span>
      </div>
    </div>
  )
}

// https://github.com/JedWatson/react-select/issues/4170#issuecomment-682465724
const ValueContainer = (props) => {
  const { options, children, getValue } = props
  const selectCount = getValue().length
  let contents = children
  if (selectCount > 0) {
    if (selectCount === options.length) {
      contents = (
        <>
          All SKUs selected
          { children[1] }
        </>
      )
    } else if (selectCount >= 10) {
      contents = (
        <>
          { selectCount } SKUs selected
          { children[1] }
        </>
      )
    }
  }
  return (
    <components.ValueContainer {...props}>
      { contents }
    </components.ValueContainer>
  )
}

const MultiValueLabel = (props) => {
  const { data } = props
  return (
    <components.MultiValueLabel {...props}>
      <img src={data.image} className="option-label-img" alt={data.name} />
    </components.MultiValueLabel>
  )
}

const AccountHealthComponent = () => {
  const store = useStore().getState()
  const dispatch = useDispatch()

  const {
    health: {
      isLoadingHealthData,
      isSavingNotificationPlan,
    },
    bulkEngine: {
      isGettingPortfolios,
      portfolioList,
    },
    header: {
      accountList,
      currentUserId,
      currentStartDate,
      currentEndDate,
    },
  } = store

  const currentUser = accountList.filter(user => parseInt(user['user']) === parseInt(currentUserId))[0]

  const [tab, setTab] = useState('metric')
  const [adTypeFilter, setAdTypeFilter] = useState(adTypeOptions[0])
  const [portfolioFilter, setPortfolioFilter] = useState(null)
  const [selectedProduct, setSelectedProduct] = useState(null)
  const [keyword, setKeyword] = useState('')
  const [weeklyAlert, setWeeklyAlert] = useState(currentUser ? currentUser['weekly_alert'] : false)
  const [monthlyAlert, setMonthlyAlert] = useState(currentUser ? currentUser['monthly_alert'] : false)
  const [additionalAlert, setAdditionalAlert] = useState(currentUser ? currentUser['additional_alert'] : false)
  const [openNotificationDropdown, setOpenNotificationDropdown] = useState(false)

  const dateRangeContainerRef = useRef(null)

  useEffect(() => {
    dispatch(getPortfolios())
  }, []) // eslint-disable-line

  useEffect(() => {
    const params = {
      startDate: moment(currentStartDate).format('YYYY-MM-DD'),
      endDate: moment(currentEndDate).format('YYYY-MM-DD'),
      adType: adTypeFilter.value,
      productId: selectedProduct ? selectedProduct.id : '',
      portfolioId: portfolioFilter ? portfolioFilter.value : '',
    }

    dispatch(getHealthData(params))
    dispatch(getSummaryChart(params))
    // dispatch(getCampaignData(params))
  }, [dispatch, adTypeFilter, selectedProduct, portfolioFilter, currentStartDate, currentEndDate])

  const portfolioOptions = [
    { value: '', label: 'All' },
    ...portfolioList.map(portfolio => ({
      value: portfolio.portfolio_id,
      label: portfolio.name,
    }))
  ]

  const tabs = [
    {value: 'metric', label: 'Main Metrics'},
    {value: 'performance', label: 'Performance'},
    // {value: 'report', label: 'Campaign Reports'}
  ]

  const tabElements = tabs.map(data => (
    <div key={data.value} className={tab===data.value ? "component-tab selected" : "component-tab"} onClick={()=>setTab(data.value)}>
      {data.label}
    </div>
  ))

  const onChangeDateRange = (data) => {
    dispatch(setDateRange({
      startDate: moment(data).startOf('month').format('YYYY-MM-DD'),
      endDate: moment(data).endOf('month').format('YYYY-MM-DD'),
    }))
  }

  const onSavePlan = () => {
    dispatch(saveNotificationPlan({
      weeklyAlert,
      monthlyAlert,
      additionalAlert
    }))
  }

  const handleInputChange = (inputValue, { action }) => {
    if (action !== 'input-blur' && action !== 'menu-close' && action !== 'set-value') {
      setKeyword(inputValue)
    }
  }

  const isLoading = isLoadingHealthData
    || isGettingPortfolios
    || isSavingNotificationPlan

  return (
    <div className={isLoading ? "account-health-component isLoading" : "account-health-component"}>
      { isLoading && <LoaderComponent /> }
      <div className="component-notification">
        <Dropdown
          title="Change Notification Plan"
          open={openNotificationDropdown}
          onClick={() => { setOpenNotificationDropdown(true) }}
          onMouseLeave={() => { setOpenNotificationDropdown(false) }}
        >
          <Dropdown.Item onClick={()=>setMonthlyAlert(!monthlyAlert)}>
            <CheckboxComponent checked={monthlyAlert} />
            <span>Monthly Email: Opt-in to receive monthly emails from PPC Entourage containing account performance updates.</span>
          </Dropdown.Item>
          <Dropdown.Item onClick={()=>setWeeklyAlert(!weeklyAlert)}>
            <CheckboxComponent checked={weeklyAlert} />
            <span>Weekly Email: Opt-in to receive weekly emails from PPC Entourage containing account performance updates.</span>
          </Dropdown.Item>
          <Dropdown.Item onClick={()=>setAdditionalAlert(!additionalAlert)}>
            <CheckboxComponent checked={additionalAlert} />
            <span>Opt-in to additional emails from PPC Entourage that may contain educational resources, training and webinar schedules, and marketing content. Your information is never shared with a third party.</span>
          </Dropdown.Item>
          <Dropdown.Item>
            <button type="button" className="btn btn-red" onClick={onSavePlan}>Save</button>
          </Dropdown.Item>
        </Dropdown>
      </div>
      <div className="component-header">
        <div className="header-row">
          <span>Ad Type</span>
          <Select
            options={adTypeOptions}
            value={adTypeFilter || adTypeOptions[0]}
            onChange={setAdTypeFilter}
          />
        </div>
        <div className="header-row">
          <span>Portfolio</span>
          <Select
            options={portfolioOptions}
            value={portfolioFilter || portfolioOptions[0]}
            onChange={setPortfolioFilter}
          />
        </div>
        <div className="header-row">
          <span>SKU/ASIN/Product</span>
          <SelectAsyncPaginate
            components={{ Option, ValueContainer, MultiValueLabel }}
            loadSkus={getApSkus}
            selection={selectedProduct}
            isMulti={false}
            isClearable
            closeMenuOnSelect
            placeholder="All"
            keyword={keyword}
            onChange={setSelectedProduct}
            onInputChange={handleInputChange}
          />
        </div>
        <div className="header-row date-range-container" ref={dateRangeContainerRef}>
          <span>Select Date Range</span>
          <DatePicker
            format="YYYY-MM"
            onChange={onChangeDateRange}
            value={moment(currentStartDate).toDate()}
            ranges={[]}
            limitEndYear={0}
            container={dateRangeContainerRef.current}
          />
        </div>
      </div>
      <div className="component-body">
        <div className="component-tabs">
          {tabElements}
        </div>
        {tab==='metric' &&
          <MetricsComponent
            adTypeFilter={adTypeFilter}
            selectedProduct={selectedProduct}
            portfolioFilter={portfolioFilter}
          />
        }
        {tab==='performance' &&
          <PerformanceComponent
            adTypeFilter={adTypeFilter}
          />
        }
        {tab==='report' &&
          <ReportComponent />
        }
      </div>
    </div>
  )
}

export default AccountHealthComponent
