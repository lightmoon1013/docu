import React from 'react'
import { useStore } from 'react-redux'
import moment from 'moment'
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  ResponsiveContainer,
  Tooltip
} from 'recharts'

import {
  formatValue,
} from '../../services/helper'

import LoaderComponent from '../CommonComponents/LoaderComponent'

const MetricChartComponent = ({ metric, chartData }) => {
  const store = useStore().getState()

  const {
    health: { isLoadingSummaryChart },
  } = store

  const tickFormatter = (ts) => {
    if (!ts || isNaN(ts)) {
      return ''
    }
    return moment(ts).format('MM/DD')
  }

  return (
    <div className={`chart-row${isLoadingSummaryChart ? ' loading' : ''}`}>
      { isLoadingSummaryChart && <LoaderComponent /> }
      <div className="chart-name">
        { metric.label }
      </div>
      <div className="chart-wrapper">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart
            width={300}
            height={300}
            data={chartData}
            margin={{ top: 10, right: 30, left: -25, bottom: 20, }}
          >
            <XAxis
              dataKey="startdate"
              tickMargin="10"
              angle="-45"
              tickFormatter={tickFormatter}
            />
            <YAxis
              dataKey={metric.value}
            />
            <Tooltip
              formatter={(value) => formatValue(value, 'number', metric.decimal)}
              labelFormatter={d => moment(d).format('YYYY/MM/DD')}
            />
            <Line
              type="monotone"
              dataKey={metric.value}
              name={metric.label}
              strokeWidth={2}
              activeDot={true}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}

export default MetricChartComponent
