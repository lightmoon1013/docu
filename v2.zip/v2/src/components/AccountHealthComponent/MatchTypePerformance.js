import React from 'react'
import { useStore } from 'react-redux'
import { Slider } from 'rsuite'

import {
  formatValue,
  formatCurrency
} from '../../services/helper'

const MatchTypePerformance = ({ adTypeFilter }) => {
  const store = useStore().getState()
  const {
    header: {
      currencySign,
      currencyRate,
    },
    health: { summaryData: { matchTypeSummary } },
  } = store

  const isSD = adTypeFilter !== null && adTypeFilter.value === 'sd'

  const matchTypeElements = matchTypeSummary.map((data) => {
    const ctr = data.impressions ? data.clicks / data.impressions * 100.0 : 0
    const acos = data.revenue ? data.cost / data.revenue * 100.0 : 0
    const conv = data.clicks ? data.orders / data.clicks * 100.0 : 0
    const cpc = data.clicks ? data.cost / data.clicks : 0

    return (
      <div key={data['match_type']} className="table-row by-match">
        <div className="table-col">{data['match_type']}</div>
        <div className="table-col">
          <div className="col-title">CTR</div>
          <div className="col-value">
            { !isSD ? formatValue(ctr, 'percent') : 'N/A' }
          </div>
          {
            !isSD && (
              <div className="col-progress">
                <div className="label">
                  <span>Clicks: {formatValue(data['clicks'], 'number', 0)}</span>
                  <span>Impressions: {formatValue(data['impressions'], 'number', 0)}</span>
                </div>
                <div className="content">
                  <Slider
                    barClassName="performance-ctr"
                    progress
                    value={parseFloat(ctr || 0)}
                  />
                </div>
              </div>
            )
          }
        </div>
        <div className="table-col">
          <div className="col-title">Conversion</div>
          <div className="col-value">
            { !isSD ? formatValue(conv, 'percent') : 'N/A' }
          </div>
          {
            !isSD && (
              <div className="col-progress">
                <div className="label">
                  <span>Orders: {formatValue(data['orders'], 'number', 0)}</span>
                  <span>Clicks: {formatValue(data['clicks'], 'number', 0)}</span>
                </div>
                <div className="content">
                  <Slider
                    barClassName="performance-conv"
                    progress
                    value={parseFloat(conv || 0)}
                  />
                </div>
              </div>
            )
          }
        </div>
        <div className="table-col">
          <div className="col-title">Acos</div>
          <div className="col-value">
            { !isSD ? formatValue(acos, 'percent') : 'N/A' }
          </div>
          {
            !isSD && (
              <div className="col-progress">
                <div className="label">
                  <span>Sales: {formatCurrency(data['revenue'], currencySign, currencyRate)}</span>
                  <span>CPC: {formatValue(cpc, 'number', 0)}</span>
                </div>
                <div className="content">
                  <Slider
                    barClassName="performance-acos"
                    progress
                    value={parseFloat(acos || 0)}
                  />
                </div>
              </div>
            )
          }
        </div>
      </div>
    )
  })

  return (
    <div className="performance-section">
      <div className="table-toolbar">
        <div className="toolbar-left">
          By Match Type
        </div>
      </div>
      <div className="table-body">
        {matchTypeElements}
      </div>
    </div>
  )
}

export default MatchTypePerformance
