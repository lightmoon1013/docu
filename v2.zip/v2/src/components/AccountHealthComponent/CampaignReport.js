import React from 'react'

import AreaRechartComponent from '../CommonComponents/AreaChart'

import {
  formatValue,
  formatCurrency
} from '../../services/helper'

const CampaignReport = ({ name, isLoading, campaigns, prevData, historyData,
  currencySign, currencyRate, startDate, endDate }) => {

  const renderChange = (campaign, prevMonth, field) => (
    <div className="col-change">
      {
        campaign[field]
        ? formatValue(
            ((prevMonth ? prevMonth[field] || 0 : 0) - campaign[field]) / campaign[field] * 100,
            'percent'
          )
        : 0
      }
    </div>
  )

  const campaignRows = campaigns.map((campaign) => {
    const prevMonth = prevData.find(record => record.campaignid === campaign.campaignid)

    const dataWithHistory = (historyData || []).find(record => record.campaign_id === campaign.campaignid)
    const chartData = dataWithHistory ? dataWithHistory.chartData : null

    return (
      <div key={campaign.campaignid} className="table-row">
        <div className="table-col col-campaign-name">
          { campaign.campaign }
        </div>
        <div className="table-col">
          <div className="col-value">
            { formatValue(campaign.acos1, 'number', 0) }
          </div>
        </div>
        <div className="table-col">
          <div className="col-value">
            { formatValue(campaign.acos, 'percent', 2) }
          </div>
          { renderChange(campaign, prevMonth, 'acos') }
          <AreaRechartComponent
            areaData={
              (chartData || []).map(item => ({
                date: item.startdate,
                value: item['acos'] || 0
              }))
            }
            startDate={startDate}
            endDate={endDate}
          />
        </div>
        <div className="table-col">
          <div className="col-value">
            { formatCurrency(campaign.revenue, currencySign, currencyRate) }
          </div>
          { renderChange(campaign, prevMonth, 'revenue') }
          <AreaRechartComponent
            areaData={
              (chartData || []).map(item => ({
                date: item.startdate,
                value: item['revenue'] || 0
              }))
            }
            startDate={startDate}
            endDate={endDate}
          />
        </div>
        <div className="table-col">
          <div className="col-value">
            {formatValue(campaign.impressions, 'number', 0)}
          </div>
          { renderChange(campaign, prevMonth, 'impressions') }
          <AreaRechartComponent
            areaData={
              (chartData || []).map(item => ({
                date: item.startdate,
                value: item['impressions'] || 0
              }))
            }
            startDate={startDate}
            endDate={endDate}
          />
        </div>
        <div className="table-col">
          <div className="col-value">
            { formatValue(campaign.clicks, 'number', 0) }
          </div>
          { renderChange(campaign, prevMonth, 'clicks') }
          <AreaRechartComponent
            areaData={
              (chartData || []).map(item => ({
                date: item.startdate,
                value: item['clicks'] || 0
              }))
            }
            startDate={startDate}
            endDate={endDate}
          />
        </div>
        <div className="table-col">
          <div className="col-value">
            {formatValue(campaign.ctr, 'percent', 2)}
          </div>
          { renderChange(campaign, prevMonth, 'ctr') }
          <AreaRechartComponent
            areaData={
              (chartData || []).map(item => ({
                date: item.startdate,
                value: item.ctr || 0
              }))
            }
            startDate={startDate}
            endDate={endDate}
          />
        </div>
        <div className="table-col">
          <div className="col-value">
            {formatValue(campaign.conversionrate, 'percent', 2)}
          </div>
          { renderChange(campaign, prevMonth, 'conversionrate') }
          <AreaRechartComponent
            areaData={
              (chartData || []).map(item => ({
                date: item.startdate,
                value: item['conversion'] || 0
              }))
            }
            startDate={startDate}
            endDate={endDate}
          />
        </div>
      </div>
    )
  })

  return (
    <div className={`report-table${isLoading ? ' loading' : ''}`}>
      <div className="table-header">
        <div className="table-title">{ name }</div>
      </div>
      <div className="table-body">
        <div className="table-row content-header">
          <div className="table-col col-campaign-name">Campaign Name</div>
          <div className="table-col">Target ACoS</div>
          <div className="table-col">Actual ACoS</div>
          <div className="table-col">AD Sales</div>
          <div className="table-col">Impr.</div>
          <div className="table-col">Clicks</div>
          <div className="table-col">CTR</div>
          <div className="table-col">Conversion</div>
        </div>
        { campaignRows }
      </div>
    </div>
  )
}

export default CampaignReport
