import React, { useState, useMemo } from 'react'
import { useStore, useDispatch } from 'react-redux'
import moment from 'moment'

import AreaRechartComponent from '../CommonComponents/AreaChart'
import MetricChartComponent from './metric-chart'

import {
  formatValue,
  formatCurrency,
  parseHealthKpi,
} from '../../services/helper'

import {
  getSummaryChart,
} from '../../redux/actions/health'

const chartMonthOptions = [
  {
    label: 'Selected month',
    value: 'current',
  },
  {
    label: 'Prior 3 months',
    value: 'past3',
  },
  {
    label: 'Prior 6 months',
    value: 'past6',
  },
]

const metrics = [
  { value: 'sales', label: 'Organic Sales', decimal: 2, type: 'currency' },
  { value: 'revenue', label: 'AD Sales', decimal: 2, type: 'currency' },
  { value: 'acos', label: 'ACoS %', decimal: 2, type: 'percent' },
  { value: 'cost', label: 'AD Spend', decimal: 2, type: 'currency' },
  { value: 'impressions', label: 'Impressions', decimal: 0, type: 'number' },
  { value: 'orders', label: 'Orders', decimal: 0, type: 'number' },
  { value: 'clicks', label: 'Clicks', decimal: 0, type: 'number' },
  { value: 'ctr', label: 'CTR %', decimal: 2, type: 'percent' },
  { value: 'conv', label: 'Conversion', decimal: 2, type: 'percent' },
  { value: 'totalCampaigns', label: 'Active Campaigns', decimal: 0, type: 'number' },
  { value: 'totalKeywords', label: 'Active Targets', decimal: 0, type: 'number' }
]

const MetricsComponent = ({ adTypeFilter, selectedProduct, portfolioFilter }) => {
  const store = useStore().getState()
  const dispatch = useDispatch()
  const { header, health } = store

  const {
    currencySign,
    currencyRate,
    currentStartDate,
    currentEndDate,
  } = header

  const {
    summaryData,
    summaryChartData,
  } = health

  const [selectedChartMonth, setSelectedChartMonth] = useState('current')

  const { kpiForThisMonth, kpiForPrevMonth } = useMemo(() => {
    return parseHealthKpi(summaryData)
  }, [summaryData])

  const chart = (summaryChartData || [])
    .sort((x, y) => x.startdate - y.startdate)
    .map((record) => {
      let conversion = 0
      if (parseInt(record.clicks, 10)) {
        conversion = parseInt(record.orders, 10) / parseInt(record.clicks, 10) * 100
      }
      return {
        ...record,
        conv: conversion,
        totalCampaigns: record.total_campaigns,
        totalKeywords: record.total_keywords,
      }
    })

  const handleChartMonthChange = (month) => {
    setSelectedChartMonth(month)

    let chartStartDate
    switch (month) {
      case 'past3':
        chartStartDate = moment(currentStartDate).subtract(2, 'months').format('YYYY-MM-DD')
        break
      case 'past6':
        chartStartDate = moment(currentStartDate).subtract(5, 'months').format('YYYY-MM-DD')
        break
      default:
        chartStartDate = currentStartDate
    }

    dispatch(getSummaryChart({
      startDate: chartStartDate,
      endDate: currentEndDate,
      adTypeFilter,
      productFilter: selectedProduct ? selectedProduct.id : '',
      portfolioFilter,
    }))
  }

  return (
    <div className="account-health-metrics">
      <div className="account-health-metrics-table">
        <div className="table-header">
          <div className="table-row">
            <div className="table-col"></div>
            {
              metrics.map(metric => (
                <div key={metric.value} className="table-col">
                  { metric.label }
                </div>
              ))
            }
          </div>
        </div>
        <div className="table-body">
          <div className="table-row">
            <div className="table-col">Total:</div>
            {
              metrics.map((metric) => {
                const key = metric.value
                let value
                if (key === 'sales' && adTypeFilter && adTypeFilter.value) {
                  value = 'N/A'
                } else if (metric.type === 'currency') {
                  value = formatCurrency(kpiForThisMonth[key], currencySign, currencyRate)
                } else if (metric.type === 'percent') {
                  value = formatValue(kpiForThisMonth[key], 'percent', 2)
                } else if (metric.type === 'number') {
                  value = formatValue(kpiForThisMonth[key], 'number', 0)
                }
                return (
                  <div key={key} className="table-col">
                    { value }
                  </div>
                )
              })
            }
          </div>
        </div>
        <div className="table-footer">
          <div className="table-row">
            <div className="table-col">Change from previous month</div>
            {
              metrics.map((metric) => {
                const key = metric.value
                const change = 100 - kpiForThisMonth[key] / kpiForPrevMonth[key] * 100
                const metricChart = chart.map(record => ({
                  date: record.startdate,
                  value: record[metric.value],
                }))

                return (
                  <div key={key} className="table-col">
                    <div className="col-value">
                      { formatValue(change, 'percent') }
                    </div>
                    <AreaRechartComponent
                      areaData={metricChart}
                      startDate={currentStartDate}
                      endDate={currentEndDate}
                    />
                  </div>
                )
              })
            }
          </div>
        </div>
      </div>
      <div className="metric-chart">
        <div className="month-selector">
          {
            chartMonthOptions.map(month => (
              <button
                key={month.value}
                type="button"
                className={`btn ${month.value === selectedChartMonth ? 'btn-red' : 'btn-white'}`}
                onClick={() => { handleChartMonthChange(month.value) }}
              >
                { month.label }
              </button>
            ))
          }
        </div>
        {
          metrics.map(metric => (
            <MetricChartComponent
              key={metric.value}
              metric={metric}
              chartData={chart}
            />
          ))
        }
      </div>
    </div>
  )
}

export default MetricsComponent
