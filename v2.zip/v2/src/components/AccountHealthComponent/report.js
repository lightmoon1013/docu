import React from 'react'
import { useStore } from 'react-redux'

import LoaderComponent from '../CommonComponents/LoaderComponent'
import CampaignReport from './CampaignReport'

const ReportsComponent = () => {
  const store = useStore().getState()

  const { header, health, campaign } = store

  const { currencySign, currencyRate, currentStartDate, currentEndDate } = header
  const { isLoadingListCampaigns, listCampaignData } = health
  const { listCampaigns, listCampaignsHSA, listCampaignsHSAPrevMonth, listCampaignsPrevMonth } = listCampaignData
  const { campaignsWithHistory } = campaign

  const autoCampaigns = []
  const manualCampaigns = []
  const targetCampaigns = []
  const sdCampaigns = []; // Here semi-colon is a must
  (listCampaigns || []).forEach((campaign) => {
    if (campaign.targetingtype === 'auto') {
      autoCampaigns.push(campaign)
    } else if (campaign.targetingtype === 'manual') {
      manualCampaigns.push(campaign)
    } else if (campaign.targetingtype === 'product') {
      // FIXME: Check if the logic is correct.
      targetCampaigns.push(campaign)
    }

    if (campaign.campaignType === 'Sponsored Displays') {
      sdCampaigns.push(campaign)
    }
  })

  return (
    <div className="account-health-reports">
      {isLoadingListCampaigns && <LoaderComponent />}
      <CampaignReport
        name="Auto Campaigns"
        isLoading={isLoadingListCampaigns}
        campaigns={autoCampaigns}
        prevData={listCampaignsPrevMonth}
        historyData={campaignsWithHistory}
        currencySign={currencySign}
        currencyRate={currencyRate}
        startDate={currentStartDate}
        endDate={currentEndDate}
      />
      <CampaignReport
        name="Manual Campaigns"
        isLoading={isLoadingListCampaigns}
        campaigns={manualCampaigns}
        prevData={listCampaignsPrevMonth}
        historyData={campaignsWithHistory}
        currencySign={currencySign}
        currencyRate={currencyRate}
        startDate={currentStartDate}
        endDate={currentEndDate}
      />
      <CampaignReport
        name="Campaigns with Product Targeting"
        isLoading={isLoadingListCampaigns}
        campaigns={targetCampaigns}
        prevData={listCampaignsPrevMonth}
        historyData={campaignsWithHistory}
        currencySign={currencySign}
        currencyRate={currencyRate}
        startDate={currentStartDate}
        endDate={currentEndDate}
      />
      <CampaignReport
        name="Sponsored Brand Campaigns"
        isLoading={isLoadingListCampaigns}
        campaigns={listCampaignsHSA || []}
        prevData={listCampaignsHSAPrevMonth}
        historyData={campaignsWithHistory}
        currencySign={currencySign}
        currencyRate={currencyRate}
        startDate={currentStartDate}
        endDate={currentEndDate}
      />
      <CampaignReport
        name="Sponsored Display Ads"
        isLoading={isLoadingListCampaigns}
        campaigns={sdCampaigns}
        prevData={listCampaignsPrevMonth}
        historyData={campaignsWithHistory}
        currencySign={currencySign}
        currencyRate={currencyRate}
        startDate={currentStartDate}
        endDate={currentEndDate}
      />
    </div>
  )
}

export default ReportsComponent
