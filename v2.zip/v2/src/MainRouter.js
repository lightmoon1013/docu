import React, { useEffect, useState } from 'react'
import { useDispatch, useStore } from 'react-redux'
import { Switch, Route, Redirect } from 'react-router-dom'

import Campaign from './pages/Campaign'
import BulkEditor from './pages/BulkEditor'
import AccountHealth from './pages/AccountHealth'
import Setting from './pages/Setting'
import Tutorial from './pages/Tutorial'
import Marketplace from './pages/Marketplace'
import ActivityLog from './pages/ActivityLog'
import Dashboard from './pages/Dashboard'
import CampaignDetailComponent from './components/CampaignDetailComponent'
import ProductDetailComponent from './components/ProductDetailComponent'

import * as Sentry from '@sentry/react'

import {
  appStart,
} from './redux/actions/header'

import {
  checkAuth,
} from './redux/actions/auth'

import { getIp } from './services/axios'

const MainRouter = () => {
  const dispatch = useDispatch()
  const store = useStore().getState()

  const { auth } = store
  const { isLoggedIn, user } = auth
  const [ipAddress, setIpAddress] = useState(null)

  useEffect(() => {
    (function loadHubSpot() {
      const d = document
      const s = d.createElement("script")

      s.src="https://js.hs-scripts.com/5728104.js"
      s.async = true
      d.getElementsByTagName("body")[0].appendChild(s)
    })()
  })

  useEffect(() => {
    const chatElement = document.getElementById('hubspot-messages-iframe-container')
    if (chatElement) {
      chatElement.style.setProperty('right', '5px', 'important' )
    }
  })
  useEffect(() => {
    dispatch(appStart())
    getIp().then(res => {
      setIpAddress(res.data.ipAddress)
    })
  }, []) // eslint-disable-line

  useEffect(() => {
    if (isLoggedIn) {
      dispatch(checkAuth())
      window.smartlook('init', '2e22d7a05970a146f780514dd23f34cb2a3c6f3d');
      if (user && user.id) {
        window.smartlook('identify', user.id);

        if (ipAddress !== null) {
          Sentry.setUser({
            id: user.id,
            email: user.email,
            name: `${user.firstname} ${user.lastname}`,
            ip_address: ipAddress,
          })
        }
      }
    }
  }, [isLoggedIn, user, dispatch, ipAddress])

  return (
    <div className="main">
      <Switch>
        <Redirect
          from="/"
          to='/login'
          exact
        />
        <Route
          path='/dashboard'
          component={Dashboard}
        />
        <Route
          path='/campaigns'
          component={Campaign}
        />
        <Route
          path='/bulk-engine'
          component={BulkEditor}
        />
        <Route
          path='/account-health'
          component={AccountHealth}
        />
        <Route
          path='/settings'
          component={Setting}
        />
        <Route
          path='/tutorial'
          component={Tutorial}
        />
        <Route
          path='/marketplace'
          component={Marketplace}
        />
        <Route
          path='/activity-log'
          component={ActivityLog}
        />
        <Route
          path="/campaign/:id/:campaignType"
          component={CampaignDetailComponent}
          exact
        />
        <Route
          path="/product/:id/:sku"
          component={ProductDetailComponent}
          exact
        />
      </Switch>
    </div>
  )
}

export default MainRouter
