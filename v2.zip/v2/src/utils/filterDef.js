/** Define filter fields for various pages */

export const matchTypes = [
  { value: '', label: 'All' },
  { value: 'broad', label: 'Broad' },
  { value: 'phrase', label: 'Phrase' },
  { value: 'exact', label: 'Exact' },
]

export const STATE_OPTION_ENABLED = { value: 'enabled', label: 'Active Only' }

export const statuses = [
  { value: '', label: 'All' },
  { value: ['enabled', 'paused'], label: 'Active & Paused' },
  STATE_OPTION_ENABLED,
  { value: 'paused', label: 'Paused Only' },
  { value: 'archived', label: 'Archived' },
]

export const keywordStatuses = [
  { value: '', label: 'Active & Paused' },
  { value: 'enabled', label: 'Active Only' },
]

export const campaignTypes = [
  { value: '', label: 'All Ad Types' },
  { value: 'sponsored products', label: 'Sponsored Product' },
  { value: 'sponsored brands', label: 'Sponsored Brand' },
  { value: 'sponsored displays', label: 'Sponsored Display' },
  { value: 'sponsored brands video', label: 'Sponsored Brand Video' },
]

export const targetingTypes = [
  { value: '', label: 'All' },
  { value: 'auto', label: 'Automatic' },
  { value: 'manual', label: 'Manual' },
]

export const negativeMatchTypes = [
  { value: '', label: 'All' },
  { value: 'negativeexact', label: 'Negative Exact' },
  { value: 'negativephrase', label: 'Negative Phrase' },
]

const campaignDetailSku = [
  { key: 'orders', label: 'Orders' },
  { key: 'cost', label: 'Spend' },
  { key: 'clicks', label: 'Clicks' },
  { key: 'impressions', label: 'Impressions' },
  { key: 'ctr', label: 'CTR %' },
  { key: 'acos', label: 'ACoS %' },
  { key: 'cpc', label: 'Ave CPC' },
]

const campaignDetailBidKeyword = [
  { key: 'orders', label: 'Orders' },
  { key: 'cost', label: 'Spend' },
  { key: 'clicks', label: 'Clicks' },
  { key: 'impressions', label: 'Impressions' },
  { key: 'ctr', label: 'CTR %' },
  { key: 'acos', label: 'ACoS %' },
  { key: 'cpc', label: 'Ave CPC' },
  { key: 'conversion', label: 'Conversion' },
]

const campaignDetailBidTarget = [
  { key: 'orders', label: 'Orders' },
  { key: 'cost', label: 'Spend' },
  { key: 'clicks', label: 'Clicks' },
  { key: 'impressions', label: 'Impressions' },
  { key: 'ctr', label: 'CTR %' },
  { key: 'acos', label: 'ACoS %' },
  { key: 'cpc', label: 'Ave CPC' },
  { key: 'conversion', label: 'Conversion' },
]

const campaignDetailSt = [
  { key: 'orders', label: 'Orders' },
  { key: 'cost', label: 'Spend' },
  { key: 'clicks', label: 'Clicks' },
  { key: 'impressions', label: 'Impressions' },
  { key: 'ctr', label: 'CTR %' },
  { key: 'acos', label: 'ACoS %' },
]

const campaignDetailKeywordCleaner = [
  { key: 'orders', label: 'Orders' },
  { key: 'cost', label: 'Spend' },
  { key: 'clicks', label: 'Clicks' },
  { key: 'impressions', label: 'Impressions' },
  { key: 'acos', label: 'ACoS %' },
  { key: 'revenue', label: 'Sales' },
  { key: 'cpc', label: 'Ave CPC' },
]

const campaignDetailNegative = [
  { key: 'cost', label: 'Spend' },
  { key: 'clicks', label: 'Clicks' },
  { key: 'impressions', label: 'Impressions' },
  { key: 'ctr', label: 'CTR %' },
]

const campaignDetailPlacement = [
  { key: 'orders', label: 'Orders' },
  { key: 'cost', label: 'Spend' },
  { key: 'clicks', label: 'Clicks' },
  { key: 'impressions', label: 'Impressions' },
  { key: 'ctr', label: 'CTR %' },
  { key: 'acos', label: 'ACoS %' },
  { key: 'cpc', label: 'Ave CPC' },
]

const campaignTable = [
  { key: 'targeting_type', label: 'Targeting', type: 'select', options: targetingTypes },
  { key: 'state', label: 'Campaign Status', type: 'select', options: statuses },
  { key: 'acos', label: 'ACoS %' },
  { key: 'daily_budget', label: 'Daily Budget' },
  { key: 'orders', label: 'Orders' },
  { key: 'cost', label: 'Spend' },
  { key: 'impressions', label: 'Impressions' },
  { key: 'clicks', label: 'Clicks' },
]

const productTable = [
  { key: 'cog', label: 'Cost Of Goods' },
  { key: 'break_even_cpa', label: 'Break Even CPA' },
  { key: 'orders', label: 'Orders' },
  { key: 'cost', label: 'Spend' },
  { key: 'total_clicks', label: 'Clicks' },
  { key: 'ctr', label: 'CTR %' },
  { key: 'acos', label: 'ACoS %' },
]

const portfolioTable = [
  { key: 'daily_budget', label: 'Daily Budget' },
  { key: 'impressions', label: 'Impressions' },
  { key: 'clicks', label: 'Clicks' },
  { key: 'ctr', label: 'CTR %' },
  { key: 'cost', label: 'Spend' },
  { key: 'cpc', label: 'Ave CPC' },
  { key: 'orders', label: 'Orders' },
  { key: 'revenue', label: 'Sales' },
  { key: 'acos', label: 'ACoS %' },
]

const productDetailKeyword = [
  { key: 'revenue', label: 'Gross Revenue' },
  { key: 'cost', label: 'Spend' },
  { key: 'impressions', label: 'Impressions' },
  { key: 'clicks', label: 'Clicks' },
  { key: 'cpc', label: 'Ave CPC' },
  { key: 'orders', label: 'Orders' },
  { key: 'conversionrate', label: 'Conversion' },
]

const productCampaignTable = [
  { key: 'campaignType', label: 'Ad Type', type: 'select', options: campaignTypes },
  { key: 'targeting_type', label: 'Targeting', type: 'select', options: targetingTypes },
  { key: 'state', label: 'Campaign Status', type: 'select', options: statuses },
  { key: 'acos', label: 'ACoS %' },
  { key: 'daily_budget', label: 'Daily Budget' },
  { key: 'orders', label: 'Orders' },
  { key: 'cost', label: 'Spend' },
  { key: 'impressions', label: 'Impressions' },
  { key: 'clicks', label: 'Clicks' },
]

const targetSearchKeyword = [
  { key: 'acos', label: 'ACoS %' },
  { key: 'orders', label: 'Orders' },
  { key: 'cost', label: 'Spend' },
  { key: 'clicks', label: 'Clicks' },
  { key: 'impressions', label: 'Impressions' },
  { key: 'ctr', label: 'CTR %' },
  { key: 'cpc', label: 'Ave CPC' },
  { key: 'conversion', label: 'Conversion' },
]

const targetSearchTarget = [
  { key: 'acos', label: 'ACoS %' },
  { key: 'orders', label: 'Orders' },
  { key: 'cost', label: 'Spend' },
  { key: 'clicks', label: 'Clicks' },
  { key: 'impressions', label: 'Impressions' },
  { key: 'ctr', label: 'CTR %' },
  { key: 'cpc', label: 'Ave CPC' },
  { key: 'conversion', label: 'Conversion' },
]

const targetSearchST = [
  { key: 'acos', label: 'ACoS %' },
  { key: 'orders', label: 'Orders' },
  { key: 'cost', label: 'Spend' },
  { key: 'clicks', label: 'Clicks' },
  { key: 'impressions', label: 'Impressions' },
  { key: 'ctr', label: 'CTR %' },
  { key: 'cpc', label: 'Ave CPC' },
  { key: 'conversion', label: 'Conversion' },
]

const dupKeyword = [
  { key: 'campaignType', label: 'Ad Type', type: 'select', options: campaignTypes, customProcessing: true },
  { key: 'acos', label: 'ACoS %' },
  { key: 'orders', label: 'Orders' },
  { key: 'cost', label: 'Spend' },
  { key: 'clicks', label: 'Clicks' },
  { key: 'impressions', label: 'Impressions' },
  { key: 'ctr', label: 'CTR %' },
  { key: 'cpc', label: 'Ave CPC' },
  { key: 'conversion', label: 'Conversion' },
]

const dupTarget = [
  { key: 'campaignType', label: 'Ad Type', type: 'select', options: campaignTypes, customProcessing: true },
  { key: 'acos', label: 'ACoS %' },
  { key: 'orders', label: 'Orders' },
  { key: 'cost', label: 'Spend' },
  { key: 'clicks', label: 'Clicks' },
  { key: 'impressions', label: 'Impressions' },
  { key: 'ctr', label: 'CTR %' },
  { key: 'cpc', label: 'Ave CPC' },
  { key: 'conversion', label: 'Conversion' },
]

const stEx = [
  { key: 'acos', label: 'ACoS Target Zone, %' },
  { key: 'orders', label: 'Orders' },
  { key: 'cost', label: 'Spend' },
  { key: 'clicks', label: 'Clicks' },
  { key: 'impressions', label: 'Impressions' },
  { key: 'ctr', label: 'CTR %' },
]

const ptExAsin = [
  { key: 'acos', label: 'ACoS Target Zone, %' },
  { key: 'orders', label: 'Orders' },
  { key: 'cost', label: 'Spend' },
  { key: 'clicks', label: 'Clicks' },
  { key: 'impressions', label: 'Impressions' },
  { key: 'ctr', label: 'CTR %' },
]

const ptExCategory = [
  { key: 'acos', label: 'ACoS Target Zone, %' },
  { key: 'orders', label: 'Orders' },
  { key: 'cost', label: 'Spend' },
  { key: 'clicks', label: 'Clicks' },
  { key: 'impressions', label: 'Impressions' },
  { key: 'ctr', label: 'CTR %' },
]

const bulkSkuOp = [
  { key: 'target_acos', label: 'Above Target ACoS', type: 'target_acos' },
  { key: 'acos', label: 'ACoS %', depends: 'target_acos', dependValue: false },
  { key: 'orders', label: 'Orders' },
  { key: 'cost', label: 'Spend' },
  { key: 'clicks', label: 'Clicks' },
  { key: 'impressions', label: 'Impressions' },
  { key: 'ctr', label: 'CTR %' },
  { key: 'cpc', label: 'Ave CPC' },
  { key: 'conversion', label: 'Conversion' },
]

const bulkTargetOp = [
  { key: 'target_acos', label: 'Above Target ACoS', type: 'target_acos' },
  { key: 'acos', label: 'ACoS %', depends: 'target_acos', dependValue: false },
  { key: 'orders', label: 'Orders' },
  { key: 'cost', label: 'Spend' },
  { key: 'clicks', label: 'Clicks' },
  { key: 'impressions', label: 'Impressions' },
  { key: 'ctr', label: 'CTR %' },
  { key: 'cpc', label: 'Ave CPC' },
  { key: 'conversion', label: 'Conversion' },
]

const bulkStOp = [
  { key: 'target_acos', label: 'Above Target ACoS', type: 'target_acos' },
  { key: 'acos', label: 'ACoS %', depends: 'target_acos', dependValue: false },
  { key: 'orders', label: 'Orders' },
  { key: 'cost', label: 'Spend' },
  { key: 'clicks', label: 'Clicks' },
  { key: 'impressions', label: 'Impressions' },
  { key: 'ctr', label: 'CTR %' },
  { key: 'cpc', label: 'Ave CPC' },
  { key: 'conversion', label: 'Conversion' },
]

const bulkAdvancedOp = [
  { key: 'acos', label: 'ACoS %' },
  { key: 'orders', label: 'Orders' },
  { key: 'cost', label: 'Spend' },
  { key: 'clicks', label: 'Clicks' },
  { key: 'impressions', label: 'Impressions' },
  { key: 'ctr', label: 'CTR %' },
  { key: 'cpc', label: 'Ave CPC' },
  { key: 'conversion', label: 'Conversion' },
]

export default {
  campaignDetailSku,
  campaignDetailBidKeyword,
  campaignDetailBidTarget,
  campaignDetailSt,
  campaignDetailKeywordCleaner,
  campaignDetailNegative,
  campaignDetailPlacement,
  campaignTable,
  productTable,
  portfolioTable,
  productDetailKeyword,
  productCampaignTable,
  targetSearchKeyword,
  targetSearchTarget,
  targetSearchST,
  dupKeyword,
  dupTarget,
  stEx,
  ptExAsin,
  ptExCategory,
  bulkSkuOp,
  bulkTargetOp,
  bulkStOp,
  bulkAdvancedOp,
}
