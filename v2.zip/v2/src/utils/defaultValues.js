import React from 'react'
import { Tooltip, Whisper } from 'rsuite'

import { ReactComponent as InfoSvg } from '../assets/svg/info.svg'

export const EXTENSION_ID = 'cclbjbpflgdponoegbmgkcicpjjdikci'
export const MIN_BID_PRICE = 0.02

export const campaignColumnList = [
  { key: 'campaign', default: true, fixed: true, label: 'Campaign' },
  { key: 'target_acos', default: true, label: 'ACoS Target %' },
  { key: 'daily_budget', default: true, label: 'Daily Budget' },
  { key: 'acos', default: true, label: 'ACoS %', direct: true },
  { key: 'impressions', default: true, label: 'Imp.' },
  { key: 'clicks', default: true, label: 'Clicks' },
  { key: 'ctr', default: true, label: 'CTR %' },
  { key: 'cost', default: true, label: 'Spend' },
  { key: 'cpc', default: true, label: 'Ave CPC', direct: true },
  { key: 'orders', default: true, label: 'Orders' },
  { key: 'revenue', default: true, label: 'Sales' },
  { key: 'roas', label: 'Return on Ad Spend', name: 'ROAS' },
  { key: 'conversion', label: 'Conversion Rate', name: 'Conv %' },
  { key: 'ntb_orders', label: 'NTB Orders' },
  { key: 'ntb_orders_percent', label: 'NTB Orders %' },
  { key: 'ntb_sales', label: 'NTB Sales' },
  { key: 'ntb_sales_percent', label: 'NTB Sales %' },
  {
    key: 'viewable_impressions',
    label: 'Viewable Imp.',
    name: (
      <span>
        Viewable Imp.
        <Whisper placement="left" trigger="hover" speaker={(
          <Tooltip>
            <p>
              Estimated number of impressions that meet the Media
              Rating Council's (MRC) standard for viewability.
            </p>
          </Tooltip>
        )}>
          <InfoSvg />
        </Whisper>
      </span>
    ),
  },
]

export const productColumnList = [
  { key: 'product', default: true, fixed: true, label: 'Product', },
  { key: 'cog', default: true, label: 'Cost of Goods' },
  { key: 'profit_margin', default: true, label: 'Profit Margin' },
  { key: 'break_even_cpa', default: true, label: 'Break Even CPA' },
  { key: 'clicks_order_ratio', default: true, label: 'Click/Order' },
  { key: 'max_cpc', default: true, label: 'Max CPC' },
  { key: 'weeklyorders', default: true, label: '7 Day Avg' },
  { key: 'monthlyorders', default: true, label: '30 Day Avg' },
  { key: 'twomonthlyorders', default: true, label: '60 Day Avg' },
  { key: 'active_campaigns', default: true, label: 'Active Campaigns' },
  { key: 'revenue', label: 'Sales' },
  { key: 'sales', label: 'Organic/PPC Sales' },
  { key: 'sales_ratio', label: 'Organic/PPC ratio' },
  { key: 'ad_spend_margin', label: 'Ad Spend Margin Impact' },
  { key: 'total_clicks', label: 'Clicks' },
  { key: 'ctr', label: 'CTR %' },
  { key: 'cost', label: 'Spend' },
  { key: 'orders', label: 'Orders' },
  { key: 'acos', label: 'ACoS %' },
]

export const portfolioColumnList = [
  { key: 'portfolio', default: true, fixed: true, label: 'Portfolio' },
  { key: 'daily_budget', default: true, label: 'Daily Budget', name: 'Daily Budget' },
  { key: 'impressions', default: true, label: 'Imp.', name: 'Imp.' },
  { key: 'clicks', default: true, label: 'Clicks', name: 'Clicks'  },
  { key: 'ctr', default: true, label: 'CTR %', name: 'CTR %' },
  { key: 'cost', default: true, label: 'Spend', name: 'Spend' },
  { key: 'cpc', default: true, label: 'Ave CPC', name: 'Ave CPC' },
  { key: 'orders', default: true, label: 'Orders', name: 'Orders' },
  { key: 'revenue', default: true, label: 'Sales', name: 'Sales' },
  { key: 'acos', default: true, label: 'ACoS %', name: 'ACoS %' },
  { key: 'roas', default: true, label: 'ROAS', name: 'ROAS' },
  { key: 'ntb_orders', label: 'NTB Orders', name: 'NTB Orders' },
  { key: 'ntb_orders_percent', label: 'NTB Orders %', name: 'NTB Orders %' },
  { key: 'ntb_sales', label: 'NTB Sales', name: 'NTB Sales' },
  { key: 'ntb_sales_percent', label: 'NTB Sales %', name: 'NTB Sales %' },
]

export const productCampaignColumnList = [
  { key: 'campaign', default: true, fixed: true, label: 'Campaign' },
  { key: 'impressions', default: true, label: 'Imp.' },
  { key: 'clicks', default: true, label: 'Clicks'  },
  { key: 'ctr', default: true, label: 'CTR %' },
  { key: 'cost', default: true, label: 'Spend' },
  { key: 'cpc', default: true, label: 'Ave CPC' },
  { key: 'orders', default: true, label: 'Orders',  },
  { key: 'revenue', default: true, label: 'Sales' },
  { key: 'acos', default: true, label: 'ACoS %' },
  { key: 'roas', label: 'Return on Ad Spend' },
  { key: 'conversion', label: 'Conversion Rate' },
  { key: 'ntb_orders', label: 'NTB Orders',  },
  { key: 'ntb_orders_percent', label: 'NTB Orders %' },
  { key: 'ntb_sales', label: 'NTB Sales' },
  { key: 'ntb_sales_percent', label: 'NTB Sales %' },
]

// Names are for tables, and labels are for column editor.
export const bulkNTBColumnList = [
  { key: 'orders', label: 'Orders', name: 'Orders' },
  { key: 'acos', label: 'ACoS %', name: 'ACoS %' },
  { key: 'revenue', label: 'Sales', name: 'Sales' },
  { key: 'cost', label: 'Spend', name: 'Spend' },
  { key: 'impressions', label: 'Impressions', name: 'Imp.' },
  { key: 'clicks', label: 'Clicks', name: 'Clicks' },
  { key: 'ctr', label: 'CTR %', name: 'CTR %' },
  { key: 'cpc', label: 'Ave CPC', name: 'Ave CPC' },
  { key: 'conversion', label: 'Conversion Rate %', name: 'Conv %' },
  { key: 'ntb_orders', label: 'NTB Orders', name: 'NTB Orders' },
  { key: 'ntb_orders_percent', label: 'NTB Orders %', name: 'NTB Orders %' },
  { key: 'ntb_sales', label: 'NTB Sales', name: 'NTB Sales', },
  { key: 'ntb_sales_percent', label: 'NTB Sales %', name: 'NTB Sales %', },
  {
    key: 'viewable_impressions',
    label: 'Viewable Imp.',
    name: (
      <span>
        Viewable Imp.
        <Whisper placement="left" trigger="hover" speaker={(
          <Tooltip>
            <p>
              Estimated number of impressions that meet the Media
              Rating Council's (MRC) standard for viewability.
            </p>
          </Tooltip>
        )}>
          <InfoSvg />
        </Whisper>
      </span>
    ),
  },
]

export const bulkBidColumnList = [
  { key: 'cpc', label: 'Ave CPC', name: 'Ave CPC' },
  { key: 'orders', label: 'Orders', name: 'Orders' },
  { key: 'acos', label: 'ACoS %', name: 'ACoS %' },
  { key: 'revenue', label: 'Sales', name: 'Sales' },
  { key: 'cost', label: 'Spend', name: 'Spend' },
  { key: 'impressions', label: 'Impressions', name: 'Imp.' },
  { key: 'clicks', label: 'Clicks', name: 'Clicks' },
  { key: 'ctr', label: 'CTR %', name: 'CTR %' },
  { key: 'conversion', label: 'Conversion Rate %', name: 'Conv %' },
  { key: 'ntb_orders', label: 'NTB Orders', name: 'NTB Orders' },
  { key: 'ntb_orders_percent', label: 'NTB Orders %', name: 'NTB Orders %' },
  { key: 'ntb_sales', label: 'NTB Sales', name: 'NTB Sales', },
  { key: 'ntb_sales_percent', label: 'NTB Sales %', name: 'NTB Sales %', },
  {
    key: 'viewable_impressions',
    label: 'Viewable Imp.',
    name: (
      <span>
        Viewable Imp.
        <Whisper placement="left" trigger="hover" speaker={(
          <Tooltip>
            <p>
              Estimated number of impressions that meet the Media
              Rating Council's (MRC) standard for viewability.
            </p>
          </Tooltip>
        )}>
          <InfoSvg />
        </Whisper>
      </span>
    ),
  },
]

export const bulkSKUColumnList = [
  { key: 'orders', label: 'Orders', name: 'Orders' },
  { key: 'acos', label: 'ACoS %', name: 'ACoS %' },
  { key: 'revenue', label: 'Sales', name: 'Sales' },
  { key: 'cost', label: 'Spend', name: 'Spend' },
  { key: 'impressions', label: 'Impressions', name: 'Imp.' },
  { key: 'clicks', label: 'Clicks', name: 'Clicks' },
  { key: 'ctr', label: 'CTR %', name: 'CTR %' },
  { key: 'cpc', label: 'Ave CPC', name: 'Ave CPC' },
  { key: 'conversion', label: 'Conversion Rate %', name: 'Conv %' },
  { key: 'ntb_orders', label: 'NTB Orders', name: 'NTB Orders' },
  { key: 'ntb_orders_percent', label: 'NTB Orders %', name: 'NTB Orders %' },
  { key: 'ntb_sales', label: 'NTB Sales', name: 'NTB Sales', },
  { key: 'ntb_sales_percent', label: 'NTB Sales %', name: 'NTB Sales %', },
]

export const bulkSTColumnList = [
  { key: 'orders', label: 'Orders', name: 'Orders' },
  { key: 'acos', label: 'ACoS %', name: 'ACoS %' },
  { key: 'revenue', label: 'Sales', name: 'Sales' },
  { key: 'cost', label: 'Spend', name: 'Spend' },
  { key: 'impressions', label: 'Impressions', name: 'Imp.' },
  { key: 'clicks', label: 'Clicks', name: 'Clicks' },
  { key: 'ctr', label: 'CTR %', name: 'CTR %' },
  { key: 'cpc', label: 'Ave CPC', name: 'Ave CPC' },
  { key: 'conversion', label: 'Conversion Rate %', name: 'Conv %' },
  { key: 'st_impr_rank', label: 'Search Term Impression Rank', name: 'ST Imp. Rank' },
  { key: 'st_impr_share', label: 'Search Term Impression Share %', name: 'ST Imp. Share' },
  {
    key: 'viewable_impressions',
    label: 'Viewable Imp.',
    name: (
      <span>
        Viewable Imp.
        <Whisper placement="left" trigger="hover" speaker={(
          <Tooltip>
            <p>
              Estimated number of impressions that meet the Media
              Rating Council's (MRC) standard for viewability.
            </p>
          </Tooltip>
        )}>
          <InfoSvg />
        </Whisper>
      </span>
    ),
  },
]

export const currencyList = [
  {
    text: 'USD - US Dollar',
    sign: '$',
    flag: 'flag-us',
    code: 'us',
    currencyCode: 'USD',
  },
  {
    text: 'EUR - Euro',
    sign: '€',
    flag: 'flag-eu',
    code: 'eu',
    currencyCode: 'EUR',
  },
  {
    text: 'GBP - British Pound',
    sign: '£',
    flag: 'flag-gb',
    code: 'gb',
    currencyCode: 'GBP',
  },
  {
    text: 'INR - Indian Rupee',
    sign: '₹',
    flag: 'flag-in',
    code: 'in',
    currencyCode: 'INR',
  },
  {
    text: 'AUD - Australian Dollar',
    sign: '$',
    flag: 'flag-au',
    code: 'au',
    currencyCode: 'AUD',
  },
  {
    text: 'CAD - Canadian Dollar',
    sign: '$',
    flag: 'flag-ca',
    code: 'ca',
    currencyCode: 'CAD',
  },
  {
    text: 'JPY - Japanese Yen',
    sign: '¥',
    flag: 'flag-jp',
    code: 'jp',
    currencyCode: 'JPY',
  },
  {
    text: 'MXN - Mexican Peso',
    sign: '$',
    flag: 'flag-mx',
    code: 'mx',
    currencyCode: 'MXN',
  },
  {
    text: 'AED - Emirati Dirham',
    sign: 'د.إ',
    flag: 'flag-ae',
    code: 'ae',
    currencyCode: 'AED',
  },
  {
    text: 'SGD - Singapore Dollar',
    sign: '$',
    flag: 'flag-sg',
    code: 'sg',
    currencyCode: 'SGD',
  },
]

// List of regions supported by Amazon.
export const regionList = [
  { label: 'North America', value: 'na' },
  { label: 'Europe', value: 'eu' },
  { label: 'Far East', value: 'fe' },
]

// Key to sessionStorage to keep the app state.
export const STORAGE_KEY_STATE = 'sp_state'

// Key to sessionStorage to keep the selected region.
export const STORAGE_KEY_REGION = 'signup_region'

// List of seller central URLs for each region.
export const sellerCentralUrls = {
  na: 'https://sellercentral.amazon.com',
  eu: 'https://sellercentral-europe.amazon.com',
  fe: 'https://sellercentral.amazon.com.au',
}

// A list of log types for filtering on the activity log page
// and campaign details/log table.
export const logTypeOptions = [
  { value: '', label: '- Select All -' },
  { value: 'ap_kw_basic', label: 'Target bid optimization' },
  { value: 'ap_kw_adv', label: 'Target bid optimization/Advanced settings' },
  { value: 'ap_nta', label: 'Negative target automation' },
  { value: 'ap_npt', label: 'Negative product targeting' },
  { value: 'ap_kw_ex', label: 'Target bid expansion' },
  { value: 'ap_st_ex', label: 'Search term expansion' },
  { value: 'ap_pt_ex', label: 'Product targeting expansion' },
  { value: 'out_of_budget', label: 'Out of budget' },
  { value: 'ap_dayparting', label: 'Dayparting on/off' },
]

export const REVERTABLE_LOG_TYPES = [
  'campaign_placement_apply',
  'campaign_placement_update',
]

export const campaignTypeMap = {
  'Sponsored Brands': 'Sponsored Brand',
  'Sponsored Products': 'Sponsored Product',
  'Sponsored Displays': 'Sponsored Display',
  'Sponsored Brands Video': 'Sponsored Brand Video'
}

export const ADJUST_BID_RAISE = 'raiseBid'
export const ADJUST_BID_LOWER = 'lowerBid'
export const ADJUST_BID_CPC = 'cpc'

export const adjustBidOptions = [
  { value: 'setBid', label: 'Set bid to ($)' },
  { value: ADJUST_BID_RAISE, label: 'Raise bid by (%)' },
  { value: ADJUST_BID_LOWER, label: 'Lower bid by (%)' },
  { value: ADJUST_BID_CPC, label: 'Change to avg CPC ($)' },
]
